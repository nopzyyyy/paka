"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [6976],
  {
    36609: function (e, t, n) {
      n.d(t, {
        $: function () {
          return tA;
        },
        A: function () {
          return tU;
        },
        B: function () {
          return nC;
        },
        C: function () {
          return tI;
        },
        D: function () {
          return tO;
        },
        E: function () {
          return nF;
        },
        F: function () {
          return nv;
        },
        G: function () {
          return tV;
        },
        H: function () {
          return tE;
        },
        I: function () {
          return t$;
        },
        J: function () {
          return nV;
        },
        K: function () {
          return nP;
        },
        L: function () {
          return tq;
        },
        M: function () {
          return nW;
        },
        N: function () {
          return tt;
        },
        O: function () {
          return tN;
        },
        P: function () {
          return nz;
        },
        Q: function () {
          return tL;
        },
        R: function () {
          return td;
        },
        S: function () {
          return tS;
        },
        T: function () {
          return tK;
        },
        U: function () {
          return tT;
        },
        V: function () {
          return tf;
        },
        W: function () {
          return al;
        },
        X: function () {
          return t0;
        },
        Y: function () {
          return tm;
        },
        Z: function () {
          return tx;
        },
        _: function () {
          return tw;
        },
        a: function () {
          return tD;
        },
        a$: function () {
          return pE;
        },
        a0: function () {
          return tj;
        },
        a1: function () {
          return tz;
        },
        a2: function () {
          return ty;
        },
        a3: function () {
          return tv;
        },
        a4: function () {
          return tb;
        },
        a5: function () {
          return tC;
        },
        a6: function () {
          return tu;
        },
        a7: function () {
          return tp;
        },
        a8: function () {
          return tk;
        },
        a9: function () {
          return np;
        },
        aA: function () {
          return aw;
        },
        aB: function () {
          return nn;
        },
        aC: function () {
          return nX;
        },
        aD: function () {
          return iW;
        },
        aE: function () {
          return aU;
        },
        aF: function () {
          return dC;
        },
        aG: function () {
          return dj;
        },
        aH: function () {
          return uI;
        },
        aI: function () {
          return ul;
        },
        aJ: function () {
          return ur;
        },
        aK: function () {
          return ua;
        },
        aL: function () {
          return uo;
        },
        aM: function () {
          return l4;
        },
        aN: function () {
          return uv;
        },
        aO: function () {
          return iM;
        },
        aP: function () {
          return sM;
        },
        aQ: function () {
          return th;
        },
        aR: function () {
          return o4;
        },
        aS: function () {
          return s_;
        },
        aT: function () {
          return sS;
        },
        aU: function () {
          return tg;
        },
        aV: function () {
          return lQ;
        },
        aW: function () {
          return uN;
        },
        aX: function () {
          return u_;
        },
        aY: function () {
          return sG;
        },
        aZ: function () {
          return p7;
        },
        a_: function () {
          return rY;
        },
        aa: function () {
          return am;
        },
        ab: function () {
          return rS;
        },
        ac: function () {
          return aT;
        },
        ad: function () {
          return aA;
        },
        ae: function () {
          return aL;
        },
        af: function () {
          return iA;
        },
        ag: function () {
          return ik;
        },
        ah: function () {
          return iS;
        },
        ai: function () {
          return ix;
        },
        aj: function () {
          return a4;
        },
        ak: function () {
          return iI;
        },
        al: function () {
          return aP;
        },
        am: function () {
          return a$;
        },
        an: function () {
          return ar;
        },
        ao: function () {
          return aY;
        },
        ap: function () {
          return iL;
        },
        aq: function () {
          return iz;
        },
        ar: function () {
          return iF;
        },
        as: function () {
          return ap;
        },
        at: function () {
          return r3;
        },
        au: function () {
          return aR;
        },
        av: function () {
          return r4;
        },
        aw: function () {
          return aS;
        },
        ax: function () {
          return tM;
        },
        ay: function () {
          return iN;
        },
        az: function () {
          return ai;
        },
        b: function () {
          return tH;
        },
        b$: function () {
          return pg;
        },
        b0: function () {
          return u4;
        },
        b1: function () {
          return pC;
        },
        b2: function () {
          return sg;
        },
        b3: function () {
          return pD;
        },
        b4: function () {
          return dg;
        },
        b5: function () {
          return sh;
        },
        b6: function () {
          return iP;
        },
        b7: function () {
          return iD;
        },
        b8: function () {
          return lR;
        },
        b9: function () {
          return lW;
        },
        bA: function () {
          return lJ;
        },
        bB: function () {
          return nI;
        },
        bC: function () {
          return t2;
        },
        bD: function () {
          return dv;
        },
        bE: function () {
          return tJ;
        },
        bF: function () {
          return pY;
        },
        bG: function () {
          return ag;
        },
        bH: function () {
          return iT;
        },
        bI: function () {
          return nu;
        },
        bJ: function () {
          return oH;
        },
        bK: function () {
          return au;
        },
        bL: function () {
          return pa;
        },
        bM: function () {
          return nf;
        },
        bN: function () {
          return no;
        },
        bO: function () {
          return ly;
        },
        bP: function () {
          return nQ;
        },
        bQ: function () {
          return nO;
        },
        bR: function () {
          return db;
        },
        bS: function () {
          return lM;
        },
        bT: function () {
          return nE;
        },
        bU: function () {
          return dc;
        },
        bV: function () {
          return p6;
        },
        bW: function () {
          return oU;
        },
        bX: function () {
          return pG;
        },
        bY: function () {
          return uE;
        },
        bZ: function () {
          return lz;
        },
        b_: function () {
          return uO;
        },
        ba: function () {
          return rX;
        },
        bb: function () {
          return lB;
        },
        bc: function () {
          return lO;
        },
        bd: function () {
          return lv;
        },
        be: function () {
          return lE;
        },
        bf: function () {
          return o6;
        },
        bg: function () {
          return tX;
        },
        bh: function () {
          return t7;
        },
        bi: function () {
          return sY;
        },
        bj: function () {
          return aJ;
        },
        bk: function () {
          return sJ;
        },
        bl: function () {
          return sK;
        },
        bm: function () {
          return lb;
        },
        bn: function () {
          return aa;
        },
        bo: function () {
          return lf;
        },
        bp: function () {
          return lm;
        },
        bq: function () {
          return ah;
        },
        br: function () {
          return ay;
        },
        bs: function () {
          return o0;
        },
        bt: function () {
          return o2;
        },
        bu: function () {
          return nh;
        },
        bv: function () {
          return nm;
        },
        bw: function () {
          return nA;
        },
        bx: function () {
          return ho;
        },
        by: function () {
          return p2;
        },
        bz: function () {
          return ui;
        },
        c: function () {
          return tP;
        },
        c2: function () {
          return tF;
        },
        d: function () {
          return tW;
        },
        d1: function () {
          return iY;
        },
        d2: function () {
          return iQ;
        },
        e: function () {
          return tG;
        },
        f: function () {
          return tY;
        },
        g: function () {
          return tR;
        },
        h: function () {
          return tZ;
        },
        i: function () {
          return tQ;
        },
        j: function () {
          return tB;
        },
        k: function () {
          return nk;
        },
        l: function () {
          return nb;
        },
        m: function () {
          return nL;
        },
        n: function () {
          return t6;
        },
        o: function () {
          return tc;
        },
        p: function () {
          return nl;
        },
        q: function () {
          return n_;
        },
        r: function () {
          return nD;
        },
        s: function () {
          return tn;
        },
        t: function () {
          return nr;
        },
        u: function () {
          return nR;
        },
        v: function () {
          return ni;
        },
        w: function () {
          return nU;
        },
        x: function () {
          return nG;
        },
        y: function () {
          return nM;
        },
        z: function () {
          return nY;
        },
      });
      var a = n(57437),
        r = n(74530),
        i = n(45355),
        o = n(62442),
        s = n(56224),
        l = n(4631),
        c = n(12741),
        d = n(5589),
        u = n(69806),
        p = n(97982),
        h = n(53711),
        g = n(78417),
        f = n(34822),
        m = n(82549),
        y = n(50178),
        w = n(21271),
        v = n(66538),
        x = n(1295),
        b = n(53589),
        C = n(2265),
        j = n(94818),
        k = n(54315),
        T = n(39169),
        A = n(18616),
        S = n(46943),
        I = n(49192),
        E = n(96760),
        N = n(79352),
        _ = n(45008),
        M = n(39803),
        F = n(16775),
        z = n(87364),
        L = n(21693),
        P = n(21273),
        D = n(29580),
        W = n(11571),
        R = n(39730),
        B = n(80459),
        U = n(52078),
        O = n(76384),
        H = n(30838),
        V = n(62238),
        $ = n(13631),
        Z = n(69442),
        q = n(54266),
        G = n(11207),
        Y = n(15286),
        Q = n(61773),
        K = n(15093),
        X = n(89459),
        J = n(65450),
        ee = n(79121),
        et = n(5733),
        en = n(22317),
        ea = n(58500),
        er = n(83234),
        ei = n(30361),
        eo = n(48594),
        es = n(52644),
        el = n(90091),
        ec = n(50006),
        ed = n(38822),
        eu = n(7405),
        ep = n(25016),
        eh = n(2487),
        eg = n(10375),
        ef = n(49863),
        em = n(33753),
        ey = n(29538),
        ew = n(96689),
        ev = n(95705),
        ex = n(34424),
        eb = n(25587),
        eC = n(31095),
        ej = n(10887),
        ek = n(39427),
        eT = n(5838),
        eA = n(67026),
        eS = n(83179),
        eI = n(50683),
        eE = n(54184),
        eN = n(4238),
        e_ = n(96888),
        eM = n(41379),
        eF = n(31706),
        ez = n(19367),
        eL = n(91543),
        eP = n(11226),
        eD = n(70432),
        eW = n(84209),
        eR = n(57548),
        eB = n(36108),
        eU = n(52466),
        eO = n(32938),
        eH = n(74020),
        eV = n(38799),
        e$ = n(84164),
        eZ = n(91122),
        eq = n(2864),
        eG = n(67805),
        eY = n(75298),
        eQ = n(11953),
        eK = n(59115),
        eX = n(40558),
        eJ = n(51733),
        e0 = n(84753),
        e1 = n(20387),
        e2 = n(67057),
        e3 = n(15526),
        e4 = n(17082),
        e5 = n(49186),
        e6 = n(20787),
        e8 = n(35450),
        e7 = n(14228),
        e9 = n(91183);
      class te {
        get(e) {
          let t = localStorage.getItem(e);
          return null === t ? void 0 : JSON.parse(t);
        }
        put(e, t) {
          void 0 !== t
            ? localStorage.setItem(e, JSON.stringify(t))
            : this.del(e);
        }
        del(e) {
          localStorage.removeItem(e);
        }
        getKeys() {
          return Object.entries(localStorage).map(([e]) => e);
        }
      }
      function tt() {
        try {
          let e = "privy:__session_storage__test",
            t = new te();
          return t.put(e, "blobby"), t.del(e), !0;
        } catch (e) {
          return !1;
        }
      }
      var tn =
        "undefined" != typeof window && window.localStorage
          ? new te()
          : new (class {
              get(e) {
                return this._cache[e];
              }
              put(e, t) {
                void 0 !== t ? (this._cache[e] = t) : this.del(e);
              }
              del(e) {
                delete this._cache[e];
              }
              getKeys() {
                return Object.keys(this._cache);
              }
              constructor() {
                this._cache = {};
              }
            })();
      function ta(e) {
        return {
          name: e.metadata?.shortName || e.name || "",
          universalLink: e.mobile.universal,
          deepLink: e.mobile.native,
        };
      }
      function tr(e, t) {
        let n = ta(t);
        if (n.universalLink) return tl(n.universalLink, e);
      }
      let ti = "WALLETCONNECT_DEEPLINK_CHOICE";
      function to(e) {
        return e.startsWith("http://") || e.startsWith("https://");
      }
      function ts(e, t) {
        if (to(e)) return tl(e, t);
        let n = e;
        return (
          n.includes("://") ||
            ((n = e.replaceAll("/", "").replaceAll(":", "")), (n = `${n}://`)),
          n.endsWith("/") || (n = `${n}/`),
          { redirect: `${n}wc?uri=${encodeURIComponent(t)}`, href: n }
        );
      }
      function tl(e, t) {
        if (!to(e)) return ts(e, t);
        let n = e;
        return (
          n.endsWith("/") || (n = `${n}/`),
          { redirect: `${n}wc?uri=${encodeURIComponent(t)}`, href: n }
        );
      }
      function tc(e, t) {
        window.open(e, t, "noreferrer noopener");
      }
      class td {
        execute(e) {
          return (
            null === this.promise &&
              (this.promise = (async () => {
                try {
                  return await this.fn(e);
                } finally {
                  this.promise = null;
                }
              })()),
            this.promise
          );
        }
        constructor(e) {
          (this.promise = null), (this.fn = e);
        }
      }
      let tu = "https://auth.privy.io",
        tp = 2e4,
        th = 1400,
        tg = 2500,
        tf = "3.3.0",
        tm = "privy:token",
        ty = "privy-token",
        tw = "privy:refresh_token",
        tv = "privy-refresh-token",
        tx = "privy:pat",
        tb = "privy:id_token",
        tC = "privy-id-token",
        tj = "privy-session",
        tk = "privy:caid",
        tT = (e) => `privy:guest:${e}`,
        tA = (e) => `privy:cross-app:${e}`,
        tS = "privy:state_code",
        tI = "privy:code_verifier",
        tE = "privy:headless_oauth",
        tN = "privy:oauth_disable_signup",
        t_ = (e) => `privy:wallet:${e}`,
        tM = "privy:connections",
        tF = 3e4,
        tz = "deprecated";
      function tL(e) {
        return crypto.getRandomValues(new Uint8Array(e));
      }
      function tP() {
        return eM.c(tL(36));
      }
      function tD() {
        return tP();
      }
      async function tW(e, t = "S256") {
        if ("S256" != t) return e;
        {
          let t = await (async function (e) {
            let t = new TextEncoder().encode(e);
            return new Uint8Array(await crypto.subtle.digest("SHA-256", t));
          })(e);
          return eM.c(t);
        }
      }
      function tR() {
        let e = tn.get(tI);
        if (!e) throw new eh.P("Authentication error.");
        return e;
      }
      function tB(e) {
        return e.charAt(0).toUpperCase() + e.slice(1);
      }
      let tU = ({ style: e, ...t }) =>
          (0, a.jsxs)("svg", {
            width: "33",
            height: "32",
            viewBox: "0 0 33 32",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            style: { height: "24px", ...e },
            ...t,
            children: [
              (0, a.jsx)("rect", {
                x: "0.5",
                width: "32",
                height: "32",
                rx: "4",
                fill: "#040507",
              }),
              (0, a.jsx)("path", {
                d: "M17.2949 6.37537C18.0156 5.44684 19.4671 4.57877 20.4927 4.46512C20.8178 4.42885 20.8581 4.43127 20.9312 4.50139L20.9967 4.56426L20.9816 4.99225C20.9564 5.65963 20.8682 6.12873 20.6716 6.6341C20.4751 7.13705 20.1198 7.71738 19.8426 7.97852C19.7594 8.06074 19.6007 8.22516 19.4948 8.34848C19.0563 8.84901 18.439 9.20205 17.5973 9.4366C17.2823 9.52606 17.2596 9.52848 16.8917 9.52606C16.4482 9.52365 16.3852 9.51156 16.3524 9.43176C16.3398 9.39791 16.3272 9.18996 16.3222 8.9675L16.3171 8.56127L16.423 8.17922C16.6347 7.41512 16.8791 6.90733 17.2949 6.37537Z",
                fill: "white",
              }),
              (0, a.jsx)("path", {
                d: "M17.4512 10.2081C18.4163 9.84541 19.7595 9.48754 20.2584 9.46336C20.6616 9.4416 21.2966 9.49238 21.7225 9.57943C22.1383 9.66164 22.4357 9.76078 22.8666 9.96148C23.5571 10.2831 24.1442 10.7135 24.6104 11.2382C24.9582 11.6299 24.9783 11.6807 24.8397 11.8113C24.7944 11.8548 24.6885 11.9249 24.6054 11.9709C24.4542 12.0507 23.8368 12.5464 23.8368 12.5875C23.8368 12.5971 23.736 12.7108 23.6125 12.8341C23.2068 13.25 23.0279 13.5861 22.7683 14.4252C22.7078 14.6186 22.6448 14.8725 22.6272 14.9934C22.5566 15.4577 22.5919 16.125 22.7154 16.7344C22.7885 17.1044 23.0808 17.7306 23.3706 18.1489C23.7763 18.7317 24.3786 19.2491 24.9909 19.5514C25.316 19.7086 25.5 19.8464 25.5 19.9334C25.5 19.96 25.4773 20.0205 25.4521 20.064C25.4244 20.1075 25.3866 20.2164 25.3639 20.3034C25.311 20.521 25.001 21.244 24.807 21.5971C24.0862 22.9052 23.3731 23.8748 22.6095 24.5833C21.8611 25.2725 21.1606 25.582 20.4348 25.5385C19.9359 25.5094 19.4596 25.3934 18.7842 25.1322C18.2248 24.917 18.0081 24.8493 17.7939 24.8203C17.688 24.8058 17.4915 24.7768 17.3604 24.7574C16.9774 24.697 16.7254 24.6921 16.4533 24.7478C15.5461 24.9267 15.5133 24.9364 15.0144 25.1371C14.2231 25.4562 13.8073 25.5578 13.2907 25.5578C12.8875 25.5602 12.696 25.5143 12.2575 25.3087C11.8694 25.125 11.5948 24.9315 11.2546 24.5978C10.9295 24.2811 10.7052 24.0151 10.2642 23.4323C9.18818 22.0081 9.02187 21.7276 8.49519 20.4582C8.28612 19.9546 8.19971 19.7502 8.13026 19.5402C8.07498 19.373 8.03043 19.2023 7.94332 18.8744C7.73164 18.074 7.70896 17.9869 7.70896 17.8709C7.70896 17.8153 7.68628 17.675 7.66108 17.5565C7.44184 16.5917 7.44688 15.0007 7.67116 14.1713C7.82236 13.6127 8.02648 13.088 8.30367 12.5512C8.92863 11.3325 9.71738 10.5539 10.874 10.0123C11.2571 9.8309 11.5444 9.74627 12.0534 9.65922C12.2903 9.62054 12.5523 9.56976 12.6355 9.54799C12.8421 9.49238 13.3184 9.49963 13.6057 9.56008C14.2911 9.71 14.7548 9.84058 15.2059 10.0123C16.0551 10.3411 16.549 10.4789 16.7506 10.4475C16.7692 10.4444 16.7848 10.4418 16.8002 10.4387C16.8815 10.4225 16.9601 10.3929 17.4512 10.2081Z",
                fill: "white",
              }),
            ],
          }),
        tO = ({ style: e, ...t }) =>
          (0, a.jsxs)("svg", {
            width: "33",
            height: "32",
            viewBox: "0 0 33 32",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            style: { height: "24px", ...e },
            ...t,
            children: [
              (0, a.jsx)("rect", {
                x: "0.5",
                width: "32",
                height: "32",
                rx: "4",
                fill: "#5462EB",
              }),
              (0, a.jsx)("path", {
                d: "M23.5433 8.87438C22.2479 8.26174 20.8587 7.81038 19.4063 7.55187C19.3799 7.54688 19.3534 7.55934 19.3398 7.58428C19.1612 7.91179 18.9633 8.33905 18.8247 8.67487C17.2625 8.43382 15.7084 8.43382 14.1782 8.67487C14.0396 8.33158 13.8345 7.91179 13.6551 7.58428C13.6414 7.56018 13.615 7.54771 13.5886 7.55187C12.1369 7.80955 10.7478 8.26092 9.45159 8.87438C9.44037 8.87937 9.43075 8.88769 9.42437 8.89849C6.78947 12.9558 6.06766 16.9134 6.42176 20.8219C6.42336 20.841 6.43378 20.8593 6.4482 20.871C8.18663 22.1868 9.87059 22.9857 11.5233 23.5152C11.5497 23.5235 11.5778 23.5135 11.5946 23.491C11.9855 22.9408 12.334 22.3606 12.6328 21.7504C12.6505 21.7147 12.6336 21.6723 12.5976 21.6581C12.0448 21.442 11.5185 21.1785 11.0122 20.8793C10.9721 20.8552 10.9689 20.7961 11.0058 20.7679C11.1123 20.6856 11.2189 20.6 11.3206 20.5135C11.339 20.4977 11.3647 20.4944 11.3863 20.5044C14.7125 22.0696 18.3136 22.0696 21.6006 20.5044C21.6222 20.4936 21.6479 20.4969 21.6671 20.5127C21.7688 20.5991 21.8754 20.6856 21.9827 20.7679C22.0196 20.7961 22.0172 20.8552 21.9771 20.8793C21.4708 21.1843 20.9445 21.442 20.3909 21.6573C20.3548 21.6715 20.3388 21.7147 20.3564 21.7504C20.6617 22.3597 21.0101 22.9399 21.3939 23.4902C21.4099 23.5135 21.4387 23.5235 21.4652 23.5152C23.1259 22.9857 24.8099 22.1868 26.5483 20.871C26.5635 20.8593 26.5731 20.8419 26.5747 20.8228C26.9985 16.3041 25.8649 12.3789 23.5697 8.89931C23.5641 8.88769 23.5545 8.87937 23.5433 8.87438ZM13.1295 18.442C12.1281 18.442 11.303 17.4944 11.303 16.3307C11.303 15.1669 12.1121 14.2193 13.1295 14.2193C14.155 14.2193 14.9721 15.1752 14.9561 16.3307C14.9561 17.4944 14.1469 18.442 13.1295 18.442ZM19.883 18.442C18.8816 18.442 18.0564 17.4944 18.0564 16.3307C18.0564 15.1669 18.8655 14.2193 19.883 14.2193C20.9084 14.2193 21.7255 15.1752 21.7095 16.3307C21.7095 17.4944 20.9084 18.442 19.883 18.442Z",
                fill: "#F7F7F7",
              }),
            ],
          }),
        tH = ({ style: e, ...t }) =>
          (0, a.jsxs)("svg", {
            width: "33",
            height: "32",
            viewBox: "0 0 33 32",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            style: { height: "24px", ...e },
            ...t,
            children: [
              (0, a.jsx)("rect", {
                x: "0.5",
                width: "32",
                height: "32",
                rx: "4",
                fill: "black",
              }),
              (0, a.jsx)("path", {
                "fill-rule": "evenodd",
                "clip-rule": "evenodd",
                d: "M16.5083 5.62451C10.8896 5.62451 6.34741 10.2078 6.34741 15.878C6.34741 20.4104 9.25774 24.2471 13.2951 25.605C13.7999 25.7071 13.9848 25.3844 13.9848 25.1129C13.9848 24.8752 13.9682 24.0604 13.9682 23.2115C11.1417 23.8227 10.5531 21.9892 10.5531 21.9892C10.0988 20.8009 9.42579 20.4954 9.42579 20.4954C8.50068 19.8673 9.49318 19.8673 9.49318 19.8673C10.5194 19.9352 11.0578 20.9198 11.0578 20.9198C11.9661 22.4815 13.4297 22.0402 14.0185 21.7686C14.1025 21.1065 14.3719 20.6482 14.6579 20.3936C12.4035 20.1559 10.0317 19.2732 10.0317 15.3347C10.0317 14.2142 10.4351 13.2976 11.0745 12.5847C10.9736 12.3301 10.6202 11.2774 11.1756 9.86844C11.1756 9.86844 12.0335 9.59678 13.968 10.9209C14.7962 10.6965 15.6503 10.5823 16.5083 10.5814C17.3662 10.5814 18.2408 10.7003 19.0484 10.9209C20.9831 9.59678 21.841 9.86844 21.841 9.86844C22.3963 11.2774 22.0428 12.3301 21.9419 12.5847C22.5981 13.2976 22.9849 14.2142 22.9849 15.3347C22.9849 19.2732 20.6131 20.1388 18.3419 20.3936C18.7121 20.7161 19.0316 21.3271 19.0316 22.2948C19.0316 23.6698 19.0149 24.7733 19.0149 25.1127C19.0149 25.3844 19.2 25.7071 19.7046 25.6052C23.742 24.2469 26.6523 20.4104 26.6523 15.878C26.669 10.2078 22.1102 5.62451 16.5083 5.62451Z",
                fill: "white",
              }),
            ],
          }),
        tV = (e) =>
          (0, a.jsxs)("svg", {
            width: "33",
            height: "32",
            viewBox: "0 0 33 32",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            ...e,
            children: [
              (0, a.jsx)("rect", {
                x: "0.5",
                width: "32",
                height: "32",
                rx: "4",
                fill: "#F1F2F9",
              }),
              (0, a.jsx)("path", {
                d: "M26.1001 16.2273C26.1001 15.5182 26.0365 14.8364 25.9183 14.1818H16.5001V18.05H21.8819C21.6501 19.3 20.9456 20.3591 19.8865 21.0682V23.5773H23.1183C25.0092 21.8364 26.1001 19.2727 26.1001 16.2273Z",
                fill: "#4285F4",
              }),
              (0, a.jsx)("path", {
                d: "M16.5001 26C19.2001 26 21.4637 25.1046 23.1182 23.5773L19.8864 21.0682C18.991 21.6682 17.8455 22.0227 16.5001 22.0227C13.8955 22.0227 11.691 20.2637 10.9046 17.9H7.56372V20.4909C9.20917 23.7591 12.591 26 16.5001 26Z",
                fill: "#34A853",
              }),
              (0, a.jsx)("path", {
                d: "M10.9047 17.8999C10.7047 17.2999 10.591 16.659 10.591 15.9999C10.591 15.3408 10.7047 14.6999 10.9047 14.0999V11.509H7.56376C6.86376 12.9025 6.49951 14.4405 6.50012 15.9999C6.50012 17.6136 6.88649 19.1408 7.56376 20.4908L10.9047 17.8999Z",
                fill: "#FBBC05",
              }),
              (0, a.jsx)("path", {
                d: "M16.5001 9.97726C17.9682 9.97726 19.2864 10.4818 20.3228 11.4727L23.191 8.60454C21.4591 6.99091 19.1955 6 16.5001 6C12.591 6 9.20917 8.2409 7.56372 11.5091L10.9046 14.1C11.691 11.7364 13.8955 9.97726 16.5001 9.97726Z",
                fill: "#EA4335",
              }),
            ],
          });
      function t$(e) {
        return (0, a.jsxs)("svg", {
          xmlns: "http://www.w3.org/2000/svg",
          xmlnsXlink: "http://www.w3.org/1999/xlink",
          width: 26,
          height: 26,
          viewBox: "0 0 140 140",
          x: "0px",
          y: "0px",
          fill: "none",
          ...e,
          children: [
            (0, a.jsxs)("defs", {
              children: [
                (0, a.jsxs)("linearGradient", {
                  id: "b",
                  children: [
                    (0, a.jsx)("stop", { offset: "0", stopColor: "#3771c8" }),
                    (0, a.jsx)("stop", {
                      stopColor: "#3771c8",
                      offset: ".128",
                    }),
                    (0, a.jsx)("stop", {
                      offset: "1",
                      stopColor: "#60f",
                      stopOpacity: "0",
                    }),
                  ],
                }),
                (0, a.jsxs)("linearGradient", {
                  id: "a",
                  children: [
                    (0, a.jsx)("stop", { offset: "0", stopColor: "#fd5" }),
                    (0, a.jsx)("stop", { offset: ".1", stopColor: "#fd5" }),
                    (0, a.jsx)("stop", { offset: ".5", stopColor: "#ff543e" }),
                    (0, a.jsx)("stop", { offset: "1", stopColor: "#c837ab" }),
                  ],
                }),
                (0, a.jsx)("radialGradient", {
                  id: "c",
                  cx: "158.429",
                  cy: "578.088",
                  r: "65",
                  xlinkHref: "#a",
                  gradientUnits: "userSpaceOnUse",
                  gradientTransform:
                    "matrix(0 -1.98198 1.8439 0 -1031.402 454.004)",
                  fx: "158.429",
                  fy: "578.088",
                }),
                (0, a.jsx)("radialGradient", {
                  id: "d",
                  cx: "147.694",
                  cy: "473.455",
                  r: "65",
                  xlinkHref: "#b",
                  gradientUnits: "userSpaceOnUse",
                  gradientTransform:
                    "matrix(.17394 .86872 -3.5818 .71718 1648.348 -458.493)",
                  fx: "147.694",
                  fy: "473.455",
                }),
              ],
            }),
            (0, a.jsx)("path", {
              fill: "url(#c)",
              d: "M65.03 0C37.888 0 29.95.028 28.407.156c-5.57.463-9.036 1.34-12.812 3.22-2.91 1.445-5.205 3.12-7.47 5.468C4 13.126 1.5 18.394.595 24.656c-.44 3.04-.568 3.66-.594 19.188-.01 5.176 0 11.988 0 21.125 0 27.12.03 35.05.16 36.59.45 5.42 1.3 8.83 3.1 12.56 3.44 7.14 10.01 12.5 17.75 14.5 2.68.69 5.64 1.07 9.44 1.25 1.61.07 18.02.12 34.44.12 16.42 0 32.84-.02 34.41-.1 4.4-.207 6.955-.55 9.78-1.28 7.79-2.01 14.24-7.29 17.75-14.53 1.765-3.64 2.66-7.18 3.065-12.317.088-1.12.125-18.977.125-36.81 0-17.836-.04-35.66-.128-36.78-.41-5.22-1.305-8.73-3.127-12.44-1.495-3.037-3.155-5.305-5.565-7.624C116.9 4 111.64 1.5 105.372.596 102.335.157 101.73.027 86.19 0H65.03z",
              transform: "translate(1.004 1)",
            }),
            (0, a.jsx)("path", {
              fill: "url(#d)",
              d: "M65.03 0C37.888 0 29.95.028 28.407.156c-5.57.463-9.036 1.34-12.812 3.22-2.91 1.445-5.205 3.12-7.47 5.468C4 13.126 1.5 18.394.595 24.656c-.44 3.04-.568 3.66-.594 19.188-.01 5.176 0 11.988 0 21.125 0 27.12.03 35.05.16 36.59.45 5.42 1.3 8.83 3.1 12.56 3.44 7.14 10.01 12.5 17.75 14.5 2.68.69 5.64 1.07 9.44 1.25 1.61.07 18.02.12 34.44.12 16.42 0 32.84-.02 34.41-.1 4.4-.207 6.955-.55 9.78-1.28 7.79-2.01 14.24-7.29 17.75-14.53 1.765-3.64 2.66-7.18 3.065-12.317.088-1.12.125-18.977.125-36.81 0-17.836-.04-35.66-.128-36.78-.41-5.22-1.305-8.73-3.127-12.44-1.495-3.037-3.155-5.305-5.565-7.624C116.9 4 111.64 1.5 105.372.596 102.335.157 101.73.027 86.19 0H65.03z",
              transform: "translate(1.004 1)",
            }),
            (0, a.jsx)("path", {
              fill: "#fff",
              d: "M66.004 18c-13.036 0-14.672.057-19.792.29-5.11.234-8.598 1.043-11.65 2.23-3.157 1.226-5.835 2.866-8.503 5.535-2.67 2.668-4.31 5.346-5.54 8.502-1.19 3.053-2 6.542-2.23 11.65C18.06 51.327 18 52.964 18 66s.058 14.667.29 19.787c.235 5.11 1.044 8.598 2.23 11.65 1.227 3.157 2.867 5.835 5.536 8.503 2.667 2.67 5.345 4.314 8.5 5.54 3.054 1.187 6.543 1.996 11.652 2.23 5.12.233 6.755.29 19.79.29 13.037 0 14.668-.057 19.788-.29 5.11-.234 8.602-1.043 11.656-2.23 3.156-1.226 5.83-2.87 8.497-5.54 2.67-2.668 4.31-5.346 5.54-8.502 1.18-3.053 1.99-6.542 2.23-11.65.23-5.12.29-6.752.29-19.788 0-13.036-.06-14.672-.29-19.792-.24-5.11-1.05-8.598-2.23-11.65-1.23-3.157-2.87-5.835-5.54-8.503-2.67-2.67-5.34-4.31-8.5-5.535-3.06-1.187-6.55-1.996-11.66-2.23-5.12-.233-6.75-.29-19.79-.29zm-4.306 8.65c1.278-.002 2.704 0 4.306 0 12.816 0 14.335.046 19.396.276 4.68.214 7.22.996 8.912 1.653 2.24.87 3.837 1.91 5.516 3.59 1.68 1.68 2.72 3.28 3.592 5.52.657 1.69 1.44 4.23 1.653 8.91.23 5.06.28 6.58.28 19.39s-.05 14.33-.28 19.39c-.214 4.68-.996 7.22-1.653 8.91-.87 2.24-1.912 3.835-3.592 5.514-1.68 1.68-3.275 2.72-5.516 3.59-1.69.66-4.232 1.44-8.912 1.654-5.06.23-6.58.28-19.396.28-12.817 0-14.336-.05-19.396-.28-4.68-.216-7.22-.998-8.913-1.655-2.24-.87-3.84-1.91-5.52-3.59-1.68-1.68-2.72-3.276-3.592-5.517-.657-1.69-1.44-4.23-1.653-8.91-.23-5.06-.276-6.58-.276-19.398s.046-14.33.276-19.39c.214-4.68.996-7.22 1.653-8.912.87-2.24 1.912-3.84 3.592-5.52 1.68-1.68 3.28-2.72 5.52-3.592 1.692-.66 4.233-1.44 8.913-1.655 4.428-.2 6.144-.26 15.09-.27zm29.928 7.97c-3.18 0-5.76 2.577-5.76 5.758 0 3.18 2.58 5.76 5.76 5.76 3.18 0 5.76-2.58 5.76-5.76 0-3.18-2.58-5.76-5.76-5.76zm-25.622 6.73c-13.613 0-24.65 11.037-24.65 24.65 0 13.613 11.037 24.645 24.65 24.645C79.617 90.645 90.65 79.613 90.65 66S79.616 41.35 66.003 41.35zm0 8.65c8.836 0 16 7.163 16 16 0 8.836-7.164 16-16 16-8.837 0-16-7.164-16-16 0-8.837 7.163-16 16-16z",
            }),
          ],
        });
      }
      function tZ(e) {
        return (0, a.jsxs)("svg", {
          width: "33",
          height: "32",
          viewBox: "0 0 33 32",
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg",
          xmlnsXlink: "http://www.w3.org/1999/xlink",
          ...e,
          children: [
            (0, a.jsx)("rect", {
              x: "0.5",
              width: "32",
              height: "32",
              rx: "4",
              fill: "black",
            }),
            (0, a.jsx)("rect", {
              x: "0.5",
              width: "32",
              height: "32",
              rx: "4",
              fill: "#06C755",
            }),
            (0, a.jsx)("rect", {
              x: "0.5",
              width: "32",
              height: "32",
              rx: "4",
              fill: "url(#pattern0_1769_69)",
            }),
            (0, a.jsxs)("defs", {
              children: [
                (0, a.jsx)("pattern", {
                  id: "pattern0_1769_69",
                  patternContentUnits: "objectBoundingBox",
                  width: "1",
                  height: "1",
                  children: (0, a.jsx)("use", {
                    xlinkHref: "#image0_1769_69",
                    transform: "scale(0.003125)",
                  }),
                }),
                (0, a.jsx)("image", {
                  id: "image0_1769_69",
                  width: "320",
                  height: "320",
                  preserveAspectRatio: "none",
                  xlinkHref:
                    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAUAAAAFACAYAAADNkKWqAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAABpkSURBVHgB7d1fbFTXtcfxdWZs45h7g6lClajoetJIRKIqGKmhTSvF5qEvqUqIitM+XEIikYf+QWlVaF+IACVPBamN0ps8NFL5cx+qmioOVXsf+oCJ1Pg2VMKkKlKRSMZVqlalCiaSHf9hZvesMx5jm/k/58w5Z+/vR3KM8cSAPf55rbX32ccTx/Rf3tO/uNiXWygsDnri5UTMgOd5/UZMTozXX3qU/2vAOl4++K+Y4LUR8V97U5KRyUwxM93bOzc5vWNsWhziicU07GYXeoY9I0P+mzljZJBwA6rzv0emM55MGvEuajD29SyM2xyKVgWgBt7cXO+g8YpP+BXdsASBB6AtfiD63dK4ZzJvzj36i3GxSOoDUENvZq57T0Zkf9EPPM+TfgEQGX9kNFY05s31vYtjaa8OUxuAvRPfGDZSOEroAfHRMDSenF74/C/HJIVSFYDBTG+u53ljzHcJPSBR8hqGfpv8st8m5yUlUhGAWu0VTfF58cweAZB0pzKSPZ6GIEx0AJbbXH+5flgApE3igzCRAdj9+5HBTEZ+TPABVkhsECYqAIMV3fmeo54/4xMAtklcECYmANf9/9efLxaLx1jcAKyW9zu744uPjp6SBIg9AP05X86f8/2cdhdwSt6vBnfFXQ1mJEZa9RVM4TLhBzgnV5TC+z0TTx2VGMVSAVL1AVjmyWTGZJ+MoxrseAXY84ev7aHqA7DMyKBfDV7onhh5RjqsowHY8we/3C1m3mChA8AaOb8d/XmnW+KOtMC6veXjue43qPoA1KOX1N2zbuHZThy0EHkA6ryvKMULnMMHoAkdWSWOtAXWKzoIPwAt0FXiC1pASYQiqwA1/PyPfoF5H4CWeTLdnZFdMztHJyUCkQQg4QcgNBGGYOgBSPgBCF1EIRhqABJ+ACITQQiGFoA6rNQNzoQfgMiEHIKhrAKXt7oQfgAiZaR/sSBvhLU63HYA6iZntroA6KBgi4xmj7Sp7QCc/bjn54QfgA7L6dVl0qa2AjC4tpcbFQGIgV5a2+61wy0vgujJDXrxsgBAnDLFJxc+/6uW7kvcUgByfS+AxPBXhjMmu6OV64ZbaoGLXuENwg9AIvgrw3rAsrSg6QAM5n5GBgUAEkLngeve/nrTd5NsqgUutb6F9wUAkqaFVripCrA09wOABGqhFW44AEvn9TP3A5BczbbCDbXArPoCSA2/Fe5bt/hgI0fqN1QB+nO/o4QfgFTwW+GZj3sa2iBdtwJk4QNAGnVnZUe9U2PqVoCl6g8A0uV2QX5c7zE1K0CqPwBplhGza+7Rc+PV318D1R+ANDPi1cywqhUg1R8AG9SqAqtWgFR/AGxgvMzz1d5XsQKk+gNgk77exY2V9gVWrAAL3u2qiQkAaTM721Px6pCKAeiZDKc8A7BH1lQs6u4KwJ63v7aHqz4AWMVIf+/E3uG1v31XAHqZ7H4BAMtU2hKzehHkwp7+nt7umwIAtqlwSMKqCrC7t5vZHwA76SEJc6szblUAZjzvCQEAS/mBt3/N23cYwz1+AdjLeDLYf3lPf/nt5QDsnfjGsACAzfw2eG6ua/mmbssBWDAFqj8A1jPGW8665QD0l4OHBAAsZ1ZkXWkbDNtfADikfG1wUAH2rMsOCwA4YvbjnmF9XWqBveygAIAjPDHD+rpr6Y0hI0B7+rvWy4bsehlYtyl4CX4v2ycb/N9XuXWfbOjj5Of/Gby+dXtGpguzcqvgv749G7w9tXDD//WMAG3K6X+CADRGBhu7QzBcpgE30LNJtq3PBQGngVYOu3Lgdcq7s/kgFKfmbwSBWX679JqARG3Gk+362mMBBJUM+OH22L1bZbuGnR9625dCLw3KQXjFf3nroz/L1NyN4NfASroQ4ukG6KIULgicpZWdht1j935GtvflZJv/0t/VJzYph+JFPxDf+ugqlSKkO9u9o6toFvvFq3t7YFhEA09DbvcnHpEhP/j017bTQC+F/Nbl3ysF4lU5/+GloFKEWxYKi4NdpRVglkBspy3t7o2f80Nvp5UVXiu2LVW7B+9/PHhbK8OzN8aDUJxaWoiBvTzxcroIkhNYSVtarfD2bRpOzfwuTisrRK0O3/Qrw1/7L8wPLeWZAW/dxMgFv/4bFlhBK72nNw0ReiHSleZX/v4bOX/zj1SGFvGMvEkAWkBnevvuGwra25UzLoSv3Caf8V+QckYmvZ6Jp97nJkjppC2uLmTsu2+YmV6HaVWoCycvfnCOqjC98gRgCmmlp4N7qr1koCpMLQ3AEZaAU0DbXA2979z/Faq9hNKq8KUPRgnCFCEAE47gSx8WTdKDAEwogi/9NAhLrfFFgjChCMCEIfjsQ2ucXARggujevZMDzxB8liIIk4cATADdzvLC5hFWdR1xZSYvI9dO0hYnAAEYI213Twzsl6f9yg/u0fkg+wjjRQDGROd8RzY/RbvrONrieBGAHabX6r7+0Ldod7EK1WA8CMAOoupDLXpA6+Gp01SDHUQAdgBVH5pBNdg5BGDE9LCCn33621R9aIrOBg9cf5WTqiPGWfgROpl7Rka3HCb80DQ9y/F3W48G26MQHSrACGjLe+7hQ07cawPR0yrwwPXXaIkjQAUYMt3UrD+5CT+EpfycGmjwxvJoHAEYIl3lLT1ROYoe4dLn1LUdP12+gRPCQQCGRGc1OvMDoqTPMeaC4ekStEUvZzs5sD84yADohCN+AG7I9smhqdOC9hCAbdDwY96HOBx84CtBW/zce68FG6jRGlrgFulAmvBDnPTeMPoc1B/EaA0B2ALCD0mhz8F3PvsjVohbRAA2qRx+rPQiKcqbpgnB5hGATSD8kFTlEKQdbg4B2CDCD0lHCDaPAGyAPqH00jbCD0mnM8HRLYcEjSEAG/CzT3+LBQ+khl46p8evoT4CsA7dda9HWgFpohvzuWKkPgKwBn0CHeFJhJTS5y7XDtdGAFahbQThh7TTa4e3M76pigCsoHyEPWCD0YcPs0ewCgKwAra7wCb6XH79oW8K7kYArqEtA+EH2+hIR08twmoE4Aq6csbQGLbSE2Q0CHEHAbhEZyRsG4DtdLbNlSJ3EIBLjmzeS+sL6+lz/Min9gpKCEAptb5Pc6IzHEErfIfzAUjrCxfRCpc4H4C0vnARrXCJ0wGoBxzQ+sJV2gq7fpWI0wF47uHDArjsZM7tvYHOBqAufND6wnW6GOLygoizAcjCB1Di8nXvTgYg1R9wh34vuDoLdzIAqf6A1Vw9+s25AKT6A+7mahXoXABS/QGVuVgFOhWAVH9Adfq94dqKsFMBSPUH1PbCZreuDnEmAPUnG9UfUJtr+wKdCcB9m4YEQH0u3QbWiQDUE1+45hdozL77hpw5KcaJAHzs3q0CoDEafo/9pxvfM13igCRUf1PzN2q+P+75ZL2/n0rLDHX69ozcKszWfMyGbB/n4dVw8IHH5fzNS2I76wNQ2984K8Cp+X/Kl68ebygAdR9WHGF94PqrcvbGeN3H6fFhl7b9qOZjzvgf55W//7ZuAOnXJIprUPXzvfNPPwxCsJ7RLYdrzrvenc0HX7tGPlZU9DkRx+4F/VrrD4g4/+2dYH0LHHf7q2HQSHWlj3npg1HptLc+utpQ+CkNhDM1Hqvh85wfpvo4/XWtF/0zD02dlrAdyp9u+Jv2lX/8tub7v9/Ex4qKPiemb89Kp2n4fXWj/Ysh1gdg3O3vdKHzT964TM3/q6nHv/L33/gB/GcJUzOfbw3iWv5a5/2dMl2IJ4SHHJidWx2AwTCXBZBEG7l2sm4QIR5UgCm3zfHjvtNAW8wD118TJE+pgLB7U7TVAejShs400zb4xRjmn6jP9g7K6gB0/YYvaaLD/rDngWif7XNAawOQ+V/66HacOFY8UZ3tYyRrA5D5X/roVqCRaycEyaGFhM2dlMUBOCBIH22D6+3PQ2dtW58TW1kbgEMb3L3VX9odyp9iHrhEr2TKxXwJ4naLA9DaS+H6s1znmWY6D3znsyf8FqxP0kCDKuwj17T93HffsMRtoOc+sZW1AcgMMN10Hvjce6/K6JZDkgZ6LbetJ45vX/+g2MrKFlh/cqalckB15z98h3lgAmi423pyjpUBSPVnD90fqIcrIF79WTsLCmsrQNhBL5Xb+5cT7A+Mma1FhZUB+F8WD21dpPPAQ1OnBPHZQAucHlSA9tHzA5kHxocWOEW4/aWddB7I0VnxsLUCdOKeILCDzgP1iPok7g/UhRrduxgmrbr03hy6xzBucW/GjoqVAUgLbK/g1gF/G5WTA/slSTScG721QDP0xkRp2hCeNnbOALkKJBUOPvCVln5Y6VH6ZyIImyTSwI/rSHwXOHFfYCSTHlhx5FN7pRWHp04zD0TbCEDESqvAVm5cVdofeFKAdhCAiN0Jf57XyqBfFx6iuLUm3GFlAOZpjVJF54DnHm7t0AOdB57/8JIAraACRCLopVatruzqqTHMA6Nl6/2tCUAkhs4DW7kNI7fWjJ5+jm1kZQDq1gGkk57/18o8UE+QZh4YnVsEYHoQgOml88DXH/qmtELngTYenZWEfa20wECHaBvc6jzQplZNfxiczD2TiKtAbC0qrLwU7t3ZKUG66Tzw/M0/pubmSBrav9t6VGxFC5wirAja4fWHvpWIgwAgcsXSU7mtDEBtgzhBOP30WLNW54EIz5WZvNjK2hngXxeoAm2greXB+x8XxOeWpQsgytoAnLT4p5ZrdCGglf2BCIet7a+yNgBtLttdpPNAznmMx1u30rEQ1QprA5CVYLvoPPBnn2YeGAeb99VaeyR+WjfEhv1k25Dts6Zy2v2JncE8MIk3R9I5mY1fO91RYXMLbG0A6kqw7iFL0+xIv4G2XP62hE331CXtCPlW6TzwrY+uJu6b8srM+5F87Y5sHpEX/Je42D5KsvpKkCu0wQHbLhEbffiwM/NAvRNePsYW9Nc3/yg2szoAOSfuDpv2Reo80JaKNumoAFNMqx42RNtp36Zh9gdGzPb5n7I6AHUO+O7s+wI76Xxse19OEA2dtdrO+tNg3qQNtpbOAV2aB3bamRsXxXbWB+D//sv+L6LLdB7Y6q01UZ22v2k5iacd1gdgeTsM7KXbfJgHhsuF9lc5cSAqbbD9dB7I0VnhefGDUXGBEwGobTCrweFI6rytfGvNZv5+/V3/Ibibbn1x5bYSTgSgtsFn/zUucRi6d6vETSsjnZVVsq1voOHKScOl1qqrfqxmAmgo5Kt09NaazcwDd2/8XM33//emYYmbfm1yVb52UflpAi81jIrXMzFixAFxHlmu85SLMc0hNZB2b3ykagAq/Wl/5sZ42x9Hnf/wHXnlH/9X52P1yVf9j/V0RAGjn2/9oVfrHDv9dzzWwA+ns/7nJa4rMfRzvu++4Y7eE0QXP7Zc/o64wpkAVBqAnCsHVKeXTbp0e1Gn7grnwr4moB1JPGknSk4F4K9vXmIxBKhC233X7qntVADqXOiVf/xGANzNla0vKzl3Y3Rd4aIKBFZzsfpTzgUgVSCwmn5PuFj9KecCUFEFAnfowoeL1Z9yMgD1J96hqVMCuE73/b3kaPWnnAxApTMPDkmA61764Jy4zNkAVC86/sWH2/SWEfWuALKd0wGoFaDrTwC4izGQ4wGoDk+dZkEEztFVX1cXPlZyPgB1QeSlv7k7BIZ7XF/4WMn5AFR6ATgLInDFl68eF5QQgEsOXH+VVhjWo/VdjQBcok+K5957VQBb6aovre9qBOAKpcM83ToOCG7QuR+rvncjANd4KWgR/imATfb+5SStbwUE4Bq6KqxDYuaBsIXO/d6dzQvuRgBWwDwQttBLPpn7VUcAVqHzQFePCIIdSnM/d+7v0QoCsAb9ycmiCNJIw680ypkRVEcA1nEof4pN0kgVDT0WPRpDADZg5NpJhshIDZ1f83xtDAHYgNJP1BNsj0Hi6dxaNzyjMQRgg7Sd0JkKIYik0vBjxbc5BGATCEEklS7WEX7NIwCbRAgiabTl1cU6NI8AbAEhiKTQxQ427beOAGxROQRZbUNc9LnHXr/2EIBtKIcgq27oNDY6h4MAbJM+AUeuneCyOXQM4RceAjAkugJHCCJq5fDjKo9wEIAh0hBkcQRR0Znfzj/9kPALEQEYMr1umBBE2FjwiAYBGAH9Cb3l8nc4SQaheOujq4RfRAjACOnmVL3bHNUgWnXmxrgffscIv4gQgBE7GzyBj3OkFpqmi2rPXWeTc5QIwA4o7xdklRiN4mCDzvB6JkaMoGMG1m2Scw8flm19OQEq0dEJ8+POIABjsm/TsLywea8fiJ8UQJU21Z9kXNJBBGCMtBo8snlEnvbDEG5jg3M8CMAE2L4+J6NbDlENOkr3+JVOHCf8Oo1FkAS4MpMP9g2yZcY9Z5Z2CRB+8aACTCDmg25gpTd+BGBC6XxQg/DpTUMEoWV0sUNvWK57RBEvAjDhNAgfu/czVISW0BGH3rOXg3STgQBMEVrjdGOxI3kIwBTa/YmdcvD+x/3KcKsgHXRjMzcuSh4CMMXK+wiH/CCkKkwuruxILgLQEtoe7974iF8dPiJIBuZ9yUcAWqa8aKJXl9Aix0fP8Dtw/X+Y9yUcAWgxwjAe7O9LDwLQEf1d6+WrfousQcjMMBocZpA+BKCj9DguDUKtEDUUNSDROra4pBMBiIAGoh7KoGE46L/mvMLGscUlvQhAVKQVYRCKfQMy0PtJ/7WG4gCV4gra8j733qty/sNLgnQiANGUcjDq6/I80cVqkVVeOxCAaJuuNusexIMPPO7E4gotrz0IQITK5uuVdWPzgeuvscprEQIQodOK8OTAM1ZdlaJzPp33cX9eu3AiNEKnc7GRayesqJSCs/v8dlf/PYSffQhAREYP/Uwz3du3808/4CADixGAiIze6yStBwFo6D3y7g9Y5bVclwARmvRDME3bZFjocAsBiEilqYLSqk8PMWDW5w4CEJFKQwBS9bmLAITTqPrcRgDCSVzHC0UAIlK6KTpp2NSMMgIQkUrS6TFUfViLAESkklIBMutDJQQgItWfjbcCZIUXtRCAiFScm6Cp+lAPAYjIbF//oD8D7JNOo+pDowhARGZDtrPhp5VeueoDGkEAIjJ6D5FO4Yh6tIIARGSGNnxGoqZV3+Gp03LmxrgAzfID0MuLmJwAIYt6BZhFDrQpTwWIyES1Aqzt7ot+8LHIgXZ1iTHT4gkQqihWgLXS04qPE5oRBk8rQC/j5Y0xgwKEKOwVYNpdRKHLGLklQMjCWgFmdRdRMV5pBpgXIGS53vbuC6z3Evl+/jRzPkTHeFNdRkyeESDC1moLzLYWdIyRya6erEwuFgQI1a3CbFOPL1/F8VP/hTkfOiHjFae7ZmYW8z293QKESWd3B+9/vO7jCD7Epbf39mTQ/fZMPPU+m6ERtkvbflR1LyB7+RArT6YXvjC6MdgI7Xky6a8G5wQIkd5YfN+mYRm6t3RJ3HRhJgg+DT2qPcTJ8+d/+joIwGLRTHmshCACZ/3FjLMsaCBhjHgX9XVG/+NJcVwAwBVLFWAQgAvzhXEBAEf03bMwrq+DAJRdY9PlRAQAq/lZN73DzzwpB2Dwe3JRAMBy3oqsWw7ArGfGBAAs563IuuUAnJu7PemXgdMCABabe/TcePnXywGoc0DdDygAYCnPyJsr386sfKMocloAwFJ+kbdq1LcqABfnFsdogwHYqrd3sXoA0gYDsJW2v+XtL2WZux4k5rgAgGWMeKfW/l7FK4B73h656b+nXwDAAnoDpPlHRx9c+/uZyo/2XhYAsETR8yruc64YgAtzCz8RALBE1mQqFnWVK8BgMcTjyhAA6efJqblHf5Gv9K5M1f/HFGmDAaRexmSrLuxWDUC9XMQfHI4LAKRVjepPZWr/v2yJAZBetaq/4P213kkVCCC16lR/qmYAqmJRvicAkDL1qr/gMfUesPil0UnDggiANGmg+lN1A1AtzheOcUgCgDTQqz4aqf5UQwEY7AvMsCACIPn8ADzeSPW39NjGrZsYuWBEhgUAEqjaNb/VNFYBLn/w7LO0wgCSys+oXc08vqkA1LKSVhhAIhVNw61vWVMtcBmtMIAk0YOc578wukOa1FQFuPyH0QoDSAid+3km+6S0oKUALJWZxWcFAGLWzKrvWi0FoFr44q/GhGuFAcQpmPuNnpIWtTQDXIl5IIBYeN7Ywhd+2VLrW9ZyBVg2P7f4pCdeXgCgQ3Tu17duoe0xXNsBGFwlIpldhCCATggWPSS7a+0tLlv8WOHo/v3IoL8UfYG7yQGIjJHpjJfd0eqix1rtV4BLSqfGyC62xwCIhJ8tmjFhhZ8KrQIsoxIEELql8NNCS0IUegAqQhBAaCIKPxVJACpCEEDbIgw/FdoMcC39C+uwktVhAK3Q1d4ow2/pz4hW78Q3ckaKF4yYnABAA8pbXcJc8KgksgqwTP8B83MLO8R4YwIAdeidKO/pXdwRdfgt/Vmd0zOx95j/Rx4VAKikaI4vfOncMemQjgag6p0Yecb4IUhLDGCZv9jRlS0+O/v5X3W0U+x4ACqdCxZN4Q3/Tx8UAE7TllfPGO1Ey7tWLAFYRksMOMyv+jwxx+e/eO4nEpNYA1CxSgy4J86qb83fIxmYDQIOSEDVt1JiAlAFs0G5fcz/a+0XAFbxTPHle+4pHAvjGKuwJCoAywhCwB7a7haL8r0or+hoVSIDsIwgBNKrNOfTe3acG5eESnQAlhGEQHp4njem7W6Sg68sFQFYpkFYMIvfzXjZJ1gsARJED0L2zMt9vbd/kqQZXz2pCsCVet7+2h6R7H7/k75HAHSeruh6Mpn0NreW1AZgWf/lPf1zc917isZ7gjAEIrYUekWR0+t7F8fSVO1VkvoAXKt3Yu+w8bw9pihDXGoHhMD4VV5GLnrGjPX23p5Me+itZF0ArqTV4ezH2WHxsoN+mT5kjB+InFAN1ODlS4FnpkyxON53T2HcpsBby+oArKTUMncNFo3p12D0f7wN+J+EnL7PiJcrPYoFFtho6XR2Y6aDX3vB6yl/QTEvRZlc37eYtznsKvk3kqxyUwkTXfIAAAAASUVORK5CYII=",
                }),
              ],
            }),
          ],
        });
      }
      function tq(e) {
        return (0, a.jsxs)("svg", {
          width: "33",
          height: "32",
          viewBox: "0 0 33 32",
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg",
          ...e,
          children: [
            (0, a.jsxs)("g", {
              "clip-path": "url(#clip0_1715_1956)",
              children: [
                (0, a.jsx)("rect", {
                  x: "0.5",
                  width: "32",
                  height: "32",
                  rx: "4",
                  fill: "#0977B6",
                }),
                (0, a.jsx)("path", {
                  d: "M9.46878 6.82104C10.6699 6.82104 11.6461 7.79742 11.6461 8.999C11.6461 10.2017 10.6699 11.1782 9.46878 11.1782C8.26447 11.1782 7.28967 10.2017 7.28967 8.999C7.28967 7.79742 8.26447 6.82104 9.46878 6.82104ZM7.58908 12.8309H11.3467V24.9207H7.58908V12.8309Z",
                  fill: "white",
                }),
                (0, a.jsx)("path", {
                  d: "M13.7032 12.8309H17.3076V14.4827H17.3576C17.8589 13.5322 19.0846 12.53 20.9127 12.53C24.7175 12.53 25.42 15.0341 25.42 18.2891V24.9207H21.6651V19.0415C21.6651 17.6388 21.6394 15.8355 19.7126 15.8355C17.7573 15.8355 17.4579 17.363 17.4579 18.9399V24.9207H13.7032L13.7032 12.8309Z",
                  fill: "white",
                }),
              ],
            }),
            (0, a.jsx)("defs", {
              children: (0, a.jsx)("clipPath", {
                id: "clip0_1715_1956",
                children: (0, a.jsx)("rect", {
                  x: "0.5",
                  width: "32",
                  height: "32",
                  rx: "4",
                  fill: "white",
                }),
              }),
            }),
          ],
        });
      }
      function tG(e) {
        return (0, a.jsxs)("svg", {
          xmlns: "http://www.w3.org/2000/svg",
          viewBox: "0 0 496 512",
          ...e,
          children: [
            (0, a.jsx)("path", {
              fill: "#1ed760",
              d: "M248 8C111.1 8 0 119.1 0 256s111.1 248 248 248 248-111.1 248-248S384.9 8 248 8Z",
            }),
            (0, a.jsx)("path", {
              d: "M406.6 231.1c-5.2 0-8.4-1.3-12.9-3.9-71.2-42.5-198.5-52.7-280.9-29.7-3.6 1-8.1 2.6-12.9 2.6-13.2 0-23.3-10.3-23.3-23.6 0-13.6 8.4-21.3 17.4-23.9 35.2-10.3 74.6-15.2 117.5-15.2 73 0 149.5 15.2 205.4 47.8 7.8 4.5 12.9 10.7 12.9 22.6 0 13.6-11 23.3-23.2 23.3zm-31 76.2c-5.2 0-8.7-2.3-12.3-4.2-62.5-37-155.7-51.9-238.6-29.4-4.8 1.3-7.4 2.6-11.9 2.6-10.7 0-19.4-8.7-19.4-19.4s5.2-17.8 15.5-20.7c27.8-7.8 56.2-13.6 97.8-13.6 64.9 0 127.6 16.1 177 45.5 8.1 4.8 11.3 11 11.3 19.7-.1 10.8-8.5 19.5-19.4 19.5zm-26.9 65.6c-4.2 0-6.8-1.3-10.7-3.6-62.4-37.6-135-39.2-206.7-24.5-3.9 1-9 2.6-11.9 2.6-9.7 0-15.8-7.7-15.8-15.8 0-10.3 6.1-15.2 13.6-16.8 81.9-18.1 165.6-16.5 237 26.2 6.1 3.9 9.7 7.4 9.7 16.5s-7.1 15.4-15.2 15.4z",
            }),
          ],
        });
      }
      function tY(e) {
        return (0, a.jsx)("svg", {
          xmlns: "http://www.w3.org/2000/svg",
          "shape-rendering": "geometricPrecision",
          "text-rendering": "geometricPrecision",
          "image-rendering": "optimizeQuality",
          "fill-rule": "evenodd",
          "clip-rule": "evenodd",
          viewBox: "0 0 1000 1000",
          ...e,
          children: (0, a.jsx)("path", {
            d: "M906.25 0H93.75C42.19 0 0 42.19 0 93.75v812.49c0 51.57 42.19 93.75 93.75 93.75l812.5.01c51.56 0 93.75-42.19 93.75-93.75V93.75C1000 42.19 957.81 0 906.25 0zM684.02 319.72c-32.42-21.13-55.81-54.96-63.11-94.38-1.57-8.51-2.45-17.28-2.45-26.25H515l-.17 414.65c-1.74 46.43-39.96 83.7-86.8 83.7-14.57 0-28.27-3.63-40.35-9.99-27.68-14.57-46.63-43.58-46.63-76.97 0-47.96 39.02-86.98 86.97-86.98 8.95 0 17.54 1.48 25.66 4.01V421.89c-8.41-1.15-16.95-1.86-25.66-1.86-105.01 0-190.43 85.43-190.43 190.45 0 64.42 32.18 121.44 81.3 155.92 30.93 21.72 68.57 34.51 109.14 34.51 105.01 0 190.43-85.43 190.43-190.43V400.21c40.58 29.12 90.3 46.28 143.95 46.28V343.03c-28.89 0-55.8-8.59-78.39-23.31z",
          }),
        });
      }
      function tQ(e) {
        return (0, a.jsx)("svg", {
          xmlns: "http://www.w3.org/2000/svg",
          xmlnsXlink: "http://www.w3.org/1999/xlink",
          viewBox: "0 0 2400 2800",
          ...e,
          children: (0, a.jsxs)("g", {
            children: [
              (0, a.jsx)("polygon", {
                fill: "#FFFFFF",
                points:
                  "2200,1300 1800,1700 1400,1700 1050,2050 1050,1700 600,1700 600,200 2200,200",
              }),
              (0, a.jsx)("g", {
                children: (0, a.jsxs)("g", {
                  id: "Layer_1-2",
                  children: [
                    (0, a.jsx)("path", {
                      fill: "#9146FF",
                      d: "M500,0L0,500v1800h600v500l500-500h400l900-900V0H500z M2200,1300l-400,400h-400l-350,350v-350H600V200h1600V1300z",
                    }),
                    (0, a.jsx)("rect", {
                      x: "1700",
                      y: "550",
                      width: "200",
                      height: "600",
                      fill: "#9146FF",
                    }),
                    (0, a.jsx)("rect", {
                      x: "1150",
                      y: "550",
                      width: "200",
                      height: "600",
                      fill: "#9146FF",
                    }),
                  ],
                }),
              }),
            ],
          }),
        });
      }
      let tK = (e) =>
        (0, a.jsxs)("svg", {
          width: "33",
          height: "32",
          viewBox: "0 0 33 32",
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg",
          ...e,
          children: [
            (0, a.jsx)("rect", {
              x: "0.5",
              width: "32",
              height: "32",
              rx: "4",
              fill: "black",
            }),
            (0, a.jsx)("path", {
              d: "M8.53901 8L14.7164 16.2153L8.5 22.8947H9.89907L15.3415 17.0468L19.7389 22.8947H24.5L17.975 14.2173L23.7612 8H22.3621L17.3499 13.3858L13.3001 8H8.53901ZM10.5964 9.02501H12.7837L22.4422 21.8695H20.255L10.5964 9.02501Z",
              fill: "#F7F7F7",
            }),
          ],
        });
      function tX() {
        let e = new URL(window.location.href);
        e.searchParams.delete("privy_oauth_code"),
          e.searchParams.delete("privy_oauth_provider"),
          e.searchParams.delete("privy_oauth_state"),
          tn.del(tS),
          window.history.replaceState({}, "", e);
      }
      let tJ = ({ address: e, chainId: t, nonce: n }) => `${
        window.location.host
      } wants you to sign in with your Ethereum account:
${e}

By signing, you are proving you own this wallet and logging in. This does not initiate a transaction or cost any fees.

URI: ${window.location.origin}
Version: 1
Chain ID: ${t}
Nonce: ${n}
Issued At: ${new Date().toISOString()}
Resources:
- https://privy.io`;
      class t0 {
        get meta() {
          return {
            connectorType: this.wallet?.connectorType,
            walletClientType: this.wallet?.walletClientType,
            chainId: this.wallet?.chainId,
            address: this.wallet?.address,
            disableSignup: this._meta.disableSignup,
          };
        }
        async authenticate() {
          if (!this.client) throw new eh.P("SiweFlow has no client instance");
          try {
            if (this.preparedMessage && this.signature)
              return await this.client.authenticateWithSiweInternal({
                message: this.preparedMessage,
                signature: this.signature,
                chainId: this.wallet?.chainId,
                walletClientType: this.wallet?.walletClientType,
                connectorType: this.wallet?.connectorType,
                mode: this._meta.disableSignup
                  ? "no-signup"
                  : "login-or-sign-up",
              });
            if (!this.wallet) throw new eh.P("SiweFlow has no wallet instance");
            let { message: e, signature: t } = await this.sign();
            return await this.client.authenticateWithSiweInternal({
              message: e,
              signature: t,
              chainId: this.wallet.chainId,
              walletClientType: this.wallet.walletClientType,
              connectorType: this.wallet.connectorType,
              mode: this.meta.disableSignup ? "no-signup" : "login-or-sign-up",
            });
          } catch (e) {
            throw (0, eh.f)(e);
          }
        }
        async link() {
          if (!this.client) throw new eh.P("SiweFlow has no client instance");
          try {
            if (!this.wallet) throw new eh.P("SiweFlow has no wallet instance");
            let { message: e, signature: t } = await this.sign();
            return await this.client.linkWithSiweInternal({
              message: e,
              signature: t,
              chainId: this.wallet.chainId,
              walletClientType: this.wallet.walletClientType,
              connectorType: this.wallet.connectorType,
            });
          } catch (e) {
            throw (0, eh.f)(e);
          }
        }
        async sign() {
          if (!this.client) throw new eh.P("SiweFlow has no client instance");
          if ((await this.buildMessage(), !this.preparedMessage))
            throw new eh.P("Could not prepare SIWE message");
          if (!this.wallet) throw new eh.P("SiweFlow has no wallet instance");
          let e = await this.wallet.sign(this.preparedMessage);
          return { message: this.preparedMessage, signature: e };
        }
        async _getNonceOnce() {
          if (!this.client) throw new eh.P("SiweFlow has no client instance");
          if (!this.wallet)
            throw new eh.P("UI SiweFlow has no wallet instance");
          return await this.client.generateSiweNonce({
            address: this.wallet.address,
            captchaToken: this.captchaToken,
          });
        }
        async buildMessage() {
          if (!this.client) throw new eh.P("SiweFlow has no client instance");
          if (!this.wallet) throw new eh.P("SiweFlow has no wallet instance");
          let e = this.wallet.address,
            t = this.wallet.chainId.replace("eip155:", "");
          return (
            this.nonce || (this.nonce = await this.getNonceOnce.execute()),
            (this.preparedMessage = tJ({
              address: e,
              chainId: t,
              nonce: this.nonce,
            })),
            this.preparedMessage
          );
        }
        constructor(e, t, n, a = !1, r) {
          (this._meta = { disableSignup: !1 }),
            (this.getNonceOnce = new td(this._getNonceOnce.bind(this))),
            (this.wallet = t),
            (this.captchaToken = n),
            (this.client = e),
            (this._meta.disableSignup = a),
            (this.preparedMessage = r?.message),
            (this.signature = r?.signature);
        }
      }
      let t1 = ({ address: e, nonce: t }) => `${
        window.location.host
      } wants you to sign in with your Solana account:
${e}

You are proving you own ${e}.

URI: ${window.location.origin}
Version: 1
Chain ID: mainnet
Nonce: ${t}
Issued At: ${new Date().toISOString()}
Resources:
- https://privy.io`;
      class t2 {
        get meta() {
          return {
            connectorType: this.wallet.connectorType,
            walletClientType: this.wallet.walletClientType,
            disableSignup: this._meta.disableSignup,
            messageType: this._meta.messageType,
            address: this.wallet?.address,
          };
        }
        set messageType(e) {
          this._meta.messageType = e;
        }
        async authenticate() {
          if (!this.client) throw new eh.P("SiwsFlow has no client instance");
          try {
            let { message: e, signature: t } = await this.sign();
            return await this.client.authenticateWithSiwsInternal({
              message: e,
              signature: t,
              walletClientType: this.wallet.walletClientType,
              connectorType: this.wallet.connectorType,
              mode: this.meta.disableSignup ? "no-signup" : "login-or-sign-up",
              messageType: this.meta.messageType,
            });
          } catch (e) {
            throw (0, eh.f)(e);
          }
        }
        async link() {
          if (!this.client) throw new eh.P("SiwsFlow has no client instance");
          try {
            let { message: e, signature: t } = await this.sign();
            return await this.client.linkWithSiwsInternal({
              message: e,
              signature: t,
              walletClientType: this.wallet.walletClientType,
              connectorType: this.wallet.connectorType,
              messageType: this.meta.messageType,
            });
          } catch (e) {
            throw (0, eh.f)(e);
          }
        }
        async sign() {
          let e, t;
          if (!this.client) throw new eh.P("SiwsFlow has no client instance");
          await this.buildMessage();
          let n = "transaction" === this.meta.messageType;
          if (!this.preparedMessage)
            throw new eh.P("Could not prepare SIWS message");
          if (
            (!n && !this.wallet.provider.signMessage) ||
            (n && !this.wallet.provider.signTransaction)
          )
            throw new eh.P(
              "Wallet does not support the necessary signing methods"
            );
          if (n && this._plugin) {
            let n = await this.wallet.provider.signTransaction({
              transaction: S.US.decode(this.preparedMessage),
            });
            (e = S.US.encode(n.signedTransaction)),
              (t = this._plugin.getSignatureFromTransaction(
                n.signedTransaction,
                this.wallet.address
              ));
          } else {
            e = this.preparedMessage;
            let n = await this.wallet.provider.signMessage({
              message: new TextEncoder().encode(this.preparedMessage),
            });
            t = S.US.encode(n.signature);
          }
          return { message: e, signature: t };
        }
        async _getNonceOnce() {
          if (!this.client) throw new eh.P("SiwsFlow has no client instance");
          return await this.client.generateSiwsNonce({
            address: this.wallet.address,
            captchaToken: this.captchaToken,
          });
        }
        async buildMessage() {
          if (!this.client) throw new eh.P("SiwsFlow has no client instance");
          let e = this.wallet.address;
          return (
            this.nonce || (this.nonce = await this.getNonceOnce.execute()),
            "transaction" === this.meta.messageType && this._plugin
              ? (this.preparedMessage = this._plugin.createSiwsMemoTransaction({
                  address: e,
                  nonce: this.nonce,
                }))
              : (this.preparedMessage = t1({ address: e, nonce: this.nonce })),
            this.preparedMessage
          );
        }
        constructor(e, t, n, a = !1, r = "plain", i) {
          (this._meta = { disableSignup: !1, messageType: "plain" }),
            (this.getNonceOnce = new td(this._getNonceOnce.bind(this))),
            (this.wallet = e),
            (this.captchaToken = n),
            (this.client = t),
            (this._meta.disableSignup = a),
            (this._meta.messageType = r),
            (this._plugin = i);
        }
      }
      let t3 = (e) =>
          e.isApexWallet
            ? "Apex Wallet"
            : e.isAvalanche
            ? "Core Wallet"
            : e.isBackpack
            ? "Backpack"
            : e.isBifrost
            ? "Bifrost Wallet"
            : e.isBitKeep
            ? "BitKeep"
            : e.isBitski
            ? "Bitski"
            : e.isBlockWallet
            ? "BlockWallet"
            : e.isBraveWallet
            ? "Brave Wallet"
            : e.isClover
            ? "Clover"
            : e.isCoin98
            ? "Coin98 Wallet"
            : e.isCoinbaseWallet
            ? "Coinbase Wallet"
            : e.isDawn
            ? "Dawn Wallet"
            : e.isDefiant
            ? "Defiant"
            : e.isDesig
            ? "Desig Wallet"
            : e.isEnkrypt
            ? "Enkrypt"
            : e.isExodus
            ? "Exodus"
            : e.isFordefi
            ? "Fordefi"
            : e.isFrame
            ? "Frame"
            : e.isFrontier
            ? "Frontier Wallet"
            : e.isGamestop
            ? "GameStop Wallet"
            : e.isHaqqWallet
            ? "HAQQ Wallet"
            : e.isHyperPay
            ? "HyperPay Wallet"
            : e.isImToken
            ? "ImToken"
            : e.isHaloWallet
            ? "Halo Wallet"
            : e.isKuCoinWallet
            ? "KuCoin Wallet"
            : e.isMathWallet
            ? "MathWallet"
            : e.isNovaWallet
            ? "Nova Wallet"
            : e.isOkxWallet || e.isOKExWallet
            ? "OKX Wallet"
            : e.isOneInchIOSWallet || e.isOneInchAndroidWallet
            ? "1inch Wallet"
            : e.isOneKey
            ? "OneKey Wallet"
            : e.isOpera
            ? "Opera"
            : e.isPhantom || "isPhantom" in e
            ? "Phantom"
            : e.isPortal
            ? "Ripio Portal"
            : e.isRabby
            ? "Rabby Wallet"
            : e.isRainbow
            ? "Rainbow"
            : e.isSafePal
            ? "SafePal Wallet"
            : e.isStatus
            ? "Status"
            : e.isSubWallet
            ? "SubWallet"
            : e.isTalisman
            ? "Talisman"
            : e.isTally || e.isTaho
            ? "Taho"
            : e.isTokenPocket
            ? "TokenPocket"
            : e.isTokenary
            ? "Tokenary"
            : e.isTrust || e.isTrustWallet
            ? "Trust Wallet"
            : e.isTTWallet
            ? "TTWallet"
            : e.isXDEFI
            ? "XDEFI Wallet"
            : e.isZeal
            ? "Zeal"
            : e.isZerion
            ? "Zerion"
            : e.isMetaMask
            ? "MetaMask"
            : void 0,
        t4 = (e, t) => {
          if (!e.isMetaMask) return !1;
          if (e.isMetaMask && !t) return !0;
          if (
            (e.isBraveWallet && !e._events && !e._state) ||
            "MetaMask" !== t3(e)
          )
            return !1;
          if (e.providers) {
            for (let t of e.providers) if (!t4(t)) return !1;
          }
          return !0;
        },
        t5 = () => {
          let e = window;
          if (!e.ethereum) return !1;
          if (e.ethereum.isCoinbaseWallet) return !0;
          if (e.ethereum.providers) {
            for (let t of e.ethereum.providers)
              if (t && t.isCoinbaseWallet) return !0;
          }
          return !1;
        },
        t6 = (e, t, n, a) => {
          let r = Number(e),
            i = t.find((e) => e.id === r);
          if (!i) throw new eh.x(`Unsupported chainId ${e}`, 4901);
          return (0, I.v)({ transport: (0, E.d)(t8(i, n, a.appId)), chain: i });
        },
        t8 = (e, t, n) => {
          let a,
            r = e.id,
            i = Number(e.id);
          if (
            e.rpcUrls.privyWalletOverride &&
            e.rpcUrls.privyWalletOverride.http[0]
          )
            a = e.rpcUrls.privyWalletOverride.http[0];
          else if (t.rpcUrls && t.rpcUrls[i]) a = t.rpcUrls[i];
          else if (e.rpcUrls.privy?.http[0]) {
            let t = new URL(e.rpcUrls.privy.http[0]);
            t.searchParams.append("privyAppId", n), (a = t.toString());
          } else
            a = e.rpcUrls.public?.http[0]
              ? e.rpcUrls.public.http[0]
              : e.rpcUrls.default?.http[0];
          if (!a) throw new eh.x(`No RPC url found for ${r}`);
          return a;
        },
        t7 = (e) =>
          !!String(e)
            .toLowerCase()
            .match(
              /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
            ),
        t9 = (e, t = 3, n = 4, a = "ethereum") => {
          if (!e) return "";
          let r = "ethereum" === a ? 2 : 0;
          return t + n + r + 3 >= e.length
            ? e
            : `${e.slice(0, r + t)}...${e.slice(e.length - n, e.length)}`;
        },
        ne = (e, t = 3, n = 4) => t9(e, t, n, "solana"),
        nt = (e) => new Promise((t) => setTimeout(t, e)),
        nn = (e, t = {}) => {
          let n = t.delayMs || 150,
            a = t.maxAttempts || 270;
          return new Promise(async (r, i) => {
            let o = !1,
              s = 0;
            for (; !o && s < a; ) {
              if (t.abortSignal?.aborted) return;
              e().then(
                (e) => {
                  (o = !0), r(e);
                },
                (...e) => {
                  (o = !0), i(...e);
                }
              ),
                (s += 1),
                await nt(n);
            }
            o || i(Error("Exceeded max attempts before resolving function"));
          });
        },
        na = (e) =>
          e.replace(
            /([\u2700-\u27BF]|[\uE000-\uF8FF]|\uD83C[\uDC00-\uDFFF]|\uD83D[\uDC00-\uDFFF]|[\u2011-\u26FF]|\uD83E[\uDD10-\uDDFF])/g,
            ""
          ),
        nr = (e) => ("string" == typeof e ? e : "0x" + e.toString(16));
      async function ni({
        store: e,
        walletList: t,
        externalWalletConfig: n,
        walletChainType: a,
        timeout: r = 3e3,
      }) {
        let i = !1,
          o = window;
        return new Promise((s) => {
          function l() {
            if (i) return;
            (i = !0), window.removeEventListener("ethereum#initialized", l);
            let r = e.getProviders();
            console.debug(
              "Detected injected providers:",
              r.map((e) => e.info)
            );
            let o = [];
            for (let e of r)
              (t.includes("coinbase_wallet") &&
                "com.coinbase.wallet" === e.info.rdns) ||
                ("solana-only" === a && "app.phantom" === e.info.rdns) ||
                o.push({
                  type: e.info.name.toLowerCase().replace(/\s/g, "_"),
                  eip6963InjectedProvider: e,
                });
            if ("solana-only" !== a)
              for (let e of (function () {
                let e = window,
                  t = e.ethereum;
                if (!t) return [];
                let n = [];
                if (t.providers?.length)
                  for (let e of t.providers) e && n.push(e);
                return n.push(e.ethereum), n;
              })()) {
                let t = t3(e);
                if (!r.some((e) => e.info.name === t)) {
                  if (t4(e, !0) && !o.find((e) => "metamask" === e.type)) {
                    o.push({ type: "metamask", legacyInjectedProvider: e });
                    continue;
                  }
                  if ("Phantom" === t && !o.find((e) => "phantom" === e.type)) {
                    o.push({ type: "phantom", legacyInjectedProvider: e });
                    continue;
                  }
                  if (
                    "Coinbase Wallet" === t &&
                    !o.find(
                      (e) =>
                        "coinbase_wallet" === e.type &&
                        "smartWalletOnly" !==
                          n.coinbaseWallet?.config?.preference?.options
                    )
                  ) {
                    o.push({
                      type: "coinbase_wallet",
                      legacyInjectedProvider: e,
                    });
                    continue;
                  }
                  o.find((e) => "unknown_browser_extension" === e.type) ||
                    o.push({
                      type: "unknown_browser_extension",
                      legacyInjectedProvider: e,
                    });
                }
              }
            s(o);
          }
          o.ethereum
            ? l()
            : (window.addEventListener("ethereum#initialized", l, { once: !0 }),
              setTimeout(() => {
                l();
              }, r));
        });
      }
      function no(e) {
        return `eip155:${String(Number(e))}`;
      }
      let ns = (e, t, n, a) => {
          let r = Number(e),
            i = t.find((e) => e.id === r);
          if (!i) throw new eh.x(`Unsupported chainId ${e}`, 4901);
          return t8(i, n, a);
        },
        nl = (e) => {
          let t = {
              name: "string",
              version: "string",
              chainId: "uint256",
              verifyingContract: "address",
              salt: "bytes32",
            },
            n =
              e.types.EIP712Domain ??
              Object.entries(e.domain)
                .map(([e, n]) => {
                  if (null != n && "string" == typeof e && e in t)
                    return { name: e, type: t[e] };
                })
                .filter((e) => void 0 !== e);
          return { ...e, types: { ...e.types, EIP712Domain: n } };
        },
        nc = (0, C.createContext)({
          siteKey: "",
          enabled: !1,
          appId: void 0,
          token: void 0,
          error: void 0,
          status: "disabled",
          setToken: j.n,
          setError: j.n,
          setExecuting: j.n,
          waitForResult: () => Promise.resolve(""),
          ref: { current: null },
          remove: j.n,
          reset: j.n,
          execute: j.n,
        });
      class nd extends eh.aa {
        constructor(e, t, n) {
          super(e || "Captcha failed"),
            (this.type = "Captcha"),
            t instanceof Error && (this.cause = t),
            (this.privyErrorCode = n);
        }
      }
      let nu = ({
          children: e,
          id: t,
          captchaSiteKey: n,
          captchaEnabled: r,
        }) => {
          let i = (0, C.useRef)(null),
            [o, s] = (0, C.useState)(),
            [l, c] = (0, C.useState)(),
            [d, u] = (0, C.useState)(!1),
            p = (0, C.useMemo)(
              () =>
                r
                  ? d || o || l
                    ? !d || o || l
                      ? o && !l
                        ? { status: "success", token: o }
                        : l
                        ? { status: "error", error: l }
                        : { status: "ready" }
                      : { status: "loading" }
                    : { status: "ready" }
                  : { status: "disabled" },
              [r, o, l, d]
            );
          return (0, a.jsx)(nc.Provider, {
            value: {
              ...p,
              ref: i,
              enabled: r,
              siteKey: n,
              appId: t,
              setToken: s,
              setError: c,
              setExecuting: u,
              remove() {
                r && (i.current?.remove(), u(!1), c(void 0), s(void 0));
              },
              reset() {
                r && (i.current?.reset(), u(!1), c(void 0), s(void 0));
              },
              execute() {
                r && (u(!0), i.current?.execute());
              },
              async waitForResult() {
                if (!r) return "";
                try {
                  return await (function (
                    e,
                    { interval: t = 100, timeout: n = 5e3 } = {}
                  ) {
                    return new Promise((a, r) => {
                      let i,
                        o = 0,
                        s = () => {
                          o >= n
                            ? r("Max attempts reached without result")
                            : ((i = e()),
                              (o += t),
                              null == i ? setTimeout(s, t) : a(i));
                        };
                      s();
                    });
                  })(() => i.current?.getResponse(), {
                    interval: 200,
                    timeout: 2e4,
                  });
                } catch (e) {
                  throw new nd("Captcha failed", null, eh.h.CAPTCHA_TIMEOUT);
                }
              },
            },
            children: e,
          });
        },
        np = () => (0, C.useContext)(nc);
      class nh {
        async authenticate() {
          if (!this.api) throw new eh.P("Auth flow has no API instance");
          try {
            return await this.api.post(eh.ad, {
              captcha_token: this.meta.captchaToken,
              telegram_auth_result: this.meta.telegramAuthResult,
              telegram_web_app_data: this.meta.telegramWebAppData,
              mode: this.meta.disableSignup ? "no-signup" : "login-or-sign-up",
            });
          } catch (e) {
            throw (0, eh.f)(e);
          }
        }
        async link() {
          if (!this.api) throw new eh.P("Auth flow has no API instance");
          try {
            return await this.api.post(eh.ae, {
              telegram_auth_result: this.meta.telegramAuthResult,
              telegram_web_app_data: this.meta.telegramWebAppData,
            });
          } catch (e) {
            throw (0, eh.f)(e);
          }
        }
        constructor(e, t = !1) {
          (this.meta = { disableSignup: !1 }),
            (this.meta = { captchaToken: e, disableSignup: !1 }),
            (this.meta.disableSignup = t);
        }
      }
      function ng(e) {
        let t = { detail: "", retryable: !1 };
        return (
          e?.privyErrorCode === eh.h.LINKED_TO_ANOTHER_USER &&
            (t.detail =
              "This account has already been linked to another user."),
          e?.privyErrorCode === eh.h.DISALLOWED_LOGIN_METHOD &&
            (t.detail = "Login with Telegram not allowed."),
          e?.privyErrorCode === eh.h.INVALID_DATA &&
            ((t.retryable = !0),
            (t.detail = "Something went wrong. Try again.")),
          e?.privyErrorCode === eh.h.CANNOT_LINK_MORE_OF_TYPE &&
            ((t.retryable = !0),
            (t.detail = "Something went wrong. Try again.")),
          e?.privyErrorCode === eh.h.INVALID_CREDENTIALS &&
            ((t.retryable = !0),
            (t.detail = "Something went wrong. Try again.")),
          e?.privyErrorCode === eh.h.TOO_MANY_REQUESTS &&
            (t.detail = "Too many requests. Please wait before trying again."),
          e?.privyErrorCode === eh.h.TOO_MANY_REQUESTS &&
            e.message.includes("rate limit") &&
            (t.detail =
              "Request limit reached for Telegram. Please wait a moment and try again."),
          e instanceof nd &&
            ((t.retryable = !0),
            (t.detail = "Something went wrong. Try again.")),
          t
        );
      }
      function nf() {
        let e;
        return (e = (function () {
          let e = new URLSearchParams(window.location.search),
            t = Number(e.get("id") || ""),
            n = e.get("hash"),
            a = Number(e.get("auth_date") || ""),
            r = e.get("first_name");
          if (t && r && a && n) return Object.fromEntries(e.entries());
        })())
          ? (ny(), { flowType: "login-url", authData: e })
          : (e = (function () {
              let e = window.location.hash;
              if (!e || !e.startsWith("#tgWebAppData")) return;
              let t = nm(e.replace("#tgWebAppData=", "")),
                { user: n, auth_date: a, hash: r } = t;
              return n && a && r ? t : void 0;
            })())
          ? (ny(), { flowType: "web-app", authData: e })
          : void 0;
      }
      function nm(e) {
        return Object.fromEntries(
          decodeURIComponent(e)
            .split("&")
            .map((e) => e.split("=").map(decodeURIComponent))
        );
      }
      function ny() {
        let e = new URL(window.location.href);
        e.searchParams.delete("id"),
          e.searchParams.delete("hash"),
          e.searchParams.delete("auth_date"),
          e.searchParams.delete("first_name"),
          e.searchParams.delete("last_name"),
          e.searchParams.delete("username"),
          e.searchParams.delete("photo_url"),
          (e.hash = ""),
          window.history.replaceState({}, "", e);
      }
      let nw = (e) => {
          if ("ethereum" === e.chainType)
            return {
              entropyId: e.address,
              entropyIdVerifier: "ethereum-address-verifier",
            };
          if ("solana" === e.chainType)
            return {
              entropyId: e.address,
              entropyIdVerifier: "solana-address-verifier",
            };
          throw Error("Failed to get account entropy details");
        },
        nv = (e, t) => {
          if (t?.imported) return nw(t);
          let n = (0, k.a)(e);
          if (!n) throw Error("Failed to find primary wallet");
          return nw(n);
        },
        nx = ({ style: e, ...t }) =>
          (0, a.jsxs)("svg", {
            viewBox: "0 0 1024 1024",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            style: { height: "28px", width: "28px", ...e },
            ...t,
            children: [
              (0, a.jsx)("rect", {
                width: "1024",
                height: "1024",
                fill: "#0052FF",
                rx: 100,
                ry: 100,
              }),
              (0, a.jsx)("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M152 512C152 710.823 313.177 872 512 872C710.823 872 872 710.823 872 512C872 313.177 710.823 152 512 152C313.177 152 152 313.177 152 512ZM420 396C406.745 396 396 406.745 396 420V604C396 617.255 406.745 628 420 628H604C617.255 628 628 617.255 628 604V420C628 406.745 617.255 396 604 396H420Z",
                fill: "white",
              }),
            ],
          }),
        nb =
          "data:image/svg+xml;base64,PHN2ZyB2aWV3Qm94PScwIDAgMTAyNCAxMDI0JyBmaWxsPSdub25lJyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHN0eWxlPSdoZWlnaHQ6MjhweDt3aWR0aDoyOHB4Jz48cmVjdCB3aWR0aD0nMTAyNCcgaGVpZ2h0PScxMDI0JyBmaWxsPScjMDA1MkZGJyByeD0nMTAwJyByeT0nMTAwJz48L3JlY3Q+PHBhdGggZmlsbC1ydWxlPSdldmVub2RkJyBjbGlwLXJ1bGU9J2V2ZW5vZGQnIGQ9J00xNTIgNTEyQzE1MiA3MTAuODIzIDMxMy4xNzcgODcyIDUxMiA4NzJDNzEwLjgyMyA4NzIgODcyIDcxMC44MjMgODcyIDUxMkM4NzIgMzEzLjE3NyA3MTAuODIzIDE1MiA1MTIgMTUyQzMxMy4xNzcgMTUyIDE1MiAzMTMuMTc3IDE1MiA1MTJaTTQyMCAzOTZDNDA2Ljc0NSAzOTYgMzk2IDQwNi43NDUgMzk2IDQyMFY2MDRDMzk2IDYxNy4yNTUgNDA2Ljc0NSA2MjggNDIwIDYyOEg2MDRDNjE3LjI1NSA2MjggNjI4IDYxNy4yNTUgNjI4IDYwNFY0MjBDNjI4IDQwNi43NDUgNjE3LjI1NSAzOTYgNjA0IDM5Nkg0MjBaJyBmaWxsPSd3aGl0ZSc+PC9wYXRoPjwvc3ZnPg==",
        nC =
          "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAAXNSR0IArs4c6QAAALZJREFUaEPtmjEOhDAMBNc/O14GvOzys3CAKK6eAlmaVGl2Zc+kTOU685vkc9/bnD2prZK5/TZY24z9P+g4F5hNh7/GdoG37WlAA5CATwgCxHENYISwQAMQII5rACOEBRqAAHFcAxghLNAABIjjGsAIYYEGIEAc1wBGCAs0AAHiuAYwQligAQgQxzWAEcICDUCAOK4BjBAWaAACxHENYISwQAMQII6fBjr+VHkW3+u+tfyxMpJaDgYzYxb/ALZVAAAAAElFTkSuQmCC";
      class nj extends eh.x {
        constructor() {
          super("Wallet timeout"), (this.type = "wallet_error");
        }
      }
      let nk = (e) =>
        e instanceof eh.x
          ? e
          : e?.code
          ? new nA(e)
          : new eh.x("Unknown connector error", e);
      class nT extends eh.aa {
        constructor(e, t, n) {
          super(e),
            (this.type = "provider_error"),
            (this.code = t),
            (this.data = n);
        }
      }
      class nA extends nT {
        constructor(e) {
          super(e.message, e.code, e.data);
          let t = Object.values(V.M_).find((t) => t.eipCode === e.code);
          (this.details = t || V.M_.UNKNOWN_ERROR),
            -32002 === e.code &&
              (e.message?.includes("already pending for origin")
                ? e.message?.includes("wallet_requestPermissions")
                  ? (this.details = V.M_.E32002_CONNECTION_ALREADY_PENDING)
                  : (this.details = V.M_.E32002_REQUEST_ALREADY_PENDING)
                : e.message?.includes("Already processing") &&
                  e.message.includes("eth_requestAccounts") &&
                  (this.details = V.M_.E32002_WALLET_LOCKED));
        }
      }
      let nS = {
        ERROR_USER_EXISTS: {
          message: "User already exists for this address",
          detail: "Try another address!",
          retryable: !1,
        },
        ERROR_TIMED_OUT: {
          message: "Wallet request timed out",
          detail: "Please try connecting again.",
          retryable: !0,
        },
        ERROR_WALLET_CONNECTION: {
          message: "Could not log in with wallet",
          detail: "Please try connecting again.",
          retryable: !0,
        },
        ERROR_USER_REJECTED_CONNECTION: {
          message: "You rejected the request",
          detail: "Please try connecting again.",
          retryable: !0,
        },
        ERROR_USER_LIMIT_REACHED: {
          message: "Unable to link",
          detail: "You've reached the maximum number of linked wallets.",
          retryable: !1,
        },
        ...V.M_,
      };
      function nI(e) {
        return "ethereum" === e.type;
      }
      function nE(e, t) {
        if (e.length !== t.length) return !1;
        for (let n = 0; n < e.length; n++) {
          let a = e[n],
            r = t[n];
          if (
            a?.address !== r?.address ||
            (a && r && nI(a) && nI(r) && a?.chainId !== r?.chainId) ||
            a?.connectorType !== r?.connectorType ||
            a?.connectedAt !== r?.connectedAt ||
            a?.walletClientType !== r?.walletClientType ||
            a?.isConnected !== r?.isConnected ||
            a?.linked !== r?.linked
          )
            return !1;
        }
        return !0;
      }
      class nN extends eQ.Z {
        constructor(e) {
          super(),
            (this.walletClientType = e),
            (this.connected = !1),
            (this.initialized = !1);
        }
      }
      let n_ = (e, t) => (e.rpcTimeouts && e.rpcTimeouts[t]) || 12e4;
      function nM(e) {
        return "ethereum" === e.chainType;
      }
      class nF extends nN {
        buildConnectedWallet(e, t, n, a) {
          let r = async () =>
            !!this.wallets.find((t) => (0, M.K)(t.address) === (0, M.K)(e));
          return {
            type: "ethereum",
            address: (0, M.K)(e),
            chainId: t,
            meta: n,
            imported: a,
            switchChain: async (n) => {
              let a, i;
              if (!r) throw new eh.x("Wallet is not currently connected.");
              let o = this.wallets.find(
                (t) => M.K(t.address) === M.K(e)
              )?.chainId;
              if (!o) throw new eh.x("Unable to determine current chainId.");
              if (
                ("number" == typeof n
                  ? ((a = `0x${n.toString(16)}`), (i = n))
                  : ((a = n), (i = Number(n))),
                o === no(a))
              )
                return;
              let s = this.chains.find((e) => e.id === i);
              if (!s) throw new eh.x(`Unsupported chainId: ${n}`);
              let l = async () => {
                await this.proxyProvider.request({
                  method: "wallet_switchEthereumChain",
                  params: [{ chainId: a }],
                });
              };
              try {
                return await l();
              } catch (e) {
                if (
                  ((e, t) => {
                    switch (t) {
                      case "coinbase_wallet":
                      case "base_account":
                        return e.message.includes("addEthereumChain");
                      case "rabby_wallet":
                        return e.message.includes("Unrecognized chain ID");
                      default:
                        return 4902 === e.code || e.message?.includes("4902");
                    }
                  })(e, this.walletClientType)
                )
                  return (
                    "rabby_wallet" === this.walletClientType && (await nt(300)),
                    await this.proxyProvider.request({
                      method: "wallet_addEthereumChain",
                      params: [
                        {
                          chainId: a,
                          chainName: s.name,
                          nativeCurrency: s.nativeCurrency,
                          rpcUrls: [s.rpcUrls.default?.http[0] ?? ""],
                          blockExplorerUrls: [
                            s.blockExplorers?.default.url ?? "",
                          ],
                        },
                      ],
                    }),
                    l()
                  );
                if (
                  "rainbow" === this.walletClientType &&
                  e.message?.includes("wallet_switchEthereumChain")
                )
                  throw new eh.x(`Rainbow does not support the chainId ${t}`);
                throw e;
              }
            },
            connectedAt: Date.now(),
            walletClientType: this.walletClientType,
            connectorType: this.connectorType,
            isConnected: r,
            getEthereumProvider: async () => {
              if (!(await r()))
                throw new eh.x("Wallet is not currently connected.");
              return this.proxyProvider;
            },
            sign: async (e) => {
              if (!(await r()))
                throw new eh.x("Wallet is not currently connected.");
              return await this.sign(e);
            },
            disconnect: () => {
              this.disconnect();
            },
          };
        }
        async syncAccounts(e) {
          let t,
            n = e;
          try {
            if (void 0 === n) {
              let e = await nn(
                () => this.proxyProvider.request({ method: "eth_accounts" }),
                { maxAttempts: 10, delayMs: 500 }
              );
              console.debug(`eth_accounts for ${this.walletClientType}:`, e),
                Array.isArray(e) && (n = e);
            }
          } catch (e) {
            console.debug(
              "Wallet did not respond to eth_accounts. Defaulting to prefetched accounts.",
              e
            );
          }
          if (!n || !Array.isArray(n) || n.length <= 0 || !n[0]) return;
          let a = n[0],
            r = (0, M.K)(a),
            i = [];
          if ("privy" === this.walletClientType) {
            let e = tn.get(t_(r));
            this.chains.find((t) => t.id === Number(e)) ||
              (tn.del(t_(r)), (e = null)),
              (t = e || `0x${this.defaultChain.id.toString(16)}`);
            try {
              await this.proxyProvider.request({
                method: "wallet_switchEthereumChain",
                params: [{ chainId: t }],
              });
            } catch (e) {
              console.warn(
                `Unable to switch embedded wallet to chain ID ${t} on initialization`
              );
            }
          } else
            try {
              let e = await nn(
                () => this.proxyProvider.request({ method: "eth_chainId" }),
                { maxAttempts: 10, delayMs: 500 }
              );
              if (
                (console.debug(`eth_chainId for ${this.walletClientType}:`, e),
                "string" == typeof e)
              )
                t = e;
              else {
                if ("number" != typeof e)
                  throw Error("Invalid chainId returned from provider");
                t = `0x${e.toString(16)}`;
              }
            } catch (e) {
              console.warn(
                "Failed to get chainId from provider, defaulting to 0x1",
                e
              ),
                (t = "0x1");
            }
          let o = no(t);
          if (!i.find((e) => (0, M.K)(e.address) === r)) {
            let e = {
              name: this.walletBranding.name,
              icon:
                "string" == typeof this.walletBranding.icon
                  ? this.walletBranding.icon
                  : void 0,
              id: this.walletBranding.id,
            };
            i.push(
              this.buildConnectedWallet(
                (0, M.K)(a),
                o,
                e,
                "embedded_imported" === this.connectorType
              )
            );
          }
          nE(i, this.wallets) ||
            ((this.wallets = i), this.emit("walletsUpdated"));
        }
        async getConnectedWallet() {
          let e = await this.proxyProvider.request({ method: "eth_accounts" });
          return (
            this.wallets
              .sort((e, t) => t.connectedAt - e.connectedAt)
              .find((t) =>
                e.find((e) => (0, M.K)(e) === (0, M.K)(t.address))
              ) || null
          );
        }
        async isConnected() {
          let e = await this.proxyProvider.request({ method: "eth_accounts" });
          return Array.isArray(e) && e.length > 0;
        }
        async sign(e) {
          return (
            await this.connect({ showPrompt: !1 }),
            this.proxyProvider.request({
              method: "personal_sign",
              params: [(0, L.NC)(e), this.wallets[0]?.address],
            })
          );
        }
        subscribeListeners() {
          this.proxyProvider.on("accountsChanged", this.onAccountsChanged),
            this.proxyProvider.on("chainChanged", this.onChainChanged),
            this.proxyProvider.on("disconnect", this.onDisconnect),
            this.proxyProvider.on("connect", this.onConnect);
        }
        unsubscribeListeners() {
          this.proxyProvider.removeListener(
            "accountsChanged",
            this.onAccountsChanged
          ),
            this.proxyProvider.removeListener(
              "chainChanged",
              this.onChainChanged
            ),
            this.proxyProvider.removeListener("disconnect", this.onDisconnect),
            this.proxyProvider.removeListener("connect", this.onConnect);
        }
        constructor(e, t, n, a) {
          super(e),
            (this.chainType = "ethereum"),
            (this.onAccountsChanged = (e) => {
              0 === e.length ? this.onDisconnect() : this.syncAccounts(e);
            }),
            (this.onChainChanged = (e) => {
              this.wallets.forEach((t) => {
                (t.chainId = no(e)),
                  "privy" === this.walletClientType && tn.put(t_(t.address), e);
              }),
                this.emit("walletsUpdated");
            }),
            (this.onDisconnect = () => {
              (this.connected = !1),
                (this.wallets = []),
                this.emit("walletsUpdated");
            }),
            (this.onConnect = async () => {
              ("base_account" === this.connectorType && this.connected) ||
                ((this.connected = !0),
                "coinbase_wallet" === this.connectorType && (await nt(500)),
                this.syncAccounts());
            }),
            (this.wallets = []),
            (this.walletClientType = e),
            (this.chains = t),
            (this.defaultChain = n),
            (this.rpcConfig = a),
            (this.rpcTimeoutDuration = n_(a, e)),
            (this.connected = !1),
            (this.initialized = !1);
        }
      }
      class nz {
        on(e, t) {
          if (this.walletProvider) return this.walletProvider.on(e, t);
          this._subscriptions.push({ eventName: e, listener: t });
        }
        async request(e) {
          if (!this.walletProvider)
            throw new eh.x(
              `A wallet request of type ${e.method} was made before setting a wallet provider.`
            );
          return Promise.race([
            this.walletProvider.request(e),
            this.walletTimeout(),
          ]).catch((e) => {
            throw nk(e);
          });
        }
        constructor(e, t) {
          (this.removeListener = (e, t) => {
            if (this.walletProvider)
              try {
                return this.walletProvider.removeListener(e, t);
              } catch (e) {
                console.warn("Unable to remove wallet provider listener");
              }
          }),
            (this.walletTimeout = (e = new nj(), t = this.rpcTimeoutDuration) =>
              new Promise((n, a) =>
                setTimeout(() => {
                  a(e);
                }, t)
              )),
            (this.setWalletProvider = (e) => {
              this.walletProvider &&
                this._subscriptions.forEach((e) => {
                  this.removeListener(e.eventName, e.listener);
                }),
                (this.walletProvider = e),
                this._subscriptions.forEach((e) => {
                  this.walletProvider?.on(e.eventName, e.listener);
                });
            }),
            (this.walletProvider = e),
            (this.rpcTimeoutDuration = t || 12e4),
            (this._subscriptions = []);
        }
      }
      let nL = ({ ...e }) =>
        (0, a.jsx)("svg", {
          width: "15",
          height: "15",
          viewBox: "0 0 15 15",
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg",
          ...e,
          children: (0, a.jsx)("path", {
            fillRule: "evenodd",
            clipRule: "evenodd",
            d: "M2.37126 11.0323C2.37126 12.696 3.90598 13.4421 5.40654 13.4468C8.91753 13.4468 12.8021 11.2897 12.7819 7.67984C12.7673 5.07728 10.3748 2.86167 7.54357 2.88296C4.8495 2.88296 2.21821 4.6411 2.21803 7.03628C2.21803 7.67951 2.58722 8.30178 3.55231 8.37184C2.74763 9.16826 2.37126 10.1225 2.37126 11.0323ZM7.55283 8.68012C8.11562 8.68012 8.57186 8.13217 8.57186 7.45624C8.57186 6.78032 8.11562 6.23237 7.55283 6.23237C6.99003 6.23237 6.53379 6.78032 6.53379 7.45624C6.53379 8.13217 6.99003 8.68012 7.55283 8.68012ZM10.4747 8.68012C11.0375 8.68012 11.4937 8.13217 11.4937 7.45625C11.4937 6.78032 11.0375 6.23237 10.4747 6.23237C9.91186 6.23237 9.45562 6.78032 9.45562 7.45625C9.45562 8.13217 9.91186 8.68012 10.4747 8.68012Z",
            fill: e.color || "var(--privy-color-foreground-3)",
          }),
        });
      class nP extends nF {
        get walletBranding() {
          return { id: this.id, name: this.name, icon: this.icon };
        }
        async initialize() {
          (this.initialized = !0), this.emit("initialized");
        }
        async connect() {
          throw Error(
            "connect called for an uninstalled wallet via the EthereumNullConnector"
          );
        }
        disconnect() {
          throw Error(
            "disconnect called for an uninstalled wallet via the EthereumNullConnector"
          );
        }
        promptConnection(e) {
          throw Error(
            `promptConnection called for an uninstalled wallet via the EthereumNullConnector for ${e}`
          );
        }
        constructor({
          id: e,
          name: t,
          icon: n,
          walletClientType: a,
          defaultChain: r,
        }) {
          super(a, [], r, {}),
            (this.connectorType = "null"),
            (this.proxyProvider = new nz(void 0, 12e4)),
            (this.id = e),
            (this.name = t),
            (this.icon = n),
            (this.connectorType = a);
        }
      }
      let nD = ({ style: e, ...t }) =>
          (0, a.jsx)("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: 1.5,
            viewBox: "0 0 24 24",
            style: { ...e },
            ...t,
            children: (0, a.jsx)("path", {
              strokeLinecap: "round",
              strokeLinejoin: "round",
              d: "M9 17.25v1.007a3 3 0 01-.879 2.122L7.5 21h9l-.621-.621A3 3 0 0115 18.257V17.25m6-12V15a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 15V5.25m18 0A2.25 2.25 0 0018.75 3H5.25A2.25 2.25 0 003 5.25m18 0V12a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 12V5.25",
            }),
          }),
        nW = ({ ...e }) =>
          (0, a.jsxs)("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            width: "32",
            height: "32",
            viewBox: "0 0 32 32",
            fill: "none",
            ...e,
            children: [
              (0, a.jsx)("rect", {
                width: "32",
                height: "32",
                rx: "6",
                fill: "#121314",
              }),
              (0, a.jsx)("g", {
                transform: "translate(4, 4)",
                children: (0, a.jsxs)("svg", {
                  width: "24",
                  height: "24",
                  viewBox: "0 0 318.6 318.6",
                  children: [
                    (0, a.jsx)("style", {
                      children:
                        ".s1{stroke-linecap:round;stroke-linejoin:round}.s2{fill:#e4761b;stroke:#e4761b}.s3{fill:#f6851b;stroke:#f6851b}",
                    }),
                    (0, a.jsx)("path", {
                      fill: "#e2761b",
                      stroke: "#e2761b",
                      className: "s1",
                      d: "m274.1 35.5-99.5 73.9L193 65.8z",
                    }),
                    (0, a.jsx)("path", {
                      d: "m44.4 35.5 98.7 74.6-17.5-44.3zm193.9 171.3-26.5 40.6 56.7 15.6 16.3-55.3zm-204.4.9L50.1 263l56.7-15.6-26.5-40.6z",
                      className: "s1 s2",
                    }),
                    (0, a.jsx)("path", {
                      d: "m103.6 138.2-15.8 23.9 56.3 2.5-2-60.5zm111.3 0-39-34.8-1.3 61.2 56.2-2.5zM106.8 247.4l33.8-16.5-29.2-22.8zm71.1-16.5 33.9 16.5-4.7-39.3z",
                      className: "s1 s2",
                    }),
                    (0, a.jsx)("path", {
                      fill: "#d7c1b3",
                      stroke: "#d7c1b3",
                      className: "s1",
                      d: "m211.8 247.4-33.9-16.5 2.7 22.1-.3 9.3zm-105 0 31.5 14.9-.2-9.3 2.5-22.1z",
                    }),
                    (0, a.jsx)("path", {
                      fill: "#233447",
                      stroke: "#233447",
                      className: "s1",
                      d: "m138.8 193.5-28.2-8.3 19.9-9.1zm40.9 0 8.3-17.4 20 9.1z",
                    }),
                    (0, a.jsx)("path", {
                      fill: "#cd6116",
                      stroke: "#cd6116",
                      className: "s1",
                      d: "m106.8 247.4 4.8-40.6-31.3.9zM207 206.8l4.8 40.6 26.5-39.7zm23.8-44.7-56.2 2.5 5.2 28.9 8.3-17.4 20 9.1zm-120.2 23.1 20-9.1 8.2 17.4 5.3-28.9-56.3-2.5z",
                    }),
                    (0, a.jsx)("path", {
                      fill: "#e4751f",
                      stroke: "#e4751f",
                      className: "s1",
                      d: "m87.8 162.1 23.6 46-.8-22.9zm120.3 23.1-1 22.9 23.7-46zm-64-20.6-5.3 28.9 6.6 34.1 1.5-44.9zm30.5 0-2.7 18 1.2 45 6.7-34.1z",
                    }),
                    (0, a.jsx)("path", {
                      d: "m179.8 193.5-6.7 34.1 4.8 3.3 29.2-22.8 1-22.9zm-69.2-8.3.8 22.9 29.2 22.8 4.8-3.3-6.6-34.1z",
                      className: "s3",
                    }),
                    (0, a.jsx)("path", {
                      fill: "#c0ad9e",
                      stroke: "#c0ad9e",
                      className: "s1",
                      d: "m180.3 262.3.3-9.3-2.5-2.2h-37.7l-2.3 2.2.2 9.3-31.5-14.9 11 9 22.3 15.5h38.3l22.4-15.5 11-9z",
                    }),
                    (0, a.jsx)("path", {
                      fill: "#161616",
                      stroke: "#161616",
                      className: "s1",
                      d: "m177.9 230.9-4.8-3.3h-27.7l-4.8 3.3-2.5 22.1 2.3-2.2h37.7l2.5 2.2z",
                    }),
                    (0, a.jsx)("path", {
                      fill: "#763d16",
                      stroke: "#763d16",
                      className: "s1",
                      d: "m278.3 114.2 8.5-40.8-12.7-37.9-96.2 71.4 37 31.3 52.3 15.3 11.6-13.5-5-3.6 8-7.3-6.2-4.8 8-6.1zM31.8 73.4l8.5 40.8-5.4 4 8 6.1-6.1 4.8 8 7.3-5 3.6 11.5 13.5 52.3-15.3 37-31.3-96.2-71.4z",
                    }),
                    (0, a.jsx)("path", {
                      d: "m267.2 153.5-52.3-15.3 15.9 23.9-23.7 46 31.2-.4h46.5zm-163.6-15.3-52.3 15.3-17.4 54.2h46.4l31.1.4-23.6-46zm71 26.4 3.3-57.7 15.2-41.1h-67.5l15 41.1 3.5 57.7 1.2 18.2.1 44.8h27.7l.2-44.8z",
                      className: "s3",
                    }),
                  ],
                }),
              }),
            ],
          }),
        nR = ({ style: e, ...t }) =>
          (0, a.jsxs)("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            width: "108",
            height: "108",
            viewBox: "0 0 108 108",
            fill: "none",
            style: { height: "28px", width: "28px", ...e },
            ...t,
            children: [
              (0, a.jsx)("rect", {
                width: "108",
                height: "108",
                rx: "23",
                fill: "#AB9FF2",
              }),
              (0, a.jsx)("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M46.5267 69.9229C42.0054 76.8509 34.4292 85.6182 24.348 85.6182C19.5824 85.6182 15 83.6563 15 75.1342C15 53.4305 44.6326 19.8327 72.1268 19.8327C87.768 19.8327 94 30.6846 94 43.0079C94 58.8258 83.7355 76.9122 73.5321 76.9122C70.2939 76.9122 68.7053 75.1342 68.7053 72.314C68.7053 71.5783 68.8275 70.7812 69.0719 69.9229C65.5893 75.8699 58.8685 81.3878 52.5754 81.3878C47.993 81.3878 45.6713 78.5063 45.6713 74.4598C45.6713 72.9884 45.9768 71.4556 46.5267 69.9229ZM83.6761 42.5794C83.6761 46.1704 81.5575 47.9658 79.1875 47.9658C76.7816 47.9658 74.6989 46.1704 74.6989 42.5794C74.6989 38.9885 76.7816 37.1931 79.1875 37.1931C81.5575 37.1931 83.6761 38.9885 83.6761 42.5794ZM70.2103 42.5795C70.2103 46.1704 68.0916 47.9658 65.7216 47.9658C63.3157 47.9658 61.233 46.1704 61.233 42.5795C61.233 38.9885 63.3157 37.1931 65.7216 37.1931C68.0916 37.1931 70.2103 38.9885 70.2103 42.5795Z",
                fill: "#FFFDF8",
              }),
            ],
          }),
        nB = [
          "metamask",
          "phantom",
          "brave_wallet",
          "rainbow",
          "uniswap_wallet_extension",
          "uniswap_extension",
          "rabby_wallet",
          "bybit_wallet",
          "ronin_wallet",
          "haha_wallet",
          "crypto.com_wallet_extension",
          "crypto.com_onchain",
          "binance",
          "bitkeep",
          "coinbase_wallet",
          "coinbase_smart_wallet",
          "base_account",
          "metamask",
          "trust",
          "safe",
          "rainbow",
          "uniswap",
          "zerion",
          "argent",
          "spot",
          "omni",
          "cryptocom",
          "blockchain",
          "safepal",
          "bitkeep",
          "zengo",
          "1inch",
          "binance",
          "exodus",
          "mew_wallet",
          "alphawallet",
          "keyring_pro",
          "mathwallet",
          "unstoppable",
          "obvious",
          "ambire",
          "internet_money_wallet",
          "coin98",
          "abc_wallet",
          "arculus_wallet",
          "haha",
          "cling_wallet",
          "broearn",
          "copiosa",
          "burrito_wallet",
          "enjin_wallet",
          "plasma_wallet",
          "avacus",
          "bee",
          "pitaka",
          "pltwallet",
          "minerva",
          "kryptogo",
          "prema",
          "slingshot",
          "kriptonio",
          "timeless",
          "secux",
          "bitizen",
          "blocto",
          "okx_wallet",
          "safemoon",
          "rabby_wallet",
          "bybit_wallet",
          "ronin_wallet",
          "haha_wallet",
          "privy",
          "unknown",
          "phantom",
          "solflare",
          "glow",
          "backpack",
          "mobile_wallet_adapter",
        ],
        nU = Object.freeze({
          phantom: {
            client: "phantom",
            name: "Phantom",
            installLink: eC.vU
              ? "https://addons.mozilla.org/en-US/firefox/addon/phantom-app/"
              : "https://chrome.google.com/webstore/detail/phantom/bfnaelmomeimhlpmgjnjophhpkkoljpa?hl=en",
            chainTypes: ["ethereum", "solana"],
            get isInstalled() {
              if ("phantom" in window) {
                let e = window;
                if (
                  (e?.phantom?.ethereum?.isPhantom &&
                    e?.phantom?.ethereum?.chainId) ||
                  e?.phantom?.solana?.isPhantom
                )
                  return !0;
              }
              return !1;
            },
            getMobileRedirect({
              useUniversalLink: e,
              isSolana: t,
              connectOnly: n,
            }) {
              let a = nH({ client: this.client, isSolana: t, connectOnly: n });
              return `${
                e ? "phantom://" : "https://phantom.app/ul/"
              }browse/${a}?ref=${a}`;
            },
          },
          solflare: {
            client: "solflare",
            name: "Solflare",
            installLink: eC.vU
              ? "https://addons.mozilla.org/es/firefox/addon/solflare-wallet/"
              : "https://chromewebstore.google.com/detail/solflare-wallet/bhhhlbepdkbapadjdnnojkbgioiodbic",
            chainTypes: ["solana"],
            get isInstalled() {
              return "solflare" in window && !!window?.solflare?.isSolflare;
            },
            getMobileRedirect({
              useUniversalLink: e,
              isSolana: t,
              connectOnly: n,
            }) {
              let a = nH({ client: this.client, isSolana: t, connectOnly: n });
              return `${
                e ? "solflare://ul/v1/" : "https://solflare.com/ul/v1/"
              }browse/${a}?ref=${a}`;
            },
          },
          backpack: {
            client: "backpack",
            name: "Backpack",
            installLink:
              "https://chromewebstore.google.com/detail/backpack/aflkmfhebedbjioipglgcbcmnbpgliof",
            chainTypes: ["ethereum", "solana"],
            get isInstalled() {
              return !(
                !("backpack" in window) ||
                (!window?.backpack?.ethereum?.isBackpack &&
                  !window?.backpack?.solana?.isBackpack)
              );
            },
            getMobileRedirect({
              useUniversalLink: e,
              isSolana: t,
              connectOnly: n,
            }) {
              let a = nH({ client: this.client, isSolana: t, connectOnly: n });
              return `${
                e ? "backpack://ul/v1/" : "https://backpack.app/ul/v1/"
              }browse/${a}?ref=${a}`;
            },
          },
          okx_wallet: {
            client: "okx_wallet",
            name: "OKX Wallet",
            installLink:
              "https://chromewebstore.google.com/detail/okx-wallet/mcohilncbfahbmgdjkbpemcciiolgcge",
            chainTypes: ["solana"],
            get isInstalled() {
              return "okxwallet" in window && !!window?.okxwallet?.isOkxWallet;
            },
            getMobileRedirect({ isSolana: e, connectOnly: t }) {
              return (
                "https://www.okx.com/download?deeplink=" +
                encodeURIComponent(
                  "okx://wallet/dapp/url?dappUrl=" +
                    nH({ client: this.client, isSolana: e, connectOnly: t })
                )
              );
            },
          },
        });
      function nO({ connectorType: e, walletClientType: t }) {
        for (let n of nB) if (e === n || t === n) return nU[n];
      }
      function nH({ client: e, isSolana: t, connectOnly: n }) {
        let a = new URL(window.location.href);
        return (
          a.searchParams.set(
            "privy_connector",
            t ? "solana_adapter" : "injected"
          ),
          a.searchParams.set("privy_wallet_client", e),
          a.searchParams.set("privy_connect_only", String(n)),
          encodeURIComponent(a.href.replace(/\/$/g, ""))
        );
      }
      let nV = () => {
          let e = tn.get(tM);
          return e &&
            Array.isArray(e) &&
            e
              .map(
                (e) =>
                  e &&
                  "string" == typeof e.address &&
                  "string" == typeof e.connectorType &&
                  "string" == typeof e.walletClientType &&
                  "number" == typeof e.connectedAt
              )
              .every(Boolean)
            ? e
            : [];
        },
        n$ = [
          "phantom",
          "glow",
          "solflare",
          "backpack",
          "okx_wallet",
          "walletconnect",
          "mobile_wallet_adapter",
        ];
      function nZ(e) {
        return e.toLowerCase().split(" ").join("_");
      }
      class nq extends nN {
        get isInstalled() {
          return !0;
        }
        get wallet() {
          return this._wallet;
        }
        buildConnectedWallet() {
          return this._wallet.accounts.map((e) => ({
            type: "solana",
            provider: new $.O({ wallet: this._wallet, account: e }),
            address: e.address,
            connectedAt: Date.now(),
            walletClientType: this._wallet.name,
            connectorType: this.connectorType,
            imported: !1,
            meta: {
              name: this._wallet.name,
              id: this._wallet.name,
              icon: this._wallet.icon,
            },
            isConnected: async () => this._wallet.accounts.length > 0,
            disconnect: () => {
              this.disconnect();
            },
          }));
        }
        async syncAccounts() {
          (this.wallets = this.buildConnectedWallet()),
            this.emit("walletsUpdated");
        }
        get walletBranding() {
          return {
            id: this.wallet.name,
            name: this.wallet.name,
            icon: this.wallet.icon,
          };
        }
        async initialize() {
          this.subscribeListeners(),
            await this.syncAccounts(),
            this.shouldAttemptAutoConnect() &&
              (await this.wallet.features["standard:connect"]
                ?.connect({ silent: !0 })
                .catch(() => {})),
            (this.initialized = !0),
            this.emit("initialized");
        }
        async connect(e) {
          return (
            e.showPrompt && (await this.promptConnection()),
            (await this.isConnected()) ? this.getConnectedWallet() : null
          );
        }
        async getConnectedWallet() {
          return (
            this.wallets.sort((e, t) => t.connectedAt - e.connectedAt)[0] ||
            null
          );
        }
        async isConnected() {
          return this._wallet.accounts.length > 0;
        }
        subscribeListeners() {
          this._unsubscribeListeners = this.wallet.features[
            "standard:events"
          ]?.on("change", this.onChange);
        }
        unsubscribeListeners() {
          this._unsubscribeListeners?.();
        }
        shouldAttemptAutoConnect() {
          return (
            !(
              !this.autoConnectEnabled || !n$.includes(this.walletClientType)
            ) &&
            ("phantom" !== this.walletClientType ||
              nV().some(({ walletClientType: e }) => "phantom" === e))
          );
        }
        constructor(e, t) {
          super(nZ(e.name)),
            (this.chainType = "solana"),
            (this.connectorType = "solana_adapter"),
            (this.disconnect = () => {
              this.wallet.features["standard:disconnect"]
                ?.disconnect()
                .catch((e) => console.error("Error disconnecting", e));
            }),
            (this.promptConnection = async () => {
              try {
                await this.wallet.features["standard:connect"]?.connect();
              } catch (e) {
                throw nk(e);
              }
            }),
            (this.onChange = () => {
              this.syncAccounts();
            }),
            (this._wallet = e),
            (this.autoConnectEnabled = t),
            (this.wallets = []);
        }
      }
      class nG extends nq {
        get walletBranding() {
          return { id: this.id, name: this.name, icon: this.icon };
        }
        async initialize() {
          (this.initialized = !0), this.emit("initialized");
        }
        async connect() {
          throw Error(
            "connect called for an uninstalled wallet via the SolanaNullConnector"
          );
        }
        constructor({ id: e, name: t, icon: n }) {
          super({ name: t }, !1),
            (this.connectorType = "null"),
            (this.proxyProvider = new nz(void 0, 12e4)),
            (this.disconnect = async () => {
              throw Error(
                "disconnect called for an uninstalled wallet via the SolanaNullConnector"
              );
            }),
            (this.promptConnection = async () => {
              throw Error(
                "promptConnection called for an uninstalled wallet via the SolanaNullConnector"
              );
            }),
            (this.id = e),
            (this.name = t),
            (this.icon = n);
        }
      }
      function nY(e) {
        return "solana" === e.chainType;
      }
      function nQ(e) {
        return "solana" === e.type;
      }
      let nK = (0, eK.U)(() => ({ listings: [] })),
        nX = nK.setState,
        nJ = (e) => {
          let t;
          try {
            t = new URL(e).hostname;
          } catch (e) {
            return;
          }
          return nK.getState().listings.find(({ homepage: e }) => {
            let n;
            try {
              n = new URL(e).hostname;
            } catch (e) {
              return !1;
            }
            return t.includes(n);
          });
        },
        n0 = (e) =>
          nK(({ listings: t }) => t.find(({ slug: t }) => n1(t) === n1(e)));
      function n1(e) {
        return "cryptocom" === e
          ? "cryptocom-defi"
          : "binance" === e
          ? "binance-defi"
          : e.replace(/[-_]wallet$/, "");
      }
      let n2 = {
          appearance: {
            landingHeader: "Log in or sign up",
            theme: "light",
            walletList: [
              "detected_ethereum_wallets",
              "metamask",
              "coinbase_wallet",
              "rainbow",
              "base_account",
              "wallet_connect",
            ],
          },
          walletConnectCloudProjectId: "34357d3c125c2bcf2ce2bc3309d98715",
          captchaEnabled: !1,
          _render: { standalone: !1 },
          fundingMethodConfig: { moonpay: { useSandbox: !1 } },
        },
        n3 = new Set([
          "coinbase_wallet",
          "base_account",
          "cryptocom",
          "metamask",
          "okx_wallet",
          "phantom",
          "rainbow",
          "uniswap",
          "zerion",
          "universal_profile",
          "bybit_wallet",
          "ronin_wallet",
          "haha_wallet",
          "wallet_connect",
          "wallet_connect_qr",
          "detected_solana_wallets",
          "detected_ethereum_wallets",
          "rabby_wallet",
          "safe",
          "solflare",
          "backpack",
          "binance",
          "binanceus",
          "bitkeep",
        ]),
        n4 = (e) => n3.has(e),
        n5 = (e, t, n) => n.indexOf(e) === t;
      function n6(e, t) {
        let n = Math.max(0, Math.min(1, e.toHsl().l + t));
        return (0, eg.Z)({ ...e.toHsl(), l: n });
      }
      function n8(e, t) {
        let n = e.getLuminance(),
          a = t.getLuminance();
        return (Math.max(n, a) + 0.05) / (Math.min(n, a) + 0.05);
      }
      let n7 = {
          background: {
            default: "#020713",
            elevated: "#1A2230",
            "default-hover": "#101724",
            "elevated-hover": "#242B3B",
            "default-clicked": "#1A2230",
            "elevated-clicked": "#2C3444",
            "default-disabled": "#020713",
            "elevated-disabled": "#141824",
            success: "#0E3E2D",
            warning: "#373827",
            error: "#2E0C18",
            interactive: "#8B86FF",
            "error-hover": "#441821",
            "interactive-hover": "#7B73E5",
            "interactive-clicked": "#6560CC",
            "interactive-disabled": "#141824",
            info: "#1F2937",
            "info-hover": "#141824",
          },
          icon: {
            default: "#F8F8F8",
            muted: "#9BA2AE",
            subtle: "#7B8491",
            inverse: "#020713",
            success: "#88E3B5",
            warning: "#FDF27B",
            error: "#EF4444",
            interactive: "#88B6FF",
            "default-hover": "#F8F8F8",
            "muted-hover": "#AEB3BD",
            "subtle-hover": "#8B939E",
            "default-clicked": "#F8F8F8",
            "muted-clicked": "#9097A5",
            "subtle-clicked": "#78818E",
            "default-disabled": "#404452",
            "muted-disabled": "#404452",
            "subtle-disabled": "#404452",
            "error-hover": "#F05555",
            "interactive-hover": "#7B73E5",
            "error-clicked": "#EF4444",
            "interactive-clicked": "#6560CC",
            "muted-disabled-alt": "#404452",
            "subtle-disabled-alt": "#404452",
          },
          text: {
            default: "#F8F8F8",
            muted: "#9BA2AE",
            placeholder: "#7B8491",
            inverse: "#020713",
            success: "#ACEECB",
            warning: "#FEF9A0",
            error: "#FCA5A5",
            interactive: "#A29EFF",
            "default-hover": "#F8F8F8",
            "muted-hover": "#9BA2AE",
            "placeholder-hover": "#656C78",
            "default-clicked": "#F8F8F8",
            "muted-clicked": "#9BA2AE",
            "placeholder-clicked": "#656C78",
            "default-disabled": "#404452",
            "muted-disabled": "#404452",
            "placeholder-disabled": "#404452",
            "error-hover": "#FA8B8B",
            "interactive-hover": "#8C88E5",
            "error-clicked": "#F87171",
            "interactive-clicked": "#7671CC",
            "error-disabled": "#404452",
            "interactive-disabled": "#404452",
          },
          border: {
            default: "#1F2937",
            primary: "#110F2A",
            interactive: "#88B0FF",
            focused: "#F8F8FC",
            info: "#5B83D3",
            success: "#317056",
            warning: "#FBBF24",
            error: "#F87171",
            "default-hover": "#34304A",
            "interactive-hover": "#88B0FF",
            "default-clicked": "#1F2937",
            "interactive-clicked": "#88B0FF",
            "default-active": "#F8F8F8",
            "default-disabled": "#1F2937",
            "interactive-disabled": "#1F2937",
            "error-hover": "#971B1C",
            "error-clicked": "#971B1C",
            "error-disabled": "#1F2937",
          },
        },
        n9 = {
          background: {
            default: "#FFFFFF",
            elevated: "#F1F2F9",
            "default-hover": "#F8F9FC",
            "elevated-hover": "#E8E9F4",
            "default-clicked": "#F1F2F9",
            "elevated-clicked": "#DFE0EF",
            "default-disabled": "#FFFFFF",
            "elevated-disabled": "#F1F2F9",
            success: "#DCFCE7",
            warning: "#FEF3C7",
            error: "#FEE2E2",
            interactive: "#5B4FFF",
            "error-hover": "#FECACA",
            "interactive-hover": "#4F46E5",
            "interactive-clicked": "#4338CA",
            "interactive-disabled": "#F1F2F9",
            info: "#E0E7FF",
            "info-hover": "#EEF2FF",
          },
          icon: {
            default: "#110F2A",
            muted: "#64668B",
            subtle: "#9498B8",
            inverse: "#FFFFFF",
            success: "#33B287",
            warning: "#F59E0B",
            error: "#EF4444",
            interactive: "#564FFF",
            "default-hover": "#1D1B35",
            "muted-hover": "#64668B",
            "subtle-hover": "#888AAE",
            "default-clicked": "#060C23",
            "muted-clicked": "#64668B",
            "subtle-clicked": "#788804",
            "default-disabled": "#CBCDE1",
            "muted-disabled": "#CBCDE1",
            "subtle-disabled": "#CBCDE1",
            "error-hover": "#F06060",
            "interactive-hover": "#4F46E5",
            "error-clicked": "#DC3838",
            "interactive-clicked": "#2BA482",
            "error-disabled": "#CBCDE1",
            "interactive-disabled": "#CBCDE1",
          },
          text: {
            default: "#040217",
            muted: "#64668B",
            placeholder: "#9498B8",
            inverse: "#FFFFFF",
            success: "#135638",
            warning: "#906218",
            error: "#991B1B",
            interactive: "#5B4FFF",
            "default-hover": "#040217",
            "muted-hover": "#64668B",
            "placeholder-hover": "#9498B8",
            "default-clicked": "#040217",
            "muted-clicked": "#64668B",
            "placeholder-clicked": "#9498B8",
            "default-disabled": "#CBCDE1",
            "muted-disabled": "#CBCDE1",
            "placeholder-disabled": "#CBCDE1",
            "error-hover": "#991B1B",
            "interactive-hover": "#5B4FFF",
            "error-clicked": "#991B1B",
            "interactive-clicked": "#5B4FFF",
            "error-disabled": "#CBCDE1",
            "interactive-disabled": "#CBCDE1",
          },
          border: {
            default: "#E2E3F0",
            primary: "#110F2A",
            interactive: "#5B4FFF",
            focused: "#949DF9",
            info: "#F1F2F9",
            success: "#87D7B7",
            warning: "#FACD63",
            error: "#F69393",
            "default-hover": "#E2E3F0",
            "interactive-hover": "#5B4FFF",
            "default-clicked": "#E2E3F0",
            "interactive-clicked": "#5B4FFF",
            "default-active": "#110F2A",
            "default-disabled": "#E2E3F0",
            "interactive-disabled": "#E2E3F0",
            "error-hover": "#F69393",
            "error-clicked": "#F69393",
            "error-disabled": "#E2E3F0",
          },
        };
      function ae(e, t, n, a, r) {
        let i,
          o,
          s,
          l,
          c,
          d,
          u,
          p,
          h,
          g,
          f,
          m,
          y,
          w,
          v,
          x,
          b,
          C = n ? console.warn : () => {};
        t?.loginMethods
          ? ((i = t.loginMethods.includes("email")),
            (o = t.loginMethods.includes("sms")),
            (l = t.loginMethods.includes("wallet")),
            (c = t.loginMethods.includes("google")),
            (d = t.loginMethods.includes("twitter")),
            (u = t.loginMethods.includes("discord")),
            (f = t.loginMethods.includes("spotify")),
            (m = t.loginMethods.includes("instagram")),
            (p = t.loginMethods.includes("tiktok")),
            (h = t.loginMethods.includes("line")),
            (g = t.loginMethods.includes("twitch")),
            (w = t.loginMethods.includes("github")),
            (y = t.loginMethods.includes("linkedin")),
            (v = t.loginMethods.includes("apple")),
            (x = t.loginMethods.includes("farcaster")),
            (b = t.loginMethods.includes("telegram")),
            (s = t.loginMethods.includes("passkey")))
          : ((i = e.email_auth),
            (o = e.sms_auth),
            (l = e.wallet_auth || e.solana_wallet_auth),
            (c = e.google_oauth),
            (d = e.twitter_oauth),
            (u = e.discord_oauth),
            (w = e.github_oauth),
            (f = e.spotify_oauth),
            (m = e.instagram_oauth),
            (p = e.tiktok_oauth),
            (h = e.line_oauth),
            (g = e.twitch_oauth),
            (y = e.linkedin_oauth),
            (v = e.apple_oauth),
            (x = e.farcaster_auth),
            (b = e.telegram_auth),
            (s = e.passkey_auth)),
          e.passkey_auth && (s = !0),
          "undefined" != typeof window &&
            "function" != typeof window.PublicKeyCredential &&
            (s = !1);
        let j = [i, o].filter(Boolean),
          k = [c, d, u, w, f, m, p, h, y, v, x, b].filter(Boolean),
          T = [l].filter(Boolean),
          A = t?.loginMethods?.includes("passkey") ?? !1,
          S = e.passkeys_for_signup_enabled ?? !1,
          I = [s && (S || A)].filter(Boolean);
        if (j.length + k.length + T.length + I.length === 0)
          throw Error("You must enable at least one login method");
        let E =
          void 0 !== t?.appearance?.showWalletLoginFirst
            ? t?.appearance?.showWalletLoginFirst
            : e.show_wallet_login_first;
        E && 0 === T.length
          ? (C(
              "You should only enable `showWalletLoginFirst` when `wallet` logins are also enabled. `showWalletLoginFirst` has been set to false"
            ),
            (E = !1))
          : E ||
            k.length + j.length !== 0 ||
            (C(
              "You should only disable `showWalletLoginFirst` when `email`, `sms`, or social logins are also enabled. `showWalletLoginFirst` has been set to true"
            ),
            (E = !0));
        let N = t?.externalWallets?.walletConnect?.enabled ?? !0;
        t?.loginMethods &&
          t.loginMethodsAndOrder &&
          C(
            "You should only configure one of `loginMethods` or `loginMethodsAndOrder`"
          );
        let _ = (({ input: e, overrides: t }) =>
            t
              ? t.primary
                  .concat(t.overflow ?? [])
                  .filter(n4)
                  .filter(n5)
              : e
              ? e.filter(n4).filter(n5)
              : n2.appearance.walletList)({
            input: t?.appearance?.walletList,
            overrides: t?.loginMethodsAndOrder,
          }),
          M = (({ input: e }) => {
            if (!e || !e.primary[0]) return;
            let t = [e.primary[0]],
              n = [];
            for (let n of (e.primary.length > 4 &&
              console.warn(
                "You should not specify greater than 4 login methods in `loginMethodsAndOrder.primary`"
              ),
            e.primary.slice(1)))
              t.includes(n)
                ? console.warn(`Duplicated login method: ${n}`)
                : t.push(n);
            for (let a of e.overflow ?? [])
              t.includes(a) || n.includes(a)
                ? console.warn(`Duplicated login method: ${a}`)
                : n.push(a);
            return { primary: t, overflow: n };
          })({ input: t?.loginMethodsAndOrder }),
          F = t?.intl?.defaultCountry ?? "US",
          { chains: z, defaultChain: L } = (function ({
            supportedChains: e,
            defaultChainFromConfig: t,
          }) {
            let n;
            if (e) {
              if (0 === e.length)
                throw Error(
                  "`supportedChains` must contain at least one chain"
                );
              n = (0, Z.G)(e);
            } else n = [...q.B];
            let a = e ? n[0] : G.R,
              r = t ?? a;
            if (!n.find((e) => e.id === r.id))
              throw Error(
                "`defaultChain` must be included in `supportedChains`"
              );
            return { chains: n, defaultChain: r };
          })({
            supportedChains: t?.supportedChains,
            defaultChainFromConfig: t?.defaultChain,
          }),
          P = !!t?.defaultChain,
          D =
            t?.customAuth?.getCustomAccessToken &&
            !1 !== t?.customAuth?.enabled,
          W = D
            ? "all-users"
            : e.embedded_wallet_config.ethereum.create_on_login,
          R = e.embedded_wallet_config.solana.create_on_login;
        e.solana_wallet_auth &&
          !t?.externalWallets?.solana?.connectors &&
          console.warn(
            "App configuration has Solana wallet login enabled, but no Solana wallet connectors have been passed to Privy. Make sure to pass Solana connectors to the `config.externalWallets.solana.connectors` field of the `PrivyProvider`"
          );
        let B = e.telegram_auth_config
            ? {
                botId: e.telegram_auth_config.bot_id,
                botName: e.telegram_auth_config.bot_name,
                linkEnabled: e.telegram_auth_config.link_enabled,
                seamlessAuthEnabled:
                  e.telegram_auth_config.seamless_auth_enabled,
              }
            : void 0,
          U = e.funding_config
            ? {
                methods: e.funding_config.methods,
                options: e.funding_config.options,
                defaultRecommendedAmount:
                  e.funding_config.default_recommended_amount,
                defaultRecommendedCurrency:
                  e.funding_config.default_recommended_currency,
                promptFundingOnWalletCreation:
                  e.funding_config.prompt_funding_on_wallet_creation,
                crossChainBridgingEnabled:
                  e.funding_config.cross_chain_bridging_enabled,
              }
            : void 0;
        return {
          id: e.id,
          appClientId: r,
          name: e.name,
          allowlistConfig: {
            errorTitle: e.allowlist_config.error_title,
            errorDetail: e.allowlist_config.error_detail,
            errorCtaText: e.allowlist_config.cta_text,
            errorCtaLink: e.allowlist_config.cta_link,
          },
          legacyWalletUiConfig: e.legacy_wallet_ui_config,
          appearance: {
            logo: t?.appearance?.logo ?? e.logo_url ?? void 0,
            landingHeader:
              t?.appearance?.landingHeader ?? n2.appearance.landingHeader,
            loginMessage:
              "string" == typeof t?.appearance?.loginMessage
                ? t?.appearance?.loginMessage.slice(0, 100)
                : t?.appearance?.loginMessage,
            footerLogo: t?.appearance?.footerLogo,
            palette: (function ({ backgroundTheme: e, accentHex: t }) {
              let n, a, r, i, o, s, l;
              "light" === e
                ? (n = !1)
                : "dark" === e
                ? (n = !0)
                : ((n = 0.5 >= (0, eg.Z)(e).getLuminance()),
                  (a = (0, eg.Z)(e).toHslString()));
              let c = n ? "dark" : "light",
                d = n ? n7 : n9,
                {
                  accent: u,
                  accentLight: p,
                  accentHover: h,
                  accentDark: g,
                  accentDarkest: f,
                } = (function (e, t) {
                  if (!e) {
                    let e = t ? n7 : n9;
                    return {
                      accent: (0, eg.Z)(e.background.interactive),
                      accentLight: (0, eg.Z)(e.background.interactive),
                      accentHover: (0, eg.Z)(e.background["interactive-hover"]),
                      accentDark: (0, eg.Z)(
                        e.background["interactive-clicked"]
                      ),
                      accentDarkest: (0, eg.Z)(
                        e.background["interactive-disabled"]
                      ),
                    };
                  }
                  let n = (0, eg.Z)(e);
                  return {
                    accent: n,
                    accentLight: n6(n, 0.15),
                    accentHover: n6(n, 0.3),
                    accentDark: n6(n, -0.06),
                    accentDarkest: n6(n, -0.6),
                  };
                })(t, n),
                m =
                  ((r = (0, eg.Z)(n9.text.default)),
                  (i = (0, eg.Z)(n7.text.default)),
                  (o = n8(u, r)),
                  (s = n8(u, i)),
                  (l = u.toHsl()).h >= 220 && l.h <= 300 && s >= 3
                    ? n7.text.default
                    : o > s
                    ? n9.text.default
                    : n7.text.default),
                y = (0, eg.Z)(m),
                w = n8(u, (0, eg.Z)(d.background.default)) >= 3;
              return {
                colorScheme: c,
                background: a || d.background.default,
                background2: d.background.elevated,
                background3: d.background.interactive,
                foreground: d.text.default,
                foreground2: d.text.muted,
                foreground3: d.text.placeholder,
                foreground4: d.border.default,
                accent: u.toHslString(),
                accentLight: p.toHslString(),
                accentHover: h.toHslString(),
                accentDark: g.toHslString(),
                accentDarkest: f.toHslString(),
                foregroundAccent: y.toHslString(),
                success: d.background.success,
                successDark: d.text.success,
                successLight: d.background.success,
                error: d.text.error,
                errorLight: d.background.error,
                warn: d.background.warning,
                warnLight: d.background.warning,
                warningDark: d.text.warning,
                errorDark: d.text.error,
                successBg: d.background.success,
                errorBg: d.background.error,
                errorBgHover: d.background["error-hover"],
                warnBg: d.background.warning,
                infoBg: d.background.info,
                infoBgHover: d.background["info-hover"],
                borderDefault: d.border.default,
                borderHover: d.border["default-hover"],
                borderFocus: d.border.focused,
                borderError: d.border.error,
                borderSuccess: d.border.success,
                borderWarning: d.border.warning,
                borderInfo: d.border.info,
                borderInteractive: d.border.interactive,
                borderInteractiveHover: d.border["interactive-hover"],
                backgroundHover: d.background["default-hover"],
                backgroundClicked: d.background["default-clicked"],
                backgroundDisabled: d.background["default-disabled"],
                backgroundInteractive: d.background.interactive,
                backgroundInteractiveHover: d.background["interactive-hover"],
                backgroundInteractiveClicked:
                  d.background["interactive-clicked"],
                backgroundInteractiveDisabled:
                  d.background["interactive-disabled"],
                foregroundHover: d.text.default,
                foregroundClicked: d.text.default,
                foregroundDisabled: d.text["default-disabled"],
                foregroundInteractive: d.text.interactive,
                foregroundInteractiveHover: d.text["interactive-hover"],
                accentHasGoodContrast: w ? "1" : "0",
                linkNavigationColor: w ? u.toHslString() : d.text.default,
                linkNavigationDecoration: w ? "none" : "underline",
                iconDefault: d.icon.default,
                iconMuted: d.icon.muted,
                iconSubtle: d.icon.subtle,
                iconInverse: d.icon.inverse,
                iconSuccess: d.icon.success,
                iconWarning: d.icon.warning,
                iconError: d.icon.error,
                iconInteractive: d.icon.interactive,
                iconDefaultHover: d.icon["default-hover"],
                iconMutedHover: d.icon["muted-hover"],
                iconSubtleHover: d.icon["subtle-hover"],
                iconDefaultClicked: d.icon["default-clicked"],
                iconMutedClicked: d.icon["muted-clicked"],
                iconSubtleClicked: d.icon["subtle-clicked"],
                iconDefaultDisabled: d.icon["default-disabled"],
                iconMutedDisabled: d.icon["muted-disabled"],
                iconSubtleDisabled: d.icon["subtle-disabled"],
                iconErrorHover: d.icon["error-hover"],
                iconInteractiveHover: d.icon["interactive-hover"],
                iconErrorClicked: d.icon["error-clicked"],
                iconInteractiveClicked: d.icon["interactive-clicked"],
                iconMutedDisabledAlt: d.icon["muted-disabled"],
                iconSubtleDisabledAlt: d.icon["subtle-disabled"],
              };
            })({
              backgroundTheme: t?.appearance?.theme ?? n2.appearance.theme,
              accentHex: t?.appearance?.accentColor ?? e.accent_color,
            }),
            loginGroupPriority: E ? "web3-first" : "web2-first",
            hideDirectWeb2Inputs: !!t?.appearance?.hideDirectWeb2Inputs,
            walletList: _,
            walletChainType:
              t?.appearance?.walletChainType ??
              (({ evmWalletAuth: e, solanaWalletAuth: t }) =>
                e && t
                  ? "ethereum-and-solana"
                  : e
                  ? "ethereum-only"
                  : t
                  ? "solana-only"
                  : "ethereum-only")({
                evmWalletAuth: e.wallet_auth ?? !1,
                solanaWalletAuth: e.solana_wallet_auth ?? !1,
              }),
          },
          loginMethods: {
            wallet: l,
            email: i,
            sms: o,
            passkey: s,
            google: c,
            twitter: d,
            discord: u,
            github: w,
            spotify: f,
            instagram: m,
            tiktok: p,
            line: h,
            twitch: g,
            linkedin: y,
            apple: v,
            farcaster: x,
            telegram: b,
          },
          customOAuthProviders: (e.custom_oauth_providers ?? []).filter(
            (e) => !1 !== e.enabled
          ),
          disablePlusEmails: e.disable_plus_emails,
          loginMethodsAndOrder: M,
          legal: {
            termsAndConditionsUrl:
              t?.legal?.termsAndConditionsUrl ?? e.terms_and_conditions_url,
            privacyPolicyUrl:
              t?.legal?.privacyPolicyUrl ?? e.privacy_policy_url,
            requireUsersAcceptTerms: e.require_users_accept_terms ?? !1,
          },
          walletConnectCloudProjectId:
            t?.walletConnectCloudProjectId ??
            e.wallet_connect_cloud_project_id ??
            n2.walletConnectCloudProjectId,
          rpcConfig: {
            rpcUrls: {},
            rpcTimeouts: t?.externalWallets?.signatureRequestTimeouts ?? {},
          },
          chains: z,
          defaultChain: L,
          intl: { defaultCountry: F },
          shouldEnforceDefaultChainOnConnect: P,
          captchaEnabled: e.captcha_enabled ?? n2.captchaEnabled,
          captchaSiteKey: e.captcha_site_key,
          externalWallets: {
            coinbaseWallet: {
              config: {
                appName: e.name,
                appLogoUrl: e.logo_url,
                preference: {
                  options: "all",
                  ...t?.externalWallets?.coinbaseWallet?.config?.preference,
                },
                ...t?.externalWallets?.coinbaseWallet?.config,
              },
            },
            baseAccount: {
              config: {
                appName: e.name,
                appLogoUrl: e.logo_url,
                ...t?.externalWallets?.baseAccount?.config,
                preference: {
                  ...t?.externalWallets?.baseAccount?.config?.preference,
                  telemetry: !1,
                },
              },
            },
            walletConnect: { enabled: N },
            solana: { connectors: t?.externalWallets?.solana?.connectors },
            disableAllExternalWallets:
              t?.externalWallets?.disableAllExternalWallets ?? !1,
          },
          embeddedWallets: {
            requireUserOwnedRecoveryOnCreate:
              !D &&
              (e.embedded_wallet_config.require_user_owned_recovery_on_create ??
                !1),
            userOwnedRecoveryOptions: D
              ? ["user-passcode"]
              : e.embedded_wallet_config.user_owned_recovery_options,
            priceDisplay: t?.embeddedWallets?.priceDisplay ?? {
              primary: "fiat-currency",
              secondary: "native-token",
            },
            ethereum: {
              createOnLogin: t?.embeddedWallets?.ethereum?.createOnLogin ?? W,
            },
            solana: {
              createOnLogin: t?.embeddedWallets?.solana?.createOnLogin ?? R,
            },
            disableAutomaticMigration:
              t?.embeddedWallets?.disableAutomaticMigration ?? !1,
            mode: e.embedded_wallet_config.mode,
            showWalletUIs:
              t?.embeddedWallets?.showWalletUIs ?? e.enforce_wallet_uis ?? !0,
            extendedCalldataDecoding:
              t?.embeddedWallets?.extendedCalldataDecoding ?? !1,
            transactionScanning: {
              enabled: t?.embeddedWallets?.transactionScanning?.enabled ?? !1,
              domain:
                t?.embeddedWallets?.transactionScanning?.domain ??
                a ??
                "https://auth.privy.io",
            },
          },
          mfa: {
            methods: e.mfa_methods ?? [],
            noPromptOnMfaRequired: t?.mfa?.noPromptOnMfaRequired ?? !1,
          },
          passkeys: {
            shouldUnlinkOnUnenrollMfa: t?.passkeys?.shouldUnlinkOnUnenrollMfa,
            shouldUnenrollMfaOnUnlink: t?.passkeys?.shouldUnenrollMfaOnUnlink,
          },
          customAuth: D ? { enabled: !0, ...t.customAuth } : void 0,
          loginConfig: {
            telegramAuthConfiguration: B,
            passkeysForSignupEnabled: e.passkeys_for_signup_enabled,
          },
          headless: !!t?.headless,
          render: {
            standalone: t?._render?.standalone ?? n2._render.standalone,
          },
          fundingConfig: U,
          fundingMethodConfig: {
            ...(t?.fundingMethodConfig ?? n2.fundingMethodConfig),
            moonpay: {
              ...(t?.fundingMethodConfig?.moonpay ??
                n2.fundingMethodConfig.moonpay),
              useSandbox:
                t?.fundingMethodConfig?.moonpay.useSandbox ??
                n2.fundingMethodConfig.moonpay.useSandbox,
            },
          },
          whatsAppEnabled: !!e.whatsapp_enabled,
          customOAuthRedirectUrl: t?.customOAuthRedirectUrl,
          solanaRpcs: {
            "solana:mainnet": t?.solana?.rpcs?.["solana:mainnet"] ?? null,
            "solana:devnet": t?.solana?.rpcs?.["solana:devnet"] ?? null,
            "solana:testnet": t?.solana?.rpcs?.["solana:testnet"] ?? null,
          },
        };
      }
      let at = {
          show_wallet_login_first: !0,
          allowlist_config: {
            error_title: null,
            error_detail: null,
            cta_text: null,
            cta_link: null,
          },
          wallet_auth: !0,
          email_auth: !0,
          sms_auth: !1,
          google_oauth: !1,
          twitter_oauth: !1,
          discord_oauth: !1,
          github_oauth: !1,
          linkedin_oauth: !1,
          apple_oauth: !1,
          disable_plus_emails: !1,
          terms_and_conditions_url: null,
          privacy_policy_url: null,
          embedded_wallet_config: {
            create_on_login: "off",
            ethereum: { create_on_login: "off" },
            solana: { create_on_login: "off" },
            require_user_owned_recovery_on_create: !1,
            user_owned_recovery_options: ["user-passcode"],
            mode: "user-controlled-server-wallets-only",
          },
          fiat_on_ramp_enabled: !1,
          captcha_enabled: !1,
          captcha_site_key: "",
          enforce_wallet_uis: !1,
          legacy_wallet_ui_config: !1,
          id: "",
          name: "",
          passkeys_for_signup_enabled: !1,
          whatsapp_enabled: !1,
        },
        an = (0, C.createContext)({
          appConfig: ae(at, void 0, !1),
          isServerConfigLoaded: !1,
        }),
        aa = ({
          children: e,
          client: t,
          legacyClient: n,
          clientConfig: r,
          appClientId: i,
        }) => {
          let [o, s] = (0, C.useState)(null),
            l = (0, C.useMemo)(
              () =>
                ae(
                  o ?? at,
                  r,
                  !!o,
                  "undefined" != typeof window
                    ? window.location.origin
                    : void 0,
                  i
                ),
              [o, r, i]
            );
          return (
            (0, C.useEffect)(() => {
              if (!o) return;
              let e = (function (e) {
                  if (!e) return {};
                  let {
                    appearance: t,
                    supportedChains: n,
                    defaultChain: a,
                    externalWallets: r,
                    ...i
                  } = e;
                  return {
                    ...i,
                    ...(n ? { supportedChains: n.map((e) => e.id) } : void 0),
                    ...(a ? { defaultChain: a.id } : void 0),
                    ...(r
                      ? {
                          walletConnect: r.walletConnect
                            ? { enabled: r.walletConnect.enabled }
                            : void 0,
                          coinbaseWallet: r.coinbaseWallet,
                          solana: {
                            connectors: r.solana?.connectors
                              ?.get()
                              .map((e) => e.walletClientType),
                          },
                        }
                      : void 0),
                  };
                })(r),
                t = (function (e, t = 0) {
                  let n = 3735928559 ^ t,
                    a = 1103547991 ^ t;
                  for (let t, r = 0; r < e.length; r++)
                    (n = Math.imul(n ^ (t = e.charCodeAt(r)), 2654435761)),
                      (a = Math.imul(a ^ t, 1597334677));
                  return (
                    (n =
                      Math.imul(n ^ (n >>> 16), 2246822507) ^
                      Math.imul(a ^ (a >>> 13), 3266489909)),
                    4294967296 *
                      (2097151 &
                        (a =
                          Math.imul(a ^ (a >>> 16), 2246822507) ^
                          Math.imul(n ^ (n >>> 13), 3266489909))) +
                      (n >>> 0)
                  );
                })(JSON.stringify(e)).toString(),
                a = `privy:sent:${o.id}:${t}`;
              localStorage.getItem(a) ||
                (n.createAnalyticsEvent({
                  eventName: "sdk_initialize",
                  payload: e,
                }),
                localStorage.setItem(a, "t"));
            }, [r, o]),
            (0, C.useEffect)(() => {
              o ||
                (async () => {
                  try {
                    await t.initialize();
                    let e = t.app.getConfig();
                    e.custom_api_url && n.updateApiUrl(e.custom_api_url), s(e);
                  } catch (e) {
                    console.warn("Error generating app config: ", e);
                  }
                })();
            }, []),
            (0, a.jsx)(an.Provider, {
              value: { appConfig: l, isServerConfigLoaded: !!o },
              children: e,
            })
          );
        },
        ar = () => {
          let { appConfig: e } = (0, C.useContext)(an);
          return e;
        },
        ai = () => {
          let { isServerConfigLoaded: e } = (0, C.useContext)(an);
          return e;
        },
        ao = ({ style: e, ...t }) => {
          let n = ar();
          return (0, a.jsxs)("svg", {
            width: "28",
            height: "28",
            viewBox: "0 0 28 28",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            style: { height: "28px", width: "28px", ...e },
            ...t,
            children: [
              (0, a.jsx)("rect", {
                width: "28",
                height: "28",
                rx: "3",
                fill:
                  "dark" === n?.appearance.palette.colorScheme
                    ? "#3396ff"
                    : "#141414",
              }),
              (0, a.jsx)("g", {
                clipPath: "url(#clip0_1765_9946)",
                children: (0, a.jsx)("path", {
                  d: "M8.09448 10.3941C11.3558 7.20196 16.6442 7.20196 19.9055 10.3941L20.2982 10.7782C20.3369 10.8157 20.3677 10.8606 20.3887 10.9102C20.4097 10.9599 20.4206 11.0132 20.4206 11.0671C20.4206 11.121 20.4097 11.1744 20.3887 11.224C20.3677 11.2737 20.3369 11.3186 20.2982 11.3561L18.9554 12.6702C18.9158 12.7086 18.8628 12.7301 18.8077 12.7301C18.7526 12.7301 18.6996 12.7086 18.66 12.6702L18.1198 12.1415C15.8448 9.91503 12.1557 9.91503 9.88015 12.1415L9.30167 12.7075C9.26207 12.7459 9.20909 12.7673 9.15395 12.7673C9.0988 12.7673 9.04582 12.7459 9.00622 12.7075L7.66346 11.3934C7.62475 11.3559 7.59397 11.3109 7.57295 11.2613C7.55193 11.2117 7.5411 11.1583 7.5411 11.1044C7.5411 11.0505 7.55193 10.9971 7.57295 10.9475C7.59397 10.8979 7.62475 10.8529 7.66346 10.8154L8.09448 10.3941ZM22.6829 13.1115L23.8776 14.2814C23.9163 14.319 23.9471 14.3639 23.9681 14.4135C23.9892 14.4632 24 14.5165 24 14.5704C24 14.6243 23.9892 14.6777 23.9681 14.7273C23.9471 14.777 23.9163 14.8219 23.8776 14.8594L18.4893 20.1332C18.4102 20.2101 18.3042 20.2531 18.1938 20.2531C18.0835 20.2531 17.9775 20.2101 17.8984 20.1332L14.0743 16.3901C14.0545 16.3708 14.0279 16.36 14.0003 16.36C13.9726 16.36 13.9461 16.3708 13.9263 16.3901L10.1021 20.1332C10.023 20.2101 9.91703 20.2531 9.8067 20.2531C9.69636 20.2531 9.59038 20.2101 9.51124 20.1332L4.12236 14.8594C4.08365 14.8219 4.05287 14.777 4.03185 14.7273C4.01083 14.6777 4 14.6243 4 14.5704C4 14.5165 4.01083 14.4632 4.03185 14.4135C4.05287 14.3639 4.08365 14.319 4.12236 14.2814L5.31767 13.1115C5.39678 13.0348 5.50265 12.9919 5.61285 12.9919C5.72305 12.9919 5.82892 13.0348 5.90803 13.1115L9.73216 16.8546C9.75194 16.874 9.7785 16.8848 9.80616 16.8848C9.83381 16.8848 9.86037 16.874 9.88015 16.8546L13.7043 13.1115C13.7834 13.0346 13.8894 12.9916 13.9997 12.9916C14.1101 12.9916 14.216 13.0346 14.2952 13.1115L18.1198 16.8546C18.1396 16.874 18.1662 16.8848 18.1938 16.8848C18.2215 16.8848 18.2481 16.874 18.2678 16.8546L22.092 13.1115C22.1711 13.0346 22.2771 12.9916 22.3874 12.9916C22.4977 12.9916 22.6037 13.0346 22.6829 13.1115Z",
                  fill: "white",
                }),
              }),
              (0, a.jsx)("defs", {
                children: (0, a.jsx)("clipPath", {
                  id: "clip0_1765_9946",
                  children: (0, a.jsx)("rect", {
                    width: "20",
                    height: "12.2531",
                    fill: "white",
                    transform: "translate(4 8)",
                  }),
                }),
              }),
            ],
          });
        },
        as =
          "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAIGNIUk0AAHomAACAhAAA+gAAAIDoAAB1MAAA6mAAADqYAAAXcJy6UTwAAAAGYktHRAD/AP8A/6C9p5MAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAHdElNRQfoDAIVODUC+w+GAAAGsUlEQVRYw6WXbYwWVxXHf+fOLAtCXYS2QJdIaClipGCTknXXNqBQMVHbfmhItH4Aral+IAEaG03UxJgYKQJGTUxtDWjaxDSNtcZqIGDwpRuW1oYiVqpdpZSlpC3qysu+PHPP3w/3mXnmeXZbPzjJZO7cefn/z/mfe865xlscq3dGDIguGiHLaMQVLja4s87FShcLo5jtApdddnHexUmHIy475JmdUkPRAQMu7gzT4ljnxJpdk0QPmMFkyAKN2OfOFpc2uuh1J3MZDrjAvXmVEQUuoosRxw642FcEG7IoDxiFxNiu8NYE+vcUYIFYRKKs113bXWx2Z34CoQZsVHOiCZ7mopdzdsFhv8NexEgRDHMxUSNREbh1bwNZwBsFblmfu/a4a6AEENYO5i3AOoEWeEUCF4MOOxBDMQAOk99OJALA2u80sBCwWGBZWG/yRwMaCAbBIAsQTJT3gea1OWfNeaPzvjoHEI85rA8ObtB1v7cIdJkIHgkh9AXpocy0LJjIKvB2wPpZB0v3wkrw5jdNEjeYeMhFX3BAyfn2ke9NUrgB9LrrcZcGJFCld4fWNddXbvbWfWzGR6xJFZsBGh0cBh3bBIxIEGTQ3W0h4NuDaSAzyAxCmGq11Vzf5uaa1aG8p+WFtrEYQGwvjICJkAEqvC+YNmcmMlMNvEaCdrcbyUvQAWDTjVuESHObM6cPGWHmzDwLaEtmzG9Z3qF1zUpXmuuZBb1z4bqeNC6f0WE1NtUTwHzEloiy3BvFisy0sYoLlQtT6XW15md2Qf9SY+2Ngfdca/TMSm/9ewz+/Boc/It45h/i4kSTsKw90SQJsPTvjSZbkWemDW7qTRZ0JEYJWSKxZJ7xmf6M224MzMzbX1s8F1YugjtvMg6eErt/4/z1jUrz1rXUKxnZC2zIg2mdBTK1mFUOKC1fOt/48kdzVixIz86Nij+eEacvpJWyZJ5xy7th8VzjjpuMJfMCW58QL73ekXPVlhsyE+vyzFiplJyauEIyrGIquruMq7qTxk+dcB495rzyTzFepCUWLIFv/kBg081Gd55WUk1IDGFTS89K++TDYxddzKnWcbluHd450xgdh7EGrOo1rr868PMTzqWJRGZ2d8oB/xpL33Xnxl2rjeNn4blXRXduzJ4B5y+28kWscAwXl+yeR654FFZPHoUb710YuPeDOUdPO48di1xptKpeEeHqOcYXNwQKGd88EDk3mqxtxPSfGRlsXRtYt8z4ytPOH/7eqpg1Aso7fYKgK4NPrMpYvsC4/poMA34yVJIQC3sCD9yecdsNyaV5yPj6ryJnR1PAvSNP4J+/1cgDfLbfePaMGGtM7Qdyl12WmKOmXgKKAp54vmBRTxfLrjE+tSYjBPjRM5FrrzIeuD2jf2lLzw8vN4JlfPVp581LsO1DgXv7jSzAiXPw/d+JiYLpjsu26Yfjf5O0rF5WoxsNT9G/bX0XKxakmPjlSee6HlizJJXSX7/oRDc+vjKR+f2wODcKd78/gR8/C9uedF44myJxmhh4OY/ipMQyqaWxmjn95TfEroMFOzbkvG+RceeqViPx1Aln1yEnOow1AnffHCpJAJ5/Vex4UvzptZRdY/O/1dJIS/NkcNmR6MTYah6qzseA4TfFtw4UvHBW1bc/O+7sPhwZHYf/jMODh5yfPudVbXj2TAJ/8XxrOZagNamj4Ei2/GNfuyRxh8t6BG2l15up+MIVODEiFr8rcPS0+O6RBF6mrrEGHHtFzOo2Lo7Dl37hvPQ6mNV6R9JYKgnYWcE37K5HlE2OT/5A0udaPUBHH+BQOMzuNsYLuDyZflTW+fTcmJFDHhJhaZqewMuewXDxcDR9IYyPN6Jj+6K4MF2vV8qBtZJScqVRNi6lpGONVJis5mpKi1WbgwsY+zIsBpcR8mzIZfuTRVZrtdu9odrptR/Xx5XONXJqBmCN0P6YMUQq9WJiwt0Je102WHdbpxSqydMObBWYdwDWLVcqcIMYe3NPjg0Ht84od0Ajju1w2XCr9e6QoqM9V23ZtnmI6cfAMMb9AY0YEHdb6oobEh4y3H3Ize6LsmGvN5IdUnhttdQ9UVrfLk/ljWEZ9wXsqAdQk1EA+O22GcgdZTke/bAs3OPY4HSdcB20HhvVtTMu0jmI8ekAhz2IICj2hKpNqI60NcuIRUHEej1quzubXa2tmZhenrfZmv3YYQ9ipDAIgvHptmblccuDjdRcmjFpWbDi/9ycZjZkRbk5jYztai/AUwiUx+qdEQB/m+25i9lxyvbcjrg45Lmd0uT/3p7/Fw6ODf+WO019AAAAJXRFWHRkYXRlOmNyZWF0ZQAyMDI0LTEyLTAyVDIxOjU2OjQ4KzAwOjAwMVpslgAAACV0RVh0ZGF0ZTptb2RpZnkAMjAyNC0xMi0wMlQyMTo1Njo0OCswMDowMEAH1CoAAAAodEVYdGRhdGU6dGltZXN0YW1wADIwMjQtMTItMDJUMjE6NTY6NTMrMDA6MDDZv6GRAAAAAElFTkSuQmCC";
      class al extends nF {
        async initialize() {
          let e = await this.createProvider();
          (this.provider = e),
            this.proxyProvider.setWalletProvider(e),
            this.subscribeListeners(),
            e.session &&
              (this.walletProvider?.session?.peer.metadata.url &&
                ((this.walletEntry = nJ(
                  this.walletProvider?.session?.peer.metadata.url
                )),
                (this.walletClientType = this.walletEntry?.slug || "unknown")),
              (this.connected = !0),
              await this.syncAccounts()),
            (this.initialized = !0),
            this.emit("initialized");
        }
        async connect(e) {
          return (
            e.showPrompt && (await this.promptConnection()),
            this.getConnectedWallet()
          );
        }
        async isConnected() {
          return !!this.walletProvider?.connected;
        }
        get walletBranding() {
          let e = this.walletProvider?.session?.peer.metadata.icons?.[0];
          return {
            name:
              na(this.walletProvider?.session?.peer.metadata.name || "") ||
              "WalletConnect",
            icon: "string" == typeof e ? e : as,
            id:
              this.walletProvider?.session?.peer.metadata.name.toLowerCase() ||
              "wallet_connect_v2",
          };
        }
        async resetConnection(e) {
          this.walletProvider &&
            this.walletProvider.connected &&
            (await this.walletProvider.disconnect(),
            (this.walletProvider.signer.session = void 0),
            (this.walletClientType = e),
            (this.redirectUri = void 0),
            (this.fallbackUniversalRedirectUri = void 0),
            (function () {
              try {
                localStorage.removeItem(ti);
              } catch {}
            })(),
            this.onDisconnect());
        }
        async promptConnection() {
          if (this.provider)
            return new Promise((e, t) => {
              (async () => {
                let t = "",
                  n = await Promise.race([
                    this.walletProvider?.enable(),
                    this.proxyProvider.walletTimeout(),
                  ]);
                if ((n?.length && (t = n[0]), !t || "" === t))
                  throw new eh.x("Unable to retrieve address");
                this.walletProvider?.session?.peer.metadata.url &&
                  ((this.walletEntry = nJ(
                    this.walletProvider?.session?.peer.metadata.url
                  )),
                  (this.walletClientType = this.walletEntry?.slug || "unknown"),
                  (this.proxyProvider.rpcTimeoutDuration = n_(
                    this.rpcConfig,
                    this.walletClientType
                  ))),
                  (this.connected = !0),
                  await this.syncAccounts(n),
                  e();
              })().catch((e) => {
                t(e ? nk(e) : new eh.x("Unknown error during connection"));
              });
            });
        }
        disconnect() {
          this.walletProvider
            ?.disconnect()
            .then(() => this.onDisconnect())
            .catch(() =>
              console.warn("Unable to disconnect WalletConnect provider")
            );
        }
        get walletProvider() {
          return this.proxyProvider.walletProvider;
        }
        setWalletProvider(e) {
          this.proxyProvider.setWalletProvider(e);
        }
        async createProvider() {
          let e = {};
          for (let t of this.chains) {
            let n = ns(t.id, this.chains, this.rpcConfig, this.privyAppId);
            n && (e[t.id] = n);
          }
          let t = this.shouldEnforceDefaultChainOnConnect
              ? [this.defaultChain.id]
              : [],
            n = this.chains.map((e) => e.id),
            a = await eX.Gn.init({
              projectId: this.walletConnectCloudProjectId,
              chains: t,
              optionalChains: n,
              optionalEvents: eX.gy,
              optionalMethods: eX.lI,
              rpcMap: e,
              showQrModal: !1,
              metadata: {
                description: this.privyAppName,
                name: this.privyAppName,
                url: window.location.origin,
                icons: [],
              },
            });
          return (
            a.on("display_uri", (e) => {
              if (
                (a.signer.abortPairingAttempt(),
                (function () {
                  try {
                    localStorage.removeItem(ti);
                  } catch {}
                })(),
                !this.showPrivyQrModal)
              )
                throw new eh.x(
                  "WalletConnect modal not available - Privy handles wallet connections through its own UI"
                );
              if (eC.tq && this.walletEntry) {
                let { redirect: t, href: n } = (function (e, t) {
                  let n = ta(t);
                  if (n.deepLink) return ts(n.deepLink, e);
                  if (n.universalLink) return tl(n.universalLink, e);
                  throw new eh.P(`Unsupported wallet ${t.id}`);
                })(e, this.walletEntry);
                tc(t, "_self"),
                  (function ({ href: e, name: t }) {
                    try {
                      localStorage.setItem(
                        ti,
                        JSON.stringify({ href: e, name: t })
                      );
                    } catch {}
                  })({
                    href: n,
                    name:
                      this.walletEntry.metadata?.shortName ||
                      this.walletEntry.name,
                  });
                let a = tr(e, this.walletEntry);
                return (
                  (this.redirectUri = t),
                  (this.fallbackUniversalRedirectUri = a?.redirect),
                  this.showPrivyQrModal({ native: t, universal: t })
                );
              }
              if (((this.redirectUri = void 0), this.walletEntry)) {
                let t = tr(e, this.walletEntry);
                this.fallbackUniversalRedirectUri = t?.redirect;
              }
              this.showPrivyQrModal({ native: e, universal: void 0 });
            }),
            a.on("connect", () => {
              a.session?.peer.metadata.url &&
                ((this.walletEntry = nJ(a.session?.peer.metadata.url)),
                (this.walletClientType = this.walletEntry?.slug || "unknown"));
            }),
            a
          );
        }
        async enableProvider() {
          return this.walletProvider?.connected
            ? Promise.resolve(this.walletProvider.accounts)
            : await this.walletProvider?.enable();
        }
        setWalletEntry(e, t) {
          (this.walletEntry = e), (this.showPrivyQrModal = t);
        }
        constructor({
          walletConnectCloudProjectId: e,
          rpcConfig: t,
          chains: n,
          defaultChain: a,
          shouldEnforceDefaultChainOnConnect: r,
          privyAppId: i,
          privyAppName: o,
          walletClientType: s,
        }) {
          super(s || "unknown", n, a, t),
            (this.connectorType = "wallet_connect_v2"),
            (this.privyAppId = i),
            (this.privyAppName = o),
            (this.walletConnectCloudProjectId = e),
            (this.rpcConfig = t),
            (this.shouldEnforceDefaultChainOnConnect = r),
            (this.proxyProvider = new nz(void 0, this.rpcTimeoutDuration)),
            s &&
              ((this.walletEntry = nK
                .getState()
                .listings.find(({ slug: e }) => n1(e) === n1(s))),
              (this.walletClientType = s));
        }
      }
      function ac({ src: e, ...t }) {
        return (0, a.jsx)("img", { src: e, ...t, style: { display: "none" } });
      }
      let ad = (0, C.createContext)({
          currentScreen: null,
          lastScreen: null,
          navigate: j.n,
          navigateBack: j.n,
          resetNavigation: j.n,
          setModalData: j.n,
          onUserCloseViaDialogOrKeybindRef: void 0,
        }),
        au = (e) => {
          let t = ar(),
            n = e.authenticated,
            [r, i] = (0, C.useState)(e.initialScreen);
          (0, C.useEffect)(() => {
            n ||
              !e.initialScreen ||
              e.initialScreen.isUnauthenticatedScreem ||
              e.setInitialScreen(null);
          }, [n]);
          let o = (0, C.useRef)(null);
          (0, C.useEffect)(() => {
            e.open || (o.current = null);
          }, [e.open]),
            (0, C.useEffect)(() => {
              o.current = null;
            }, [e.initialScreen]);
          let s = {
            data: e.data,
            setModalData: e.setModalData,
            currentScreen: e.initialScreen,
            lastScreen: r,
            navigate: (t, n = !0) => {
              e.setInitialScreen(t), n && i(e.initialScreen);
            },
            navigateBack: () => {
              e.setInitialScreen(r);
            },
            resetNavigation: () => {
              e.setInitialScreen(null), i(null);
            },
            onUserCloseViaDialogOrKeybindRef: o,
          };
          return (0, a.jsxs)(ad.Provider, {
            value: s,
            children: [
              ("string" == typeof t.appearance.logo ||
                "img" === t.appearance.logo?.type) &&
                (0, a.jsx)(ac, {
                  src:
                    "string" == typeof t.appearance.logo
                      ? t.appearance.logo
                      : t.appearance.logo.props.src,
                }),
              e.children,
            ],
          });
        },
        ap = () => (0, C.useContext)(ad),
        ah = {
          login: { onComplete: [], onError: [] },
          logout: { onSuccess: [] },
          connectWallet: { onSuccess: [], onError: [] },
          connectOrCreateWallet: { onSuccess: [], onError: [] },
          createWallet: { onSuccess: [], onError: [] },
          linkAccount: { onSuccess: [], onError: [] },
          update: { onSuccess: [], onError: [] },
          configureMfa: { onMfaRequired: [] },
          setWalletPassword: { onSuccess: [], onError: [] },
          setWalletRecovery: { onSuccess: [], onError: [] },
          signMessage: { onSuccess: [], onError: [] },
          signTypedData: { onSuccess: [], onError: [] },
          sendTransaction: { onSuccess: [], onError: [] },
          signTransaction: { onSuccess: [], onError: [] },
          accessToken: { onAccessTokenGranted: [], onAccessTokenRemoved: [] },
          oAuthAuthorization: { onOAuthTokenGrant: [] },
          fundWallet: { onUserExited: [] },
          fundSolanaWallet: { onUserExited: [] },
          customAuth: { onAuthenticated: [], onUnauthenticated: [] },
        },
        ag = (0, C.createContext)(void 0),
        af = () => (0, C.useContext)(ag);
      function am(e, t) {
        if (!t) return;
        let n = af().current[e];
        return (0, C.useEffect)(() => {
          for (let [a, r] of Object.entries(t))
            Object.prototype.hasOwnProperty.call(n, a) ||
              console.warn(`Invalid event type "${a}" for action "${e}"`),
              n[a]?.push(r);
          return () => {
            for (let [a, r] of Object.entries(t))
              Object.prototype.hasOwnProperty.call(n, a) ||
                console.warn(`Invalid event type "${a}" for action "${e}"`),
                (n[a] = n[a]?.filter((e) => e !== r));
          };
        }, [t]);
      }
      function ay(e, t, n, ...a) {
        for (let r of e.current[t][n]) r(...a);
      }
      function aw() {
        let e = af();
        return (t, n, ...a) => ay(e, t, n, ...a);
      }
      let av = T.zo.div.withConfig({
          displayName: "Grow",
          componentId: "sc-681ff332-0",
        })(["text-align:left;flex-grow:1;"]),
        ax = T.zo.div.withConfig({
          displayName: "AlignBottom",
          componentId: "sc-681ff332-1",
        })([
          "display:flex;flex-direction:column;justify-content:flex-end;flex-grow:1;",
        ]),
        ab = T.zo.div.withConfig({
          displayName: "LoginMethodContainer",
          componentId: "sc-681ff332-2",
        })([
          "display:flex;flex-direction:column;gap:8px;-ms-overflow-style:none;scrollbar-width:none;&::-webkit-scrollbar{display:none;}",
        ]),
        aC = (0, T.zo)(ab).withConfig({
          displayName: "LoginMethodContainerWithScrollShadows",
          componentId: "sc-681ff332-3",
        })(
          [
            "",
            " background-repeat:no-repeat;background-size:100% 32px,100% 16px;background-attachment:local,scroll;max-height:400px;overflow-y:auto;scrollbar-width:none;padding:3px;",
          ],
          (e) =>
            "light" === e.$colorScheme
              ? "background: linear-gradient(var(--privy-color-background), var(--privy-color-background) 70%) bottom, linear-gradient(rgba(0, 0, 0, 0) 20%, rgba(0, 0, 0, 0.06)) bottom;"
              : "dark" === e.$colorScheme
              ? "background: linear-gradient(var(--privy-color-background), var(--privy-color-background) 70%) bottom, linear-gradient(rgba(255, 255, 255, 0) 20%, rgba(255, 255, 255, 0.06)) bottom;"
              : void 0
        ),
        aj = (0, T.iv)([
          "&&{width:100%;font-size:16px;line-height:24px;min-height:56px;@media (min-width:440px){font-size:14px;}display:flex;gap:12px;align-items:center;color:var(--privy-color-foreground);padding:10px 12px;border:1px solid var(--privy-color-foreground-4) !important;border-radius:var(--privy-border-radius-md);transition:background-color 200ms ease;cursor:pointer;&:hover{background-color:var(--privy-color-background-2);}&:disabled{cursor:pointer;background-color:var(--privy-color-background-2);}}",
        ]),
        ak = T.zo.div.withConfig({
          displayName: "Subtitle",
          componentId: "sc-681ff332-4",
        })(["text-align:center;font-size:14px;margin-bottom:24px;"]),
        aT = T.zo.button
          .attrs({ className: "login-method-button" })
          .withConfig({
            displayName: "LoginMethodButton",
            componentId: "sc-681ff332-5",
          })(["", ""], aj),
        aA = T.zo.div.withConfig({
          displayName: "LoginMethodIconWrapper",
          componentId: "sc-681ff332-7",
        })(
          [
            "width:32px;height:32px;border-radius:",
            ";background:",
            ";display:flex;align-items:center;justify-content:center;flex-shrink:0;svg{width:",
            ";height:",
            ";color:",
            ";}",
          ],
          (e) => (e.$fullSize ? "0" : "4px"),
          (e) =>
            e.$fullSize ? "transparent" : "var(--privy-color-background-2)",
          (e) => (e.$fullSize ? "32px" : "18px"),
          (e) => (e.$fullSize ? "32px" : "18px"),
          (e) => (e.$fullSize ? "inherit" : "var(--privy-color-icon-muted)")
        ),
        aS = T.zo.div.withConfig({
          displayName: "Hide",
          componentId: "sc-681ff332-8",
        })(
          [
            "width:100%;height:100%;min-height:inherit;display:flex;flex-direction:column;",
            "",
          ],
          (e) => (e.$if ? "display: none;" : "")
        ),
        aI = T.zo.div.withConfig({
          displayName: "EmptyWalletState",
          componentId: "sc-681ff332-9",
        })(["width:100%;height:100%;padding:", ";"], (e) =>
          e.$withPadding ? "64px 0px" : "0px"
        ),
        aE = T.zo.div.withConfig({
          displayName: "Header",
          componentId: "sc-681ff332-10",
        })([
          "display:flex;flex-direction:column;align-items:center;justify-content:center;margin-bottom:32px;gap:12px;& h3{font-size:18px;font-style:normal;font-weight:600;line-height:24px;}& p{max-width:300px;font-size:14px;font-style:normal;font-weight:400;line-height:20px;}",
        ]);
      function aN(e) {
        return (0, a.jsx)("svg", {
          xmlns: "http://www.w3.org/2000/svg",
          viewBox: "0 0 460 40",
          ...e,
          children: (0, a.jsx)("g", {
            fill: e.color || "var(--privy-color-foreground)",
            children: (0, a.jsx)("path", {
              d: "M0 15.4v15.38h4.64V19.96h3.58c2.47 0 3.63-.01 3.77-.02 1-.08 1.49-.15 2.18-.3a9.45 9.45 0 0 0 4.6-2.37c1.66-1.57 2.64-3.87 2.81-6.56.02-.3.02-1.19 0-1.49-.1-1.77-.56-3.35-1.36-4.72A8.84 8.84 0 0 0 15.14.57c-.93-.3-1.75-.43-3.09-.54C11.9.02 10.2 0 5.93 0H0ZM10.85 4c1.85.05 3.1.45 4.16 1.3.22.17.54.49.69.68a5.97 5.97 0 0 1 1.19 3.13c.04.35.04 1.36 0 1.71-.08.68-.23 1.3-.44 1.85a4.8 4.8 0 0 1-1.09 1.68A5.63 5.63 0 0 1 12 15.92c-.6.08-.4.08-4.01.09H4.64V3.98h2.9c1.6 0 3.08 0 3.31.02ZM187.65 5.71v5.72h-.27l-.09-.14a15.9 15.9 0 0 0-1.21-1.73c-.43-.5-1-.95-1.7-1.36-.54-.3-1.05-.5-1.73-.63a8.98 8.98 0 0 0-1.7-.17 8.84 8.84 0 0 0-7.8 4.03 12.95 12.95 0 0 0-2.03 6.39c-.07.98-.06 2.15.02 3.13.2 2.47.87 4.53 2.02 6.25a8.98 8.98 0 0 0 10.22 3.65 6.5 6.5 0 0 0 2.8-1.93c.41-.51.84-1.1 1.1-1.55l.1-.17h.37v3.58h4.38V0h-4.48Zm-5.24 5.54c1.3.14 2.3.6 3.17 1.48.9.9 1.5 2.09 1.85 3.64.36 1.6.39 3.72.06 5.43a8.13 8.13 0 0 1-1.54 3.62 5.1 5.1 0 0 1-3.93 1.96 6.13 6.13 0 0 1-2.32-.31 5.87 5.87 0 0 1-3.33-3.5c-.39-1-.62-2.05-.72-3.32-.03-.32-.04-1.35-.02-1.73.08-1.56.4-2.91.96-4.05a6.2 6.2 0 0 1 1.06-1.58 5.08 5.08 0 0 1 3.6-1.66c.25-.02.9 0 1.16.02ZM210.07 15.39l.01 15.38h4.38l.01-3.57h.37l.09.15c.24.44.84 1.26 1.21 1.7a6.79 6.79 0 0 0 2.57 1.75 9.3 9.3 0 0 0 6.86-.49 9.28 9.28 0 0 0 4.05-4.07A13.05 13.05 0 0 0 231 21.6c.21-1.73.18-3.7-.09-5.32a13.03 13.03 0 0 0-1.5-4.3 9.1 9.1 0 0 0-3.75-3.63 9.15 9.15 0 0 0-4.43-.96 7.46 7.46 0 0 0-2.8.5A7.07 7.07 0 0 0 216 9.7c-.4.52-.82 1.12-1.1 1.59l-.07.14h-.27V0h-4.5Zm11.13-4.14c1.07.1 1.94.44 2.7 1.04a6.1 6.1 0 0 1 1.64 1.98c.43.84.78 2 .94 3.11.15 1.16.16 2.4.02 3.54a9.34 9.34 0 0 1-1.39 4.03 5.33 5.33 0 0 1-2.69 2.15c-.9.3-2.04.38-3.06.2a5.14 5.14 0 0 1-3.45-2.37 6.03 6.03 0 0 1-.45-.8c-.5-1.03-.8-2.2-.92-3.58-.04-.49-.06-.89-.05-1.53.01-.76.05-1.23.13-1.85.38-2.53 1.47-4.38 3.15-5.31a5.46 5.46 0 0 1 2.3-.63 10 10 0 0 1 1.13.02ZM69.05 2.17l-.01 2.77V7.7h-3.36v3.6h3.36v6.8l.01 7.15c.06 1.4.4 2.44 1.1 3.37a5.8 5.8 0 0 0 2.97 2.07c.91.3 1.83.42 2.9.38a8.71 8.71 0 0 0 2.66-.48l-.8-3.7-.38.06a4.96 4.96 0 0 1-2.43-.06c-.33-.1-.56-.25-.8-.49-.4-.41-.6-.88-.7-1.67-.02-.2-.02-.62-.03-6.82v-6.6h4.73V7.7h-4.73V2.16h-4.49ZM133.34 2.17V7.7h-3.39v3.6h3.38v6.9l.01 7.17a5.66 5.66 0 0 0 2.36 4.49c.85.6 2.03 1.03 3.26 1.17.85.1 2.03.05 2.81-.1.3-.06.75-.18 1-.26l.2-.06v-.05l-.81-3.67-.37.06a4.99 4.99 0 0 1-1.8.09c-.85-.13-1.32-.4-1.7-.97a2.63 2.63 0 0 1-.39-1.04c-.06-.4-.06 0-.06-7.1V11.3h4.7V7.7h-4.7l-.01-2.77V2.16h-4.49ZM293.41 2.36a14.56 14.56 0 0 0-13.7 16.07 14.59 14.59 0 0 0 21.86 11.08 14.5 14.5 0 0 0 7.11-14.07 14.61 14.61 0 0 0-6.53-10.73 14.49 14.49 0 0 0-8.74-2.35ZM350.8 2.36a10.17 10.17 0 0 0-7.56 4.2c-.16.2-.45.63-.58.83l-.05.1h-.47l-.01-4.36h-7.36v36.4h7.82V27.27h.49l.05.07a11.3 11.3 0 0 0 7.49 4.15 10.52 10.52 0 0 0 9.38-4.1c1.66-2.1 2.73-4.9 3.07-8.06.1-.87.13-1.4.13-2.37 0-.8 0-1.1-.07-1.76a15.95 15.95 0 0 0-3.23-8.72 12.8 12.8 0 0 0-1.85-1.84 10.49 10.49 0 0 0-7.26-2.28Zm-.94 6.05c1.27.15 2.33.65 3.2 1.5.98.96 1.67 2.31 2.03 4 .34 1.57.38 3.68.12 5.39a9.78 9.78 0 0 1-1.04 3.25c-.14.25-.44.69-.6.89a5.35 5.35 0 0 1-4.31 2.07 5.25 5.25 0 0 1-4.41-1.9 7.35 7.35 0 0 1-1.26-2.32 14.09 14.09 0 0 1-.62-4.83c.05-1.98.38-3.53 1.02-4.85a5.63 5.63 0 0 1 2.5-2.65c.66-.34 1.3-.5 2.14-.58.18-.02 1.04 0 1.23.03ZM363.63 3.1l-.01 3.2v3.16h1.43c1.26.01 1.44.02 1.54.04.42.09.66.28.79.62.08.23.08.08.08 2.96a911.57 911.57 0 0 1 .03 10.18v7.54h7.82v-7.4l.01-7.83c.03-.94.11-1.63.27-2.28.46-1.9 1.54-2.93 3.35-3.23.52-.08.2-.08 5-.08h4.4V3.08h-3.1c-3.48 0-3.91.01-4.67.1-1.83.2-3.04.79-3.96 1.88-.5.6-.9 1.32-1.26 2.26l-.06.17h-.46V3.09h-5.6c-4.46 0-5.6 0-5.6.02ZM390.8 16.95V30.8h3.87l3.86-.01V3.09h-7.73ZM400.6 3.1l-.01.4v.38l4.66 13.4 4.69 13.47.02.05h10.3l.03-.05 4.67-13.45 4.67-13.4V3.1h-7.43l-6.7 19.26h-.5l-3.28-9.5-3.31-9.64-.05-.12h-3.88l-3.88.01ZM430.98 3.1c-.01 0-.02.19-.02.4v.39l5.08 14.59c2.8 8.02 5.08 14.6 5.08 14.61.01.02-.22.02-4.8.02h-4.82v6.42h4.95c5.09 0 5.23 0 5.87-.06 3.15-.28 5.29-1.63 6.63-4.15.28-.55.44-.95.87-2.16L459 6.78l1-2.89v-.8h-7.43l-6.69 19.26h-.5l-3.27-9.46-3.31-9.64-.06-.16h-3.88l-3.88.01ZM36.57 7.36c-1.36.1-2.6.6-3.62 1.45a5.65 5.65 0 0 0-1.67 2.42l-.05.13H31V7.7h-4.35v23.08h4.5v-7.3c0-8 0-7.34.08-7.82a4.89 4.89 0 0 1 2.06-3.18c.83-.58 1.74-.89 2.87-.98a11.87 11.87 0 0 1 2.8.25H39v-4.3l-.21-.02c-.61-.07-1.74-.1-2.22-.07ZM51.08 7.41c-2.33.12-4.3.84-5.95 2.16a9.89 9.89 0 0 0-2.03 2.2 12.5 12.5 0 0 0-2 5.78 18.04 18.04 0 0 0 0 3.65 12.13 12.13 0 0 0 2.26 6.05 9.74 9.74 0 0 0 5 3.52c2.11.64 4.7.64 6.8 0a9.78 9.78 0 0 0 4.88-3.37c1.38-1.78 2.19-4 2.4-6.58.13-1.46.06-3.06-.18-4.42a11.24 11.24 0 0 0-3.58-6.6 10 10 0 0 0-5.75-2.35c-.56-.06-1.31-.07-1.85-.04Zm1.42 3.78c.88.1 1.62.34 2.28.75a6.13 6.13 0 0 1 1.99 2.15 10.31 10.31 0 0 1 1.2 5c.02 1.23-.12 2.44-.42 3.51a7.14 7.14 0 0 1-1.81 3.32c-.61.6-1.2.98-1.95 1.24a6 6 0 0 1-2 .3 5.7 5.7 0 0 1-2.72-.6 5 5 0 0 1-1.28-.94A7.1 7.1 0 0 1 46 22.73c-.57-1.99-.6-4.46-.08-6.5a7.24 7.24 0 0 1 2.03-3.67 5.13 5.13 0 0 1 3.35-1.4 11 11 0 0 1 1.2.03ZM92.05 7.4c-.96.06-1.56.15-2.3.33a9.62 9.62 0 0 0-6.09 4.66 13.5 13.5 0 0 0-1.71 7c0 .83 0 1.04.06 1.6.16 1.77.58 3.32 1.29 4.7A9.72 9.72 0 0 0 90.28 31c1.84.37 4.08.32 5.85-.13a9.07 9.07 0 0 0 5.02-3.1A7.64 7.64 0 0 0 102.5 25l-2.11-.39-2.11-.38-.08.13a4.72 4.72 0 0 1-2.35 2.55 6.3 6.3 0 0 1-2.23.58c-.29.03-1.13.03-1.44 0a6.35 6.35 0 0 1-3.02-1.04 5.93 5.93 0 0 1-2.02-2.43 8.44 8.44 0 0 1-.72-3.18v-.26h16.38v-.81c0-1.83-.06-2.76-.25-3.87-.2-1.22-.53-2.24-1.05-3.28a8.9 8.9 0 0 0-2.66-3.26 10.1 10.1 0 0 0-5.34-1.94 18.3 18.3 0 0 0-1.46-.03Zm1.3 3.75c1.2.13 2.19.55 3.05 1.3a5.8 5.8 0 0 1 1.78 2.96c.13.51.21 1.17.21 1.66v.15H86.43v-.12c.08-.97.3-1.78.72-2.61.5-1 1.2-1.8 2.14-2.42a5.32 5.32 0 0 1 2.9-.95c.2-.01.97 0 1.17.03ZM116.79 7.41c-2 .1-3.73.65-5.22 1.65a10.7 10.7 0 0 0-4.25 6.06 16.1 16.1 0 0 0-.5 5.8c.2 2.17.84 4.13 1.88 5.76.58.9 1.32 1.73 2.15 2.4a9.37 9.37 0 0 0 3.6 1.8 12.06 12.06 0 0 0 3.92.34 10.2 10.2 0 0 0 3.84-.95 8.31 8.31 0 0 0 4.76-6.75l.01-.04h-4.37l-.05.16a4.87 4.87 0 0 1-4.24 3.75c-.59.07-1.32.06-1.93-.05a5.47 5.47 0 0 1-3.5-2.27c-.56-.75-1-1.73-1.26-2.79a13.8 13.8 0 0 1-.16-5.24 7.77 7.77 0 0 1 2.1-4.3 5.48 5.48 0 0 1 2.15-1.3 6.4 6.4 0 0 1 3.89.1c.59.21 1.03.5 1.5.96a5.32 5.32 0 0 1 1.46 2.5l.04.15h4.37v-.06a8.22 8.22 0 0 0-5.31-6.94 10.98 10.98 0 0 0-4.88-.74ZM156.2 7.41a9.87 9.87 0 0 0-6 2.29 11.02 11.02 0 0 0-3.41 5.43c-.52 1.78-.68 3.9-.48 5.97.17 1.8.63 3.38 1.37 4.8a9.68 9.68 0 0 0 5.91 4.86c1.65.48 3.63.61 5.53.36 3.72-.49 6.55-2.62 7.56-5.69.12-.39.13-.42.1-.43-.02 0-4.13-.75-4.19-.75-.03 0-.04 0-.1.16-.18.42-.45.9-.72 1.22-.16.2-.49.53-.7.7-.67.54-1.5.9-2.43 1.08-.48.08-.83.11-1.41.11-.64 0-1.07-.04-1.6-.15a5.76 5.76 0 0 1-3.93-2.83 8 8 0 0 1-.99-3.79v-.16h16.38v-1.11l-.02-1.43c-.1-2.25-.53-4-1.35-5.59a9.24 9.24 0 0 0-6.18-4.75c-1.04-.26-2.2-.36-3.33-.3Zm1.45 3.74a5.35 5.35 0 0 1 3.66 1.94 6.1 6.1 0 0 1 1.38 4.01v.12h-11.97v-.06c0-.02 0-.14.02-.25a6.6 6.6 0 0 1 2.15-4.32 5.73 5.73 0 0 1 3.5-1.46c.25-.02 1 0 1.26.02ZM233.58 7.82l8.37 23.22a49.22 49.22 0 0 1-.67 1.9 5.36 5.36 0 0 1-1.14 1.8c-.41.4-.82.58-1.48.69-.27.04-1.03.03-1.35 0a8.05 8.05 0 0 1-1.1-.23l-1.08 3.67c0 .02.32.14.66.22.83.21 1.57.29 2.56.28.56-.01.8-.03 1.24-.1 2.71-.4 4.66-2.09 5.86-5.08l9.64-26.44c0-.02-4.82-.06-4.83-.05l-2.93 8.96-2.91 8.94h-.24l-.22-.65-2.91-8.95-2.7-8.3H233.53ZM293.05 35.8c-1.18.04-1.93.09-2.8.16-2.52.24-4.53.69-5.43 1.23-.7.41-.76.86-.2 1.28.88.66 3.29 1.19 6.36 1.4a48.55 48.55 0 0 0 5.75.05c3.47-.19 6.24-.78 7.11-1.5.22-.19.3-.34.3-.53 0-.1 0-.12-.04-.22-.35-.69-2.32-1.3-5.25-1.63a41.09 41.09 0 0 0-5.8-.24Zm0 0",
            }),
          }),
        });
      }
      let a_ = T.zo.span.withConfig({
        displayName: "TermsAndConditionsContainer",
        componentId: "sc-ff3bd734-0",
      })([
        "margin-top:16px;font-size:13px;text-align:center;color:var(--privy-color-foreground-3);display:block;&& > a{color:var(--privy-color-accent);}",
      ]);
      function aM({
        app: {
          legal: {
            privacyPolicyUrl: e,
            termsAndConditionsUrl: t,
            requireUsersAcceptTerms: n,
          },
        },
        alwaysShowImplicitConsent: r,
      }) {
        let i = !(!e || !t);
        return (!n || r) && (t || e)
          ? (0, a.jsxs)(a_, {
              children: [
                "By logging in I agree to the",
                " ",
                t &&
                  (0, a.jsx)("a", {
                    href: t,
                    target: "_blank",
                    children: i ? "Terms" : "Terms of Service",
                  }),
                i && " & ",
                e &&
                  (0, a.jsx)("a", {
                    href: e,
                    target: "_blank",
                    children: "Privacy Policy",
                  }),
              ],
            })
          : (0, a.jsx)(a_, {});
      }
      let aF = ({ className: e }) => {
          let { appearance: t } = ar();
          return (0, a.jsx)(aL, {
            className: e,
            children:
              t.footerLogo ??
              (0, a.jsx)(az, {
                href: "https://www.privy.io/",
                target: "_blank",
                id: "protected-by-privy",
                children: (0, a.jsx)(aN, {
                  color: "currentColor",
                  height: 13,
                  width: 150,
                }),
              }),
          });
        },
        az = T.zo.a.withConfig({
          displayName: "PrivyLink",
          componentId: "sc-ff3bd734-1",
        })(["&&{padding:0;color:var(--privy-color-foreground-3);}"]),
        aL = T.zo.div.withConfig({
          displayName: "ModalFooter",
          componentId: "sc-ff3bd734-2",
        })([
          "display:flex;align-items:center;justify-content:center;padding-top:8px;padding-bottom:12px;gap:8px;font-size:13px;&& a{padding:0.5rem 0;&:hover{text-decoration:none;}}@media all and (display-mode:standalone){padding-bottom:30px;}",
        ]),
        aP = ({ success: e, fail: t }) =>
          (0, a.jsxs)(aW, {
            children: [
              (0, a.jsx)(aD, {
                children: (0, a.jsx)(aB, {
                  className: e ? "success" : t ? "fail" : "",
                }),
              }),
              (0, a.jsx)(aD, {
                children: (0, a.jsx)(aR, {
                  className: e ? "success" : t ? "fail" : "",
                }),
              }),
            ],
          }),
        aD = T.zo.span.withConfig({
          displayName: "PositionedAbsoluteLoader",
          componentId: "sc-aba6339d-0",
        })(["&&{position:absolute;top:0;left:0;z-index:2;}"]),
        aW = T.zo.span.withConfig({
          displayName: "ConnectionLoaderContainer",
          componentId: "sc-aba6339d-1",
        })(["position:relative;width:82px;height:82px;display:inline-block;"]),
        aR = T.zo.span.withConfig({
          displayName: "Loader",
          componentId: "sc-aba6339d-2",
        })(
          [
            "&&{width:82px;height:82px;border-width:4px;border-style:solid;border-color:",
            ";border-bottom-color:transparent;border-radius:50%;display:inline-block;box-sizing:border-box;animation:rotation 1.2s linear infinite;transition:border-color 800ms;}@keyframes rotation{0%{transform:rotate(0deg);}100%{transform:rotate(360deg);}}&&&.success{border-color:var(--privy-color-icon-success);border-bottom-color:var(--privy-color-icon-success);}&&&.fail{border-color:var(--privy-color-icon-error);border-bottom-color:var(--privy-color-icon-error);}",
          ],
          (e) => e.color ?? "var(--privy-color-icon-subtle)"
        ),
        aB = (0, T.zo)(aR).withConfig({
          displayName: "LoaderFaint",
          componentId: "sc-aba6339d-3",
        })(
          [
            "&&{border-bottom-color:",
            ";border-color:",
            ";animation:none;opacity:0.5;}",
          ],
          (e) => e.color ?? "var(--privy-color-border-default)",
          (e) => e.color ?? "var(--privy-color-border-default)"
        ),
        aU = (e) =>
          (0, a.jsx)(aO, {
            color: e.color || "var(--privy-color-foreground-3)",
          }),
        aO = (0, T.zo)(aR).withConfig({
          displayName: "StyledButtonLoader",
          componentId: "sc-aba6339d-4",
        })([
          "&&{height:1rem;width:1rem;margin:2px 0;border-width:1.5px;transition:border-color 200ms ease;}",
        ]),
        aH = ({
          variant: e = "primary",
          size: t = "lg",
          children: n,
          success: r,
          ...i
        }) => {
          switch (e) {
            case "secondary":
              return (0, a.jsx)(aY, { size: t, ...i, children: n });
            case "error":
              return (0, a.jsx)(aY, { $warn: !0, size: t, ...i, children: n });
            case "muted":
              return (0, a.jsx)(aQ, { size: t, ...i, children: n });
            default:
              return (0, a.jsx)(a$, { size: t, success: r, ...i, children: n });
          }
        },
        aV = T.zo.button.withConfig({
          displayName: "BaseButton",
          componentId: "sc-e537b447-0",
        })(
          [
            "display:flex;flex-direction:row;align-items:center;justify-content:center;user-select:none;&{width:auto;cursor:pointer;border-radius:",
            ";font-size:14px;font-style:normal;font-weight:500;line-height:22px;letter-spacing:-0.016px;}&&{height:",
            ";padding:0 ",
            ";}",
          ],
          ({ $size: e }) =>
            "sm" === e ? "6px" : "var(--privy-border-radius-sm)",
          ({ $size: e }) => ("sm" === e ? "28px" : "48px"),
          ({ $size: e }) => ("sm" === e ? "10px" : "16px")
        ),
        a$ = ({
          children: e,
          loading: t,
          disabled: n,
          success: r,
          size: i = "lg",
          loadingText: o = "Loading...",
          as: s,
          onClick: l,
          ...c
        }) => {
          let d = "a" === s,
            u = !(!t && !n);
          return (0, a.jsx)(aG, {
            as: s,
            disabled: d ? void 0 : u,
            "aria-disabled": d ? u : void 0,
            $success: r,
            $size: i,
            onClick: (e) => {
              d && u ? e.preventDefault() : l?.(e);
            },
            ...c,
            children: t
              ? (0, a.jsxs)(a.Fragment, {
                  children: [
                    (0, a.jsx)(aU, {}),
                    o
                      ? (0, a.jsx)("span", {
                          style: { marginLeft: "8px" },
                          children: o,
                        })
                      : null,
                  ],
                })
              : e,
          });
        },
        aZ = ({ children: e, loading: t, disabled: n, ...r }) =>
          (0, a.jsx)(aq, {
            disabled: n,
            ...r,
            children: t
              ? (0, a.jsx)(aU, {
                  color: "var(--privy-color-foreground-accent)",
                })
              : e,
          }),
        aq = (0, T.zo)(aV).withConfig({
          displayName: "StyledPrimaryButtonWithoutGray",
          componentId: "sc-e537b447-1",
        })([
          "position:relative;&&{background-color:var(--privy-color-accent);color:var(--privy-color-foreground-accent);transition:background-color 200ms ease;}&:hover{background-color:var(--privy-color-accent-dark);}&:active{background-color:var(--privy-color-accent-dark);}&:disabled,&:hover:disabled,&:active:disabled{cursor:not-allowed;color:var(--privy-color-foreground-disabled);background-color:var(--privy-color-accent-dark);}",
        ]),
        aG = (0, T.zo)(aV).withConfig({
          displayName: "StyledPrimaryButton",
          componentId: "sc-e537b447-2",
        })(
          [
            "position:relative;&&{background-color:",
            ";color:var(--privy-color-foreground-accent);transition:background-color 200ms ease;}&:hover{background-color:",
            ";}&:active{background-color:",
            ";}&:focus{outline:none;box-shadow:0 0 0 3px #949df9;}&:disabled{background-color:var(--privy-color-background-2);border:1px solid var(--privy-color-border-default);color:var(--privy-color-foreground-disabled);cursor:not-allowed;}&:hover:disabled,&:active:disabled{background-color:var(--privy-color-background-2);border:1px solid var(--privy-color-border-default);color:var(--privy-color-foreground-disabled);cursor:not-allowed;}",
            "",
          ],
          (e) =>
            e.$warn
              ? "var(--privy-color-error-dark)"
              : "var(--privy-color-accent)",
          (e) =>
            e.$warn
              ? "var(--privy-color-error-dark)"
              : "var(--privy-color-accent-dark)",
          (e) =>
            e.$warn
              ? "var(--privy-color-error-dark)"
              : "var(--privy-color-accent-dark)",
          (e) =>
            e.disabled &&
            (0, T.iv)([
              "&&&,&&&:hover,&&&:active{background-color:var(--privy-color-background-2);border:1px solid var(--privy-color-border-default);color:var(--privy-color-foreground-disabled);cursor:not-allowed;}",
            ])
        ),
        aY = ({
          children: e,
          loading: t,
          disabled: n,
          size: r = "lg",
          loadingText: i = "Loading...",
          as: o,
          onClick: s,
          ...l
        }) => {
          let c = "a" === o,
            d = !(!t && !n);
          return (0, a.jsx)(aK, {
            as: o,
            disabled: c ? void 0 : d,
            "aria-disabled": c ? d : void 0,
            $size: r,
            onClick: (e) => {
              c && d ? e.preventDefault() : s?.(e);
            },
            ...l,
            children: t
              ? (0, a.jsxs)(a.Fragment, {
                  children: [
                    (0, a.jsx)(aU, {}),
                    i
                      ? (0, a.jsx)("span", {
                          style: { marginLeft: "8px" },
                          children: i,
                        })
                      : null,
                  ],
                })
              : e,
          });
        },
        aQ = ({
          children: e,
          loading: t,
          disabled: n,
          size: r = "lg",
          loadingText: i = "Loading...",
          as: o,
          onClick: s,
          ...l
        }) => {
          let c = "a" === o,
            d = !(!t && !n);
          return (0, a.jsx)(aX, {
            as: o,
            disabled: c ? void 0 : d,
            "aria-disabled": c ? d : void 0,
            $size: r,
            onClick: (e) => {
              c && d ? e.preventDefault() : s?.(e);
            },
            ...l,
            children: t
              ? (0, a.jsxs)(a.Fragment, {
                  children: [
                    (0, a.jsx)(aU, {}),
                    i
                      ? (0, a.jsx)("span", {
                          style: { marginLeft: "8px" },
                          children: i,
                        })
                      : null,
                  ],
                })
              : e,
          });
        },
        aK = (0, T.zo)(aV).withConfig({
          displayName: "StyledSecondaryButton",
          componentId: "sc-e537b447-3",
        })(
          [
            "&&{border-width:1px;border-style:solid;border-color:",
            ";background-color:var(--privy-color-background);color:",
            ";transition:border-color 200ms ease,color 200ms ease,background-color 200ms ease;}&:hover{border-color:",
            ";background-color:",
            ";color:",
            ";}&:active{border-color:",
            ";background-color:",
            ";color:",
            ";}&:disabled{border-color:var(--privy-color-border-default);background-color:var(--privy-color-background-2);color:var(--privy-color-foreground-disabled);cursor:not-allowed;}&:hover:disabled,&:active:disabled{border-color:var(--privy-color-border-default);background-color:var(--privy-color-background-2);color:var(--privy-color-foreground-disabled);cursor:not-allowed;}",
            "",
          ],
          (e) =>
            e.$warn
              ? "var(--privy-color-border-error)"
              : "var(--privy-color-accent)",
          (e) =>
            e.$warn
              ? "var(--privy-color-error-dark)"
              : "var(--privy-color-accent)",
          (e) =>
            e.$warn
              ? "var(--privy-color-border-error)"
              : "var(--privy-color-border-interactive-hover)",
          (e) =>
            e.$warn
              ? "var(--privy-color-error-light)"
              : "var(--privy-color-info-bg-hover)",
          (e) =>
            e.$warn
              ? "var(--privy-color-error-dark)"
              : "var(--privy-color-accent)",
          (e) =>
            e.$warn
              ? "var(--privy-color-border-error)"
              : "var(--privy-color-border-interactive)",
          (e) =>
            e.$warn
              ? "var(--privy-color-error-bg-hover)"
              : "var(--privy-color-info-bg)",
          (e) =>
            e.$warn
              ? "var(--privy-color-error-dark)"
              : "var(--privy-color-accent)",
          (e) =>
            e.disabled &&
            (0, T.iv)([
              "&&&,&&&:hover,&&&:active{border-color:var(--privy-color-border-default);background-color:var(--privy-color-background-2);color:var(--privy-color-foreground-disabled);cursor:not-allowed;}",
            ])
        ),
        aX = (0, T.zo)(aV).withConfig({
          displayName: "StyledMutedButton",
          componentId: "sc-e537b447-4",
        })(
          [
            "&&{border-width:1px;border-style:solid;border-color:var(--privy-color-border-default);background-color:transparent;color:var(--privy-color-text-muted);transition:border-color 200ms ease,color 200ms ease,background-color 200ms ease;}&:hover{border-color:var(--privy-color-border-default);background-color:var(--privy-color-info-bg-hover);color:var(--privy-color-foreground-2);}&:active{border-color:var(--privy-color-border-default);background-color:var(--privy-color-info-bg);color:var(--privy-color-foreground-2);}&:focus{outline:none;box-shadow:0 0 0 3px #949df9;}&:disabled{border-color:var(--privy-color-border-default);background-color:var(--privy-color-background-2);color:var(--privy-color-foreground-disabled);cursor:not-allowed;}&:hover:disabled,&:active:disabled{border-color:var(--privy-color-border-default);background-color:var(--privy-color-background-2);color:var(--privy-color-foreground-disabled);cursor:not-allowed;}",
            "",
          ],
          (e) =>
            e.disabled &&
            (0, T.iv)([
              "&&&,&&&:hover,&&&:active{border-color:var(--privy-color-border-default);background-color:var(--privy-color-background-2);color:var(--privy-color-foreground-disabled);cursor:not-allowed;}",
            ])
        ),
        aJ = ({
          children: e,
          onClick: t,
          disabled: n,
          isSubmitting: r,
          ...i
        }) =>
          (0, a.jsxs)(a0, {
            $isSubmitting: r,
            onClick: t,
            disabled: n,
            ...i,
            children: [
              (0, a.jsx)("span", { children: e }),
              (0, a.jsx)("span", { children: (0, a.jsx)(aU, {}) }),
            ],
          }),
        a0 = T.zo.button.withConfig({
          displayName: "StyledEmbeddedButton",
          componentId: "sc-e537b447-7",
        })(
          [
            "&&{color:var(--privy-color-accent);font-size:16px;font-style:normal;font-weight:500;line-height:24px;cursor:pointer;border-radius:0px var(--privy-border-radius-mdlg) var(--privy-border-radius-mdlg) 0px;border:none;transition:color 200ms ease;@media (min-width:441px){font-size:14px;}:hover{color:var(--privy-color-accent-dark);}&& > :first-child{opacity:",
            ";}&& > :last-child{position:absolute;display:flex;top:50%;left:50%;transform:translate3d(-50%,-50%,0);opacity:",
            ";}:disabled,:hover:disabled{color:var(--privy-color-foreground-disabled);cursor:not-allowed;}}",
          ],
          (e) => (e.$isSubmitting ? 0 : 1),
          (e) => (e.$isSubmitting ? 1 : 0)
        ),
        a1 = ({ backFn: e }) =>
          (0, a.jsx)("div", {
            children: (0, a.jsx)(a5, {
              onClick: e,
              children: (0, a.jsx)(em.Z, {
                height: "16px",
                width: "16px",
                strokeWidth: 2,
              }),
            }),
          }),
        a2 = ({ infoFn: e }) =>
          (0, a.jsx)("div", {
            children: (0, a.jsx)(a6, {
              "aria-label": "info",
              onClick: e,
              children: (0, a.jsx)(ey.Z, {
                height: "22px",
                width: "22px",
                strokeWidth: 2,
              }),
            }),
          }),
        a3 = (e) =>
          (0, a.jsx)("div", {
            children: (0, a.jsx)(a5, {
              "aria-label": "close modal",
              onClick: e.onClose,
              children: (0, a.jsx)(ew.Z, {
                height: "16px",
                width: "16px",
                strokeWidth: 2,
              }),
            }),
          }),
        a4 = ({
          backFn: e,
          infoFn: t,
          onClose: n,
          title: r,
          closeable: i = !0,
          className: o,
        }) => {
          let { closePrivyModal: s } = (0, j.u)(),
            l = ar();
          return (0, a.jsxs)(a8, {
            className: o,
            children: [
              (0, a.jsxs)(a7, {
                children: [
                  e && (0, a.jsx)(a1, { backFn: e }),
                  t && (0, a.jsx)(a2, { infoFn: t }),
                ],
              }),
              r && (0, a.jsx)(re, { id: "privy-dialog-title", children: r }),
              (0, a.jsx)(a9, {
                children:
                  !l.render.standalone &&
                  i &&
                  (0, a.jsx)(a3, { onClose: n || (() => s()) }),
              }),
            ],
          });
        },
        a5 = T.zo.button.withConfig({
          displayName: "StyledButton",
          componentId: "sc-e033e17a-0",
        })([
          "&&{cursor:pointer;display:flex;opacity:0.6;background-color:var(--privy-color-background-2);border-radius:var(--privy-border-radius-full);padding:4px;> svg{margin:auto;color:var(--privy-color-foreground);}:hover{opacity:1;}}",
        ]),
        a6 = (0, T.zo)(a5).withConfig({
          displayName: "TransparentStyledButton",
          componentId: "sc-e033e17a-1",
        })(["&&{background-color:transparent;}"]),
        a8 = T.zo.div.withConfig({
          displayName: "StyledHeader",
          componentId: "sc-e033e17a-2",
        })([
          "padding:16px 0;display:flex;align-items:center;justify-content:space-between;h2{font-size:16px;line-height:24px;font-weight:600;color:var(--privy-color-foreground);}",
        ]),
        a7 = T.zo.div.withConfig({
          displayName: "LeftActionContainer",
          componentId: "sc-e033e17a-3",
        })(["flex:1;align-items:center;display:flex;gap:8px;"]),
        a9 = T.zo.div.withConfig({
          displayName: "RightActionContainer",
          componentId: "sc-e033e17a-4",
        })(["flex:1;display:flex;justify-content:flex-end;"]),
        re = T.zo.div.withConfig({
          displayName: "TitleContainer",
          componentId: "sc-e033e17a-5",
        })([
          "overflow:hidden;white-space:nowrap;max-width:100%;text-overflow:ellipsis;text-align:center;color:var(--privy-color-foreground-2);",
        ]),
        rt = ({ size: e, centerIcon: t }) =>
          (0, a.jsx)(rn, {
            $size: e,
            children: (0, a.jsxs)(ra, {
              children: [
                (0, a.jsx)(ri, {}),
                (0, a.jsx)(ro, {}),
                t ? (0, a.jsx)(rr, { children: t }) : null,
              ],
            }),
          }),
        rn = T.zo.div.withConfig({
          displayName: "LoadingContainer",
          componentId: "sc-ebc93df8-0",
        })(
          [
            "--spinner-size:",
            ";display:inline-flex;justify-content:center;align-items:center;@media all and (display-mode:standalone){margin-bottom:30px;}",
          ],
          (e) => (e.$size ? e.$size : "96px")
        ),
        ra = T.zo.div.withConfig({
          displayName: "SpinnerContainer",
          componentId: "sc-ebc93df8-1",
        })([
          "position:relative;height:var(--spinner-size);width:var(--spinner-size);opacity:1;animation:fadein 200ms ease;",
        ]),
        rr = T.zo.div.withConfig({
          displayName: "CenterIconContainer",
          componentId: "sc-ebc93df8-2",
        })([
          "position:absolute;top:0;right:0;bottom:0;left:0;display:flex;align-items:center;justify-content:center;svg,img{width:calc(var(--spinner-size) * 0.4);height:calc(var(--spinner-size) * 0.4);border-radius:var(--privy-border-radius-full);}",
        ]),
        ri = T.zo.div.withConfig({
          displayName: "CircleFixed",
          componentId: "sc-ebc93df8-3",
        })([
          "position:absolute;top:0;right:0;bottom:0;left:0;width:var(--spinner-size);height:var(--spinner-size);&&{border:4px solid var(--privy-color-border-default);border-radius:50%;}",
        ]),
        ro = T.zo.div.withConfig({
          displayName: "CircleRotate",
          componentId: "sc-ebc93df8-4",
        })([
          "position:absolute;top:0;right:0;bottom:0;left:0;width:var(--spinner-size);height:var(--spinner-size);animation:spin 1200ms linear infinite;&&{border:4px solid;border-color:var(--privy-color-icon-subtle) transparent transparent transparent;border-radius:50%;}@keyframes spin{from{transform:rotate(0deg);}to{transform:rotate(360deg);}}",
        ]),
        rs = T.zo.div.withConfig({
          displayName: "ScreenRoot",
          componentId: "sc-cc9e9a32-0",
        })([
          "--screen-space:16px;--screen-space-lg:calc(var(--screen-space) * 1.5);position:relative;overflow:hidden;margin:0 calc(-1 * var(--screen-space));height:100%;border-radius:var(--privy-border-radius-lg);",
        ]),
        rl = T.zo.div.withConfig({
          displayName: "ScreenRootInner",
          componentId: "sc-cc9e9a32-1",
        })([
          "display:flex;flex-direction:column;gap:calc(var(--screen-space) * 1.5);width:100%;background:var(--privy-color-background);padding:0 var(--screen-space-lg) var(--screen-space);height:100%;border-radius:var(--privy-border-radius-lg);",
        ]),
        rc = T.zo.div.withConfig({
          displayName: "HeaderContainer",
          componentId: "sc-cc9e9a32-2",
        })(["position:relative;display:flex;flex-direction:column;"]),
        rd = (0, T.zo)(a4).withConfig({
          displayName: "StyledModalHeader",
          componentId: "sc-cc9e9a32-3",
        })(["margin:0 -8px;"]),
        ru = T.zo.div.withConfig({
          displayName: "BodyContainer",
          componentId: "sc-cc9e9a32-4",
        })(
          [
            "flex:1 1 auto;display:flex;flex-direction:column;overflow-y:auto;padding:3px;margin:-3px;&::-webkit-scrollbar{display:none;}scrollbar-gutter:stable both-edges;scrollbar-width:none;-ms-overflow-style:none;",
            " background-repeat:no-repeat;background-size:100% 32px,100% 16px;background-attachment:local,scroll;",
          ],
          ({ $colorScheme: e }) =>
            "light" === e
              ? "background: linear-gradient(var(--privy-color-background), var(--privy-color-background) 70%) bottom, linear-gradient(rgba(0, 0, 0, 0) 20%, rgba(0, 0, 0, 0.06)) bottom;"
              : "dark" === e
              ? "background: linear-gradient(var(--privy-color-background), var(--privy-color-background) 70%) bottom, linear-gradient(rgba(255, 255, 255, 0) 20%, rgba(255, 255, 255, 0.06)) bottom;"
              : void 0
        ),
        rp = T.zo.div.withConfig({
          displayName: "FooterContainer",
          componentId: "sc-cc9e9a32-5",
        })(["display:flex;flex-direction:column;gap:var(--screen-space-lg);"]),
        rh = T.zo.div.withConfig({
          displayName: "CenteredHeader",
          componentId: "sc-cc9e9a32-6",
        })([
          "text-align:center;display:flex;flex-direction:column;align-items:center;gap:var(--screen-space);",
        ]),
        rg = T.zo.div.withConfig({
          displayName: "TitleContainer",
          componentId: "sc-cc9e9a32-7",
        })(["display:flex;flex-direction:column;gap:4px;"]),
        rf = T.zo.h3.withConfig({
          displayName: "HeaderTitle",
          componentId: "sc-cc9e9a32-8",
        })([
          "&&{font-size:20px;line-height:32px;font-weight:500;color:var(--privy-color-foreground);margin:0;}",
        ]),
        rm = T.zo.p.withConfig({
          displayName: "HeaderSubtitle",
          componentId: "sc-cc9e9a32-9",
        })([
          "&&{margin:0;font-size:16px;font-weight:300;line-height:24px;color:var(--privy-color-foreground);}",
        ]),
        ry = T.zo.div.withConfig({
          displayName: "IconContainer",
          componentId: "sc-cc9e9a32-10",
        })(
          [
            "background:",
            ";border-radius:50%;width:64px;height:64px;display:flex;align-items:center;justify-content:center;",
          ],
          ({ $variant: e }) => {
            switch (e) {
              case "success":
                return "var(--privy-color-success-bg, #EAFCEF)";
              case "warning":
                return "var(--privy-color-warn, #FEF3C7)";
              case "error":
                return "var(--privy-color-error-bg, #FEE2E2)";
              case "loading":
              case "logo":
                return "transparent";
              default:
                return "var(--privy-color-background-2)";
            }
          }
        ),
        rw = T.zo.div.withConfig({
          displayName: "LogoContainer",
          componentId: "sc-cc9e9a32-11",
        })([
          "display:flex;align-items:center;justify-content:center;margin-bottom:var(--screen-space);img,svg{max-height:90px;max-width:180px;}",
        ]),
        rv = T.zo.div.withConfig({
          displayName: "LoadingWithIconContainer",
          componentId: "sc-cc9e9a32-12",
        })([
          "display:flex;flex-direction:column;justify-content:center;align-items:center;width:100%;height:82px;> div{position:relative;}> div > :first-child{position:relative;}> div > :last-child{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);}",
        ]),
        rx = ({ children: e, ...t }) =>
          (0, a.jsx)(rs, { children: (0, a.jsx)(rl, { ...t, children: e }) }),
        rb = T.zo.div.withConfig({
          displayName: "ProgressBarContainer",
          componentId: "sc-cc9e9a32-13",
        })([
          "position:absolute;top:0;left:calc(-1 * var(--screen-space-lg));width:calc(100% + calc(var(--screen-space-lg) * 2));height:4px;background:var(--privy-color-background-2);border-top-left-radius:inherit;border-top-right-radius:inherit;overflow:hidden;",
        ]),
        rC = (0, T.zo)(aF).withConfig({
          displayName: "StyledBlobbyFooter",
          componentId: "sc-cc9e9a32-14",
        })([
          "padding:0;&& a{padding:0;color:var(--privy-color-foreground-3);}",
        ]),
        rj = T.zo.div.withConfig({
          displayName: "ProgressBarFill",
          componentId: "sc-cc9e9a32-15",
        })(
          [
            "height:100%;width:",
            "%;background:var(--privy-color-foreground-3);border-radius:2px;transition:width 300ms ease-in-out;",
          ],
          ({ pct: e }) => e
        ),
        rk = ({ step: e }) =>
          e
            ? (0, a.jsx)(rb, {
                children: (0, a.jsx)(rj, {
                  pct: Math.min(100, (e.current / e.total) * 100),
                }),
              })
            : null;
      (rx.Header = ({
        title: e,
        subtitle: t,
        icon: n,
        iconVariant: r,
        iconLoadingStatus: i,
        showBack: o,
        onBack: s,
        showInfo: l,
        onInfo: c,
        showClose: d,
        onClose: u,
        step: p,
        ...h
      }) =>
        (0, a.jsxs)(rc, {
          ...h,
          children: [
            (0, a.jsx)(rd, {
              backFn: o ? s : void 0,
              infoFn: l ? c : void 0,
              onClose: d ? u : void 0,
              closeable: d,
            }),
            (n || r || e || t) &&
              (0, a.jsxs)(rh, {
                children: [
                  n || r
                    ? (0, a.jsx)(rx.Icon, {
                        icon: n,
                        variant: r,
                        loadingStatus: i,
                      })
                    : null,
                  (0, a.jsxs)(rg, {
                    children: [
                      e && (0, a.jsx)(rf, { children: e }),
                      t && (0, a.jsx)(rm, { children: t }),
                    ],
                  }),
                ],
              }),
            p && (0, a.jsx)(rk, { step: p }),
          ],
        })),
        (rx.Body = C.forwardRef(({ children: e, ...t }, n) =>
          (0, a.jsx)(ru, { ref: n, ...t, children: e })
        )),
        (rx.Body.displayName = "Screen.Body"),
        (rx.Footer = ({ children: e, ...t }) =>
          (0, a.jsx)(rp, { ...t, children: e })),
        (rx.Actions = ({ children: e, ...t }) =>
          (0, a.jsx)(rT, { ...t, children: e })),
        (rx.HelpText = ({ children: e, ...t }) =>
          (0, a.jsx)(rA, { ...t, children: e })),
        (rx.Watermark = () => (0, a.jsx)(rC, {})),
        (rx.Icon = ({ icon: e, variant: t = "subtle", loadingStatus: n }) =>
          "logo" === t && e
            ? (0, a.jsx)(
                rw,
                "string" == typeof e
                  ? { children: (0, a.jsx)("img", { src: e, alt: "" }) }
                  : C.isValidElement(e)
                  ? { children: e }
                  : { children: C.createElement(e) }
              )
            : "loading" === t
            ? e
              ? (0, a.jsx)(rv, {
                  children: (0, a.jsxs)("div", {
                    style: {
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    },
                    children: [
                      (0, a.jsx)(aP, { success: n?.success, fail: n?.fail }),
                      "string" == typeof e
                        ? (0, a.jsx)("span", {
                            style: {
                              background: `url('${e}') 0 0 / contain`,
                              height: "38px",
                              width: "38px",
                              borderRadius: "6px",
                              margin: "auto",
                              backgroundSize: "contain",
                            },
                          })
                        : C.isValidElement(e)
                        ? C.cloneElement(e, {
                            style: { width: "38px", height: "38px" },
                          })
                        : C.createElement(e, {
                            style: { width: "38px", height: "38px" },
                          }),
                    ],
                  }),
                })
              : (0, a.jsx)(ry, {
                  $variant: t,
                  children: (0, a.jsx)(rt, { size: "64px" }),
                })
            : (0, a.jsx)(ry, {
                $variant: t,
                children:
                  e &&
                  ("string" == typeof e
                    ? (0, a.jsx)("img", {
                        src: e,
                        alt: "",
                        style: {
                          width: "32px",
                          height: "32px",
                          borderRadius: "6px",
                        },
                      })
                    : C.isValidElement(e)
                    ? e
                    : C.createElement(e, {
                        width: 32,
                        height: 32,
                        stroke: (() => {
                          switch (t) {
                            case "success":
                              return "var(--privy-color-icon-success)";
                            case "warning":
                              return "var(--privy-color-icon-warning)";
                            case "error":
                              return "var(--privy-color-icon-error)";
                            default:
                              return "var(--privy-color-icon-muted)";
                          }
                        })(),
                        strokeWidth: 2,
                      })),
              }));
      let rT = T.zo.div.withConfig({
          displayName: "ActionsContainer",
          componentId: "sc-cc9e9a32-16",
        })([
          "width:100%;display:flex;flex-direction:column;gap:calc(var(--screen-space) / 2);",
        ]),
        rA = T.zo.p.withConfig({
          displayName: "HelpTextContainer",
          componentId: "sc-cc9e9a32-17",
        })([
          "&&{margin:0;width:100%;text-align:center;color:var(--privy-color-foreground-3);font-size:14px;line-height:22px;& a{color:var(--privy-color-accent);}}",
        ]),
        rS = ({
          primaryCta: e,
          secondaryCta: t,
          helpText: n,
          watermark: r = !0,
          children: i,
          ...o
        }) => {
          let s =
            e || t
              ? (0, a.jsxs)(a.Fragment, {
                  children: [
                    e &&
                      (() => {
                        let { label: t, ...n } = e,
                          r = n.variant || "primary";
                        return (0, a.jsx)(aH, {
                          ...n,
                          variant: r,
                          style: { width: "100%", ...n.style },
                          children: t,
                        });
                      })(),
                    t &&
                      (() => {
                        let { label: e, ...n } = t,
                          r = n.variant || "secondary";
                        return (0, a.jsx)(aH, {
                          ...n,
                          variant: r,
                          style: { width: "100%", ...n.style },
                          children: e,
                        });
                      })(),
                  ],
                })
              : null;
          return (0, a.jsxs)(rx, {
            id: o.id,
            className: o.className,
            children: [
              (0, a.jsx)(rx.Header, { ...o }),
              i ? (0, a.jsx)(rx.Body, { children: i }) : null,
              n || s || r
                ? (0, a.jsxs)(rx.Footer, {
                    children: [
                      n ? (0, a.jsx)(rx.HelpText, { children: n }) : null,
                      s ? (0, a.jsx)(rx.Actions, { children: s }) : null,
                      r ? (0, a.jsx)(rx.Watermark, {}) : null,
                    ],
                  })
                : null,
            ],
          });
        },
        rI = ({ label: e, children: t, valueStyles: n }) =>
          (0, a.jsxs)(rE, {
            children: [
              (0, a.jsx)("div", { children: e }),
              (0, a.jsx)(rN, { style: { ...n }, children: t }),
            ],
          }),
        rE = T.zo.div.withConfig({
          displayName: "StyledDetailsRow",
          componentId: "sc-4ebfdd45-0",
        })([
          "display:flex;align-items:center;justify-content:space-between;width:100%;> :first-child{color:var(--privy-color-foreground-3);text-align:left;}> :last-child{color:var(--privy-color-foreground-2);text-align:right;}",
        ]),
        rN = T.zo.div.withConfig({
          displayName: "ValueWrapper",
          componentId: "sc-4ebfdd45-1",
        })([
          "font-size:14px;line-height:100%;display:flex;align-items:center;justify-content:center;border-radius:var(--privy-border-radius-full);background-color:var(--privy-color-background-2);padding:4px 8px;",
        ]),
        r_ = new Intl.NumberFormat(void 0, {
          style: "currency",
          currency: "USD",
          maximumFractionDigits: 2,
        }),
        rM = (e) => r_.format(e),
        rF = (e, t) => {
          let n = rM(t * parseFloat(e));
          return "$0.00" !== n ? n : "<$0.01";
        },
        rz = (e, t) => {
          let n = rM(t * parseFloat((0, N.d)(e)));
          return "$0.00" === n ? "<$0.01" : n;
        },
        rL = (e, t, n = 6, a = !1) => `${rP(e, n, a)} ${t}`,
        rP = (e, t = 6, n = !1) => {
          let a = parseFloat((0, N.d)(e))
            .toFixed(t)
            .replace(/0+$/, "")
            .replace(/\.$/, "");
          return n ? a : `${"0" === a ? "<0.001" : a}`;
        },
        rD = (e) => e.reduce((e, t) => e + t, 0n),
        rW = (e, t) => {
          let { chains: n } = (0, j.u)(),
            a = `https://etherscan.io/address/${t}`,
            r = `${((e, t) => {
              let n = Number(e),
                a = t.find((e) => e.id === n);
              if (!a) throw new eh.x(`Unsupported chainId ${e}`, 4901);
              return a.blockExplorers?.default.url;
            })(e, n)}/address/${t}`;
          if (!r) return a;
          try {
            new URL(r);
          } catch {
            return a;
          }
          return r;
        },
        rR = {
          "solana:mainnet": {
            EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v: {
              symbol: "USDC",
              decimals: 6,
              address: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
            },
            Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB: {
              symbol: "USDT",
              decimals: 6,
              address: "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB",
            },
            So11111111111111111111111111111111111111112: {
              symbol: "SOL",
              decimals: 9,
              address: "So11111111111111111111111111111111111111112",
            },
          },
          "solana:devnet": {
            "4zMMC9srt5Ri5X14GAgXhaHii3GnPAEERYPJgZJDncDU": {
              symbol: "USDC",
              decimals: 6,
              address: "4zMMC9srt5Ri5X14GAgXhaHii3GnPAEERYPJgZJDncDU",
            },
            EJwZgeZrdC8TXTQbQBoL6bfuAnFUUy1PVCMB4DYPzVaS: {
              symbol: "USDT",
              decimals: 6,
              address: "EJwZgeZrdC8TXTQbQBoL6bfuAnFUUy1PVCMB4DYPzVaS",
            },
            So11111111111111111111111111111111111111112: {
              symbol: "SOL",
              decimals: 9,
              address: "So11111111111111111111111111111111111111112",
            },
          },
          "solana:testnet": {},
        };
      function rB(e, t) {
        let n = parseFloat(e.toString()) / 1e9,
          a = rU.format(t * n);
        return "$0.00" === a ? "<$0.01" : a;
      }
      let rU = new Intl.NumberFormat(void 0, {
        style: "currency",
        currency: "USD",
        maximumFractionDigits: 2,
      });
      function rO(e, t = 6, n = !1, a = !1) {
        let r = (parseFloat(e.toString()) / 1e9)
            .toFixed(t)
            .replace(/0+$/, "")
            .replace(/\.$/, ""),
          i = a ? "" : " SOL";
        return n ? `${r}${i}` : `${"0" === r ? "<0.001" : r}${i}`;
      }
      let rH = ({ weiQuantities: e, tokenPrice: t, tokenSymbol: n }) => {
          let r = rD(e),
            i = t ? rz(r, t) : void 0,
            o = rL(r, n);
          return (0, a.jsx)(r$, { children: i || o });
        },
        rV = ({ weiQuantities: e, tokenPrice: t, tokenSymbol: n }) => {
          let r = rD(e),
            i = t ? rz(r, t) : void 0,
            o = rL(r, n);
          return (0, a.jsx)(r$, {
            children: i
              ? (0, a.jsxs)(a.Fragment, {
                  children: [
                    (0, a.jsx)(rZ, { children: "USD" }),
                    "<$0.01" === i
                      ? (0, a.jsxs)(rG, {
                          children: [
                            (0, a.jsx)(rq, { children: "<" }),
                            "$0.01",
                          ],
                        })
                      : i,
                  ],
                })
              : o,
          });
        },
        r$ = T.zo.span.withConfig({
          displayName: "StyledPriceDisplay",
          componentId: "sc-3cd56c8a-0",
        })([
          "font-size:14px;line-height:140%;display:flex;gap:4px;align-items:center;",
        ]),
        rZ = T.zo.span.withConfig({
          displayName: "StyledPriceUnit",
          componentId: "sc-3cd56c8a-1",
        })([
          "font-size:12px;line-height:12px;color:var(--privy-color-foreground-3);",
        ]),
        rq = T.zo.span.withConfig({
          displayName: "TinyLessThan",
          componentId: "sc-3cd56c8a-2",
        })(["font-size:10px;"]),
        rG = T.zo.span.withConfig({
          displayName: "FlexCenter",
          componentId: "sc-3cd56c8a-3",
        })(["display:flex;align-items:center;"]),
        rY = T.zo.div.withConfig({
          displayName: "BottomPusherContainer",
          componentId: "sc-cb963810-0",
        })([
          "display:flex;flex-direction:column;align-items:flex-start;justify-content:flex-end;margin-top:auto;gap:16px;flex-grow:100;",
        ]),
        rQ = T.zo.div.withConfig({
          displayName: "CenteredItem",
          componentId: "sc-cb963810-1",
        })([
          "display:flex;flex-direction:column;align-items:center;justify-content:center;flex-grow:1;width:100%;",
        ]),
        rK = T.zo.div.withConfig({
          displayName: "HorizontallyCenteredItem",
          componentId: "sc-cb963810-2",
        })([
          "display:flex;flex-direction:column;align-items:center;width:100%;",
        ]),
        rX = (0, T.zo)(rQ).withConfig({
          displayName: "CenteredItemWithPadding",
          componentId: "sc-cb963810-3",
        })(["padding:20px 0;"]),
        rJ = (0, T.zo)(rQ).withConfig({
          displayName: "CenteredItemWithGap",
          componentId: "sc-cb963810-4",
        })(["gap:16px;"]),
        r0 = T.zo.div.withConfig({
          displayName: "FlexContainer",
          componentId: "sc-cb963810-5",
        })(["display:flex;flex-direction:column;width:100%;"]),
        r1 = T.zo.div.withConfig({
          displayName: "FixedGappedContainer",
          componentId: "sc-cb963810-6",
        })(["display:flex;flex-direction:column;gap:8px;"]),
        r2 = T.zo.div.withConfig({
          displayName: "StyledCalloutSection",
          componentId: "sc-cb963810-8",
        })([
          "display:flex;flex-direction:column;justify-content:flex-start;align-items:flex-start;text-align:left;gap:8px;padding:16px;margin-top:16px;margin-bottom:16px;width:100%;background:var(--privy-color-background-2);border-radius:var(--privy-border-radius-md);&& h4{color:var(--privy-color-foreground-3);font-size:14px;text-decoration:underline;font-weight:medium;}&& p{color:var(--privy-color-foreground-3);font-size:14px;}",
        ]),
        r3 = T.zo.div.withConfig({
          displayName: "RefactorSpacerTop",
          componentId: "sc-cb963810-9",
        })(["height:16px;"]),
        r4 = T.zo.div.withConfig({
          displayName: "RefactorSpacerBottom",
          componentId: "sc-cb963810-10",
        })(["height:12px;"]),
        r5 = T.zo.div.withConfig({
          displayName: "ConfigurableSpacer",
          componentId: "sc-cb963810-12",
        })(["height:", "px;"], (e) => e.height ?? "12"),
        r6 = ({ gas: e, tokenPrice: t, tokenSymbol: n }) =>
          (0, a.jsxs)(r0, {
            style: { paddingBottom: "12px" },
            children: [
              (0, a.jsxs)(r7, {
                children: [
                  (0, a.jsx)(ie, { children: "Est. Fees" }),
                  (0, a.jsx)("div", {
                    children: (0, a.jsx)(rV, {
                      weiQuantities: [BigInt(e)],
                      tokenPrice: t,
                      tokenSymbol: n,
                    }),
                  }),
                ],
              }),
              t && (0, a.jsx)(r9, { children: `${rL(BigInt(e), n)}` }),
            ],
          }),
        r8 = ({ value: e, gas: t, tokenPrice: n, tokenSymbol: r }) => {
          let i = BigInt(e ?? 0) + BigInt(t);
          return (0, a.jsxs)(r0, {
            children: [
              (0, a.jsxs)(r7, {
                children: [
                  (0, a.jsx)(ie, { children: "Total (including fees)" }),
                  (0, a.jsx)("div", {
                    children: (0, a.jsx)(rV, {
                      weiQuantities: [BigInt(e || 0), BigInt(t)],
                      tokenPrice: n,
                      tokenSymbol: r,
                    }),
                  }),
                ],
              }),
              n && (0, a.jsx)(r9, { children: rL(i, r) }),
            ],
          });
        },
        r7 = T.zo.div.withConfig({
          displayName: "TransactionTotalRow",
          componentId: "sc-f8ef9b74-0",
        })([
          "display:flex;flex-direction:row;justify-content:space-between;align-items:center;padding-top:4px;",
        ]),
        r9 = T.zo.div.withConfig({
          displayName: "ValueConversionRow",
          componentId: "sc-f8ef9b74-1",
        })([
          "display:flex;flex-direction:row;height:12px;font-size:12px;line-height:12px;color:var(--privy-color-foreground-3);font-weight:400;",
        ]),
        ie = T.zo.div.withConfig({
          displayName: "TotalText",
          componentId: "sc-f8ef9b74-2",
        })(["font-size:14px;line-height:22.4px;font-weight:400;"]),
        it = (0, C.createContext)(void 0),
        ia = (0, C.createContext)(void 0),
        ir = ({ defaultValue: e, children: t }) => {
          let [n, r] = (0, C.useState)(e || null);
          return (0, a.jsx)(it.Provider, {
            value: {
              activePanel: n,
              togglePanel: (e) => {
                r(n === e ? null : e);
              },
            },
            children: (0, a.jsx)(ic, { children: t }),
          });
        },
        ii = ({ value: e, children: t }) => {
          let { activePanel: n, togglePanel: r } = (0, C.useContext)(it),
            i = n === e;
          return (0, a.jsx)(ia.Provider, {
            value: { onToggle: () => r(e), value: e },
            children: (0, a.jsx)(ih, {
              isActive: i ? "true" : "false",
              "data-open": String(i),
              children: t,
            }),
          });
        },
        io = ({ children: e }) => {
          let { activePanel: t } = (0, C.useContext)(it),
            { onToggle: n, value: r } = (0, C.useContext)(ia),
            i = t === r;
          return (0, a.jsxs)(a.Fragment, {
            children: [
              (0, a.jsxs)(id, {
                onClick: n,
                "data-open": String(i),
                children: [
                  (0, a.jsx)(ip, { children: e }),
                  (0, a.jsx)(iy, {
                    isactive: i ? "true" : "false",
                    children: (0, a.jsx)(e$.Z, {
                      height: "16px",
                      width: "16px",
                      strokeWidth: "2",
                    }),
                  }),
                ],
              }),
              (0, a.jsx)(iu, {}),
            ],
          });
        },
        is = ({ children: e }) => {
          let { activePanel: t } = (0, C.useContext)(it),
            { value: n } = (0, C.useContext)(ia);
          return (0, a.jsx)(ig, {
            "data-open": String(t === n),
            children: (0, a.jsx)(im, { children: e }),
          });
        },
        il = ({ children: e }) => {
          let { activePanel: t } = (0, C.useContext)(it),
            { value: n } = (0, C.useContext)(ia);
          return (0, a.jsx)(im, {
            children: "function" == typeof e ? e({ isActive: t === n }) : e,
          });
        },
        ic = T.zo.div.withConfig({
          displayName: "AccordionRoot",
          componentId: "sc-d25f9267-0",
        })(["display:flex;flex-direction:column;width:100%;gap:8px;"]),
        id = T.zo.div.withConfig({
          displayName: "AccordionTriggerContainer",
          componentId: "sc-d25f9267-1",
        })([
          "display:flex;justify-content:space-between;align-items:center;width:100%;cursor:pointer;padding-bottom:8px;",
        ]),
        iu = T.zo.div.withConfig({
          displayName: "AccordionDivider",
          componentId: "sc-d25f9267-2",
        })([
          "width:100%;&&{border-top:1px solid;border-color:var(--privy-color-foreground-4);}padding-bottom:12px;",
        ]),
        ip = T.zo.div.withConfig({
          displayName: "AccordionTriggerContent",
          componentId: "sc-d25f9267-3",
        })([
          "font-size:14px;font-weight:500;line-height:19.6px;width:100%;padding-right:8px;",
        ]),
        ih = T.zo.div.withConfig({
          displayName: "AccordionPanelContainer",
          componentId: "sc-d25f9267-4",
        })([
          "display:flex;flex-direction:column;width:100%;overflow:hidden;padding:12px;&&{border:1px solid;border-color:var(--privy-color-foreground-4);border-radius:var(--privy-border-radius-md);}",
        ]),
        ig = T.zo.div.withConfig({
          displayName: "AccordionContentContainer",
          componentId: "sc-d25f9267-5",
        })([
          "position:relative;overflow:hidden;transition:max-height 25ms ease-out;&[data-open='true']{max-height:700px;}&[data-open='false']{max-height:0;}",
        ]),
        im = T.zo.div.withConfig({
          displayName: "ContentWrapper",
          componentId: "sc-d25f9267-6",
        })([
          "display:flex;flex-direction:column;gap:12px;flex:1 1 auto;min-height:1px;",
        ]),
        iy = T.zo.div.withConfig({
          displayName: "IconWrapper",
          componentId: "sc-d25f9267-7",
        })(["transform:", ";"], (e) =>
          "true" === e.isactive ? "rotate(180deg)" : "rotate(0deg)"
        ),
        iw = (e) => {
          var t, n;
          return (0, a.jsx)(iv, {
            href:
              "ethereum" === e.chainType
                ? rW(e.chainId, e.walletAddress)
                : ((t = e.walletAddress),
                  (n = e.chainId),
                  `https://explorer.solana.com/account/${t}?chain=${n}`),
            target: "_blank",
            children: t9(e.walletAddress),
          });
        },
        iv = T.zo.a.withConfig({
          displayName: "StyledLink",
          componentId: "sc-dd6c0f9f-0",
        })(["&:hover{text-decoration:underline;}"]),
        ix = ({
          from: e,
          to: t,
          txn: n,
          transactionInfo: r,
          tokenPrice: i,
          gas: o,
          tokenSymbol: s,
        }) => {
          let l = BigInt(n?.value || 0);
          return (0, a.jsx)(ir, {
            ...(ar().render.standalone ? { defaultValue: "details" } : {}),
            children: (0, a.jsxs)(ii, {
              value: "details",
              children: [
                (0, a.jsx)(io, {
                  children: (0, a.jsxs)(ib, {
                    children: [
                      (0, a.jsx)("div", { children: r?.title || "Details" }),
                      (0, a.jsx)(iC, {
                        children: (0, a.jsx)(rH, {
                          weiQuantities: [l],
                          tokenPrice: i,
                          tokenSymbol: s,
                        }),
                      }),
                    ],
                  }),
                }),
                (0, a.jsxs)(is, {
                  children: [
                    (0, a.jsx)(rI, {
                      label: "From",
                      children: (0, a.jsx)(iw, {
                        walletAddress: e,
                        chainId: n.chainId || 1,
                        chainType: "ethereum",
                      }),
                    }),
                    (0, a.jsx)(rI, {
                      label: "To",
                      children: (0, a.jsx)(iw, {
                        walletAddress: t,
                        chainId: n.chainId || 1,
                        chainType: "ethereum",
                      }),
                    }),
                    r &&
                      r.action &&
                      (0, a.jsx)(rI, { label: "Action", children: r.action }),
                    o &&
                      (0, a.jsx)(r6, {
                        value: n.value,
                        gas: o,
                        tokenPrice: i,
                        tokenSymbol: s,
                      }),
                  ],
                }),
                (0, a.jsx)(il, {
                  children: ({ isActive: e }) =>
                    (0, a.jsx)(r8, {
                      value: n.value,
                      displayFee: e,
                      gas: o || "0x0",
                      tokenPrice: i,
                      tokenSymbol: s,
                    }),
                }),
              ],
            }),
          });
        },
        ib = T.zo.div.withConfig({
          displayName: "AccordionTriggerContent",
          componentId: "sc-2eff9f5c-0",
        })(["display:flex;flex-direction:row;justify-content:space-between;"]),
        iC = T.zo.div.withConfig({
          displayName: "TotalText",
          componentId: "sc-2eff9f5c-1",
        })(["flex-shrink:0;padding-left:8px;"]),
        ij = ({ enabled: e = !0 } = {}) => {
          let { showFiatPrices: t, getUsdPriceForSol: n } = (0, j.u)(),
            [a, r] = (0, C.useState)(!0),
            [i, o] = (0, C.useState)(void 0),
            [s, l] = (0, C.useState)(void 0);
          return (
            (0, C.useEffect)(() => {
              (async () => {
                if (t && e)
                  try {
                    r(!0);
                    let e = await n();
                    e ? l(e) : o(Error("Unable to fetch SOL price"));
                  } catch (e) {
                    o(e);
                  } finally {
                    r(!1);
                  }
                else r(!1);
              })();
            }, []),
            { solPrice: s, isSolPriceLoading: a, solPriceError: i }
          );
        };
      function ik(e) {
        let {
            tokenPrice: t,
            isTokenPriceLoading: n,
            tokenPriceError: a,
          } = ((e) => {
            let {
                showFiatPrices: t,
                getUsdTokenPrice: n,
                chains: a,
              } = (0, j.u)(),
              [r, i] = (0, C.useState)(!0),
              [o, s] = (0, C.useState)(void 0),
              [l, c] = (0, C.useState)(void 0);
            return (
              (0, C.useEffect)(() => {
                e ||= 1;
                let r = (0, Y.Q)(a).find((t) => t.id === Number(e));
                (async () => {
                  if (t) {
                    if (!r)
                      return (
                        i(!1),
                        void s(
                          Error(`Unable to fetch token price on chain id ${e}`)
                        )
                      );
                    try {
                      i(!0);
                      let e = await n(r);
                      e
                        ? c(e)
                        : s(
                            Error(
                              `Unable to fetch token price on chain id ${r.id}`
                            )
                          );
                    } catch (e) {
                      s(e);
                    } finally {
                      i(!1);
                    }
                  } else i(!1);
                })();
              }, [e]),
              { tokenPrice: l, isTokenPriceLoading: r, tokenPriceError: o }
            );
          })("solana" === e ? -1 : e),
          {
            solPrice: r,
            isSolPriceLoading: i,
            solPriceError: o,
          } = ij({ enabled: "solana" === e });
        return "solana" === e
          ? { tokenPrice: r, isTokenPriceLoading: i, tokenPriceError: o }
          : { tokenPrice: t, isTokenPriceLoading: n, tokenPriceError: a };
      }
      let iT = (0, C.createContext)(null);
      function iA() {
        let e = (0, C.useContext)(iT);
        return null === e
          ? (console.warn(
              "`useWallets` was called outside the PrivyProvider component"
            ),
            { wallets: [], ready: !1 })
          : e;
      }
      async function iS(e, t, n, a) {
        let r = (0, e4.b)(e),
          i = await (async () =>
            a
              ? await a()
              : await t.prepareTransactionRequest({
                  ...r,
                  account: { address: n, type: "json-rpc" },
                }))();
        return { ...i, type: e4.g[i.type] };
      }
      let iI = T.zo.div.withConfig({
          displayName: "StackedContainer",
          componentId: "sc-f7e7d474-0",
        })([
          "display:flex;flex-direction:column;justify-content:center;align-items:center;width:100%;height:82px;> div{position:relative;}> div > span{position:absolute;left:-41px;top:-41px;}> div > :last-child{position:absolute;left:-19px;top:-19px;}",
        ]),
        iE = [
          "error",
          "invalid_request_arguments",
          "wallet_not_on_device",
          "invalid_recovery_pin",
          "insufficient_funds",
          "missing_or_invalid_mfa",
          "mfa_verification_max_attempts_reached",
          "mfa_timeout",
          "twilio_verification_failed",
        ];
      class iN extends Error {
        constructor(e, t) {
          super(t), (this.type = e);
        }
      }
      function i_(e) {
        let t = e.type;
        return "string" == typeof t && iE.includes(t);
      }
      function iM(e) {
        return i_(e) && "wallet_not_on_device" === e.type;
      }
      function iF(e) {
        return !!i_(e) && "mfa_timeout" === e.type;
      }
      function iz(e) {
        return !!i_(e) && "missing_or_invalid_mfa" === e.type;
      }
      function iL(e) {
        return !!i_(e) && "mfa_verification_max_attempts_reached" === e.type;
      }
      function iP(e) {
        return !(!i_(e) || !e.message.includes("code 429"));
      }
      function iD(e) {
        let t;
        return (
          !!("string" == typeof (t = e.type) && "client_error" === t) &&
          "MFA canceled" === e.message
        );
      }
      let iW = () => window.open(void 0, void 0, iR({ w: 440, h: 680 })),
        iR = ({ w: e, h: t }) => {
          let n =
              void 0 !== window.screenLeft ? window.screenLeft : window.screenX,
            a = void 0 !== window.screenTop ? window.screenTop : window.screenY,
            r = window.innerWidth
              ? window.innerWidth
              : document.documentElement.clientWidth
              ? document.documentElement.clientWidth
              : screen.width,
            i = window.innerHeight
              ? window.innerHeight
              : document.documentElement.clientHeight
              ? document.documentElement.clientHeight
              : screen.height;
          return `toolbar=0,location=0,menubar=0,height=${t},width=${e},popup=1,left=${
            (r - e) / 2 / (r / window.screen.availWidth) + n
          },top=${(i - t) / 2 / (i / window.screen.availHeight) + a}`;
        },
        iB = ({ title: e, description: t, children: n, ...r }) =>
          (0, a.jsx)(iO, {
            ...r,
            children: (0, a.jsxs)(a.Fragment, {
              children: [
                (0, a.jsx)("h3", { children: e }),
                "string" == typeof t ? (0, a.jsx)("p", { children: t }) : t,
                n,
              ],
            }),
          }),
        iU = ({ title: e, description: t, icon: n, children: r, ...i }) =>
          (0, a.jsxs)(iH, {
            ...i,
            children: [
              n || null,
              (0, a.jsx)("h3", { children: e }),
              t && "string" == typeof t ? (0, a.jsx)("p", { children: t }) : t,
              r,
            ],
          }),
        iO = T.zo.div.withConfig({
          displayName: "StyledSection",
          componentId: "sc-523a75d6-1",
        })([
          "display:flex;flex-direction:column;justify-content:flex-start;align-items:flex-start;text-align:left;gap:8px;width:100%;margin-bottom:24px;&& h3{font-size:17px;color:var(--privy-color-foreground);}&& p{color:var(--privy-color-foreground-2);font-size:14px;}",
        ]),
        iH = (0, T.zo)(iO).withConfig({
          displayName: "CenteredStyledSection",
          componentId: "sc-523a75d6-2",
        })([
          "align-items:center;text-align:center;gap:16px;h3{margin-bottom:24px;}",
        ]),
        iV = (e) =>
          (0, a.jsxs)("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            fill: "none",
            viewBox: "0 0 21 20",
            ...e,
            children: [
              (0, a.jsx)("path", {
                fill: "url(#icloud-gradient)",
                d: "M12.34 7.315a4.26 4.26 0 0 0-3.707 2.18 2.336 2.336 0 0 0-1.02-.236 2.336 2.336 0 0 0-2.3 1.963 3.217 3.217 0 0 0 1.244 6.181c.135-.001.27-.01.404-.029h8.943c.047.004.094.006.141.007.045-.001.09-.004.135-.007h.214v-.016a2.99 2.99 0 0 0 1.887-.988c.487-.55.757-1.261.757-1.998v-.006a3.017 3.017 0 0 0-.69-1.915 2.992 2.992 0 0 0-1.748-1.034 4.26 4.26 0 0 0-4.26-4.102Z",
              }),
              (0, a.jsx)("defs", {
                children: (0, a.jsxs)("linearGradient", {
                  id: "icloud-gradient",
                  x1: 19.086,
                  x2: 3.333,
                  y1: 14.38,
                  y2: 14.163,
                  gradientUnits: "userSpaceOnUse",
                  children: [
                    (0, a.jsx)("stop", { stopColor: "#3E82F4" }),
                    (0, a.jsx)("stop", { offset: 1, stopColor: "#93DCF7" }),
                  ],
                }),
              }),
            ],
          }),
        i$ = ({ style: e, ...t }) =>
          (0, a.jsxs)("svg", {
            width: "16",
            height: "14",
            style: e,
            viewBox: "0 0 16 14",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            ...t,
            children: [
              (0, a.jsxs)("g", {
                clipPath: "url(#clip0_2115_829)",
                children: [
                  (0, a.jsx)("path", {
                    d: "M2.34709 12.9404L2.3471 12.9404L2.34565 12.938L1.64031 11.7448L1.64004 11.7444L0.651257 10.0677C0.640723 10.0496 0.630746 10.0314 0.621325 10.0129H4.16461L2.39424 13.0139C2.3775 12.9901 2.36178 12.9656 2.34709 12.9404Z",
                    fill: "#0066DA",
                    stroke: "#6366F1",
                  }),
                  (0, a.jsx)("path", {
                    d: "M8 4.48713L5.47995 0.215332C5.23253 0.358922 5.02176 0.556358 4.87514 0.80764L0.219931 8.70508C0.076007 8.95094 0.000191627 9.22937 0 9.51277H5.04009L8 4.48713Z",
                    fill: "#00AC47",
                  }),
                  (0, a.jsx)("path", {
                    d: "M13.48 13.7847C13.7274 13.6411 13.9382 13.4437 14.0848 13.1924L14.3781 12.6988L15.7801 10.3206C15.9267 10.0693 16.0001 9.79114 16.0001 9.51294H10.9596L12.0321 11.577L13.48 13.7847Z",
                    fill: "#EA4335",
                  }),
                  (0, a.jsx)("path", {
                    d: "M8.00003 4.48718L10.5201 0.215385C10.2726 0.0717949 9.98857 0 9.69533 0H6.30472C6.01148 0 5.7274 0.0807692 5.47998 0.215385L8.00003 4.48718Z",
                    fill: "#00832D",
                  }),
                  (0, a.jsx)("path", {
                    d: "M10.9599 9.51294H5.04007L2.52002 13.7847C2.76744 13.9283 3.05152 14.0001 3.34476 14.0001H12.6552C12.9484 14.0001 13.2325 13.9194 13.4799 13.7847L10.9599 9.51294Z",
                    fill: "#2684FC",
                  }),
                  (0, a.jsx)("path", {
                    d: "M13.4525 4.75636L11.1249 0.80764C10.9782 0.556358 10.7675 0.358922 10.52 0.215332L8 4.48713L10.9599 9.51277H15.9908C15.9908 9.23456 15.9175 8.95636 15.7709 8.70508L13.4525 4.75636Z",
                    fill: "#FFBA00",
                  }),
                ],
              }),
              (0, a.jsx)("defs", {
                children: (0, a.jsx)("clipPath", {
                  id: "clip0_2115_829",
                  children: (0, a.jsx)("rect", {
                    width: "16",
                    height: "14",
                    fill: "white",
                  }),
                }),
              }),
            ],
          });
      async function iZ({ url: e, popup: t, provider: n }) {
        return (
          (t.location = e),
          new Promise((e, n) => {
            function a() {
              t?.close(), window.removeEventListener("message", r);
            }
            function r(t) {
              t.data &&
                ("PRIVY_OAUTH_RESPONSE" === t.data.type &&
                  t.data.stateCode &&
                  t.data.authorizationCode &&
                  (e(t.data), a()),
                "https://cdn.apple-cloudkit.com" === t.origin &&
                  t.data.ckSession &&
                  (e({
                    type: "PRIVY_OAUTH_RESPONSE",
                    ckWebAuthToken: t.data.ckSession,
                  }),
                  a()),
                "PRIVY_OAUTH_ERROR" === t.data.type && (n(t.data.error), a()));
            }
            window.addEventListener("message", r);
          })
        );
      }
      async function iq({
        api: e,
        provider: t,
        stateCode: n,
        codeVerifier: a,
        authorizationCode: r,
      }) {
        if (!r || !n)
          throw new eh.P(
            "[OAuth AuthFlow] Authorization and state codes code must be set prior to calling authenicate."
          );
        if ("undefined" === r)
          throw new eh.P("User denied confirmation during OAuth flow");
        try {
          return (
            await e.post(eh.af, {
              authorization_code: r,
              state_code: n,
              code_verifier: a,
              provider: t,
            })
          ).access_token;
        } catch (t) {
          let e = (0, eh.f)(t);
          if (e.privyErrorCode)
            throw new eh.P(
              e.message || "Invalid code during OAuth flow.",
              void 0,
              e.privyErrorCode
            );
          if ("User denied confirmation during OAuth flow" === e.message)
            throw new eh.P(
              "Invalid code during oauth flow.",
              void 0,
              eh.h.OAUTH_USER_DENIED
            );
          throw new eh.P(
            "Invalid code during OAuth flow.",
            void 0,
            eh.h.UNKNOWN_AUTH_ERROR
          );
        }
      }
      async function iG({ api: e, provider: t }) {
        let n = tP(),
          a = tD(),
          r = await tW(n);
        try {
          return "icloud" === t
            ? { url: (await e.post(eh.ag, { client_type: "web" })).url }
            : {
                url: (
                  await e.post(eh.ah, {
                    redirect_to: window.location.href,
                    code_challenge: r,
                    state_code: a,
                  })
                ).url,
                codeVerifier: n,
                stateCode: a,
                provider: t,
              };
        } catch (e) {
          throw (0, eh.f)(e);
        }
      }
      let iY = (e, { chainType: t, walletIndex: n } = {}) =>
          e?.linkedAccounts.filter(
            (e) =>
              !(
                "wallet" !== e.type ||
                "privy" !== e.walletClientType ||
                (void 0 !== n && e.walletIndex !== n) ||
                (void 0 !== t && e.chainType !== t)
              )
          ) ?? [],
        iQ = async ({
          user: e,
          accessToken: t,
          proxy: n,
          refreshSessionAndUser: a,
          privy: r,
          appConfig: i,
          recoverEmbeddedWallet: o,
          setUser: s,
          walletIndex: l,
          chainType: c,
          recoveryMethod: d,
          recoveryPassword: u,
          recoveryAccessToken: p,
        }) => {
          if (0 === l) {
            if (
              "user-controlled-server-wallets-only" === i.embeddedWallets.mode
            )
              await (0, Q.U)(r, { request: { chain_type: c } });
            else if ("ethereum" === c) {
              let a = (0, k.l)(e);
              a && (await o({ address: a.address })),
                await n.create({
                  accessToken: t,
                  solanaAddress: a?.address,
                  recoveryMethod: d,
                  recoveryPassword: u,
                  recoveryAccessToken: p,
                });
            } else {
              if ("solana" !== c) throw Error("Invalid input to create wallet");
              {
                let a = (0, k.b)(e);
                a && (await o({ address: a.address })),
                  await n.createSolana({
                    accessToken: t,
                    ethereumAddress: a?.address,
                    recoveryMethod: d,
                    recoveryPassword: u,
                    recoveryAccessToken: p,
                  });
              }
            }
          } else if (
            "user-controlled-server-wallets-only" === i.embeddedWallets.mode
          )
            await (0, Q.U)(r, { request: { chain_type: c } });
          else {
            let { entropyId: a, entropyIdVerifier: r } = nv(e);
            await o(),
              await n.addWallet({
                accessToken: t,
                entropyId: a,
                entropyIdVerifier: r,
                chainType: c,
                hdWalletIndex: l,
              });
          }
          let h = await a(),
            g = iY(h, { chainType: c, walletIndex: l })[0];
          return s(h), { user: h, account: g };
        },
        iK = () => {
          let {
              walletProxy: e,
              recoverEmbeddedWallet: t,
              setUser: n,
              refreshSessionAndUser: a,
              privy: r,
              client: i,
            } = (0, j.u)(),
            o = ar();
          return {
            create: async ({
              walletIndex: s,
              chainType: l,
              latestUser: c,
              recoveryMethod: d,
              recoveryPassword: u,
              recoveryAccessToken: p,
            }) => {
              let h = c;
              h || (h = await a());
              let g = await i.getAccessToken();
              if (!h || !g || !e)
                throw Error(
                  "User must be authenticated before creating a Privy wallet"
                );
              return await iQ({
                appConfig: o,
                user: h,
                refreshSessionAndUser: a,
                privy: r,
                accessToken: g,
                proxy: e,
                recoverEmbeddedWallet: t,
                setUser: n,
                walletIndex: s,
                chainType: l,
                recoveryMethod: d,
                recoveryPassword: u,
                recoveryAccessToken: p,
              });
            },
          };
        },
        iX = ({ title: e, description: t, onClose: n }) =>
          (0, a.jsx)(rS, {
            title: e,
            subtitle: t,
            icon: r.Z,
            iconVariant: "success",
            watermark: !0,
            onBack: n,
          }),
        iJ = {
          component: () => {
            let { user: e } = (0, k.u)(),
              {
                closePrivyModal: t,
                isNewUserThisSession: n,
                updateWallets: r,
              } = (0, j.u)(),
              { data: i, onUserCloseViaDialogOrKeybindRef: o } = ap(),
              s = ar(),
              {
                onSuccess: l,
                onFailure: c,
                callAuthOnSuccessOnClose: d,
              } = i.createWallet,
              u = () => {
                let n = (0, k.b)(e) ?? (0, k.l)(e);
                e && n
                  ? (r(), l({ user: e, account: n }))
                  : c(Error("Failed to create wallet")),
                  t({ shouldCallAuthOnSuccess: d });
              };
            return (
              (0, C.useEffect)(() => {
                let e = setTimeout(u, 2500);
                return () => clearTimeout(e);
              }, []),
              (o.current = u),
              (0, a.jsx)(iX, {
                title: n
                  ? "Welcome" + (s?.name ? ` to ${s?.name}` : "")
                  : "All set!",
                description: n
                  ? "You've successfully created an account."
                  : "Your account is secured.",
                onClose: u,
              })
            );
          },
        },
        i0 = T.zo.div.withConfig({
          displayName: "RecoveryContainer",
          componentId: "sc-12b46968-0",
        })([
          "display:flex;flex-direction:column;gap:12px;padding-top:24px;padding-bottom:24px;",
        ]),
        i1 = T.zo.div.withConfig({
          displayName: "RecoveryExplainerContainer",
          componentId: "sc-12b46968-1",
        })(["padding-bottom:24px;"]),
        i2 = {
          "google-drive": { name: "Google Drive", component: i$ },
          icloud: { name: "iCloud", component: iV },
        },
        i3 = {
          component: () => {
            let { logout: e } = (0, k.u)(),
              { navigate: t, setModalData: n, data: r } = ap(),
              { closePrivyModal: i, createAnalyticsEvent: o } = (0, j.u)(),
              { execute: s } = (() => {
                let {
                    client: e,
                    walletProxy: t,
                    refreshSessionAndUser: n,
                  } = (0, j.u)(),
                  { data: a } = ap(),
                  { user: r } = (0, k.u)(),
                  i = aw(),
                  { create: o } = iK();
                return {
                  execute: async ({
                    provider: s,
                    action: l,
                    popup: c,
                    shouldCreateEth: d,
                    shouldCreateSol: u,
                  }) => {
                    let p, h;
                    if (!e) throw new eh.P("Missing client");
                    function g(t) {
                      if (!t && e)
                        throw (
                          (e.createAnalyticsEvent({
                            eventName: "recovery_oauth_error",
                            payload: {
                              error: "Unable to open recovery OAuth popup",
                              provider: s,
                            },
                          }),
                          new eh.P("Recovery OAuth failed"))
                        );
                    }
                    switch (s) {
                      case "google-drive": {
                        let t,
                          n,
                          {
                            url: a,
                            codeVerifier: r,
                            stateCode: i,
                          } = await iG({ api: e.api, provider: s });
                        g(a);
                        try {
                          let r = await iZ({ url: a, popup: c, provider: s });
                          if (
                            ((t = r.stateCode),
                            (n = r.authorizationCode),
                            t !== i)
                          )
                            throw (
                              (e.createAnalyticsEvent({
                                eventName: "possible_phishing_attempt",
                                payload: {
                                  provider: s,
                                  storedStateCode: i ?? "",
                                  returnedStateCode: t ?? "",
                                },
                              }),
                              new eh.P(
                                "Unexpected auth flow. This may be a phishing attempt.",
                                void 0,
                                eh.h.OAUTH_UNEXPECTED
                              ))
                            );
                        } catch (t) {
                          throw (
                            (e.createAnalyticsEvent({
                              eventName: "recovery_oauth_error",
                              payload: { error: t.toString(), provider: s },
                            }),
                            new eh.P("Recovery OAuth failed"))
                          );
                        }
                        [p, h] = await Promise.all([
                          e.getAccessToken(),
                          iq({
                            api: e.api,
                            provider: s,
                            codeVerifier: r,
                            stateCode: t,
                            authorizationCode: n,
                          }),
                        ]);
                        break;
                      }
                      case "icloud": {
                        let { url: t } = await iG({ api: e.api, provider: s });
                        g(t);
                        let { ckWebAuthToken: n } = await iZ({
                          url: t,
                          popup: c,
                          provider: s,
                        });
                        (h = n), (p = await e.getAccessToken());
                      }
                    }
                    if (!t) throw new eh.P("Cannot connect to wallet proxy");
                    if (!p) throw new eh.P("Unable to authorize user");
                    switch (l) {
                      case "recover": {
                        let n = a?.recoverWallet?.entropyId,
                          r = a?.recoverWallet?.entropyIdVerifier;
                        if (!n || !r) throw new eh.P("Recovery OAuth failed");
                        e.createAnalyticsEvent({
                          eventName: "embedded_wallet_recovery_started",
                          payload: { walletAddress: n, recoveryMethod: s },
                        }),
                          await t.recover({
                            accessToken: p,
                            entropyId: n,
                            entropyIdVerifier: r,
                            recoveryAccessToken: h,
                          }),
                          e.createAnalyticsEvent({
                            eventName: "embedded_wallet_recovery_completed",
                            payload: { walletAddress: n, recoveryMethod: s },
                          });
                        break;
                      }
                      case "create-wallet": {
                        let t;
                        if (
                          (e.createAnalyticsEvent({
                            eventName: "embedded_wallet_creation_started",
                          }),
                          d && u)
                        )
                          (t = await o({
                            recoveryMethod: s,
                            recoveryAccessToken: h,
                            chainType: "ethereum",
                            walletIndex: 0,
                            latestUser: r,
                          })),
                            (t = await o({
                              chainType: "solana",
                              walletIndex: 0,
                              latestUser: t.user,
                            }));
                        else if (u)
                          t = await o({
                            recoveryMethod: s,
                            recoveryAccessToken: h,
                            chainType: "solana",
                            walletIndex: 0,
                            latestUser: r,
                          });
                        else {
                          if (!d) throw Error("Invalid args to create wallet");
                          t = await o({
                            recoveryMethod: s,
                            recoveryAccessToken: h,
                            chainType: "ethereum",
                            walletIndex: 0,
                            latestUser: r,
                          });
                        }
                        if (!t)
                          throw (
                            (i(
                              "createWallet",
                              "onError",
                              eh.h.UNKNOWN_EMBEDDED_WALLET_ERROR
                            ),
                            Error("Failed to create wallet"))
                          );
                        e.createAnalyticsEvent({
                          eventName: "embedded_wallet_creation_completed",
                          payload: { walletAddress: t.account.address },
                        }),
                          i("createWallet", "onSuccess", { wallet: t.account });
                        break;
                      }
                      case "set-recovery": {
                        let a = (0, k.a)(r);
                        if (!a)
                          throw (
                            (i(
                              "setWalletRecovery",
                              "onError",
                              eh.h.EMBEDDED_WALLET_NOT_FOUND
                            ),
                            Error("Embedded wallet not found"))
                          );
                        e.createAnalyticsEvent({
                          eventName: "embedded_wallet_set_recovery_started",
                          payload: {
                            walletAddress: a.address,
                            existingRecoveryMethod: a.recoveryMethod,
                            targetRecoveryMethod: s,
                          },
                        });
                        let { entropyId: o, entropyIdVerifier: l } = nv(r);
                        await t.setRecovery({
                          accessToken: p,
                          entropyId: o,
                          entropyIdVerifier: l,
                          recoveryMethod: s,
                          recoveryAccessToken: h,
                        });
                        let c = (0, k.a)(await n());
                        if (!c)
                          throw (
                            (i(
                              "createWallet",
                              "onError",
                              eh.h.UNKNOWN_EMBEDDED_WALLET_ERROR
                            ),
                            Error("Failed to set recovery on wallet"))
                          );
                        e.createAnalyticsEvent({
                          eventName: "embedded_wallet_set_recovery_completed",
                          payload: {
                            walletAddress: a.address,
                            existingRecoveryMethod: a.recoveryMethod,
                            targetRecoveryMethod: s,
                          },
                        }),
                          i("setWalletRecovery", "onSuccess", {
                            method: s,
                            wallet: c,
                          });
                        break;
                      }
                      default:
                        throw new eh.P("Unsupported recovery action");
                    }
                  },
                };
              })(),
              [l, c] = (0, C.useState)(!1),
              {
                provider: d,
                action: u,
                isInAccountCreateFlow: p,
                shouldCreateEth: h,
                shouldCreateSol: g,
              } = r?.recoveryOAuthStatus,
              [f, m] = (0, C.useState)(void 0),
              [y, w] = (0, C.useState)("create-wallet" === u);
            if ("user-passcode" === d)
              throw Error(
                "RecoveryOAuthScreen should never be called with a wallet that specifies recoveryMethod: `user-passcode`"
              );
            let v = i2[d].name,
              x = i2[d].component,
              b = r?.recoverWallet?.onCompleteNavigateTo,
              T = new td(
                async (e = "create-wallet") => (
                  w(!0),
                  new Promise((t, n) => {
                    setTimeout(async () => {
                      try {
                        let n = window.open();
                        await s({
                          provider: d,
                          action: e,
                          popup: n,
                          shouldCreateEth: h,
                          shouldCreateSol: g,
                        }),
                          c(!0),
                          t();
                      } catch (t) {
                        m({
                          message: `${
                            "recover" === e ? "Recovery" : "Back up"
                          } with ${v} unsuccessful`,
                          detail:
                            "recover" === u
                              ? `Please verify that you are selecting the ${v} account associated with your backup.`
                              : "",
                          retryable: !0,
                        }),
                          n();
                      }
                    }, 0);
                  })
                )
              );
            (0, C.useEffect)(() => {
              "recover" !== u &&
                T.execute(p ? "create-wallet" : "set-recovery");
            }, []),
              (0, C.useEffect)(() => {
                if (!l) return;
                let a = setTimeout(() => {
                  p
                    ? (n({
                        createWallet: {
                          onSuccess: () => {},
                          onFailure: (t) => {
                            o({
                              eventName:
                                "embedded_wallet_creation_failure_logout",
                              payload: {
                                error: t,
                                screen: "RecoveryOAuthScreen",
                              },
                            }),
                              e();
                          },
                          callAuthOnSuccessOnClose: !0,
                          shouldCreateEth: !1,
                          shouldCreateSol: !1,
                        },
                      }),
                      t(iJ))
                    : i({ shouldCallAuthOnSuccess: !1 });
                }, th);
                return () => clearTimeout(a);
              }, [l]);
            let A = (0, C.useCallback)(async () => {
                await T.execute("recover"), b ? t(b) : c(!0);
              }, []),
              S = "google-drive" === d ? "Google Drive" : "Apple iCloud",
              I =
                (l &&
                  `Successfully ${
                    "recover" === u ? "recovered" : "backed up"
                  } with ${S}.`) ||
                (f && f.message) ||
                `${"recover" === u ? "Recovering" : "Backing up"} with ${S}...`,
              E = f ? f.detail : "";
            return (0, a.jsxs)(a.Fragment, {
              children: [
                (0, a.jsx)(a4, {}),
                y
                  ? (0, a.jsx)(a.Fragment, {
                      children: (0, a.jsxs)(i0, {
                        children: [
                          (0, a.jsx)(iU, {
                            title: I,
                            icon: (0, a.jsx)(x, {
                              style: { width: "38px", height: "38px" },
                            }),
                            description: E,
                          }),
                          f && f?.retryable
                            ? (0, a.jsx)(a$, {
                                onClick: () => {
                                  tX(),
                                    m(void 0),
                                    "create-wallet" === u
                                      ? T.execute("create-wallet")
                                      : A();
                                },
                                disabled: !l && !f?.retryable,
                                children: "Try again",
                              })
                            : null,
                        ],
                      }),
                    })
                  : (0, a.jsxs)(i0, {
                      children: [
                        (0, a.jsx)(iU, {
                          title: "Confirm it's really you",
                          icon: (0, a.jsx)(x, {
                            style: { height: 42, width: 48 },
                          }),
                          description: `To confirm your identity, please log in to ${S} where your account is backed up.`,
                        }),
                        (0, a.jsxs)(a$, {
                          onClick: A,
                          children: ["Confirm with ", S],
                        }),
                      ],
                    }),
                (0, a.jsx)(aF, {}),
              ],
            });
          },
        },
        i4 = T.zo.div.withConfig({
          displayName: "IconContainer",
          componentId: "sc-ccfae04f-0",
        })([
          "width:24px;height:24px;display:flex;justify-content:center;align-items:center;",
        ]),
        i5 = {
          "google-drive": "Google Drive",
          icloud: "iCloud",
          "user-passcode": "password",
          privy: "Privy",
          "privy-v2": "Privy",
        },
        i6 = ({ onClose: e }) =>
          (0, a.jsxs)(i1, {
            children: [
              (0, a.jsx)(iU, {
                title: "Why do I need to secure my account?",
                icon: (0, a.jsx)(ey.Z, { width: 48 }),
                description: (0, a.jsxs)(a.Fragment, {
                  children: [
                    (0, a.jsx)("p", {
                      children:
                        "Your app uses cryptography to secure your account. App secrets are split and encrypted so only you can access them.",
                    }),
                    (0, a.jsx)("p", {
                      children:
                        "To use this app on new devices, secure account secrets using a password, your Google or your Apple account. It’s important you don’t lose access to the method you choose.",
                    }),
                  ],
                }),
              }),
              (0, a.jsx)(a$, { onClick: e, children: "Select backup method" }),
            ],
          }),
        i8 = {
          component: () => {
            let [e, t] = (0, C.useState)(!1),
              {
                navigate: n,
                lastScreen: r,
                navigateBack: i,
                setModalData: o,
                data: s,
                onUserCloseViaDialogOrKeybindRef: l,
              } = ap(),
              { user: c } = (0, k.u)(),
              { embeddedWallets: d } = ar(),
              { closePrivyModal: u } = (0, j.u)(),
              p = (0, k.a)(c),
              h = null === p,
              {
                isInAccountCreateFlow: g,
                isResettingPassword: f,
                shouldCreateEth: m,
                shouldCreateSol: y,
              } = s.recoverySelection,
              w = p && "privy" !== p.recoveryMethod,
              v = w
                ? (0, a.jsxs)("span", {
                    children: [
                      "Your account is currently secured using",
                      " ",
                      (0, a.jsx)("strong", {
                        children: i5[p?.recoveryMethod || "user-passcode"],
                      }),
                      ".",
                    ],
                  })
                : "Select a method for logging in on new devices and recovering your account.";
            function x(e) {
              o({
                recoveryOAuthStatus: {
                  provider: e,
                  action: h ? "create-wallet" : "set-recovery",
                  isInAccountCreateFlow: g,
                  shouldCreateEth: m,
                  shouldCreateSol: y,
                },
              }),
                n(i3);
            }
            function b() {
              s?.setWalletPassword?.onFailure(
                Error("User exited set recovery flow")
              ),
                u({
                  shouldCallAuthOnSuccess:
                    s?.setWalletPassword?.callAuthOnSuccessOnClose ?? !1,
                });
            }
            return (
              (l.current = b),
              (0, a.jsxs)(a.Fragment, {
                children: [
                  (0, a.jsx)(
                    a4,
                    {
                      onClose: b,
                      backFn: e ? () => t(!1) : r ? i : void 0,
                      infoFn: r || e ? void 0 : () => t(!0),
                    },
                    "header"
                  ),
                  e
                    ? (0, a.jsx)(i6, { onClose: () => t(!1) })
                    : (0, a.jsxs)(a.Fragment, {
                        children: [
                          (0, a.jsx)(iU, {
                            title: w
                              ? "Update backup method"
                              : "Secure your account",
                            icon: (0, a.jsx)(eN.Z, { width: 48 }),
                            description: v,
                          }),
                          (0, a.jsx)(i0, {
                            children: d.userOwnedRecoveryOptions
                              .filter(
                                (e) =>
                                  !["icloud", "google-drive"].includes(
                                    p?.recoveryMethod || ""
                                  ) || e !== p?.recoveryMethod
                              )
                              .sort()
                              .map((e) => {
                                switch (e) {
                                  case "google-drive":
                                    return (0, a.jsxs)(
                                      aT,
                                      {
                                        onClick: () => x("google-drive"),
                                        children: [
                                          (0, a.jsx)(i4, {
                                            children: (0, a.jsx)(i$, {
                                              style: { width: 18 },
                                            }),
                                          }),
                                          "Back up to Google Drive",
                                        ],
                                      },
                                      e
                                    );
                                  case "icloud":
                                    return (0, a.jsxs)(
                                      aT,
                                      {
                                        onClick: () => x("icloud"),
                                        children: [
                                          (0, a.jsx)(i4, {
                                            children: (0, a.jsx)(iV, {
                                              style: { width: 24 },
                                            }),
                                          }),
                                          "Back up to Apple iCloud",
                                        ],
                                      },
                                      e
                                    );
                                  case "user-passcode":
                                    return (0, a.jsxs)(
                                      aT,
                                      {
                                        onClick: () => {
                                          n(
                                            (function ({
                                              isCreatingWallet: e,
                                              skipSplashScreen: t,
                                            }) {
                                              return e ? p$ : t ? pW : pB;
                                            })({
                                              isCreatingWallet: h,
                                              skipSplashScreen: !0,
                                            })
                                          );
                                        },
                                        children: [
                                          (0, a.jsx)(i4, {
                                            children: (0, a.jsx)(e_.Z, {
                                              style: { width: 18 },
                                            }),
                                          }),
                                          f ? "Reset your" : "Set a",
                                          " password",
                                        ],
                                      },
                                      e
                                    );
                                  default:
                                    return null;
                                }
                              }),
                          }),
                        ],
                      }),
                  (0, a.jsx)(aF, {}),
                ],
              })
            );
          },
        },
        i7 = (0, T.iv)([
          "font-size:14px;font-style:normal;font-weight:400;line-height:20px;letter-spacing:-0.008px;text-align:left;transition:color 0.1s ease-in;",
        ]),
        i9 = T.zo.span.withConfig({
          displayName: "StatusText",
          componentId: "sc-acac4b9-0",
        })(
          [
            "",
            " transition:color 0.1s ease-in;color:",
            ";text-transform:",
            ";&[aria-hidden='true']{visibility:hidden;}",
          ],
          i7,
          ({ error: e }) =>
            e ? "var(--privy-color-error)" : "var(--privy-color-foreground-3)",
          ({ error: e }) => (e ? "" : "capitalize")
        ),
        oe = T.zo.div.withConfig({
          displayName: "EmbeddedWalletScreenContainer",
          componentId: "sc-acac4b9-1",
        })([
          "display:flex;flex-direction:column;justify-content:center;flex-grow:1;",
        ]),
        ot = (0, T.zo)(a$).withConfig({
          displayName: "NoAnimationPrimaryButton",
          componentId: "sc-acac4b9-2",
        })(
          ["", ""],
          ({ $hideAnimations: e }) => e && (0, T.iv)(["&&{transition:none;}"])
        ),
        on = (0, T.iv)([
          "&&{width:100%;border-width:1px;border-radius:var(--privy-border-radius-md);border-color:var(--privy-color-foreground-3);background:var(--privy-color-background);color:var(--privy-color-foreground);padding:12px;font-size:16px;font-style:normal;font-weight:300;line-height:22px;}",
        ]),
        oa = T.zo.input.withConfig({
          displayName: "PasswordInput",
          componentId: "sc-acac4b9-3",
        })(
          [
            "",
            " &::placeholder{color:var(--privy-color-foreground-3);font-style:italic;font-size:14px;}overflow:hidden;text-overflow:ellipsis;white-space:nowrap;",
          ],
          on
        ),
        or = T.zo.div.withConfig({
          displayName: "PasswordDisplay",
          componentId: "sc-acac4b9-4",
        })(["", ""], on),
        oi = T.zo.div.withConfig({
          displayName: "PasswordContainer",
          componentId: "sc-acac4b9-5",
        })(
          [
            "position:relative;width:100%;display:flex;align-items:center;justify-content:",
            ";",
          ],
          ({ centered: e }) => (e ? "center" : "space-between")
        ),
        oo = T.zo.div.withConfig({
          displayName: "Header",
          componentId: "sc-acac4b9-6",
        })([
          "display:flex;flex-direction:column;align-items:center;justify-content:center;margin:32px 0;gap:4px;& h3{font-size:18px;font-style:normal;font-weight:600;line-height:24px;}& p{max-width:300px;font-size:14px;font-style:normal;font-weight:400;line-height:20px;}",
        ]),
        os = T.zo.div.withConfig({
          displayName: "Details",
          componentId: "sc-acac4b9-7",
        })([
          "display:flex;flex-direction:column;gap:10px;padding-bottom:1rem;",
        ]),
        ol = T.zo.div.withConfig({
          displayName: "DetailItem",
          componentId: "sc-acac4b9-8",
        })([
          "display:flex;text-align:left;align-items:center;gap:8px;max-width:300px;font-size:14px;font-style:normal;font-weight:400;line-height:20px;letter-spacing:-0.008px;margin:0 8px;color:var(--privy-color-foreground-2);> :first-child{min-width:24px;}",
        ]),
        oc = (0, T.zo)(aH).withConfig({
          displayName: "ExportButton",
          componentId: "sc-acac4b9-10",
        })([
          "display:flex;flex:1;gap:4px;justify-content:center;&&{background:var(--privy-color-background);border-radius:var(--privy-border-radius-md);border-color:var(--privy-color-foreground-3);border-width:1px;}",
        ]),
        od = T.zo.div.withConfig({
          displayName: "InputRightIcons",
          componentId: "sc-acac4b9-11",
        })([
          "position:absolute;right:0.5rem;display:flex;flex-direction:row;justify-content:space-around;align-items:center;",
        ]),
        ou = (0, T.zo)(eF.Z).withConfig({
          displayName: "RegenerateIcon",
          componentId: "sc-acac4b9-12",
        })([
          "height:1.25rem;width:1.25rem;stroke:var(--privy-color-accent);cursor:pointer;:active{stroke:var(--privy-color-accent-light);}",
        ]),
        op = (0, T.zo)(eL.Z).withConfig({
          displayName: "HiddenIcon",
          componentId: "sc-acac4b9-13",
        })([
          "height:1.25rem;width:1.25rem;stroke:var(--privy-color-accent);cursor:pointer;:active{stroke:var(--privy-color-accent-light);}",
        ]),
        oh = (0, T.zo)(ez.Z).withConfig({
          displayName: "ShownIcon",
          componentId: "sc-acac4b9-14",
        })([
          "height:1.25rem;width:1.25rem;stroke:var(--privy-color-accent);cursor:pointer;:active{stroke:var(--privy-color-accent-light);}",
        ]),
        og = T.zo.progress.withConfig({
          displayName: "StrengthMeter",
          componentId: "sc-acac4b9-15",
        })(
          [
            "height:4px;width:100%;margin:8px 0;::-webkit-progress-bar{border-radius:8px;background:var(--privy-color-foreground-4);}::-webkit-progress-value{border-radius:8px;transition:all 0.1s ease-out;background:",
            ";}",
          ],
          ({ label: e }) =>
            ("Strong" === e
              ? "#78dca6"
              : "Medium" === e && "var(--privy-color-warn)") ||
            "var(--privy-color-error)"
        ),
        of = ({
          buttonHideAnimations: e,
          buttonLoading: t,
          password: n,
          onSubmit: r,
          onBack: i,
        }) => {
          let [o, s] = (0, C.useState)(!0),
            [l, c] = (0, C.useState)(!1),
            [d, u] = (0, C.useState)(""),
            p = n === d;
          return (
            (0, C.useEffect)(() => {
              d && !l && c(!0);
            }, [d]),
            (0, a.jsxs)(a.Fragment, {
              children: [
                (0, a.jsx)(a4, { closeable: !1, backFn: i }),
                (0, a.jsx)(r3, {}),
                (0, a.jsxs)(oe, {
                  children: [
                    (0, a.jsxs)(oo, {
                      children: [
                        (0, a.jsx)(ej.Z, {
                          height: 48,
                          width: 48,
                          stroke: "var(--privy-color-background)",
                          fill: "var(--privy-color-accent)",
                        }),
                        (0, a.jsx)("h3", {
                          style: { color: "var(--privy-color-foreground)" },
                          children: "Confirm your password",
                        }),
                        (0, a.jsx)("p", {
                          style: { color: "var(--privy-color-foreground-2)" },
                          children:
                            "Please re-enter your password below to continue.",
                        }),
                      ],
                    }),
                    (0, a.jsxs)(oi, {
                      children: [
                        (0, a.jsx)(oa, {
                          value: d,
                          onChange: (e) => u(e.target.value),
                          onKeyUp: (e) => {
                            "Enter" === e.key && r();
                          },
                          onBlur: () => c(!0),
                          placeholder: "confirm your password",
                          type: o ? "password" : "text",
                          style: { paddingRight: "2.3rem" },
                        }),
                        (0, a.jsx)(od, {
                          style: { right: "0.75rem" },
                          children: o
                            ? (0, a.jsx)(op, { onClick: () => s(!1) })
                            : (0, a.jsx)(oh, { onClick: () => s(!0) }),
                        }),
                      ],
                    }),
                    (0, a.jsx)(i9, {
                      "aria-hidden": !l || p,
                      error: !0,
                      children: "Passwords do not match",
                    }),
                  ],
                }),
                (0, a.jsx)(ot, {
                  onClick: r,
                  loading: t,
                  disabled: !p,
                  $hideAnimations: e,
                  children: "Continue",
                }),
                (0, a.jsx)(r4, {}),
                (0, a.jsx)(aF, {}),
              ],
            })
          );
        },
        om = ({
          className: e,
          checked: t,
          color: n = "var(--privy-color-accent)",
          ...r
        }) =>
          (0, a.jsx)("label", {
            children: (0, a.jsxs)(oy, {
              className: e,
              children: [
                (0, a.jsx)(ov, { checked: t, ...r }),
                (0, a.jsx)(ox, {
                  color: n,
                  checked: t,
                  children: (0, a.jsx)(ow, {
                    viewBox: "0 0 24 24",
                    children: (0, a.jsx)("polyline", {
                      points: "20 6 9 17 4 12",
                    }),
                  }),
                }),
              ],
            }),
          }),
        oy = T.zo.div.withConfig({
          displayName: "CheckboxContainer",
          componentId: "sc-db51b935-1",
        })(["display:inline-block;vertical-align:middle;"]),
        ow = T.zo.svg.withConfig({
          displayName: "Icon",
          componentId: "sc-db51b935-2",
        })(["fill:none;stroke:white;stroke-width:3px;"]),
        ov = T.zo.input
          .attrs({ type: "checkbox" })
          .withConfig({
            displayName: "HiddenCheckbox",
            componentId: "sc-db51b935-3",
          })([
          "border:0;clip:rect(0 0 0 0);clippath:inset(50%);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;white-space:nowrap;width:1px;",
        ]),
        ox = T.zo.div.withConfig({
          displayName: "StyledCheckbox",
          componentId: "sc-db51b935-4",
        })(
          [
            "display:inline-block;width:18px;height:18px;transition:all 150ms;cursor:pointer;border-color:",
            ";border-radius:3px;background:",
            ";&&{border-width:1px;}",
            ":focus + &{box-shadow:0 0 0 1px ",
            ";}",
            "{visibility:",
            ";}",
          ],
          (e) => e.color,
          (e) => (e.checked ? e.color : "var(--privy-color-background)"),
          ov,
          (e) => e.color,
          ow,
          (e) => (e.checked ? "visible" : "hidden")
        ),
        ob = ({
          buttonHideAnimations: e,
          buttonLoading: t,
          onSubmit: n,
          onBack: r,
          config: i,
        }) => {
          let [o, s] = (0, C.useState)(!1);
          return (0, a.jsxs)(a.Fragment, {
            children: [
              (0, a.jsx)(a4, { closeable: !1, backFn: r }),
              (0, a.jsx)(r3, {}),
              (0, a.jsxs)(oe, {
                children: [
                  (0, a.jsxs)(oo, {
                    children: [
                      (0, a.jsx)(ej.Z, {
                        height: 48,
                        width: 48,
                        stroke: "var(--privy-color-background)",
                        fill: "var(--privy-color-error)",
                      }),
                      (0, a.jsx)("h3", {
                        style: { color: "var(--privy-color-foreground)" },
                        children: "Confirm you have saved",
                      }),
                      (0, a.jsx)("p", {
                        style: { color: "var(--privy-color-foreground-2)" },
                        children:
                          "Losing access to your password means you will lose access to your account.",
                      }),
                    ],
                  }),
                  (0, a.jsx)(os, {
                    children: (0, a.jsxs)(ol, {
                      style: {
                        color: "var(--privy-color-error)",
                        cursor: "pointer",
                      },
                      onClick: (e) => {
                        e.preventDefault(), s((e) => !e);
                      },
                      children: [
                        (0, a.jsx)(om, {
                          color: "var(--privy-color-error)",
                          readOnly: !0,
                          checked: o,
                        }),
                        (0, a.jsx)(a.Fragment, {
                          children:
                            "I understand that if I lose my password and device, I will lose access to my account and my assets.",
                        }),
                      ],
                    }),
                  }),
                ],
              }),
              (0, a.jsxs)(oC, {
                children: [
                  "user" === i.initiatedBy &&
                    (0, a.jsx)(aY, {
                      onClick: i.onCancel,
                      disabled: t,
                      children: "Cancel",
                    }),
                  (0, a.jsx)(ot, {
                    onClick: n,
                    loading: t,
                    $hideAnimations: e,
                    disabled: !o,
                    children: "Set Password",
                  }),
                ],
              }),
              (0, a.jsx)(r4, {}),
              (0, a.jsx)(aF, {}),
            ],
          });
        },
        oC = T.zo.div.withConfig({
          displayName: "ButtonsContainer",
          componentId: "sc-d1659c5f-0",
        })(["display:flex;gap:10px;"]),
        oj = /[a-z]/,
        ok = /[A-Z]/,
        oT = /[0-9]/,
        oA = "!@#$%^&*()\\-_+.",
        oS = `a-zA-Z0-9${oA}`,
        oI = RegExp(`[${oA}]`),
        oE = RegExp(`[${oS}]`),
        oN = RegExp(`^[${oS}]{6,}$`),
        o_ = () => eI.OW(4, eE.k),
        oM = ({
          buttonHideAnimations: e,
          buttonLoading: t,
          password: n = "",
          config: r,
          isResettingPassword: i,
          onSubmit: o,
          onClose: s,
          onBack: l,
          onPasswordChange: c,
          onPasswordGenerate: d,
        }) => {
          let [u, p] = (0, C.useState)(!1),
            [h, g] = (0, C.useState)(!1);
          (0, C.useEffect)(() => {
            n && !h && g(!0);
          }, [n]);
          let f = (0, C.useMemo)(
              () =>
                h
                  ? 6 > (n?.length || 0)
                    ? "Password must be at least 6 characters"
                    : oN.test(n || "")
                    ? null
                    : `Invalid characters used ( ${((e = "") => [
                        ...new Set(
                          e
                            .split("")
                            .filter((e) => !oE.test(e))
                            .map((e) => e.replace(" ", "SPACE"))
                        ),
                      ])(n).join(" ")} )`
                  : null,
              [n, h]
            ),
            m = (0, C.useMemo)(
              () =>
                f
                  ? { value: 0, label: "Weak" }
                  : (function (e = "") {
                      let t = (function (e = "") {
                        return (
                          (0.3 *
                            (function (e) {
                              if (e.length < 8) return 0;
                              let t = 0;
                              return (
                                oj.test(e) && (t += 1),
                                ok.test(e) && (t += 1),
                                oT.test(e) && (t += 1),
                                oI.test(e) && (t += 1),
                                Math.max(0, Math.min(1, t / 3))
                              );
                            })(e) +
                            eS(e) / 95) /
                          2
                        );
                      })(e);
                      return {
                        value: t,
                        label: t > 0.9 ? "Strong" : t > 0.5 ? "Medium" : "Weak",
                      };
                    })(n),
              [n, f]
            ),
            y = (0, C.useMemo)(() => !n?.length || !!f, [f, n]);
          return (0, a.jsxs)(a.Fragment, {
            children: [
              (0, a.jsx)(a4, {
                onClose: s,
                closeable: "user" === r.initiatedBy,
                backFn: l,
              }),
              (0, a.jsx)(r3, {}),
              (0, a.jsxs)(oe, {
                children: [
                  (0, a.jsxs)(oo, {
                    children: [
                      (0, a.jsx)(eP.Z, {
                        height: 48,
                        width: 48,
                        stroke: "var(--privy-color-accent)",
                      }),
                      (0, a.jsxs)("h3", {
                        style: { color: "var(--privy-color-foreground)" },
                        children: [i ? "Reset" : "Set", " your password"],
                      }),
                      (0, a.jsx)("p", {
                        style: { color: "var(--privy-color-foreground-2)" },
                        children:
                          "Select a strong, memorable password to secure your account.",
                      }),
                    ],
                  }),
                  (0, a.jsxs)(oi, {
                    children: [
                      (0, a.jsx)(oa, {
                        value: n,
                        onChange: (e) => c(e.target.value),
                        onKeyUp: (e) => {
                          "Enter" === e.key && o();
                        },
                        placeholder: "enter or generate a strong password",
                        type: u ? "password" : "text",
                        style: { paddingRight: "3.8rem" },
                      }),
                      (0, a.jsxs)(od, {
                        style: { width: "3.5rem" },
                        children: [
                          u
                            ? (0, a.jsx)(op, { onClick: () => p(!1) })
                            : (0, a.jsx)(oh, { onClick: () => p(!0) }),
                          (0, a.jsx)(ou, { onClick: d }),
                        ],
                      }),
                    ],
                  }),
                  (0, a.jsx)(og, {
                    value: 0 === m.value ? 0.01 : m.value,
                    label: m.label,
                  }),
                  (0, a.jsx)(i9, {
                    error: !!f,
                    children: f || `Password Strength: ${h ? m.label : "--"}`,
                  }),
                  (0, a.jsxs)(oz, {
                    children: [
                      (0, a.jsx)(oF, {
                        children: (0, a.jsxs)(os, {
                          children: [
                            (0, a.jsxs)(ol, {
                              children: [
                                (0, a.jsx)(eD.Z, {
                                  width: 24,
                                  height: 24,
                                  fill: "var(--privy-color-accent)",
                                }),
                                "This password is used to secure your account.",
                              ],
                            }),
                            (0, a.jsxs)(ol, {
                              children: [
                                (0, a.jsx)(eD.Z, {
                                  width: 24,
                                  height: 24,
                                  fill: "var(--privy-color-accent)",
                                }),
                                "Use it to log in on a new environment, like another browser or device.",
                              ],
                            }),
                          ],
                        }),
                      }),
                      (0, a.jsx)(ot, {
                        onClick: o,
                        loading: t,
                        disabled: y,
                        $hideAnimations: e,
                        children: "Continue",
                      }),
                    ],
                  }),
                ],
              }),
              (0, a.jsx)(r4, {}),
              (0, a.jsx)(aF, {}),
            ],
          });
        },
        oF = (0, T.zo)(os).withConfig({
          displayName: "DetailsContainer",
          componentId: "sc-2da5fe90-0",
        })(["flex:1;padding-top:1rem;"]),
        oz = T.zo.div.withConfig({
          displayName: "LowerContainer",
          componentId: "sc-2da5fe90-1",
        })(["display:flex;flex-direction:column;height:100%;"]),
        oL = ({
          buttonHideAnimations: e,
          buttonLoading: t,
          appName: n,
          password: r,
          onSubmit: i,
          onBack: o,
        }) => {
          let [s, l] = (0, C.useState)(!1),
            [c, d] = (0, C.useState)(!0),
            u = (0, C.useCallback)(() => {
              l(!0), r && navigator.clipboard.writeText(r);
            }, [r]),
            p = (0, C.useCallback)(() => {
              let e = document.createElement("a"),
                t = n
                  .toLowerCase()
                  .replace(/[^a-z\s]/g, "")
                  .replace(/\s/g, "-"),
                a = new Blob([oP(n, r)], { type: "text/plain" }),
                i = URL.createObjectURL(a);
              (e.href = i),
                (e.target = "_blank"),
                (e.download = `${t}-privy-wallet-recovery.txt`),
                document.body.appendChild(e),
                e.click(),
                setTimeout(() => {
                  e.remove(), URL.revokeObjectURL(i);
                }, 5e3);
            }, [r]);
          return (0, a.jsxs)(a.Fragment, {
            children: [
              (0, a.jsx)(a4, { backFn: o, closeable: !1 }),
              (0, a.jsx)(r3, {}),
              (0, a.jsxs)(oe, {
                children: [
                  (0, a.jsxs)(oo, {
                    children: [
                      (0, a.jsx)(ej.Z, {
                        height: 48,
                        width: 48,
                        stroke: "var(--privy-color-background)",
                        fill: "var(--privy-color-accent)",
                      }),
                      (0, a.jsx)("h3", {
                        style: { color: "var(--privy-color-foreground)" },
                        children: "Save your password",
                      }),
                      (0, a.jsx)("p", {
                        style: { color: "var(--privy-color-foreground-2)" },
                        children:
                          "For your security, this password cannot be reset, so keep it somewhere safe.",
                      }),
                    ],
                  }),
                  (0, a.jsxs)(oi, {
                    centered: !0,
                    children: [
                      (0, a.jsx)(or, {
                        children: c ? "•".repeat(r.length) : r,
                      }),
                      (0, a.jsx)(od, {
                        style: { right: "0.75rem" },
                        children: c
                          ? (0, a.jsx)(op, { onClick: () => d(!1) })
                          : (0, a.jsx)(oh, { onClick: () => d(!0) }),
                      }),
                    ],
                  }),
                  (0, a.jsxs)("div", {
                    style: { display: "flex", margin: "12px 0", gap: "12px" },
                    children: [
                      (0, a.jsx)(oc, {
                        onClick: u,
                        children: (0, a.jsxs)(
                          a.Fragment,
                          s
                            ? {
                                children: [
                                  (0, a.jsx)(eR.Z, {
                                    style: { width: 24, height: 24 },
                                    stroke: "var(--privy-color-accent)",
                                  }),
                                  "Copied",
                                ],
                              }
                            : {
                                children: [
                                  (0, a.jsx)(eB.Z, {
                                    style: { width: 24, height: 24 },
                                    stroke: "var(--privy-color-accent)",
                                  }),
                                  "Copy",
                                ],
                              }
                        ),
                      }),
                      (0, a.jsxs)(oc, {
                        onClick: p,
                        children: [
                          (0, a.jsx)(eW.Z, {
                            style: { width: 24, height: 24 },
                            stroke: "var(--privy-color-accent)",
                          }),
                          "Download",
                        ],
                      }),
                    ],
                  }),
                ],
              }),
              (0, a.jsx)(ot, {
                onClick: i,
                loading: t,
                $hideAnimations: e,
                children: "Continue",
              }),
              (0, a.jsx)(r4, {}),
              (0, a.jsx)(aF, {}),
            ],
          });
        },
        oP = (e, t) => `Your wallet recovery password for ${e} is

${t}

You will need this password to access your ${e} wallet on a new device. Please keep it somewhere safe.`,
        oD = ({ error: e, onClose: t }) =>
          (0, a.jsxs)(a.Fragment, {
            children: [
              (0, a.jsx)(a4, { closeable: !1 }),
              (0, a.jsx)(r3, {}),
              (0, a.jsxs)(
                rJ,
                e
                  ? {
                      children: [
                        (0, a.jsx)(eU.Z, {
                          fill: "var(--privy-color-error)",
                          width: "64px",
                          height: "64px",
                        }),
                        (0, a.jsx)(iU, {
                          title: "Something went wrong",
                          description: e,
                        }),
                      ],
                    }
                  : {
                      children: [
                        (0, a.jsx)(eD.Z, {
                          fill: "var(--privy-color-success)",
                          width: "64px",
                          height: "64px",
                        }),
                        (0, a.jsx)(iU, { title: "Success" }),
                      ],
                    }
              ),
              (0, a.jsx)(a$, { onClick: t, children: "Close" }),
              (0, a.jsx)(r4, {}),
              (0, a.jsx)(aF, {}),
            ],
          }),
        oW = (e, t) => {
          switch (e) {
            case "creating":
              return "back" === t ? e : "saving";
            case "saving":
              return "back" === t ? "creating" : "confirming";
            case "confirming":
              return "back" === t ? "saving" : "finalizing";
            case "finalizing":
              return "back" === t ? "confirming" : "done";
            default:
              return e;
          }
        },
        oR = ({ onSubmit: e, ...t }) => {
          let { lastScreen: n, navigate: r } = ap(),
            { send: i, state: o } = (() => {
              let [e, t] = (0, C.useReducer)(oW, "creating");
              return { send: t, state: e };
            })(),
            s = (0, C.useCallback)(async () => {
              "finalizing" === o && (await e()), i("next");
            }, [o, i, e]);
          (0, C.useEffect)(() => {
            let e;
            return (
              "done" === o &&
                "automatic" === t.config.initiatedBy &&
                (e = setTimeout(() => t.onClose?.(), th)),
              () => {
                e && clearTimeout(e);
              }
            );
          }, [o, t.config.initiatedBy, t.onClose]);
          let l = (0, C.useCallback)(() => {
              i("back");
            }, [i]),
            c = (0, C.useCallback)(() => {
              r(i8);
            }, [n, r]);
          return "creating" === o
            ? (0, a.jsx)(oM, {
                ...t,
                onSubmit: s,
                onBack: n === i8 ? c : void 0,
              })
            : "saving" === o
            ? (0, a.jsx)(oL, { ...t, onSubmit: s, onBack: l })
            : "confirming" === o
            ? (0, a.jsx)(of, { ...t, onSubmit: s, onBack: l })
            : "finalizing" === o
            ? (0, a.jsx)(ob, { ...t, onSubmit: s, onBack: l })
            : "done" === o
            ? (0, a.jsx)(oD, { ...t, onSubmit: s })
            : null;
        },
        oB = {
          apple_oauth: "apple",
          custom_auth: "custom",
          discord_oauth: "discord",
          email: "email",
          farcaster: "farcaster",
          github_oauth: "github",
          google_oauth: "google",
          instagram_oauth: "instagram",
          linkedin_oauth: "linkedin",
          passkey: "passkey",
          phone: "sms",
          spotify_oauth: "spotify",
          telegram: "telegram",
          tiktok_oauth: "tiktok",
          line_oauth: "line",
          twitch_oauth: "twitch",
          twitter_oauth: "twitter",
          wallet: "siwe",
          smart_wallet: "siwe",
          cross_app: "privy:",
        },
        oU = (e) => {
          if ((0, k.i)(e))
            return {
              displayName: e.replace("custom:", ""),
              loginMethod: "custom",
            };
          let t = oB[e];
          return "wallet" === e || "phone" === e
            ? { displayName: e, loginMethod: t }
            : { displayName: t, loginMethod: t };
        },
        oO = (0, C.createContext)({}),
        oH = ({ children: e }) => {
          let t = ar(),
            [n, r] = (0, C.useState)({});
          return (
            am("login", {
              onComplete: ({ loginAccount: e }) => {
                e &&
                  "passkey" !== e.type &&
                  "cross_app" !== e.type &&
                  ("wallet" !== e.type || "privy" !== e.walletClientType) &&
                  (tn.put(oV(t.id), e.type),
                  "wallet" === e.type
                    ? (tn.put(o$(t.id), e.walletClientType),
                      tn.put(oZ(t.id), e.chainType),
                      r({
                        accountType: e.type,
                        walletClientType: e.walletClientType,
                        chainType: e.chainType,
                      }))
                    : (tn.del(o$(t.id)),
                      tn.del(oZ(t.id)),
                      r({ accountType: e.type })));
              },
            }),
            (0, C.useEffect)(() => {
              if (!t.id) return;
              let e = tn.get(oV(t.id)),
                n = tn.get(o$(t.id)),
                a = tn.get(oZ(t.id));
              e &&
                r(
                  "wallet" === e
                    ? { accountType: e, walletClientType: n, chainType: a }
                    : { accountType: e }
                );
            }, [t.id]),
            (0, a.jsx)(oO.Provider, { value: n, children: e })
          );
        },
        oV = (e) => `privy:${e}:recent-login-method`,
        o$ = (e) => `privy:${e}:recent-login-wallet-client`,
        oZ = (e) => `privy:${e}:recent-login-chain-type`,
        oq = () => (0, C.useContext)(oO),
        oG = () => {
          let e = ar(),
            t = e?.appearance?.logo,
            n = `${e?.name} logo`,
            r = { maxHeight: "90px", maxWidth: "180px" };
          return t
            ? "string" == typeof t
              ? (0, a.jsx)("img", { src: t, alt: n, style: r })
              : "svg" === t.type || "img" === t.type
              ? C.cloneElement(t, { alt: n, style: r })
              : (console.warn(
                  "`config.appearance.logo` must be a string, or an SVG / IMG element. Nothing will be rendered."
                ),
                null)
            : null;
        },
        oY = T.zo.div.withConfig({
          displayName: "AppLogoContainer",
          componentId: "sc-b210074-0",
        })([
          "display:flex;flex-direction:column;align-items:center;padding:24px 0;flex-grow:1;justify-content:center;",
        ]),
        oQ = ({ name: e, logoUrl: t, size: n = "38px" }) =>
          "string" == typeof t
            ? (0, a.jsx)("img", {
                src: t,
                alt: `${e ?? "Provider app"} logo`,
                style: {
                  width: n,
                  height: n,
                  maxHeight: "90px",
                  maxWidth: "180px",
                  borderRadius: "8px",
                },
              })
            : (0, a.jsx)("span", {}),
        oK = ({ appId: e }) => {
          let [t, n] = (0, C.useState)(void 0),
            { startCrossAppAuthFlow: r, authenticated: i } = (0, k.u)(),
            { client: o } = (0, j.u)();
          return (
            (0, C.useEffect)(() => {
              (async () => {
                o && n(await o.getCrossAppProviderDetails(e));
              })();
            }, [o]),
            (0, a.jsx)(aT, {
              onClick: () => r({ appId: e, action: i ? "link" : "login" }),
              disabled: !t,
              children: t
                ? (0, a.jsxs)(a.Fragment, {
                    children: [
                      (0, a.jsx)(oQ, {
                        name: t.name,
                        logoUrl: t.icon_url || void 0,
                        size: "24px",
                      }),
                      " ",
                      t.name,
                    ],
                  })
                : (0, a.jsx)(aU, {}),
            })
          );
        },
        oX = T.zo.a.withConfig({
          displayName: "StyledLink",
          componentId: "sc-c8577138-0",
        })(
          [
            "&&{color:",
            ";font-weight:400;text-decoration:",
            ";text-underline-offset:4px;text-decoration-thickness:1px;cursor:",
            ";opacity:",
            ";font-size:",
            ";line-height:",
            ";transition:color 200ms ease,text-decoration-color 200ms ease,opacity 200ms ease;&:hover{color:",
            ";text-decoration:",
            ";text-underline-offset:4px;}&:active{color:",
            ";}&:focus{outline:none;box-shadow:0 0 0 3px #949df9;border-radius:2px;}}",
          ],
          ({ $variant: e }) =>
            "underlined" === e
              ? "var(--privy-color-foreground)"
              : "var(--privy-link-navigation-color, var(--privy-color-accent))",
          ({ $variant: e }) =>
            "underlined" === e
              ? "underline"
              : "var(--privy-link-navigation-decoration, none)",
          ({ $disabled: e }) => (e ? "not-allowed" : "pointer"),
          ({ $disabled: e }) => (e ? 0.5 : 1),
          ({ $size: e }) => {
            switch (e) {
              case "xs":
                return "12px";
              case "sm":
                return "14px";
              default:
                return "16px";
            }
          },
          ({ $size: e }) => {
            switch (e) {
              case "xs":
                return "18px";
              case "sm":
                return "22px";
              default:
                return "24px";
            }
          },
          ({ $variant: e, $disabled: t }) =>
            "underlined" === e
              ? "var(--privy-color-foreground)"
              : "var(--privy-link-navigation-color, var(--privy-color-accent))",
          ({ $disabled: e }) => (e ? "none" : "underline"),
          ({ $variant: e, $disabled: t }) =>
            t
              ? "underlined" === e
                ? "var(--privy-color-foreground)"
                : "var(--privy-link-navigation-color, var(--privy-color-accent))"
              : "var(--privy-color-foreground)"
        ),
        oJ = ({
          size: e = "md",
          variant: t = "navigation",
          disabled: n = !1,
          as: r,
          children: i,
          onClick: o,
          ...s
        }) =>
          (0, a.jsx)(oX, {
            as: r,
            $size: e,
            $variant: t,
            $disabled: n,
            onClick: (e) => {
              n ? e.preventDefault() : o?.(e);
            },
            ...s,
            children: i,
          }),
        o0 = (e, t) =>
          !(0, k.b)(e) &&
          ("all-users" === t ||
            ("users-without-wallets" === t && !o1(e).length)),
        o1 = (e) =>
          e.linkedAccounts.filter(
            (e) => "wallet" === e.type && "ethereum" === e.chainType
          ),
        o2 = (e, t) =>
          !(0, k.l)(e) &&
          ("all-users" === t ||
            ("users-without-wallets" === t && !o3(e).length)),
        o3 = (e) =>
          e.linkedAccounts.filter(
            (e) => "wallet" === e.type && "solana" === e.chainType
          ),
        o4 = (e, t) =>
          o0(e, t.ethereum.createOnLogin) || o2(e, t.solana.createOnLogin),
        o5 = ({
          title: e = "Account not found",
          subtitle: t,
          appName: n = "this app",
          ctaText: r = "Try logging in again",
          onRetry: o,
        }) =>
          (0, a.jsx)(rS, {
            title: e,
            subtitle:
              t ||
              `Please try logging in again or go to ${n} to create an account.`,
            icon: i.Z,
            iconVariant: "warning",
            primaryCta: { label: r, onClick: o },
            watermark: !0,
          }),
        o6 = {
          component: () => {
            let { navigate: e, setModalData: t, data: n } = ap(),
              r = ar(),
              { getAuthMeta: i, client: o } = (0, j.u)();
            return (0, a.jsx)(o5, {
              appName: r?.name,
              onRetry: () => {
                let a = i();
                t({
                  ...n,
                  login: {
                    ...n?.login,
                    ...(a?.disableSignup ? { disableSignup: !0 } : {}),
                  },
                }),
                  o?.authFlow && (o.authFlow = void 0),
                  e(pD);
              },
            });
          },
        },
        o8 = T.zo.span.withConfig({
          displayName: "CircleBorder",
          componentId: "sc-9056b8b8-0",
        })(
          [
            "&&{width:82px;height:82px;border-width:4px;border-style:solid;border-color:",
            ";border-bottom-color:transparent;border-radius:50%;display:inline-block;box-sizing:border-box;animation:rotation 1.2s linear infinite;transition:border-color 800ms;border-bottom-color:",
            ";}",
          ],
          (e) => e.color ?? "var(--privy-color-accent)",
          (e) => e.color ?? "var(--privy-color-accent)"
        ),
        o7 = ({ address: e, showCopyIcon: t, url: n, className: r }) => {
          let [i, l] = (0, C.useState)(!1);
          function c(t) {
            t.stopPropagation(),
              navigator.clipboard
                .writeText(e)
                .then(() => l(!0))
                .catch(console.error);
          }
          return (
            (0, C.useEffect)(() => {
              if (i) {
                let e = setTimeout(() => l(!1), 3e3);
                return () => clearTimeout(e);
              }
            }, [i]),
            (0, a.jsxs)(
              o9,
              n
                ? {
                    children: [
                      (0, a.jsx)(st, {
                        title: e,
                        className: r,
                        href: `${n}/address/${e}`,
                        target: "_blank",
                        children: t9(e),
                      }),
                      t &&
                        (0, a.jsx)(aY, {
                          onClick: c,
                          size: "sm",
                          style: { gap: "0.375rem" },
                          children: (0, a.jsxs)(
                            a.Fragment,
                            i
                              ? {
                                  children: [
                                    "Copied",
                                    (0, a.jsx)(o.Z, { size: 16 }),
                                  ],
                                }
                              : {
                                  children: [
                                    "Copy",
                                    (0, a.jsx)(s.Z, { size: 16 }),
                                  ],
                                }
                          ),
                        }),
                    ],
                  }
                : {
                    children: [
                      (0, a.jsx)(se, {
                        title: e,
                        className: r,
                        children: t9(e),
                      }),
                      t &&
                        (0, a.jsx)(aY, {
                          onClick: c,
                          size: "sm",
                          style: { gap: "0.375rem", fontSize: "14px" },
                          children: (0, a.jsxs)(
                            a.Fragment,
                            i
                              ? {
                                  children: [
                                    "Copied",
                                    (0, a.jsx)(o.Z, { size: 14 }),
                                  ],
                                }
                              : {
                                  children: [
                                    "Copy",
                                    (0, a.jsx)(s.Z, { size: 14 }),
                                  ],
                                }
                          ),
                        }),
                    ],
                  }
            )
          );
        },
        o9 = T.zo.span.withConfig({
          displayName: "AddressContainer",
          componentId: "sc-3a987cc8-0",
        })(["display:inline-flex;align-items:center;gap:0.5rem;"]),
        se = T.zo.span.withConfig({
          displayName: "AddressText",
          componentId: "sc-3a987cc8-1",
        })([
          "font-size:14px;font-weight:500;color:var(--privy-color-foreground);",
        ]),
        st = T.zo.a.withConfig({
          displayName: "AddressLink",
          componentId: "sc-3a987cc8-2",
        })([
          "font-size:14px;color:var(--privy-color-foreground);text-decoration:none;&:hover{text-decoration:underline;}",
        ]);
      function sn(e) {
        return (0, a.jsxs)("svg", {
          xmlns: "http://www.w3.org/2000/svg",
          width: "24",
          height: "24",
          viewBox: "0 0 24 24",
          fill: "none",
          stroke: "currentColor",
          "stroke-width": "2",
          "stroke-linecap": "round",
          "stroke-linejoin": "round",
          ...e,
          children: [
            (0, a.jsx)("circle", { cx: "12", cy: "12", r: "10" }),
            (0, a.jsx)("line", { x1: "12", x2: "12", y1: "8", y2: "12" }),
            (0, a.jsx)("line", { x1: "12", x2: "12.01", y1: "16", y2: "16" }),
          ],
        });
      }
      let sa = "11111111111111111111111111111111",
        sr = "0x0000000000000000000000000000000000000000",
        si = ({ originCurrency: e, destinationCurrency: t, ...n }) => ({
          tradeType: "EXPECTED_OUTPUT",
          originCurrency: e ?? sr,
          destinationCurrency: t ?? sr,
          ...n,
        }),
        so = "https://api.relay.link",
        ss = "https://api.testnets.relay.link",
        sl = async ({ input: e, isTestnet: t }) => {
          let n = await fetch((t ? ss : so) + "/quote", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(e),
            }),
            a = await n.json();
          if (
            !(
              n.ok ||
              ("string" == typeof a.message &&
                a.message.startsWith("Invalid address"))
            )
          )
            throw (
              (console.error("Relay error:", a),
              Error(a.message ?? "Error fetching quote from relay"))
            );
          return a;
        },
        sc = (e) => {
          let t = e.steps[0]?.items?.[0];
          if (t)
            return {
              from: t.data.from,
              to: t.data.to,
              value: Number(t.data.value),
              chainId: Number(t.data.chainId),
              data: t.data.data,
            };
        };
      async function sd({ transactionHash: e, isTestnet: t }) {
        let n = await fetch((t ? ss : so) + "/requests/v2?hash=" + e),
          a = await n.json();
        if (!n.ok) {
          if ("message" in a && "string" == typeof a.message)
            throw Error(a.message);
          throw Error("Error fetching request from relay");
        }
        return a.requests.at(0)?.status ?? "pending";
      }
      function su({
        transactionHash: e,
        isTestnet: t,
        bridgingStatus: n,
        setBridgingStatus: a,
        onSuccess: r,
        onFailure: i,
      }) {
        (0, C.useEffect)(() => {
          if (e && n) {
            if (["delayed", "waiting", "pending"].includes(n)) {
              let n = setInterval(async () => {
                try {
                  let n = await sd({ transactionHash: e, isTestnet: t });
                  a(n);
                } catch (e) {
                  console.error(e);
                }
              }, 1e3);
              return () => clearInterval(n);
            }
            "success" === n
              ? r({ transactionHash: e })
              : ["refund", "failure"].includes(n) && i({ error: new sp(e, t) });
          }
        }, [n, e, t]);
      }
      class sp extends eh.P {
        constructor(e, t) {
          super(
            "We were unable to complete the bridging transaction. Funds will be refunded on your wallet.",
            void 0,
            eh.h.TRANSACTION_FAILURE
          ),
            (this.relayLink = t
              ? `https://testnets.relay.link/transaction/${e}`
              : `https://relay.link/transaction/${e}`);
        }
      }
      let sh = ({
          error: e,
          allowlistConfig: t,
          onRetry: n,
          onCaptchaReset: r,
          onBack: i,
        }) => {
          let o = ((e, t) => {
            if (e instanceof sp)
              return {
                title: "Transaction failed",
                detail: (0, a.jsxs)(a.Fragment, {
                  children: [
                    (0, a.jsx)("span", { children: e.message }),
                    (0, a.jsxs)("span", {
                      children: [
                        " ",
                        "Check the",
                        " ",
                        (0, a.jsx)(sf, {
                          href: e.relayLink,
                          target: "_blank",
                          children: "refund status",
                        }),
                        ".",
                      ],
                    }),
                  ],
                }),
                ctaText: "Try again",
                icon: l.Z,
              };
            if (e instanceof eh.P)
              switch (e.privyErrorCode) {
                case eh.h.CLIENT_REQUEST_TIMEOUT:
                  return {
                    title: "Timed out",
                    detail: e.message,
                    ctaText: "Try again",
                    icon: l.Z,
                  };
                case eh.h.INSUFFICIENT_BALANCE:
                  return {
                    title: "Insufficient balance",
                    detail: e.message,
                    ctaText: "Try again",
                    icon: l.Z,
                  };
                case eh.h.TRANSACTION_FAILURE:
                  return {
                    title: "Transaction failure",
                    detail: e.message,
                    ctaText: "Try again",
                    icon: l.Z,
                  };
                default:
                  return {
                    title: "Something went wrong",
                    detail: "Try again later",
                    ctaText: "Try again",
                    icon: l.Z,
                  };
              }
            else {
              if (e instanceof iN && "twilio_verification_failed" === e.type)
                return {
                  title: "Something went wrong",
                  detail: e.message,
                  ctaText: "Try again",
                  icon: c.Z,
                };
              if (!(e instanceof eh.aa))
                return e instanceof eh.G &&
                  e.status &&
                  [400, 422].includes(e.status)
                  ? {
                      title: "Something went wrong",
                      detail: e.message,
                      ctaText: "Try again",
                      icon: l.Z,
                    }
                  : {
                      title: "Something went wrong",
                      detail: "Try again later",
                      ctaText: "Try again",
                      icon: l.Z,
                    };
              switch (e.privyErrorCode) {
                case eh.h.INVALID_CAPTCHA:
                  return {
                    title: "Something went wrong",
                    detail: "Please try again.",
                    ctaText: "Try again",
                    icon: l.Z,
                  };
                case eh.h.DISALLOWED_LOGIN_METHOD:
                  return {
                    title: "Not allowed",
                    detail: e.message,
                    ctaText: "Try another method",
                    icon: l.Z,
                  };
                case eh.h.ALLOWLIST_REJECTED:
                  return {
                    title: t.errorTitle || "You don't have access to this app",
                    detail: t.errorDetail || "Have you been invited?",
                    ctaText: t.errorCtaText || "Try another account",
                    icon: d.Z,
                  };
                case eh.h.CAPTCHA_FAILURE:
                  return {
                    title: "Something went wrong",
                    detail: "You did not pass CAPTCHA. Please try again.",
                    ctaText: "Try again",
                    icon: null,
                  };
                case eh.h.CAPTCHA_TIMEOUT:
                  return {
                    title: "Something went wrong",
                    detail: "Something went wrong! Please try again later.",
                    ctaText: "Try again",
                    icon: null,
                  };
                case eh.h.LINKED_TO_ANOTHER_USER:
                  return {
                    title: "Authentication failed",
                    detail:
                      "This account has already been linked to another user.",
                    ctaText: "Try again",
                    icon: l.Z,
                  };
                case eh.h.NOT_SUPPORTED:
                  return {
                    title: "This region is not supported",
                    detail:
                      "SMS authentication from this region is not available",
                    ctaText: "Try another method",
                    icon: l.Z,
                  };
                case eh.h.TOO_MANY_REQUESTS:
                  return {
                    title: "Request failed",
                    detail: "Too many attempts.",
                    ctaText: "Try again later",
                    icon: l.Z,
                  };
                default:
                  return {
                    title: "Something went wrong",
                    detail: "Try again later",
                    ctaText: "Try again",
                    icon: l.Z,
                  };
              }
            }
          })(e, t);
          return (0, a.jsx)(rS, {
            title: o.title,
            subtitle: o.detail,
            icon: o.icon,
            onBack: i,
            iconVariant: "error",
            primaryCta: {
              label: o.ctaText,
              onClick: () => {
                e instanceof eh.aa &&
                (e.privyErrorCode === eh.h.INVALID_CAPTCHA && r?.(),
                e.privyErrorCode === eh.h.ALLOWLIST_REJECTED && t.errorCtaLink)
                  ? (window.location.href = t.errorCtaLink)
                  : n?.();
              },
              variant: "error",
            },
            watermark: !0,
          });
        },
        sg = {
          component: () => {
            let {
                navigate: e,
                data: t,
                lastScreen: n,
                currentScreen: r,
              } = ap(),
              i = ar(),
              { reset: o } = np(),
              s = t?.errorModalData?.previousScreen || (n === r ? void 0 : n);
            return (0, a.jsx)(sh, {
              error: t?.errorModalData?.error || Error(),
              allowlistConfig: i.allowlistConfig,
              onRetry: () => {
                e(s || pD, !1);
              },
              onCaptchaReset: o,
            });
          },
        },
        sf = T.zo.a.withConfig({
          displayName: "Link",
          componentId: "sc-e29a7de8-0",
        })(["color:var(--privy-color-accent) !important;font-weight:600;"]),
        sm = ({ onTransfer: e, isTransferring: t, transferSuccess: n }) =>
          (0, a.jsx)(a$, {
            ...(n
              ? { success: !0, children: "Success!" }
              : {
                  warn: !0,
                  loading: t,
                  onClick: e,
                  children: "Transfer and delete account",
                }),
          }),
        sy = T.zo.div.withConfig({
          displayName: "ConnectContainer",
          componentId: "sc-3505eb4c-0",
        })([
          "display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;width:100%;padding-bottom:16px;",
        ]),
        sw = T.zo.div.withConfig({
          displayName: "GappedContainer",
          componentId: "sc-3505eb4c-1",
        })([
          "display:flex;flex-direction:column;&& p{font-size:14px;}width:100%;gap:16px;",
        ]),
        sv = T.zo.div.withConfig({
          displayName: "DisclosedAccountContainer",
          componentId: "sc-3505eb4c-2",
        })([
          "display:flex;cursor:pointer;align-items:center;width:100%;border:1px solid var(--privy-color-foreground-4) !important;border-radius:var(--privy-border-radius-md);padding:8px 10px;font-size:14px;font-weight:500;gap:8px;",
        ]),
        sx = (0, T.zo)(eT.Z).withConfig({
          displayName: "StyledExclamationCircleIcon",
          componentId: "sc-3505eb4c-3",
        })(
          [
            "position:relative;width:",
            ";height:",
            ";color:var(--privy-color-foreground-3);margin-left:auto;",
          ],
          ({ $iconSize: e }) => `${e}px`,
          ({ $iconSize: e }) => `${e}px`
        ),
        sb = (0, T.zo)(eA.Z).withConfig({
          displayName: "StyledCopyIcon",
          componentId: "sc-3505eb4c-4",
        })([
          "position:relative;width:15px;height:15px;color:var(--privy-color-foreground-3);margin-left:auto;",
        ]),
        sC = T.zo.ol.withConfig({
          displayName: "ListContainer",
          componentId: "sc-3505eb4c-5",
        })([
          "display:flex;flex-direction:column;font-size:14px;width:100%;text-align:left;",
        ]),
        sj = T.zo.li.withConfig({
          displayName: "ListItem",
          componentId: "sc-3505eb4c-6",
        })([
          "font-size:14px;list-style-type:auto;list-style-position:outside;margin-left:1rem;margin-bottom:0.5rem;&:last-child{margin-bottom:0;}",
        ]),
        sk = T.zo.div.withConfig({
          displayName: "CircleContainer",
          componentId: "sc-3505eb4c-7",
        })([
          "position:relative;width:60px;height:60px;margin:10px;display:flex;justify-content:center;align-items:center;",
        ]),
        sT = () =>
          (0, a.jsx)(sk, { children: (0, a.jsx)(sx, { $iconSize: 60 }) }),
        sA = ({
          address: e,
          onClose: t,
          onRetry: n,
          onTransfer: r,
          isTransferring: i,
          transferSuccess: o,
        }) => {
          let { defaultChain: s } = ar(),
            l = s.blockExplorers?.default.url ?? "https://etherscan.io";
          return (0, a.jsxs)(a.Fragment, {
            children: [
              (0, a.jsx)(a4, { onClose: t, backFn: n }),
              (0, a.jsxs)(sy, {
                children: [
                  (0, a.jsx)(sT, {}),
                  (0, a.jsxs)(sw, {
                    children: [
                      (0, a.jsx)("h3", {
                        children: "Check account assets before transferring",
                      }),
                      (0, a.jsx)("p", {
                        children:
                          "Before transferring, ensure there are no assets in the other account. Assets in that account will not transfer automatically and may be lost.",
                      }),
                      (0, a.jsxs)(sC, {
                        children: [
                          (0, a.jsx)("p", {
                            children: " To check your balance, you can:",
                          }),
                          (0, a.jsx)(sj, {
                            children:
                              "Log out and log back into the other account, or ",
                          }),
                          (0, a.jsxs)(sj, {
                            children: [
                              "Copy your wallet address and use a",
                              " ",
                              (0, a.jsx)("u", {
                                children: (0, a.jsx)("a", {
                                  target: "_blank",
                                  href: l,
                                  children: "block explorer",
                                }),
                              }),
                              " ",
                              "to see if the account holds any assets.",
                            ],
                          }),
                        ],
                      }),
                      (0, a.jsxs)(sv, {
                        onClick: () =>
                          navigator.clipboard.writeText(e).catch(console.error),
                        children: [
                          (0, a.jsx)(ek.Z, {
                            color: "var(--privy-color-foreground-1)",
                            strokeWidth: 2,
                            height: "28px",
                            width: "28px",
                          }),
                          (0, a.jsx)(o7, { address: e, showCopyIcon: !1 }),
                          (0, a.jsx)(sb, {}),
                        ],
                      }),
                      (0, a.jsx)(sm, {
                        onTransfer: r,
                        isTransferring: i,
                        transferSuccess: o,
                      }),
                    ],
                  }),
                ],
              }),
              (0, a.jsx)(aF, {}),
            ],
          });
        },
        sS = {
          component: () => {
            let { initiateAccountTransfer: e, closePrivyModal: t } = (0, j.u)(),
              { data: n, navigate: r, lastScreen: i, setModalData: o } = ap(),
              [s, l] = (0, C.useState)(void 0),
              [c, d] = (0, C.useState)(!1),
              [u, p] = (0, C.useState)(!1),
              h = async () => {
                try {
                  if (
                    !n?.accountTransfer?.nonce ||
                    !n?.accountTransfer?.account
                  )
                    throw Error("missing account transfer inputs");
                  p(!0),
                    await e({
                      nonce: n?.accountTransfer?.nonce,
                      account: n?.accountTransfer?.account,
                      accountType: n?.accountTransfer?.linkMethod,
                      externalWalletMetadata:
                        n?.accountTransfer?.externalWalletMetadata,
                      telegramWebAppData:
                        n?.accountTransfer?.telegramWebAppData,
                      telegramAuthResult:
                        n?.accountTransfer?.telegramAuthResult,
                      farcasterEmbeddedAddress:
                        n?.accountTransfer?.farcasterEmbeddedAddress,
                      oAuthUserInfo: n?.accountTransfer?.oAuthUserInfo,
                    }),
                    d(!0),
                    p(!1),
                    setTimeout(t, 1e3);
                } catch (e) {
                  o({ errorModalData: { error: e, previousScreen: i || sS } }),
                    r(sg, !0);
                }
              };
            return s
              ? (0, a.jsx)(sA, {
                  address: s,
                  onClose: t,
                  onRetry: () => l(void 0),
                  onTransfer: h,
                  isTransferring: u,
                  transferSuccess: c,
                })
              : (0, a.jsx)(sI, {
                  onClose: t,
                  onInfo: () => l(n?.accountTransfer?.embeddedWalletAddress),
                  onContinue: () =>
                    l(n?.accountTransfer?.embeddedWalletAddress),
                  onTransfer: h,
                  isTransferring: u,
                  transferSuccess: c,
                  data: n,
                });
          },
        },
        sI = ({
          onClose: e,
          onContinue: t,
          onInfo: n,
          onTransfer: r,
          transferSuccess: i,
          isTransferring: o,
          data: s,
        }) => {
          if (
            !s?.accountTransfer?.linkMethod ||
            !s?.accountTransfer?.displayName
          )
            return;
          let l = {
            method: s?.accountTransfer?.linkMethod,
            handle: s?.accountTransfer?.displayName,
            disclosedAccount: s?.accountTransfer?.embeddedWalletAddress
              ? {
                  type: "wallet",
                  handle: s?.accountTransfer?.embeddedWalletAddress,
                }
              : void 0,
          };
          return (0, a.jsxs)(a.Fragment, {
            children: [
              (0, a.jsx)(a4, { closeable: !0 }),
              (0, a.jsxs)(sy, {
                children: [
                  (0, a.jsx)(iI, {
                    children: (0, a.jsxs)("div", {
                      children: [
                        (0, a.jsx)(o8, { color: "var(--privy-color-error)" }),
                        (0, a.jsx)(ej.Z, {
                          height: 38,
                          width: 38,
                          stroke: "var(--privy-color-error)",
                        }),
                      ],
                    }),
                  }),
                  (0, a.jsxs)(sw, {
                    children: [
                      (0, a.jsxs)("h3", {
                        children: [
                          (function (e) {
                            switch (e) {
                              case "sms":
                                return "Phone number";
                              case "email":
                                return "Email address";
                              case "siwe":
                                return "Wallet address";
                              case "siws":
                                return "Solana wallet address";
                              case "linkedin":
                                return "LinkedIn profile";
                              case "google":
                              case "apple":
                              case "discord":
                              case "github":
                              case "instagram":
                              case "spotify":
                              case "tiktok":
                              case "line":
                              case "twitch":
                              case "twitter":
                              case "telegram":
                              case "farcaster":
                                return `${tB(e.replace("_oauth", ""))} profile`;
                              default:
                                return e.startsWith("privy:")
                                  ? "Cross-app account"
                                  : e;
                            }
                          })(l.method),
                          " is associated with another account",
                        ],
                      }),
                      (0, a.jsxs)("p", {
                        children: [
                          "Do you want to transfer",
                          (0, a.jsx)("b", {
                            children: l.handle ? ` ${l.handle}` : "",
                          }),
                          " to this account instead? This will delete your other account.",
                        ],
                      }),
                      (0, a.jsx)(sE, {
                        onClick: n,
                        disclosedAccount: l.disclosedAccount,
                      }),
                    ],
                  }),
                  (0, a.jsxs)(sw, {
                    style: { gap: 12, marginTop: 12 },
                    children: [
                      s?.accountTransfer?.embeddedWalletAddress
                        ? (0, a.jsx)(a$, { onClick: t, children: "Continue" })
                        : (0, a.jsx)(sm, {
                            onTransfer: r,
                            transferSuccess: i,
                            isTransferring: o,
                          }),
                      (0, a.jsx)(aY, { onClick: e, children: "No thanks" }),
                    ],
                  }),
                ],
              }),
              (0, a.jsx)(aF, {}),
            ],
          });
        };
      function sE({ disclosedAccount: e, onClick: t }) {
        return e
          ? (0, a.jsxs)(sv, {
              onClick: t,
              children: [
                (0, a.jsx)(ek.Z, {
                  color: "var(--privy-color-foreground-1)",
                  strokeWidth: 2,
                  height: "28px",
                  width: "28px",
                }),
                (0, a.jsx)(o7, { address: e.handle, showCopyIcon: !1 }),
                (0, a.jsx)(sn, {
                  width: 15,
                  height: 15,
                  color: "var(--privy-color-foreground-3)",
                  style: { marginLeft: "auto" },
                }),
              ],
            })
          : null;
      }
      let sN = ({ errorMessage: e, onClose: t }) =>
          (0, a.jsx)(
            rS,
            e
              ? {
                  title: "Something went wrong",
                  subtitle: e,
                  icon: u.Z,
                  iconVariant: "error",
                  primaryCta: { label: "Close", onClick: t },
                  watermark: !0,
                }
              : {
                  title: "Creating your wallet",
                  subtitle: "Please wait...",
                  iconVariant: "loading",
                  watermark: !1,
                }
          ),
        s_ = {
          component: () => {
            let {
                setModalData: e,
                navigate: t,
                data: n,
                onUserCloseViaDialogOrKeybindRef: r,
              } = ap(),
              i = ar(),
              [o, s] = (0, C.useState)(""),
              { embeddedWallets: l } = ar(),
              { authenticated: c, user: d } = (0, k.u)(),
              { closePrivyModal: u, walletProxy: p, client: h } = (0, j.u)(),
              {
                onSuccess: g,
                onFailure: f,
                callAuthOnSuccessOnClose: m,
                shouldCreateEth: y,
                shouldCreateSol: w,
              } = n.createWallet,
              v =
                "legacy-embedded-wallets-only" === i.embeddedWallets.mode &&
                !0 === i?.embeddedWallets.requireUserOwnedRecoveryOnCreate,
              [x, b] = (0, C.useState)(null),
              { create: T } = iK(),
              A = y ?? (!!d && o0(d, i.embeddedWallets.ethereum.createOnLogin)),
              S = w ?? (!!d && o2(d, i.embeddedWallets.solana.createOnLogin)),
              I = new td(async () => {
                let e = await h.getAccessToken();
                if (d && e && p)
                  try {
                    let e;
                    if (A && S)
                      (e = await T({
                        chainType: "ethereum",
                        walletIndex: 0,
                        latestUser: d,
                      })),
                        (e = await T({
                          chainType: "solana",
                          walletIndex: 0,
                          latestUser: e.user,
                        }));
                    else if (S)
                      e = await T({
                        chainType: "solana",
                        walletIndex: 0,
                        latestUser: d,
                      });
                    else {
                      if (!A) return void u({ shouldCallAuthOnSuccess: m });
                      e = await T({
                        chainType: "ethereum",
                        walletIndex: 0,
                        latestUser: d,
                      });
                    }
                    b(e), t(iJ);
                  } catch (e) {
                    s(e.message);
                  }
              });
            return (
              (0, C.useEffect)(
                () =>
                  c && d
                    ? v
                      ? (e({
                          ...n,
                          createWallet: {
                            ...n.createWallet,
                            shouldCreateEth: A,
                            shouldCreateSol: S,
                          },
                          recoverySelection: {
                            ...n?.recoverySelection,
                            isInAccountCreateFlow: !0,
                            shouldCreateEth: A,
                            shouldCreateSol: S,
                          },
                        }),
                        t(
                          pG({
                            walletAction: "create",
                            showAutomaticRecovery: !1,
                            availableRecoveryMethods:
                              l.userOwnedRecoveryOptions,
                            legacySetWalletPasswordFlow: !1,
                            isResettingPassword: !1,
                          })
                        ))
                      : void I.execute()
                    : (t(pD),
                      void f(
                        Error(
                          "User must be authenticated before creating a Privy wallet"
                        )
                      )),
                [v, c]
              ),
              (r.current = () => null),
              (0, a.jsx)(sN, {
                errorMessage: o || void 0,
                onClose: () => {
                  x
                    ? (g(x), u({ shouldCallAuthOnSuccess: m }))
                    : (f(new eh.ai("User wallet creation failed")),
                      u({ shouldCallAuthOnSuccess: !1 }));
                },
              })
            );
          },
        },
        sM = {
          component: () => {
            let { user: e, logout: t } = (0, k.u)(),
              {
                onUserCloseViaDialogOrKeybindRef: n,
                setModalData: r,
                navigate: i,
              } = ap(),
              o = ar(),
              {
                acceptTerms: s,
                closePrivyModal: l,
                createAnalyticsEvent: c,
              } = (0, j.u)(),
              d = (e) => {
                e?.preventDefault(), l({ shouldCallAuthOnSuccess: !1 }), t();
              };
            return (
              (n.current = d),
              (0, a.jsx)(sF, {
                termsAndConditionsUrl: o?.legal.termsAndConditionsUrl,
                privacyPolicyUrl: o?.legal.privacyPolicyUrl,
                onAccept: async (n) => {
                  n?.preventDefault(),
                    await s(),
                    e && o4(e, o.embeddedWallets)
                      ? (r({
                          createWallet: {
                            onSuccess: () => {},
                            onFailure: (e) => {
                              console.error(e),
                                c({
                                  eventName:
                                    "embedded_wallet_creation_failure_logout",
                                  payload: {
                                    error: e,
                                    screen: "AffirmativeConsentScreen",
                                  },
                                }),
                                t();
                            },
                            callAuthOnSuccessOnClose: !0,
                          },
                        }),
                        i(s_))
                      : l();
                },
                onDecline: d,
              })
            );
          },
        },
        sF = ({
          termsAndConditionsUrl: e,
          privacyPolicyUrl: t,
          onAccept: n,
          onDecline: r,
          title: i = "One last step",
          subtitle:
            o = "By signing up, you agree to our terms and privacy policy.",
        }) =>
          (0, a.jsx)(rS, {
            title: i,
            subtitle: o,
            icon: p.Z,
            primaryCta: { label: "Accept", onClick: n },
            secondaryCta: { label: "No thanks", onClick: r },
            watermark: !0,
            children:
              (e || t) &&
              (0, a.jsxs)(sz, {
                children: [
                  e &&
                    (0, a.jsxs)(aH, {
                      variant: "muted",
                      href: e,
                      target: "_blank",
                      size: "lg",
                      style: { justifyContent: "space-between" },
                      as: "a",
                      children: [
                        "View Terms",
                        (0, a.jsx)(h.Z, {
                          width: 16,
                          height: 16,
                          strokeWidth: 2.25,
                        }),
                      ],
                    }),
                  t &&
                    (0, a.jsxs)(aH, {
                      variant: "muted",
                      href: t,
                      target: "_blank",
                      size: "lg",
                      style: { justifyContent: "space-between" },
                      as: "a",
                      children: [
                        "View Privacy Policy",
                        (0, a.jsx)(h.Z, {
                          width: 16,
                          height: 16,
                          strokeWidth: 2.25,
                        }),
                      ],
                    }),
                ],
              }),
          }),
        sz = T.zo.div.withConfig({
          displayName: "LinksContainer",
          componentId: "sc-21e1b98c-0",
        })([
          "display:flex;flex-direction:column;gap:12px;margin-top:var(--screen-space);",
        ]),
        sL = ({ color: e, ...t }) =>
          (0, a.jsx)("svg", {
            version: "1.1",
            id: "Layer_1",
            xmlns: "http://www.w3.org/2000/svg",
            xmlnsXlink: "http://www.w3.org/1999/xlink",
            x: "0px",
            y: "0px",
            viewBox: "0 0 115.77 122.88",
            xmlSpace: "preserve",
            ...t,
            children: (0, a.jsx)("g", {
              children: (0, a.jsx)("path", {
                fill: e || "currentColor",
                className: "st0",
                d: "M89.62,13.96v7.73h12.19h0.01v0.02c3.85,0.01,7.34,1.57,9.86,4.1c2.5,2.51,4.06,5.98,4.07,9.82h0.02v0.02 v73.27v0.01h-0.02c-0.01,3.84-1.57,7.33-4.1,9.86c-2.51,2.5-5.98,4.06-9.82,4.07v0.02h-0.02h-61.7H40.1v-0.02 c-3.84-0.01-7.34-1.57-9.86-4.1c-2.5-2.51-4.06-5.98-4.07-9.82h-0.02v-0.02V92.51H13.96h-0.01v-0.02c-3.84-0.01-7.34-1.57-9.86-4.1 c-2.5-2.51-4.06-5.98-4.07-9.82H0v-0.02V13.96v-0.01h0.02c0.01-3.85,1.58-7.34,4.1-9.86c2.51-2.5,5.98-4.06,9.82-4.07V0h0.02h61.7 h0.01v0.02c3.85,0.01,7.34,1.57,9.86,4.1c2.5,2.51,4.06,5.98,4.07,9.82h0.02V13.96L89.62,13.96z M79.04,21.69v-7.73v-0.02h0.02 c0-0.91-0.39-1.75-1.01-2.37c-0.61-0.61-1.46-1-2.37-1v0.02h-0.01h-61.7h-0.02v-0.02c-0.91,0-1.75,0.39-2.37,1.01 c-0.61,0.61-1,1.46-1,2.37h0.02v0.01v64.59v0.02h-0.02c0,0.91,0.39,1.75,1.01,2.37c0.61,0.61,1.46,1,2.37,1v-0.02h0.01h12.19V35.65 v-0.01h0.02c0.01-3.85,1.58-7.34,4.1-9.86c2.51-2.5,5.98-4.06,9.82-4.07v-0.02h0.02H79.04L79.04,21.69z M105.18,108.92V35.65v-0.02 h0.02c0-0.91-0.39-1.75-1.01-2.37c-0.61-0.61-1.46-1-2.37-1v0.02h-0.01h-61.7h-0.02v-0.02c-0.91,0-1.75,0.39-2.37,1.01 c-0.61,0.61-1,1.46-1,2.37h0.02v0.01v73.27v0.02h-0.02c0,0.91,0.39,1.75,1.01,2.37c0.61,0.61,1.46,1,2.37,1v-0.02h0.01h61.7h0.02 v0.02c0.91,0,1.75-0.39,2.37-1.01c0.61-0.61,1-1.46,1-2.37h-0.02V108.92L105.18,108.92z",
              }),
            }),
          }),
        sP = T.zo.button.withConfig({
          displayName: "CopyTextButton",
          componentId: "sc-4b0620dc-0",
        })([
          "display:flex;align-items:center;gap:0.5rem;&:hover{text-decoration:underline;}svg{width:0.875rem;height:0.875rem;}",
        ]),
        sD = T.zo.span.withConfig({
          displayName: "CopiedText",
          componentId: "sc-4b0620dc-1",
        })([
          "display:flex;align-items:center;gap:0.25rem;font-size:0.875rem;color:var(--privy-color-foreground-2);",
        ]),
        sW = (0, T.zo)(eG.Z).withConfig({
          displayName: "GreenCheck",
          componentId: "sc-4b0620dc-2",
        })(["color:var(--privy-color-success);"]),
        sR = (0, T.zo)(sL).withConfig({
          displayName: "StyledCopy",
          componentId: "sc-4b0620dc-3",
        })(["color:var(--privy-color-foreground-3);opactiy:0.5;"]),
        sB = () =>
          (0, a.jsx)("svg", {
            width: "200",
            height: "200",
            viewBox: "-77 -77 200 200",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            style: { height: "28px", width: "28px" },
            children: (0, a.jsx)("rect", {
              width: "50",
              height: "50",
              fill: "black",
              rx: 10,
              ry: 10,
            }),
          }),
        sU = (e, t, n, a, r) => {
          for (let i = t; i < t + a; i++)
            for (let t = n; t < n + r; t++) {
              let n = e?.[t];
              n && n[i] && (n[i] = 0);
            }
          return e;
        },
        sO = ({ x: e, y: t, cellSize: n, bgColor: r, fgColor: i }) =>
          (0, a.jsx)(a.Fragment, {
            children: [0, 1, 2].map((o) =>
              (0, a.jsx)(
                "circle",
                {
                  r: (n * (7 - 2 * o)) / 2,
                  cx: e + (7 * n) / 2,
                  cy: t + (7 * n) / 2,
                  fill: o % 2 != 0 ? r : i,
                },
                `finder-${e}-${t}-${o}`
              )
            ),
          }),
        sH = ({ cellSize: e, matrixSize: t, bgColor: n, fgColor: r }) =>
          (0, a.jsx)(a.Fragment, {
            children: [
              [0, 0],
              [(t - 7) * e, 0],
              [0, (t - 7) * e],
            ].map(([t, i]) =>
              (0, a.jsx)(
                sO,
                { x: t, y: i, cellSize: e, bgColor: n, fgColor: r },
                `finder-${t}-${i}`
              )
            ),
          }),
        sV = ({ matrix: e, cellSize: t, color: n }) =>
          (0, a.jsx)(a.Fragment, {
            children: e.map((e, r) =>
              e.map((e, i) =>
                e
                  ? (0, a.jsx)(
                      "rect",
                      {
                        height: t - 0.4,
                        width: t - 0.4,
                        x: r * t + 0.1 * t,
                        y: i * t + 0.1 * t,
                        rx: 0.5 * t,
                        ry: 0.5 * t,
                        fill: n,
                      },
                      `cell-${r}-${i}`
                    )
                  : (0, a.jsx)(C.Fragment, {}, `circle-${r}-${i}`)
              )
            ),
          }),
        s$ = ({
          cellSize: e,
          matrixSize: t,
          element: n,
          sizePercentage: r,
          bgColor: i,
        }) => {
          if (!n) return (0, a.jsx)(a.Fragment, {});
          let o = t * (r || 0.14),
            s = Math.floor(t / 2 - o / 2),
            l = Math.floor(t / 2 + o / 2);
          (l - s) % 2 != t % 2 && (l += 1);
          let c = (l - s) * e,
            d = c - 0.2 * c,
            u = s * e;
          return (0, a.jsxs)(a.Fragment, {
            children: [
              (0, a.jsx)("rect", {
                x: s * e,
                y: s * e,
                width: c,
                height: c,
                fill: i,
              }),
              (0, a.jsx)(n, {
                x: u + 0.1 * c,
                y: u + 0.1 * c,
                height: d,
                width: d,
              }),
            ],
          });
        },
        sZ = (e) => {
          var t, n;
          let r, i;
          let o = e.outputSize,
            s =
              ((t = e.url),
              (n = e.errorCorrectionLevel),
              (i = sU(
                (i = ((e, t) => {
                  let n = e.slice(0),
                    a = [];
                  for (; n.length; ) a.push(n.splice(0, t));
                  return a;
                })(
                  Array.from(
                    (r = eY.create(t, { errorCorrectionLevel: n }).modules).data
                  ),
                  r.size
                )),
                0,
                0,
                7,
                7
              )),
              (i = sU(i, i.length - 7, 0, 7, 7)),
              sU(i, 0, i.length - 7, 7, 7)),
            l = o / s.length,
            c = (function (e, { min: t, max: n }) {
              return Math.min(Math.max(e, t), n);
            })(2 * l, { min: 0.025 * o, max: 0.036 * o });
          return (0, a.jsxs)("svg", {
            height: e.outputSize,
            width: e.outputSize,
            viewBox: `0 0 ${e.outputSize} ${e.outputSize}`,
            style: { height: "100%", width: "100%", padding: `${c}px` },
            children: [
              (0, a.jsx)(sV, { matrix: s, cellSize: l, color: e.fgColor }),
              (0, a.jsx)(sH, {
                cellSize: l,
                matrixSize: s.length,
                fgColor: e.fgColor,
                bgColor: e.bgColor,
              }),
              (0, a.jsx)(s$, {
                cellSize: l,
                element: e.logo?.element,
                bgColor: e.bgColor,
                matrixSize: s.length,
              }),
            ],
          });
        },
        sq = T.zo.div
          .attrs({ className: "ph-no-capture" })
          .withConfig({
            displayName: "QrContainer",
            componentId: "sc-597e27f3-0",
          })(
          [
            "display:flex;justify-content:center;align-items:center;height:",
            ";width:",
            ";margin:auto;background-color:",
            ";&&{border-width:2px;border-color:",
            ";border-radius:var(--privy-border-radius-md);}",
          ],
          (e) => `${e.$size}px`,
          (e) => `${e.$size}px`,
          (e) => e.$bgColor,
          (e) => e.$borderColor
        ),
        sG = (e) => {
          let { appearance: t } = ar(),
            n = e.bgColor || "#FFFFFF",
            r = e.fgColor || "#000000",
            i = e.size || 160,
            o = "dark" === t.palette.colorScheme ? n : r;
          return (0, a.jsx)(sq, {
            $size: i,
            $bgColor: n,
            $fgColor: r,
            $borderColor: o,
            children: (0, a.jsx)(sZ, {
              url: e.url,
              logo: { element: e.squareLogoElement ?? sB },
              outputSize: i,
              bgColor: n,
              fgColor: r,
              errorCorrectionLevel: e.errorCorrectionLevel || "Q",
            }),
          });
        },
        sY = T.zo.span.withConfig({
          displayName: "ErrorMessage",
          componentId: "sc-fcb8cd50-0",
        })([
          "text-align:left;font-size:0.75rem;font-weight:500;line-height:1.125rem;color:var(--privy-color-error);",
        ]),
        sQ = T.zo.label.withConfig({
          displayName: "BaseEmailForm",
          componentId: "sc-f34af797-0",
        })(
          [
            "display:block;position:relative;width:100%;height:56px;&& > :first-child{position:absolute;left:0.75em;top:50%;transform:translate(0,-50%);}&& > input{font-size:16px;line-height:24px;color:var(--privy-color-foreground);padding:12px 88px 12px 52px;flex-grow:1;background:var(--privy-color-background);border:1px solid ",
            ";border-radius:var(--privy-border-radius-md);width:100%;height:100%;@media (min-width:441px){font-size:14px;padding-right:78px;}:focus{outline:none;border-color:",
            ";box-shadow:",
            ";}:autofill,:-webkit-autofill{background:var(--privy-color-background);}&& > input::placeholder{color:var(--privy-color-foreground-3);}&:disabled{opacity:0.4;cursor:not-allowed;}&:disabled,&:disabled:hover,&:disabled > span{color:var(--privy-color-foreground-3);}}&& > button:last-child{right:0px;line-height:24px;padding:13px 17px;:focus{outline:none;}&:disabled{opacity:0.4;cursor:not-allowed;}&:disabled,&:disabled:hover,&:disabled > span{color:var(--privy-color-foreground-3);}}",
          ],
          ({ $error: e }) =>
            e
              ? "var(--privy-color-error) !important"
              : "var(--privy-color-foreground-4)",
          ({ $error: e }) =>
            e
              ? "var(--privy-color-error) !important"
              : "var(--privy-color-accent-light)",
          ({ $error: e }) =>
            e ? "none" : "0 0 0 1px var(--privy-color-accent-light)"
        ),
        sK = (0, T.zo)(sQ).withConfig({
          displayName: "EmailUpdateForm",
          componentId: "sc-f34af797-1",
        })([
          "background-color:var(--privy-color-background);transition:background-color 200ms ease;&& > button{right:0;line-height:24px;position:absolute;padding:13px 17px;background-color:#090;:focus{outline:none;border-color:var(--privy-color-accent);}}",
        ]),
        sX = (0, T.zo)(sQ).withConfig({
          displayName: "EmailInputForm",
          componentId: "sc-f34af797-2",
        })(
          [
            "&& > input{overflow:hidden;white-space:nowrap;text-overflow:ellipsis;padding-right:",
            ";border:1px solid ",
            ";&& > input::placeholder{color:var(--privy-color-foreground-3);}}&& > :last-child{right:16px;position:absolute;top:50%;transform:translate(0,-50%);}&& > button:last-child{right:0px;line-height:24px;padding:13px 17px;:focus{outline:none;}}",
          ],
          (e) => (e.$stacked ? "16px" : "88px"),
          ({ $error: e }) =>
            e
              ? "var(--privy-color-error) !important"
              : "var(--privy-color-foreground-4)"
        ),
        sJ = T.zo.div.withConfig({
          displayName: "InputContainerForm",
          componentId: "sc-f34af797-3",
        })(
          [
            "width:100%;&& > ",
            "{display:block;text-align:left;padding-left:var(--privy-border-radius-md);padding-bottom:5px;}",
          ],
          sY
        ),
        s0 = ({ ...e }) =>
          (0, a.jsxs)("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            width: "16",
            height: "16",
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            ...e,
            children: [
              (0, a.jsx)("rect", {
                width: "18",
                height: "18",
                x: "3",
                y: "3",
                rx: "2",
              }),
              (0, a.jsx)("path", { d: "M3 9a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2" }),
              (0, a.jsx)("path", {
                d: "M3 11h3c.8 0 1.6.3 2.1.9l1.1.9c1.6 1.6 4.1 1.6 5.7 0l1.1-.9c.5-.5 1.3-.9 2.1-.9H21",
              }),
            ],
          }),
        s1 = {
          phantom: {
            mobile: {
              native: "phantom://",
              universal: "https://phantom.app/ul/",
            },
          },
          solflare: {
            mobile: {
              native: void 0,
              universal: "https://solflare.com/ul/v1/",
            },
          },
          metamask: { image_url: { sm: nW, md: nW } },
        };
      class s2 {
        static normalize(e) {
          return e
            .replace(/[-_]wallet$/, "")
            .replace(/[-_]extension$/, "")
            .toLowerCase();
        }
        isEth(e) {
          return e.chains.some((e) => e.startsWith("eip155:"));
        }
        isSol(e) {
          return e.chains.some((e) => e.startsWith("solana:"));
        }
        inAllowList(e, t) {
          if (
            !this.normalizedAllowList ||
            0 === this.normalizedAllowList.length ||
            ("listing" === t && this.includeWalletConnect)
          )
            return !0;
          let n = s2.normalize(e);
          return this.normalizedAllowList.some((e) => n === s2.normalize(e));
        }
        chainMatches(e) {
          return "ethereum-only" === this.chainFilter
            ? "ethereum" === e
            : "solana-only" !== this.chainFilter || "solana" === e;
        }
        connectorOk(e) {
          return !!(
            "null" !== e.connectorType &&
            this.chainMatches(e.chainType) &&
            (this.inAllowList(e.walletClientType, "connector") ||
              (("injected" === e.connectorType ||
                "solana_adapter" === e.connectorType) &&
                (("ethereum" === e.chainType && this.detectedEth) ||
                  ("solana" === e.chainType && this.detectedSol))))
          );
        }
        listingOk(e) {
          if (e.slug.includes("coinbase")) return !1;
          if ("ethereum-only" === this.chainFilter) {
            if (!this.isEth(e)) return !1;
          } else if ("solana-only" === this.chainFilter && !this.isSol(e))
            return !1;
          return !!this.inAllowList(e.slug, "listing");
        }
        getWallets(e, t) {
          let n = new Map(),
            a = (e) => {
              let t = n.get(e.id);
              if (t) {
                t.chainType !== e.chainType && (t.chainType = "multi");
                let n = new Set(t.chains);
                e.chains.forEach((e) => n.add(e)),
                  (t.chains = Array.from(n)),
                  !t.icon && e.icon && (t.icon = e.icon),
                  !t.url && e.url && (t.url = e.url),
                  !t.listing && e.listing && (t.listing = e.listing);
              } else n.set(e.id, e);
            };
          e
            .filter((e) => this.connectorOk(e))
            .forEach((e) => {
              let t = s2.normalize(e.walletClientType);
              a({
                id: t,
                label: e.walletBranding?.name ?? t,
                source: "connector",
                connector: e,
                chainType: e.chainType,
                icon: e.walletBranding?.icon,
                url: void 0,
                chains: ["ethereum" === e.chainType ? "eip155" : "solana"],
              });
            }),
            t
              .filter((e) => this.listingOk(e))
              .forEach((e) => {
                let t = this.isEth(e),
                  n = this.isSol(e),
                  r = s2.normalize(e.slug),
                  i = s1[e.slug],
                  o = i?.image_url?.sm || e.image_url?.sm;
                a({
                  id: r,
                  label: e.name || r,
                  source: "listing",
                  listing: e,
                  chainType: t && n ? "multi" : t ? "ethereum" : "solana",
                  icon: o,
                  url: e.homepage,
                  chains: e.chains,
                });
              });
          let r = e.find((e) => "wallet_connect_v2" === e.connectorType);
          this.includeWalletConnectQr &&
            r &&
            a({
              id: "wallet_connect_qr",
              label: "WalletConnect",
              source: "connector",
              connector: r,
              chainType: "ethereum",
              icon: as,
              url: void 0,
              chains: ["ethereum" === r.chainType ? "eip155" : "solana"],
            });
          let i = Array.from(n.values());
          i.forEach((e) => {
            let t = s1[e.listing?.slug || e.id];
            t?.image_url?.sm && (e.icon = t.image_url.sm);
          });
          let o = new Map();
          return (
            this.normalizedAllowList?.forEach((e, t) => {
              o.set(s2.normalize(e), t);
            }),
            {
              wallets: i.slice().sort((e, t) => {
                let n = s2.normalize(e.id),
                  a = s2.normalize(t.id);
                "binance-defi" === n
                  ? (n = "binance")
                  : "universalprofiles" === n
                  ? (n = "universal_profile")
                  : "cryptocom-defi" === n && (n = "cryptocom"),
                  "binance-defi" === a
                    ? (a = "binance")
                    : "universalprofiles" === a
                    ? (a = "universal_profile")
                    : "cryptocom-defi" === a && (a = "cryptocom");
                let r = o.has(n),
                  i = o.has(a);
                return r && i
                  ? o.get(n) - o.get(a)
                  : r
                  ? -1
                  : i
                  ? 1
                  : "connector" === e.source && "listing" === t.source
                  ? -1
                  : "listing" === e.source && "connector" === t.source
                  ? 1
                  : e.label.toLowerCase().localeCompare(t.label.toLowerCase());
              }),
              walletCount: i.length,
            }
          );
        }
        constructor(e, t) {
          (this.chainFilter = e),
            t &&
              t.length > 0 &&
              ((this.normalizedAllowList = t.map(String)),
              this.normalizedAllowList.includes("binance") &&
                this.normalizedAllowList.push("binance-defi-wallet")),
            (this.detectedEth =
              this.normalizedAllowList?.includes("detected_ethereum_wallets") ??
              !1),
            (this.detectedSol =
              this.normalizedAllowList?.includes("detected_solana_wallets") ??
              !1),
            (this.includeWalletConnect =
              this.normalizedAllowList?.includes("wallet_connect") ?? !1),
            (this.includeWalletConnectQr =
              this.normalizedAllowList?.includes("wallet_connect_qr") ?? !1);
        }
      }
      var s3 = (e) =>
          (0, a.jsxs)("svg", {
            viewBox: "0 0 32 32",
            xmlns: "http://www.w3.org/2000/svg",
            ...e,
            children: [
              (0, a.jsx)("path", { d: "m0 0h32v32h-32z", fill: "#5469d4" }),
              (0, a.jsx)("path", {
                d: "m15.997 5.333-.143.486v14.106l.143.143 6.548-3.87z",
                fill: "#c2ccf4",
              }),
              (0, a.jsx)("path", {
                d: "m15.996 5.333-6.548 10.865 6.548 3.87z",
                fill: "#fff",
              }),
              (0, a.jsx)("path", {
                d: "m15.997 21.306-.08.098v5.025l.08.236 6.552-9.227z",
                fill: "#c2ccf4",
              }),
              (0, a.jsx)("path", {
                d: "m15.996 26.665v-5.36l-6.548-3.867z",
                fill: "#fff",
              }),
              (0, a.jsx)("path", {
                d: "m15.995 20.07 6.548-3.87-6.548-2.976v6.847z",
                fill: "#8698e8",
              }),
              (0, a.jsx)("path", {
                d: "m9.448 16.2 6.548 3.87v-6.846z",
                fill: "#c2ccf4",
              }),
            ],
          }),
        s4 = (e) =>
          (0, a.jsxs)("svg", {
            viewBox: "0 0 32 32",
            xmlns: "http://www.w3.org/2000/svg",
            ...e,
            children: [
              (0, a.jsxs)("linearGradient", {
                id: "a",
                gradientUnits: "userSpaceOnUse",
                x1: "7.233",
                x2: "24.766",
                y1: "24.766",
                y2: "7.234",
                children: [
                  (0, a.jsx)("stop", { offset: "0", stopColor: "#9945ff" }),
                  (0, a.jsx)("stop", { offset: ".2", stopColor: "#7962e7" }),
                  (0, a.jsx)("stop", { offset: "1", stopColor: "#00d18c" }),
                ],
              }),
              (0, a.jsx)("path", { d: "m0 0h32v32h-32z", fill: "#10111a" }),
              (0, a.jsx)("path", {
                clipRule: "evenodd",
                d: "m9.873 20.41a.645.645 0 0 1 .476-.21l14.662.012a.323.323 0 0 1 .238.54l-3.123 3.438a.643.643 0 0 1 -.475.21l-14.662-.012a.323.323 0 0 1 -.238-.54zm15.376-2.862a.322.322 0 0 1 -.238.54l-14.662.012a.642.642 0 0 1 -.476-.21l-3.122-3.44a.323.323 0 0 1 .238-.54l14.662-.012a.644.644 0 0 1 .475.21zm-15.376-9.738a.644.644 0 0 1 .476-.21l14.662.012a.322.322 0 0 1 .238.54l-3.123 3.438a.643.643 0 0 1 -.475.21l-14.662-.012a.323.323 0 0 1 -.238-.54z",
                fill: "url(#a)",
                fillRule: "evenodd",
              }),
            ],
          });
      let s5 = T.zo.div.withConfig({
          displayName: "WalletIconWithActiveIndicator",
          componentId: "sc-9b65f2b6-2",
        })([
          "position:relative;display:inline-flex;align-items:center;&::after{content:' ';border-radius:var(--privy-border-radius-full);height:6px;width:6px;background-color:var(--privy-color-icon-success);position:absolute;right:-3px;top:-3px;}",
        ]),
        s6 = T.zo.img.withConfig({
          displayName: "WalletIcon",
          componentId: "sc-9b65f2b6-3",
        })([
          "width:32px;height:32px;border-radius:0.25rem;object-fit:contain;",
        ]),
        s8 = T.zo.span.withConfig({
          displayName: "Chip",
          componentId: "sc-9b65f2b6-4",
        })([
          "display:flex;gap:0.25rem;align-items:center;padding:0.25rem 0.5rem;font-size:0.75rem;font-weight:500;line-height:1.125rem;border-radius:var(--privy-border-radius-sm);background-color:var(--privy-color-background-2);svg{width:100%;max-width:1rem;max-height:1rem;stroke-width:2;}",
        ]),
        s7 = (0, eK.U)(() => ({ isModalOpen: !1, resolvers: null }));
      (0, eK.U)(() => ({}));
      let s9 = ({ address: e, client: t, appId: n }) => {
          let a = `${t}:${e}`;
          n && tn.put(le(n), a), s7.setState({ wallet: a });
        },
        le = (e) => `privy:${e}:active-wallet-connection`;
      function lt({ walletList: e, walletChainType: t }) {
        let n = ar(),
          { connectors: a } = (0, j.u)(),
          r = nK((e) => e.listings),
          i = t ?? n.appearance.walletChainType,
          o = e ?? n.appearance?.walletList,
          s = (0, C.useMemo)(() => new s2(i, o), [i, o]),
          { wallets: l, walletCount: c } = (0, C.useMemo)(
            () => s.getWallets(a, r),
            [s, a, r]
          ),
          [d, u] = (0, C.useState)(""),
          p = (0, C.useMemo)(
            () =>
              d
                ? l.filter((e) =>
                    e.label.toLowerCase().includes(d.toLowerCase())
                  )
                : l,
            [d, l]
          ),
          [h, g] = (0, C.useState)();
        return {
          selected: h,
          setSelected: g,
          search: d,
          setSearch: u,
          wallets: p,
          walletCount: c,
        };
      }
      let ln = (e) =>
          !e || ("string" != typeof e && (e instanceof nP || e instanceof nG)),
        la = ({ index: e, style: t, data: n, recent: r }) => {
          let i = n.wallets[e],
            { walletChainType: o, handleWalletClick: s } = n,
            l = { ...t, boxSizing: "border-box" };
          return i
            ? (0, a.jsxs)(ls, {
                style: l,
                onClick: () => s(i),
                children: [
                  i.icon &&
                    (i.connector && !ln(i.connector)
                      ? (0, a.jsx)(s5, {
                          children:
                            "string" == typeof i.icon
                              ? (0, a.jsx)(s6, { src: i.icon })
                              : (0, a.jsx)(i.icon, {
                                  style: { width: "32px", height: "32px" },
                                }),
                        })
                      : "string" == typeof i.icon
                      ? (0, a.jsx)(s6, { src: i.icon })
                      : (0, a.jsx)(i.icon, {
                          style: { width: "32px", height: "32px" },
                        })),
                  (0, a.jsx)(ld, { children: i.label }),
                  r
                    ? (0, a.jsxs)(a.Fragment, {
                        children: [
                          (0, a.jsx)(s8, { children: "Last used" }),
                          (0, a.jsx)(ll, {
                            children: (0, a.jsxs)(a.Fragment, {
                              children: [
                                "ethereum-only" === o && (0, a.jsx)(s3, {}),
                                "solana-only" === o && (0, a.jsx)(s4, {}),
                              ],
                            }),
                          }),
                        ],
                      })
                    : (0, a.jsx)(ll, {
                        children:
                          !("ethereum-only" === o || "solana-only" === o) &&
                          (0, a.jsxs)(a.Fragment, {
                            children: [
                              i.chains?.some((e) => e.startsWith("eip155")) &&
                                (0, a.jsx)(s3, {}),
                              i.chains?.some((e) => e.startsWith("solana")) &&
                                (0, a.jsx)(s4, {}),
                            ],
                          }),
                      }),
                ],
              })
            : null;
        };
      var lr = ({
        className: e,
        customDescription: t,
        connectOnly: n,
        preSelectedWalletId: r,
        ...i
      }) => {
        let o = ar(),
          { connectors: s } = (0, j.u)(),
          l = i.walletChainType || o.appearance.walletChainType,
          c = i.walletList || o.appearance?.walletList,
          { onBack: d, onClose: u, app: p } = i,
          {
            selected: h,
            setSelected: g,
            qrUrl: f,
            setQrUrl: m,
            connecting: y,
            uiState: w,
            wallets: v,
            walletCount: x,
            handleConnect: b,
            handleBack: k,
            showSearchBar: T,
            isInitialConnectView: A,
            title: S,
            search: I,
            setSearch: E,
          } = (function ({
            onConnect: e,
            onBack: t,
            onClose: n,
            onConnectError: a,
            walletList: r,
            walletChainType: i,
            app: o,
          }) {
            let s = ar(),
              { connectors: l } = (0, j.u)(),
              {
                wallets: c,
                walletCount: d,
                search: u,
                setSearch: p,
                selected: h,
                setSelected: g,
              } = lt({ walletList: r, walletChainType: i }),
              [f, m] = (0, C.useState)(),
              [y, w] = (0, C.useState)(),
              [v, x] = (0, C.useState)(),
              b = !h && !y && !v,
              k = b && (d > 6 || u.length > 0),
              T = l.find((e) => "wallet_connect_v2" === e.connectorType),
              A = (0, C.useCallback)(
                async (t, n) => {
                  if (t) {
                    if (v?.connector === t)
                      return void console.log(
                        "Already connecting to this wallet, skipping duplicate attempt"
                      );
                    if ((m("loading"), "string" == typeof t))
                      return (
                        x({
                          connector: t,
                          name: n?.name ?? "Wallet",
                          icon: n?.icon,
                        }),
                        void window.open(t, "_blank")
                      );
                    x({
                      connector: t,
                      name: n?.name ?? t.walletBranding.name ?? "Wallet",
                      icon: n?.icon ?? t.walletBranding.icon,
                    });
                    try {
                      let n = await t.connect({ showPrompt: !0 });
                      if (!n)
                        return (
                          m("error"),
                          void a?.(new eh.x("Unable to connect wallet"))
                        );
                      m("success"),
                        s9({
                          address: n.address,
                          client: n.walletClientType,
                          appId: s.id,
                        }),
                        setTimeout(() => {
                          e({ connector: t, wallet: n });
                        }, th);
                    } catch (e) {
                      if (
                        (console.error("ERROR: ", { e: e }),
                        e?.message?.includes("already pending for origin") ||
                          e?.message?.includes("wallet_requestPermissions"))
                      )
                        return void console.log(
                          "Connection request already pending, maintaining loading state"
                        );
                      m("error"), a?.(new eh.x("Unable to connect wallet"));
                    }
                  }
                },
                [s.id, e, v]
              ),
              S = (0, C.useCallback)(
                () =>
                  y
                    ? (m(void 0), x(void 0), void w(void 0))
                    : v
                    ? (m(void 0), void x(void 0))
                    : h
                    ? (m(void 0), x(void 0), void g(void 0))
                    : "error" === f || "loading" === f
                    ? (m(void 0), void x(void 0))
                    : void t?.(),
                [y, v, h, f, t]
              ),
              I = (0, C.useMemo)(
                () =>
                  v?.connector === T && y && eC.tq
                    ? `Go to ${v.name} to continue`
                    : v?.connector === T && y
                    ? `Scan code to connect to ${v.name}`
                    : "string" == typeof v?.connector
                    ? `Open or install ${v.name}`
                    : h && !v
                    ? "Select network"
                    : v
                    ? null
                    : "Select your wallet",
                [v, y, h, T]
              );
            return {
              selected: h,
              setSelected: g,
              qrUrl: y,
              setQrUrl: w,
              connecting: v,
              uiState: f,
              search: u,
              setSearch: p,
              wallets: c,
              walletCount: d,
              wc: T,
              isInitialConnectView: b,
              showSearchBar: k,
              title: I,
              handleConnect: A,
              handleBack: S,
              onClose: n,
              onConnect: e,
              app: o,
            };
          })({ ...i, walletList: c, walletChainType: l }),
          N = s.find((e) => "wallet_connect_v2" === e.connectorType),
          _ = (0, C.useRef)(null),
          M = (0, eq.MG)({
            count: v.length,
            getScrollElement: () => _.current,
            estimateSize: () => 56,
            overscan: 6,
            gap: 5,
          }),
          F = (0, C.useCallback)(
            async (e) => {
              let t,
                a =
                  "solana-only" !== l &&
                  e.chains?.some((e) => e.startsWith("eip155")),
                r =
                  "ethereum-only" !== l &&
                  e.chains?.some((e) => e.startsWith("solana")),
                i = nU[e.id];
              if (r && i)
                t = i.getMobileRedirect({
                  isSolana: !0,
                  connectOnly: !!n,
                  useUniversalLink: !1,
                });
              else {
                let n = e.listing?.mobile?.native;
                t = e.listing?.mobile?.universal || n || e.url;
              }
              if (a && r) {
                let n = s2.normalize(e.id),
                  a = s.filter(
                    (e) =>
                      s2.normalize(e.walletClientType) === n &&
                      !(
                        ("ethereum" === e.chainType && e instanceof nP) ||
                        ("solana" === e.chainType && e instanceof nG)
                      )
                  ),
                  r = a.find((e) => "ethereum" === e.chainType),
                  i = a.find((e) => "solana" === e.chainType);
                if (!r && e.listing) {
                  let t = s1[e.listing.slug]
                    ? { ...e.listing, ...s1[e.listing.slug] }
                    : e.listing;
                  N.setWalletEntry(t, m),
                    await N.resetConnection(e.id),
                    (r = N);
                }
                if ((!i && t && (i = t), r || i))
                  return void g({
                    eth: r,
                    sol: i,
                    name: e.label,
                    icon: e.icon,
                  });
              }
              if (!ln(e.connector))
                return (
                  "wallet_connect_v2" === e.connector?.connectorType &&
                    (await N.resetConnection(e.id),
                    N.setWalletEntry(
                      {
                        id: "wallet_connect_qr",
                        name: "WalletConnect",
                        rdns: "",
                        slug: "wallet-connect",
                        homepage: "",
                        chains: ["eip155"],
                        mobile: { native: "", universal: void 0 },
                      },
                      m
                    )),
                  void (await b(e.connector, { name: e.label, icon: e.icon }))
                );
              if (a || r || e.url || e.listing) {
                if (a && e.listing) {
                  let t = s1[e.listing.slug]
                    ? { ...e.listing, ...s1[e.listing.slug] }
                    : e.listing;
                  N.setWalletEntry(t, m), await N.resetConnection(e.id);
                }
                if (a && r)
                  return void g({
                    eth: N,
                    sol: t,
                    name: e.label,
                    icon: e.icon,
                  });
                if (r)
                  return void (await b(t, { name: e.label, icon: e.icon }));
                if (a)
                  return void (e.listing
                    ? await b(N, { name: e.label, icon: e.icon })
                    : e.url
                    ? await b(e.url, { name: e.label, icon: e.icon })
                    : console.warn(
                        "Cannot connect to EVM wallet without connector or listing details:",
                        e.label
                      ));
                if (e.url)
                  return void (await b(e.url, { name: e.label, icon: e.icon }));
              }
            },
            [N, b, g, m, k, u, p, A, S, t, o, s]
          ),
          z = d || k,
          L = !!d || !A;
        return (
          (0, C.useEffect)(() => {
            if (!r) return;
            let e = v.find(({ id: e }) => e === r);
            e && F(e).catch(console.error);
          }, [r]),
          (0, a.jsxs)(rx, {
            className: e,
            children: [
              (0, a.jsx)(rx.Header, {
                icon:
                  (y && !f) || (f && eC.tq && y?.icon)
                    ? y.icon
                    : y
                    ? void 0
                    : s0,
                iconVariant: (y && !f) || (f && eC.tq) ? "loading" : void 0,
                iconLoadingStatus:
                  (y && !f) || (f && eC.tq)
                    ? { success: "success" === w, fail: "error" === w }
                    : void 0,
                title:
                  y && !f
                    ? `Waiting for ${y.name}`
                    : f && eC.tq
                    ? `Waiting for ${y?.name ?? "connection"}`
                    : S,
                subtitle:
                  y && !f && "string" == typeof y.connector
                    ? `To connect to ${y.name}, install and open the app. Then confirm the connection when prompted.`
                    : y && !f && "string" != typeof y.connector
                    ? "error" === w
                      ? "Please try connecting again."
                      : "For the best experience, connect only one wallet at a time."
                    : A
                    ? t ??
                      (p ? `Connect a wallet to your ${p.name} account` : null)
                    : null,
                showBack: L,
                showClose: !0,
                onBack: z,
                onClose: u,
              }),
              (0, a.jsxs)(rx.Body, {
                ref: _,
                $colorScheme: o.appearance.palette.colorScheme,
                style: { marginBottom: f ? "0.5rem" : void 0 },
                children: [
                  T &&
                    (0, a.jsx)(li, {
                      children: (0, a.jsxs)(sK, {
                        style: { background: "transparent" },
                        children: [
                          (0, a.jsx)(aA, { children: (0, a.jsx)(eH.Z, {}) }),
                          (0, a.jsx)("input", {
                            className: "login-method-button",
                            type: "text",
                            placeholder: "Search wallets",
                            onChange: (e) => E(e.target.value),
                            value: I,
                          }),
                        ],
                      }),
                    }),
                  f &&
                    eC.tq &&
                    "loading" === w &&
                    (0, a.jsx)("div", {
                      style: {
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center",
                        gap: "1rem",
                      },
                      children: (0, a.jsx)(aH, {
                        variant: "primary",
                        onClick: () =>
                          window.open(f.universal ?? f.native, "_blank"),
                        style: { width: "100%" },
                        children: "Open in app",
                      }),
                    }),
                  f &&
                    !eC.tq &&
                    "loading" === w &&
                    (0, a.jsx)("div", {
                      style: {
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center",
                        gap: "1rem",
                      },
                      children: (0, a.jsx)(lu, {
                        value: f.universal ?? f.native,
                        iconOnly: !0,
                        children: "Copy link",
                      }),
                    }),
                  f &&
                    !eC.tq &&
                    (0, a.jsx)(sG, {
                      size: 280,
                      url: f.universal ?? f.native,
                      squareLogoElement: y?.icon
                        ? "string" == typeof y.icon
                          ? (e) =>
                              (0, a.jsx)("svg", {
                                ...e,
                                children: (0, a.jsx)("image", {
                                  href: y.icon,
                                  height: e.height,
                                  width: e.width,
                                }),
                              })
                          : y.icon
                        : ao,
                    }),
                  (0, a.jsxs)(lo, {
                    children: [
                      y &&
                        !f &&
                        "string" == typeof y.connector &&
                        (0, a.jsxs)(ls, {
                          onClick: () => window.open(y.connector, "_blank"),
                          children: [
                            y.icon &&
                              ("string" == typeof y.icon
                                ? (0, a.jsx)(s6, { src: y.icon })
                                : (0, a.jsx)(y.icon, {})),
                            (0, a.jsx)(ld, { children: y.name }),
                          ],
                        }),
                      h?.eth &&
                        !y &&
                        (0, a.jsxs)(ls, {
                          onClick: () =>
                            b(h.eth, { name: h.name, icon: h.icon }),
                          children: [
                            h.icon &&
                              ("string" == typeof h.icon
                                ? (0, a.jsx)(s6, { src: h.icon })
                                : (0, a.jsx)(h.icon, {})),
                            (0, a.jsx)(ld, { children: h.name }),
                            (0, a.jsx)(ll, { children: (0, a.jsx)(s3, {}) }),
                          ],
                        }),
                      h?.sol &&
                        !y &&
                        (0, a.jsxs)(ls, {
                          onClick: () =>
                            b(h.sol, { name: h.name, icon: h.icon }),
                          children: [
                            h.icon &&
                              ("string" == typeof h.icon
                                ? (0, a.jsx)(s6, { src: h.icon })
                                : (0, a.jsx)(h.icon, {})),
                            (0, a.jsx)(ld, { children: h.name }),
                            (0, a.jsx)(ll, { children: (0, a.jsx)(s4, {}) }),
                          ],
                        }),
                      A &&
                        (0, a.jsxs)(a.Fragment, {
                          children: [
                            !(x > 0) &&
                              (0, a.jsx)(lc, {
                                children:
                                  "No wallets found. Try another search.",
                              }),
                            x > 0 &&
                              !f &&
                              (0, a.jsx)("div", {
                                style: {
                                  maxHeight: 56 * Math.min(v.length, 5) + 5,
                                  width: "100%",
                                },
                                children: (0, a.jsx)("div", {
                                  style: {
                                    height: `${M.getTotalSize()}px`,
                                    width: "100%",
                                    position: "relative",
                                  },
                                  children: M.getVirtualItems().map((e) =>
                                    (0, a.jsx)(
                                      la,
                                      {
                                        index: e.index,
                                        style: {
                                          position: "absolute",
                                          top: 0,
                                          left: 0,
                                          height: `${e.size}px`,
                                          transform: `translateY(${e.start}px)`,
                                        },
                                        data: {
                                          wallets: v,
                                          walletChainType: l,
                                          handleWalletClick: F,
                                        },
                                      },
                                      e.key
                                    )
                                  ),
                                }),
                              }),
                          ],
                        }),
                    ],
                  }),
                ],
              }),
              (0, a.jsxs)(rx.Footer, {
                children: [
                  y &&
                    !f &&
                    "string" != typeof y.connector &&
                    "error" === w &&
                    (0, a.jsx)(rx.Actions, {
                      children: (0, a.jsx)(aH, {
                        style: { width: "100%", alignItems: "center" },
                        variant: "error",
                        onClick: () =>
                          b(y.connector, { name: y.name, icon: y.icon }),
                        children: "Retry",
                      }),
                    }),
                  !!(
                    p &&
                    p.legal.privacyPolicyUrl &&
                    p.legal.termsAndConditionsUrl
                  ) &&
                    (0, a.jsx)(aM, { app: p, alwaysShowImplicitConsent: !0 }),
                  (0, a.jsx)(rx.Watermark, {}),
                ],
              }),
            ],
          })
        );
      };
      let li = T.zo.div.withConfig({
          displayName: "StickySearchContainer",
          componentId: "sc-850f7dce-0",
        })([
          "position:sticky;margin-top:-3px;padding-top:3px;top:-3px;z-index:1;background:var(--privy-color-background);padding-bottom:calc(var(--screen-space) / 2);",
        ]),
        lo = T.zo.div.withConfig({
          displayName: "WalletListContainer",
          componentId: "sc-850f7dce-1",
        })(["display:flex;flex-direction:column;gap:", "px;"], 5),
        ls = T.zo.button.withConfig({
          displayName: "Button",
          componentId: "sc-850f7dce-2",
        })([
          "&&{gap:0.5rem;align-items:center;display:flex;position:relative;text-align:left;font-weight:500;transition:background 200ms ease-in;width:calc(100% - 4px);border-radius:var(--privy-border-radius-md);padding:0.75em;border:1px solid var(--privy-color-foreground-4);justify-content:space-between;}&:hover{background:var(--privy-color-background-2);}",
        ]),
        ll = T.zo.span.withConfig({
          displayName: "ButtonBadge",
          componentId: "sc-850f7dce-3",
        })([
          "display:flex;align-items:center;justify-content:end;position:relative;& > svg{border-radius:var(--privy-border-radius-full);stroke-width:2.5;width:100%;max-height:1rem;max-width:1rem;flex-shrink:0;}& > svg:not(:last-child){border-radius:var(--privy-border-radius-full);margin-right:-0.375rem;}",
        ]),
        lc = T.zo.div.withConfig({
          displayName: "EmptyContainer",
          componentId: "sc-850f7dce-4",
        })([
          "height:60px;display:flex;align-items:center;justify-content:center;text-align:center;",
        ]),
        ld = T.zo.span.withConfig({
          displayName: "WalletName",
          componentId: "sc-850f7dce-5",
        })([
          "text-overflow:ellipsis;white-space:nowrap;color:var(--privy-color-foreground);font-weight:400;flex:1;",
        ]),
        lu = (0, T.zo)(function ({
          children: e,
          iconOnly: t,
          value: n,
          hideCopyIcon: r,
          ...i
        }) {
          let [o, s] = (0, C.useState)(!1);
          return (0, a.jsxs)(sP, {
            ...i,
            onClick: () => {
              navigator.clipboard.writeText(n || e).catch(console.error),
                s(!0),
                setTimeout(() => s(!1), 1500);
            },
            children: [
              e,
              " ",
              o
                ? (0, a.jsxs)(sD, {
                    children: [(0, a.jsx)(sW, {}), " ", !t && "Copied"],
                  })
                : !r && (0, a.jsx)(sR, {}),
            ],
          });
        }).withConfig({
          displayName: "StyledCopyableText",
          componentId: "sc-850f7dce-6",
        })(["&&{margin:0.5rem auto 0 auto;}"]),
        lp = ({ ...e }) =>
          (0, a.jsxs)("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            width: "25",
            height: "25",
            viewBox: "0 0 25 25",
            fill: "none",
            ...e,
            children: [
              (0, a.jsxs)("g", {
                clipPath: "url(#clip0_2856_1743)",
                children: [
                  (0, a.jsx)("path", {
                    d: "M22.1673 8.24075V16.3642C22.1673 17.3256 21.3421 18.105 20.3241 18.105H17.0028M22.1673 8.24075C22.1673 7.27936 21.3421 6.5 20.3241 6.5H11.5302M22.1673 8.24075V8.42852C22.1673 9.03302 21.8352 9.59423 21.2901 9.91105L15.1463 13.4818C14.5539 13.8261 13.8067 13.8261 13.2143 13.4818L10.1621 11.5401",
                    stroke: "currentColor",
                    strokeWidth: "1.5",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                  }),
                  (0, a.jsx)("path", {
                    d: "M3.12913 6.64816C0.508085 12.9507 3.49251 20.1847 9.79504 22.8057L11.5068 23.5176C12.4522 23.9108 13.7783 23.2222 14.1714 22.2768L14.6054 21.2333C14.7687 20.8406 14.6438 20.3871 14.3024 20.1334L11.2872 17.8927C10.9878 17.6702 10.5843 17.6488 10.2632 17.8384L9.11575 18.5156C8.78274 18.7121 8.3597 18.6844 8.07552 18.4221C5.94293 16.4542 4.77629 13.6264 4.90096 10.7273C4.91757 10.3409 5.19796 10.023 5.57269 9.92753L6.86381 9.59869C7.22522 9.50664 7.49627 9.20696 7.55169 8.83815L8.10986 5.12321C8.17306 4.70259 7.94188 4.29293 7.54915 4.1296L6.50564 3.69564C5.56026 3.30248 4.23416 3.99103 3.84101 4.9364L3.12913 6.64816Z",
                    stroke: "currentColor",
                    strokeWidth: "1.5",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                  }),
                ],
              }),
              (0, a.jsx)("defs", {
                children: (0, a.jsx)("clipPath", {
                  id: "clip0_2856_1743",
                  children: (0, a.jsx)("rect", {
                    x: "0.5",
                    y: "0.5",
                    width: "24",
                    height: "24",
                    rx: "6",
                    fill: "white",
                  }),
                }),
              }),
            ],
          }),
        lh = (e) => {
          let t = localStorage
            .getItem("-walletlink:https://www.walletlink.org:Addresses")
            ?.split(" ")
            .filter((e) => _.v(e, { strict: !0 }))
            .map((e) => M.K(e));
          return (
            !!t?.length &&
            !!e?.linkedAccounts.filter(
              (e) => "wallet" == e.type && t.includes(e.address)
            ).length
          );
        },
        lg = (0, C.createContext)({ plugins: { current: {} } }),
        lf = ({ children: e }) => {
          let t = (0, C.useRef)({});
          return (0, a.jsx)(lg.Provider, {
            value: { plugins: t },
            children: e,
          });
        },
        lm = () => {
          let { plugins: e } = (0, C.useContext)(lg);
          return (0, C.useCallback)((t) => e.current[t], [e]);
        },
        ly = Symbol("solana-ledger-plugin"),
        lw = ({
          title: e = "You don't have access to this app",
          subtitle: t = "Have you been invited?",
          ctaText: n = "Try another account",
          ctaLink: r,
          onCtaClick: i,
        }) =>
          (0, a.jsx)(rS, {
            title: e,
            subtitle: t,
            icon: d.Z,
            iconVariant: "warning",
            primaryCta: {
              label: n,
              onClick: () => {
                r ? window.open(r, "_blank") : i?.();
              },
            },
            watermark: !0,
          }),
        lv = {
          component: () => {
            let { navigate: e } = ap(),
              t = ar(),
              n =
                t?.allowlistConfig.errorTitle ||
                "You don't have access to this app",
              r = t?.allowlistConfig.errorDetail || "Have you been invited?",
              i = t?.allowlistConfig.errorCtaText || "Try another account",
              o = t?.allowlistConfig.errorCtaLink;
            return (0, a.jsx)(lw, {
              title: n,
              subtitle: r,
              ctaText: i,
              ctaLink: o ?? void 0,
              onCtaClick: () => {
                e(pD);
              },
            });
          },
        },
        lx = ({
          status: e,
          title: t,
          description: n,
          userIntentRequired: i,
          retriesRemaining: o,
          hasSelectedCta: s,
          onContinue: l,
          onRetry: c,
        }) => {
          let d = (0, C.useMemo)(() => {
              switch (e) {
                case "loading":
                default:
                  return;
                case "success":
                  return i
                    ? {
                        label: s ? "Continuing..." : "Continue",
                        onClick: l,
                        disabled: s,
                        loading: s,
                      }
                    : void 0;
                case "error":
                  return o > 0 ? { label: "Retry", onClick: c } : void 0;
              }
            }, [e, s, l, c]),
            p = (0, C.useMemo)(
              () =>
                ({
                  loading: "loading",
                  ready: "subtle",
                  disabled: "subtle",
                  success: "success",
                  error: "error",
                }[e] || "loading"),
              [e]
            );
          return (0, a.jsx)(rS, {
            icon:
              "loading" === e || "ready" === e
                ? void 0
                : "success" === e
                ? r.Z
                : u.Z,
            iconVariant: p,
            title: t,
            subtitle: n,
            primaryCta: d,
            watermark: !0,
          });
        },
        lb = {
          component: () => {
            let { lastScreen: e, data: t, navigate: n, setModalData: r } = ap(),
              {
                status: i,
                token: o,
                waitForResult: s,
                reset: l,
                execute: c,
              } = np(),
              d = (0, C.useRef)([]),
              u = (e) => {
                d.current = [e, ...d.current];
              },
              [p, h] = (0, C.useState)(!0);
            (0, C.useEffect)(
              () => (
                u(setTimeout(h, 1e3, !1)),
                () => {
                  d.current.forEach((e) => clearTimeout(e)), (d.current = []);
                }
              ),
              []
            );
            let [g, f] = (0, C.useState)(""),
              [m, y] = (0, C.useState)("Checking that you are a human..."),
              [w, v] = (0, C.useState)(!1),
              [x, b] = (0, C.useState)(3),
              j = t?.captchaModalData,
              k = async (t) => {
                try {
                  await j?.callback(t),
                    j?.onSuccessNavigateTo && n(j?.onSuccessNavigateTo, !1);
                } catch (t) {
                  if (t instanceof nd) return;
                  r({ errorModalData: { error: t, previousScreen: e || pD } }),
                    n(j?.onErrorNavigateTo || sg, !1);
                }
              };
            return (
              (0, C.useEffect)(() => {
                "success" === i
                  ? u(
                      setTimeout(async () => {
                        let e = await s();
                        !e || j?.userIntentRequired || k(e);
                      }, 1e3)
                    )
                  : "ready" === i &&
                    u(
                      setTimeout(() => {
                        "ready" === i && c();
                      }, 500)
                    );
              }, [i]),
              (0, C.useEffect)(() => {
                if (!p)
                  switch (i) {
                    case "success":
                      f("Success!"),
                        y("CAPTCHA passed successfully."),
                        j?.userIntentRequired ||
                          setTimeout(() => {
                            v(!0), k(o);
                          }, 2e3);
                      break;
                    case "loading":
                      f(""), y("Checking that you are a human...");
                      break;
                    case "error":
                      f("Something went wrong"),
                        y(
                          x <= 0
                            ? "If you use an adblocker or VPN, try disabling and re-attempting."
                            : "You did not pass CAPTCHA. Please try again."
                        );
                  }
              }, [i, p, w]),
              (0, a.jsx)(lx, {
                status: i,
                title: g,
                description: m,
                userIntentRequired: j?.userIntentRequired,
                retriesRemaining: x,
                hasSelectedCta: w,
                onContinue: () => {
                  v(!0), k(o);
                },
                onRetry: async () => {
                  if (x <= 0) return;
                  b((e) => e - 1), l(), c();
                  let e = await s();
                  !e || j?.userIntentRequired || k(e);
                },
              })
            );
          },
        },
        lC = (e) =>
          (0, a.jsx)("svg", {
            id: "Layer_1",
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "-0.625 12.48 397.647 399.546",
            width: "2500",
            height: "674",
            preserveAspectRatio: "none",
            ...e,
            children: (0, a.jsx)("g", {
              children: (0, a.jsx)("path", {
                fill: "#333745",
                d: "M 333.9 12.8 L 150.9 12.8 L 150.9 258.4 L 396.5 258.4 L 396.5 76.7 C 396.6 42.2 368.4 12.8 333.9 12.8 Z M 94.7 12.8 L 64 12.8 C 29.5 12.8 0 40.9 0 76.8 L 0 107.5 L 94.7 107.5 L 94.7 12.8 Z M 0 165 L 94.7 165 L 94.7 259.7 L 0 259.7 L 0 165 Z M 301.9 410.6 L 332.6 410.6 C 367.1 410.6 396.6 382.5 396.6 346.6 L 396.6 316 L 301.9 316 L 301.9 410.6 Z M 150.9 316 L 245.6 316 L 245.6 410.7 L 150.9 410.7 L 150.9 316 Z M 0 316 L 0 346.7 C 0 381.2 28.1 410.7 64 410.7 L 94.7 410.7 L 94.7 316 L 0 316 Z",
              }),
            }),
          }),
        lj = ({
          onContinueWithLedger: e,
          onContinueWithoutLedger: t,
          title: n = "Phantom supports Ledger",
          subtitle:
            r = "Are you using a Ledger hardware wallet?\nContinue to sign with Ledger",
        }) =>
          (0, a.jsx)(rS, {
            title: n,
            subtitle: (0, a.jsx)(lA, { children: r }),
            primaryCta: { label: "Continue with Ledger", onClick: e },
            secondaryCta: { label: "Continue without Ledger", onClick: t },
            watermark: !0,
            children: (0, a.jsxs)(lT, {
              children: [
                (0, a.jsx)(nR, { style: { width: "48px", height: "48px" } }),
                (0, a.jsx)(g.Z, {
                  strokeWidth: 2,
                  color: "var(--privy-color-icon-subtle)",
                  width: 22,
                  height: 22,
                }),
                (0, a.jsx)(lC, { style: { width: "48px", height: "48px" } }),
              ],
            }),
          }),
        lk = {
          component: function () {
            let { data: e, setModalData: t, navigate: n } = ap();
            return (0, a.jsx)(lj, {
              onContinueWithLedger: function () {
                t({
                  ...e,
                  login: { ...e?.login, isSigningInWithLedgerSolana: !0 },
                }),
                  n(lM);
              },
              onContinueWithoutLedger: function () {
                t({
                  ...e,
                  login: { ...e?.login, isSigningInWithLedgerSolana: !1 },
                }),
                  n(lM);
              },
            });
          },
        },
        lT = T.zo.div.withConfig({
          displayName: "IconContainer",
          componentId: "sc-218811f1-0",
        })([
          "display:flex;align-items:center;justify-content:center;gap:8px;margin-bottom:var(--screen-space);",
        ]),
        lA = T.zo.span.withConfig({
          displayName: "SubtitleText",
          componentId: "sc-218811f1-1",
        })(["white-space:pre-wrap;"]),
        lS = ({ style: e, ...t }) =>
          (0, a.jsx)("svg", {
            width: "40",
            height: "40",
            viewBox: "0 0 40 40",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            style: { height: "38px", width: "38px", ...e },
            ...t,
            children: (0, a.jsx)("path", {
              d: "M20 13.6V20M20 26.4H20.016M36 20C36 28.8365 28.8366 36 20 36C11.1635 36 4.00001 28.8365 4.00001 20C4.00001 11.1634 11.1635 3.99999 20 3.99999C28.8366 3.99999 36 11.1634 36 20Z",
              stroke: "currentColor",
              strokeWidth: "3.2",
              strokeLinecap: "round",
              strokeLinejoin: "round",
            }),
          }),
        lI = ({
          title: e = "Unable to sign in",
          subtitle:
            t = "This is a test application that has reached its user limit. To allow more users, this app needs to be upgraded to production.",
          onGoBack: n,
        }) =>
          (0, a.jsx)(rS, {
            title: e,
            subtitle: t,
            icon: lS,
            iconVariant: "subtle",
            primaryCta: { label: "Go back", onClick: n },
            showBack: !0,
            onBack: n,
            watermark: !0,
          }),
        lE = {
          component: () => {
            let { navigate: e } = ap();
            return (0, a.jsx)(lI, {
              onGoBack: () => {
                e(pD);
              },
            });
          },
        },
        lN = (e) =>
          e?.privyErrorCode === eh.h.LINKED_TO_ANOTHER_USER
            ? nS.ERROR_USER_EXISTS
            : e instanceof nA && !e.details.default
            ? e.details
            : e instanceof nj
            ? nS.ERROR_TIMED_OUT
            : e?.privyErrorCode === eh.h.CANNOT_LINK_MORE_OF_TYPE
            ? nS.ERROR_USER_LIMIT_REACHED
            : nS.ERROR_WALLET_CONNECTION,
        l_ = ({
          walletLogo: e,
          title: t,
          subtitle: n,
          signSuccess: r,
          errorMessage: i,
          connectSuccess: o,
          separateConnectAndSign: s,
          signing: l,
          walletConnectRedirectUri: c,
          walletConnectFallbackUniversalUri: d,
          hasTabbedAway: u,
          showCoinbaseWalletResetCta: p,
          numRetries: h,
          onBack: g,
          onSign: f,
          onRetry: m,
          onCoinbaseReset: y,
          onDifferentWallet: w,
        }) => {
          let v = p
            ? { label: "Use a different wallet", onClick: y, disabled: r }
            : i === nS.ERROR_USER_EXISTS && g
            ? { label: "Use a different wallet", onClick: w }
            : o && !r && s
            ? {
                label: l ? "Signing" : "Sign with your wallet",
                onClick: f,
                disabled: l,
              }
            : !r && i?.retryable && h < 2
            ? { label: "Retry", onClick: m, disabled: !1 }
            : r || i
            ? void 0
            : { label: "Connecting", onClick: () => {}, disabled: !0 };
          return (0, a.jsx)(rS, {
            title: t,
            subtitle: n,
            icon: e,
            iconVariant: "loading",
            iconLoadingStatus: { success: r, fail: !!i },
            primaryCta: v,
            onBack: g,
            watermark: !0,
            children:
              !o &&
              c &&
              !u &&
              (0, a.jsxs)(lF, {
                children: [
                  "Still here?",
                  " ",
                  (0, a.jsx)(oJ, {
                    href: c,
                    target: "_blank",
                    variant: "underlined",
                    size: "sm",
                    children: "Try connecting again",
                  }),
                  d &&
                    (0, a.jsxs)(a.Fragment, {
                      children: [
                        " ",
                        "or",
                        " ",
                        (0, a.jsx)(oJ, {
                          href: d,
                          target: "_blank",
                          variant: "underlined",
                          size: "sm",
                          children: "use this different link",
                        }),
                      ],
                    }),
                ],
              }),
          });
        },
        lM = {
          component: () => {
            var e, t;
            let n,
              r,
              [i, o] = (0, C.useState)(!1),
              [s, l] = (0, C.useState)(!1),
              [c, d] = (0, C.useState)(void 0),
              { authenticated: u, logout: p } = (0, k.u)(),
              {
                navigate: h,
                navigateBack: g,
                lastScreen: f,
                currentScreen: m,
                setModalData: y,
                data: w,
              } = ap(),
              v = ar(),
              {
                getAuthFlow: x,
                walletConnectionStatus: b,
                closePrivyModal: T,
                initLoginWithWallet: A,
                loginWithWallet: S,
                updateWallets: I,
                createAnalyticsEvent: E,
              } = (0, j.u)(),
              { walletConnectors: N } = (0, k.u)(),
              [_, M] = (0, C.useState)(0),
              { user: F } = (0, k.u)(),
              z = lm(),
              [L] = (0, C.useState)(F?.linkedAccounts.length || 0),
              [P, D] = (0, C.useState)(""),
              [W, R] = (0, C.useState)(""),
              [B, U] = (0, C.useState)(!1),
              { hasTabbedAway: O } = (function () {
                let [e, t] = (0, C.useState)(!1),
                  n = (0, C.useCallback)(() => {
                    document.hidden && t(!0);
                  }, []);
                return (
                  (0, C.useEffect)(
                    () => (
                      document.addEventListener("visibilitychange", n),
                      () => document.removeEventListener("visibilitychange", n)
                    ),
                    [n]
                  ),
                  { hasTabbedAway: e, reset: () => t(!1) }
                );
              })(),
              { enabled: H, token: V } = np(),
              $ = n0(b?.connector?.walletClientType || "unknown"),
              Z =
                (eC.tq &&
                  "wallet_connect_v2" === b?.connector?.connectorType) ||
                (eC.tq && "coinbase_wallet" === b?.connector?.connectorType) ||
                (eC.tq && "base_account" === b?.connector?.connectorType) ||
                (eC.tq &&
                  "injected" === b?.connector?.connectorType &&
                  "phantom" === b?.connector?.walletClientType) ||
                (eC.tq &&
                  "solana_adapter" === b?.connector?.connectorType &&
                  "mobile_wallet_adapter" === b.connector.walletClientType),
              q = "connected" === b?.status,
              G = "switching_to_supported_chain" === b?.status;
            (0, C.useEffect)(() => {
              let e = x(),
                t = e instanceof t0 || e instanceof t2 ? e : void 0;
              q &&
              "solana" === b.connector?.chainType &&
              "phantom" === b.connector?.walletClientType &&
              z(ly) &&
              void 0 === w?.login?.isSigningInWithLedgerSolana
                ? h(lk, !1)
                : (q &&
                    !t &&
                    (!H || V || u
                      ? A(
                          b.connectedWallet,
                          V,
                          w?.login?.disableSignup,
                          w?.login?.isSigningInWithLedgerSolana
                            ? "transaction"
                            : "plain"
                        ).then(() => {
                          U(!0);
                        })
                      : (y({
                          captchaModalData: {
                            callback: (e) =>
                              A(
                                b.connectedWallet,
                                e,
                                w?.login?.disableSignup,
                                w?.login?.isSigningInWithLedgerSolana
                                  ? "transaction"
                                  : "plain"
                              ).then(() => {
                                U(!0);
                              }),
                            userIntentRequired: !1,
                            onSuccessNavigateTo: lM,
                            onErrorNavigateTo: sg,
                          },
                        }),
                        h(lb, !1))),
                  t instanceof t2 &&
                    w?.login?.isSigningInWithLedgerSolana &&
                    (t.messageType = "transaction"),
                  t && Z && q && !t.preparedMessage
                    ? t.buildMessage()
                    : t &&
                      !Z &&
                      q &&
                      (s ||
                        (async () => {
                          l(!0), d(void 0);
                          try {
                            "wallet_connect_v2" ===
                              b?.connector?.connectorType &&
                              "metamask" === b?.connector?.walletClientType &&
                              (await nt(2500)),
                              await Q();
                          } catch (e) {
                            console.warn("Auto-prompted signature failed", e);
                          } finally {
                            l(!1);
                          }
                        })()));
            }, [_, q, B]),
              (0, C.useEffect)(() => {
                if (F && i) {
                  if (v?.legal.requireUsersAcceptTerms && !F.hasAcceptedTerms) {
                    let e = setTimeout(() => {
                      h(sM);
                    }, 900);
                    return () => clearTimeout(e);
                  }
                  if (o4(F, v.embeddedWallets)) {
                    let e = setTimeout(() => {
                      y({
                        createWallet: {
                          onSuccess: () => {},
                          onFailure: (e) => {
                            console.error(e),
                              E({
                                eventName:
                                  "embedded_wallet_creation_failure_logout",
                                payload: {
                                  error: e,
                                  screen: "ConnectionStatusScreen",
                                },
                              }),
                              p();
                          },
                          callAuthOnSuccessOnClose: !0,
                        },
                      }),
                        h(s_);
                    }, 900);
                    return () => clearTimeout(e);
                  }
                  I();
                  let e = setTimeout(
                    () => T({ shouldCallAuthOnSuccess: !0, isSuccess: !0 }),
                    th
                  );
                  return () => clearTimeout(e);
                }
              }, [F, i]);
            let Y = (e) => {
              if (e?.privyErrorCode !== eh.h.ALLOWLIST_REJECTED) {
                if (e?.privyErrorCode === eh.h.USER_LIMIT_REACHED)
                  return console.error(new eh.ab(e).toString()), void h(lE);
                if (e?.privyErrorCode !== eh.h.USER_DOES_NOT_EXIST)
                  return e?.privyErrorCode === eh.h.ACCOUNT_TRANSFER_REQUIRED &&
                    e.data?.data?.nonce
                    ? (y({
                        accountTransfer: {
                          nonce: e.data?.data?.nonce,
                          account: x()?.meta.address,
                          displayName: e.data?.data?.account?.displayName,
                          externalWalletMetadata: {
                            walletClientType: x()?.meta.walletClientType,
                            chainId: x()?.meta.chainId,
                            connectorType: x()?.meta.connectorType,
                          },
                          linkMethod: x() instanceof t0 ? "siwe" : "siws",
                          embeddedWalletAddress:
                            e.data?.data?.otherUser?.embeddedWalletAddress,
                        },
                      }),
                      void h(sS))
                    : void d(lN(e));
                h(o6);
              } else h(lv);
            };
            async function Q() {
              try {
                await S(), o(!0);
              } catch (e) {
                Y(e);
              } finally {
                l(!1);
              }
            }
            (0, C.useEffect)(() => {
              b?.connectError && Y(b?.connectError);
            }, [b]),
              (e = () => {
                let e =
                  "wallet_connect_v2" === K && b?.connector instanceof al
                    ? b.connector.redirectUri
                    : void 0;
                e && D(e);
                let t =
                  "wallet_connect_v2" === K && b?.connector instanceof al
                    ? b.connector.fallbackUniversalRedirectUri
                    : void 0;
                t && R(t);
              }),
              (t = b?.connector instanceof al && !P ? 500 : null),
              (n = (0, C.useRef)(() => {})),
              (0, C.useEffect)(() => {
                n.current = e;
              }),
              (0, C.useEffect)(() => {
                if (null !== t) {
                  let e = setInterval(() => n.current(), t || 0);
                  return () => clearInterval(e);
                }
              }, [t]);
            let K = b?.connector?.connectorType || "injected",
              X = b?.connector?.walletClientType || "unknown",
              J =
                $?.metadata?.shortName ||
                $?.name ||
                b?.connector?.walletBranding.name ||
                "Browser Extension",
              ee =
                $?.image_url?.md ||
                b?.connector?.walletBranding.icon ||
                ((e) => (0, a.jsx)(nD, { ...e })),
              et = "Browser Extension" === J ? J.toLowerCase() : J;
            r = i
              ? `Successfully connected with ${et}`
              : c
              ? c.message
              : G
              ? "Switching networks"
              : q
              ? s && Z
                ? "Signing"
                : "Sign to verify"
              : `Waiting for ${et}`;
            let en = "Don’t see your wallet? Check your other browser windows.";
            i
              ? (en =
                  L === (F?.linkedAccounts.length || 0)
                    ? "Wallet was already linked."
                    : "You’re good to go!")
              : _ >= 2 && c
              ? (en = "Unable to connect wallet")
              : c
              ? (en = c.detail)
              : G
              ? (en = "Switch your wallet to the requested network.")
              : q && Z
              ? (en =
                  "Sign the message in your wallet to verify it belongs to you.")
              : "metamask" === X && eC.tq
              ? (en = "Click continue to open and connect MetaMask.")
              : "metamask" === X
              ? (en =
                  "For the best experience, connect only one wallet at a time.")
              : "wallet_connect" === K
              ? (en = "Open your mobile wallet app to continue")
              : "coinbase_wallet" === K
              ? t5() ||
                (en = lh(F)
                  ? "Continue with the Coinbase app. Not the right wallet? Reset your connection below."
                  : "Confirm in the Coinbase app/popup to continue.")
              : w?.login?.isSigningInWithLedgerSolana &&
                (en =
                  "Ledger requires a transaction to verify your identity. You’ll sign a transaction that performs no onchain action.");
            let ea = N?.walletConnectors?.find(
                (e) => "coinbase_wallet" === e.walletClientType
              ),
              er =
                "coinbase_wallet" === X &&
                (lh(F) || c === nS.ERROR_USER_EXISTS);
            return (0, a.jsx)(l_, {
              walletLogo: ee,
              title: r,
              subtitle: en,
              signSuccess: i,
              errorMessage: c,
              connectSuccess: q,
              separateConnectAndSign: Z,
              signing: s,
              walletConnectRedirectUri: P,
              walletConnectFallbackUniversalUri: W,
              hasTabbedAway: O,
              showCoinbaseWalletResetCta: er,
              numRetries: _,
              onBack: f && m !== f ? g : void 0,
              onSign: () => {
                l(!0), Q();
              },
              onRetry: () => {
                M(_ + 1), d(void 0), q ? (l(!0), Q()) : b?.connectRetry();
              },
              onCoinbaseReset: () => {
                ea && ea?.disconnect();
              },
              onDifferentWallet: g,
            });
          },
        },
        lF = T.zo.p.withConfig({
          displayName: "RedirectLinksContainer",
          componentId: "sc-7b4251f2-0",
        })([
          "text-align:center;color:var(--privy-color-foreground-2);font-size:14px;line-height:22px;margin:16px 0;",
        ]),
        lz = {
          component: () => {
            let {
                setWalletConnectionStatus: e,
                closePrivyModal: t,
                inProgressAuthFlowRef: n,
              } = (0, j.u)(),
              { data: r, navigate: i } = ap(),
              o = ar(),
              s = aw(),
              l = r?.externalConnectWallet?.description,
              c = (0, C.useRef)(
                r?.externalConnectWallet?.walletList ?? o.appearance.walletList
              ),
              d = (0, C.useRef)(
                r?.externalConnectWallet?.walletChainType ??
                  o.appearance.walletChainType
              ),
              u = c.current,
              p = d.current,
              h = "link" === n.current ? void 0 : () => i(pD);
            return (0, a.jsx)(lr, {
              walletList: u,
              walletChainType: p,
              onClose: t,
              onConnect: (0, C.useCallback)(
                ({ connector: t, wallet: n }) => {
                  s("connectWallet", "onSuccess", { wallet: n }),
                    e({
                      status: "connected",
                      connectedWallet: n,
                      connector: t,
                      connectError: null,
                      connectRetry: () => null,
                    }),
                    i(lM, !r?.externalConnectWallet?.preSelectedWalletId);
                },
                [
                  e,
                  i,
                  r?.login?.disableSignup,
                  r?.externalConnectWallet?.preSelectedWalletId,
                ]
              ),
              onConnectError: (e) => {
                e instanceof eh.aa
                  ? (console.warn(e.cause ? e.cause : e.message),
                    s(
                      "connectWallet",
                      "onError",
                      e.privyErrorCode || eh.h.GENERIC_CONNECT_WALLET_ERROR
                    ))
                  : (console.warn(e),
                    s(
                      "connectWallet",
                      "onError",
                      eh.h.UNKNOWN_CONNECT_WALLET_ERROR
                    ));
              },
              onBack: h,
              customDescription: l || "",
              preSelectedWalletId:
                r?.externalConnectWallet?.preSelectedWalletId,
              app: o,
            });
          },
          isUnauthenticatedScreem: !0,
        },
        lL = ({ children: e, theme: t }) =>
          (0, a.jsxs)(lP, {
            $theme: t,
            children: [
              (0, a.jsx)(e2.Z, {
                width: "20px",
                height: "20px",
                color: "var(--privy-color-icon-subtle)",
                strokeWidth: 2,
                style: { flexShrink: 0 },
              }),
              (0, a.jsx)(lD, { $theme: t, children: e }),
            ],
          }),
        lP = T.zo.div.withConfig({
          displayName: "Container",
          componentId: "sc-1b5ed8dd-0",
        })([
          "display:flex;gap:0.75rem;background-color:var(--privy-color-background-2);align-items:flex-start;padding:1rem;border-radius:0.75rem;",
        ]),
        lD = T.zo.div.withConfig({
          displayName: "Content",
          componentId: "sc-1b5ed8dd-1",
        })(
          [
            "color:",
            ";font-size:1rem;font-weight:400;line-height:1.5;flex:1;text-align:left;",
          ],
          (e) =>
            "dark" === e.$theme
              ? "var(--privy-color-foreground-2)"
              : "var(--privy-color-foreground)"
        ),
        lW = T.zo.span.withConfig({
          displayName: "Subtitle",
          componentId: "sc-7a11f796-0",
        })([
          "margin-top:4px;color:var(--privy-color-foreground);text-align:center;font-size:0.875rem;font-weight:400;line-height:1.375rem;&& a{color:var(--privy-color-accent);}",
        ]),
        lR = T.zo.span.withConfig({
          displayName: "Title",
          componentId: "sc-66de63c-0",
        })([
          "color:var(--privy-color-foreground);font-size:1.125rem;font-weight:600;line-height:1.875rem;text-align:center;",
        ]),
        lB = T.zo.span.withConfig({
          displayName: "LabelXs",
          componentId: "sc-4c43f9fd-0",
        })([
          "color:var(--privy-color-foreground-3);font-size:0.75rem;font-weight:500;line-height:1.125rem;",
        ]),
        lU = (0, T.iv)(
          [
            "&&{border-width:1px;padding:0.5rem 1rem;}width:100%;text-align:left;border:solid 1px var(--privy-color-foreground-4);border-radius:var(--privy-border-radius-md);display:flex;justify-content:space-between;align-items:center;",
            "",
          ],
          (e) =>
            "error" === e.$state
              ? "\n        border-color: var(--privy-color-error);\n        background: var(--privy-color-error-bg);\n      "
              : ""
        ),
        lO = T.zo.div.withConfig({
          displayName: "Box",
          componentId: "sc-7252360a-0",
        })(["", ""], lU),
        lH = (0, T.zo)(lO).withConfig({
          displayName: "StyledBox",
          componentId: "sc-4010d8f3-0",
        })(["&&{padding:0.75rem;height:56px;}"]),
        lV = T.zo.div.withConfig({
          displayName: "WalletContent",
          componentId: "sc-4010d8f3-1",
        })([
          "display:flex;align-items:center;justify-content:space-between;width:100%;",
        ]),
        l$ = T.zo.div.withConfig({
          displayName: "AddressContainer",
          componentId: "sc-4010d8f3-2",
        })(["display:flex;flex-direction:column;gap:0;"]),
        lZ = T.zo.div.withConfig({
          displayName: "BalanceText",
          componentId: "sc-4010d8f3-3",
        })([
          "font-size:12px;line-height:1rem;color:var(--privy-color-foreground-3);",
        ]),
        lq = (0, T.zo)(lB).withConfig({
          displayName: "TitleLabel",
          componentId: "sc-4010d8f3-4",
        })(["text-align:left;margin-bottom:0.5rem;"]),
        lG = (0, T.zo)(sY).withConfig({
          displayName: "StyledErrorMessage",
          componentId: "sc-4010d8f3-5",
        })(["margin-top:0.25rem;"]),
        lY = (0, T.zo)(aY).withConfig({
          displayName: "CopyButton",
          componentId: "sc-4010d8f3-6",
        })(["&&{gap:0.375rem;font-size:14px;}"]),
        lQ = ({
          errMsg: e,
          balance: t,
          address: n,
          className: r,
          title: i,
          showCopyButton: l = !1,
        }) => {
          let [c, d] = (0, C.useState)(!1);
          return (
            (0, C.useEffect)(() => {
              if (c) {
                let e = setTimeout(() => d(!1), 3e3);
                return () => clearTimeout(e);
              }
            }, [c]),
            (0, a.jsxs)("div", {
              children: [
                i && (0, a.jsx)(lq, { children: i }),
                (0, a.jsx)(lH, {
                  className: r,
                  $state: e ? "error" : void 0,
                  children: (0, a.jsxs)(lV, {
                    children: [
                      (0, a.jsxs)(l$, {
                        children: [
                          (0, a.jsx)(o7, { address: n, showCopyIcon: !1 }),
                          void 0 !== t && (0, a.jsx)(lZ, { children: t }),
                        ],
                      }),
                      l &&
                        (0, a.jsx)(lY, {
                          onClick: function (e) {
                            e.stopPropagation(),
                              navigator.clipboard
                                .writeText(n)
                                .then(() => d(!0))
                                .catch(console.error);
                          },
                          size: "sm",
                          children: (0, a.jsxs)(
                            a.Fragment,
                            c
                              ? {
                                  children: [
                                    "Copied",
                                    (0, a.jsx)(o.Z, { size: 14 }),
                                  ],
                                }
                              : {
                                  children: [
                                    "Copy",
                                    (0, a.jsx)(s.Z, { size: 14 }),
                                  ],
                                }
                          ),
                        }),
                    ],
                  }),
                }),
                e && (0, a.jsx)(lG, { children: e }),
              ],
            })
          );
        };
      function lK({ rpcConfig: e, appId: t, address: n, chain: a }) {
        let { chains: r } = (0, j.u)(),
          [i, o] = (0, C.useState)(0n),
          [s, l] = (0, C.useState)(!1),
          c = (0, C.useMemo)(() => {
            let n = a || r[0];
            if (n)
              return (0, I.v)({ chain: a, transport: (0, E.d)(t8(n, e, t)) });
          }, [a, e, t]),
          d = (0, C.useCallback)(async () => {
            if (!n || !c) return;
            l(!0);
            let e = await c.getBalance({ address: n }).catch(console.error);
            return e ? (o(e), l(!1), e) : void 0;
          }, [c, n, o]);
        return (
          (0, C.useEffect)(() => {
            d().catch(console.error);
          }, []),
          { balance: i, isLoading: s, reloadBalance: d }
        );
      }
      let lX = "sdk_fiat_on_ramp_completed_with_status";
      async function lJ({ rpc: e, address: t }) {
        return (
          (await e.getBalance(t, { commitment: "confirmed" }).send()).value ??
          0n
        );
      }
      function l0(e) {
        switch (e) {
          case "solana:mainnet":
            return "Solana";
          case "solana:devnet":
            return "Devnet";
          case "solana:testnet":
            return "Testnet";
        }
      }
      function l1(e) {
        let [t] =
          Object.entries(rR[e]).find(([e, t]) => "USDC" === t.symbol) ?? [];
        return t;
      }
      let l2 = async ({
          chain: e,
          address: t,
          appId: n,
          rpcConfig: a,
          erc20Address: r,
        }) => {
          let i = (0, I.v)({ chain: e, transport: (0, E.d)(t8(e, a, n)) });
          return {
            balance: await i
              .readContract({
                address: r,
                abi: l3,
                functionName: "balanceOf",
                args: [t],
              })
              .catch(() => 0n),
            chain: e,
          };
        },
        l3 = [
          {
            constant: !0,
            inputs: [{ name: "_owner", type: "address" }],
            name: "balanceOf",
            outputs: [{ name: "balance", type: "uint256" }],
            payable: !1,
            stateMutability: "view",
            type: "function",
          },
        ],
        l4 = {
          component: () => {
            let { wallets: e } = iA(),
              { connectors: t } = (0, j.u)(),
              n = t.filter(nY).flatMap((e) => e.wallets),
              { data: r, setModalData: i, navigate: o, lastScreen: s } = ap(),
              {
                rpcConfig: l,
                appId: c,
                createAnalyticsEvent: d,
                closePrivyModal: u,
              } = (0, j.u)(),
              p = ar(),
              [h, g] = (0, C.useState)(void 0),
              [f, m] = (0, C.useState)(!1),
              y = r?.funding,
              { reloadBalance: w } = lK({
                rpcConfig: l,
                appId: c,
                address: "ethereum" === y.chainType ? y.address : void 0,
                chain: "ethereum" === y.chainType ? y.chain : void 0,
              }),
              v = "solana" === y.chainType,
              x = v
                ? y.isUSDC
                  ? "USDC"
                  : "SOL"
                : y.erc20Address
                ? y.erc20ContractInfo?.symbol
                : y.chain.nativeCurrency.symbol,
              b = v
                ? n.find(({ address: e }) => e === y.address)
                : e.find(({ address: e }) => t9(e) === t9(y.address));
            if (!y)
              return (
                i({
                  errorModalData: {
                    error: Error("Couldn't find funding config"),
                    previousScreen: s || uI,
                  },
                  funding: r?.funding,
                  solanaFundingData: r?.solanaFundingData,
                  sendTransaction: r?.sendTransaction,
                }),
                o(sg),
                (0, a.jsx)(a.Fragment, {})
              );
            (0, C.useEffect)(() => {
              let e = v
                  ? async function () {
                      if ("solana" !== y.chainType) return;
                      let e = p.solanaRpcs[y.chain];
                      e
                        ? (y.isUSDC
                            ? (async function ({
                                rpc: e,
                                address: t,
                                mintAddress: n,
                              }) {
                                let a = await e
                                    .getTokenAccountsByOwner(
                                      t,
                                      { mint: n },
                                      {
                                        encoding: "jsonParsed",
                                        commitment: "confirmed",
                                      }
                                    )
                                    .send(),
                                  r = a.value[0]?.account;
                                return r
                                  ? BigInt(
                                      r.data.parsed.info.tokenAmount.amount
                                    )
                                  : 0n;
                              })({
                                rpc: e.rpc,
                                address: y.address,
                                mintAddress: l1(y.chain),
                              })
                            : lJ({ rpc: e.rpc, address: y.address })
                          ).then((e) => {
                            let t = BigInt(e);
                            h &&
                              t > h &&
                              (m(!0),
                              d({
                                eventName: lX,
                                payload: {
                                  provider: "manual",
                                  status: "success",
                                  chainType: "solana",
                                  address: b?.address,
                                  value: y.isUSDC
                                    ? (0, F.b)(t - h, 6)
                                    : (0, F.b)(t - h, 9),
                                  token: y.isUSDC ? "USDC" : "SOL",
                                },
                              })),
                              g(t);
                          })
                        : console.warn(
                            "Unable to load solana rpc, skipping balance"
                          );
                    }
                  : async function () {
                      "ethereum" === y.chainType &&
                        (async () => {
                          if (!y.erc20Address) return (await w()) ?? BigInt(0);
                          {
                            let { balance: e } = await l2({
                              chain: y.chain,
                              address: y.address,
                              erc20Address: y.erc20Address,
                              rpcConfig: l,
                              appId: c,
                            });
                            return e;
                          }
                        })()
                          .then((e) => {
                            h &&
                              e > h &&
                              (m(!0),
                              d({
                                eventName: lX,
                                payload: {
                                  provider: "manual",
                                  status: "success",
                                  chainType: "ethereum",
                                  address: b?.address,
                                  chainId: y.chain.id,
                                  value: (0, F.b)(
                                    e - h,
                                    y.erc20ContractInfo?.decimals ?? 18
                                  ),
                                  token:
                                    y.erc20ContractInfo?.symbol ??
                                    y.erc20Address ??
                                    "ETH",
                                },
                              })),
                              g(e);
                          })
                          .catch(() => g(void 0));
                    },
                t = setInterval(e, 2e3);
              return e(), () => clearInterval(t);
            }, [h]);
            let k = (0, C.useMemo)(
                () =>
                  null == h
                    ? ""
                    : y.isUSDC
                    ? (0, K.LH)({ amount: h, decimals: 6 })
                    : v
                    ? rO(h, 3, !0, !0)
                    : null != y.erc20ContractInfo?.decimals
                    ? (0, K.LH)({
                        amount: h,
                        decimals: y.erc20ContractInfo.decimals,
                      })
                    : (0, K.Cr)({ wei: h }),
                [h, v, y]
              ),
              T = "ethereum" === y.chainType ? y.chain.name : l0(y.chain),
              A = (0, C.useMemo)(
                () =>
                  "" === y.uiConfig?.receiveFundsTitle
                    ? null
                    : (0, a.jsx)(lR, {
                        children:
                          y.uiConfig?.receiveFundsTitle ??
                          `Receive ${y.amount} ${x ?? ""}`.trim(),
                      }),
                [y.uiConfig?.receiveFundsTitle, y.amount, x]
              ),
              S = (0, C.useMemo)(
                () =>
                  "" === y.uiConfig?.receiveFundsSubtitle
                    ? null
                    : (0, a.jsx)(lW, {
                        children:
                          y.uiConfig?.receiveFundsSubtitle ??
                          `Scan this code or copy your wallet address to receive funds on ${T}.`,
                      }),
                [y.uiConfig?.receiveFundsSubtitle, T]
              ),
              I =
                "solana" === y.chainType && y.isUSDC && l1(y.chain)
                  ? `?spl-token=${l1(y.chain)}`
                  : "";
            return (0, a.jsxs)(a.Fragment, {
              children: [
                (0, a.jsx)(dd, {}),
                A,
                S,
                (0, a.jsxs)(r0, {
                  style: { gap: "1rem", margin: A || S ? "1rem 0" : "0" },
                  children: [
                    (0, a.jsx)(sG, {
                      url: `${y.chainType}:${y.address}${I}`,
                      size: 200,
                      squareLogoElement: l5,
                    }),
                    (0, a.jsxs)(lL, {
                      theme: p.appearance.palette.colorScheme,
                      children: ["Make sure to send funds on ", T, "."],
                    }),
                    (0, a.jsx)(lQ, {
                      title: "Your wallet",
                      errMsg: void 0,
                      showCopyButton: !0,
                      balance: `${k} ${x}`,
                      address: y.address,
                    }),
                    f &&
                      (0, a.jsx)(a$, {
                        onClick: () =>
                          u({ shouldCallAuthOnSuccess: !1, isSuccess: !0 }),
                        children: "Continue",
                      }),
                  ],
                }),
                (0, a.jsx)(aF, {}),
              ],
            });
          },
        },
        l5 = ({ ...e }) => (0, a.jsx)(nL, { color: "black", ...e }),
        l6 = [
          {
            constant: !0,
            inputs: [{ name: "_owner", type: "address" }],
            name: "balanceOf",
            outputs: [{ name: "balance", type: "uint256" }],
            payable: !1,
            stateMutability: "view",
            type: "function",
          },
        ],
        l8 = async ({ address: e, chain: t, rpcConfig: n, privyAppId: a }) => {
          try {
            let r = (0, I.v)({ chain: t, transport: (0, E.d)(t8(t, n, a)) }),
              [i, o] = await Promise.all([
                r.readContract({ abi: l7, address: e, functionName: "symbol" }),
                r.readContract({
                  abi: l7,
                  address: e,
                  functionName: "decimals",
                }),
              ]);
            return { decimals: o, symbol: i };
          } catch (e) {
            return console.log(e), null;
          }
        },
        l7 = [
          {
            inputs: [],
            name: "decimals",
            outputs: [{ internalType: "uint8", name: "", type: "uint8" }],
            stateMutability: "view",
            type: "function",
          },
          {
            inputs: [],
            name: "symbol",
            outputs: [{ internalType: "string", name: "", type: "string" }],
            stateMutability: "view",
            type: "function",
          },
        ],
        l9 = 2n ** 256n - 1n,
        ce = ({ amount: e, decimals: t }) =>
          e === l9
            ? "Maximum"
            : Intl.NumberFormat(void 0, { maximumFractionDigits: t }).format(
                Number(e) / 10 ** t
              ),
        ct = ({ data: e }) => {
          let t = (e) =>
            "object" == typeof e && null !== e
              ? (0, a.jsx)(ca, {
                  children: Object.entries(e).map(([e, n]) =>
                    (0, a.jsxs)(
                      "li",
                      {
                        children: [
                          (0, a.jsxs)("strong", { children: [e, ":"] }),
                          " ",
                          t(n),
                        ],
                      },
                      e
                    )
                  ),
                })
              : (0, a.jsx)("span", { children: String(e) });
          return (0, a.jsx)("div", { children: t(e) });
        },
        cn = T.zo.div.withConfig({
          displayName: "Message",
          componentId: "sc-70ec2a4f-0",
        })([
          "margin-top:1.5rem;background-color:var(--privy-color-background-2);border-radius:var(--privy-border-radius-md);padding:12px;text-align:left;max-height:310px;overflow:scroll;white-space:pre-wrap;width:100%;font-size:0.875rem;font-weight:400;color:var(--privy-color-foreground);line-height:1.5;-ms-overflow-style:none;scrollbar-width:none;&::-webkit-scrollbar{display:none;}",
        ]),
        ca = T.zo.ul.withConfig({
          displayName: "MessageList",
          componentId: "sc-70ec2a4f-1",
        })([
          "margin-left:12px !important;white-space:nowrap;&:first-child{margin-left:0 !important;}strong{font-weight:500 !important;}",
        ]),
        cr = ({ data: e, className: t }) =>
          (0, a.jsx)(cn, {
            className: t,
            children: (0, a.jsx)(ct, { data: e }),
          }),
        ci = T.zo.div.withConfig({
          displayName: "Container",
          componentId: "sc-b3a607dd-0",
        })(["display:flex;flex-direction:column;min-height:72px;"]);
      var co = ({ onBack: e, details: t }) =>
        (0, a.jsxs)(ci, {
          children: [
            (0, a.jsx)(a4, { backFn: e }),
            (0, a.jsx)(cr, { data: t }),
            (0, a.jsx)(aF, {}),
          ],
        });
      let cs = T.zo.span.withConfig({
          displayName: "LabelSm",
          componentId: "sc-6c002d6-0",
        })([
          "color:var(--privy-color-foreground-3);font-size:0.875rem;font-weight:400;line-height:1.375rem;",
        ]),
        cl = (0, T.zo)(cs).withConfig({
          displayName: "LabelSmPrimary",
          componentId: "sc-6c002d6-1",
        })(["color:var(--privy-color-accent);"]),
        cc = (0, T.zo)(cs).withConfig({
          displayName: "InteractiveLabel",
          componentId: "sc-b57d0824-0",
        })([
          "cursor:pointer;display:inline-flex;gap:8px;align-items:center;color:var(--privy-color-accent);svg{fill:var(--privy-color-accent);}",
        ]),
        cd = T.zo.span.withConfig({
          displayName: "Rows",
          componentId: "sc-b764aab6-0",
        })(["display:flex;flex-direction:column;gap:0.35rem;width:100%;"]),
        cu = T.zo.span.withConfig({
          displayName: "Row",
          componentId: "sc-b764aab6-1",
        })([
          "display:flex;width:100%;justify-content:space-between;gap:0.5rem;",
        ]),
        cp = (0, T.F4)([
          "from,to{background:var(--privy-color-foreground-4);color:var(--privy-color-foreground-4);}50%{background:var(--privy-color-foreground-accent);color:var(--privy-color-foreground-accent);}",
        ]),
        ch = (0, T.iv)(["", ""], (e) =>
          e.$isLoading
            ? (0, T.iv)(
                [
                  "width:35%;animation:",
                  " 2s linear infinite;border-radius:var(--privy-border-radius-sm);",
                ],
                cp
              )
            : ""
        ),
        cg = T.zo.span.withConfig({
          displayName: "Value",
          componentId: "sc-72aa026-0",
        })(
          [
            "color:var(--privy-color-foreground);font-size:0.875rem;font-weight:500;line-height:1.375rem;word-break:break-all;text-align:right;",
            "",
          ],
          ch
        );
      var cf = ({
        iconUrl: e,
        value: t,
        symbol: n,
        usdValue: r,
        nftName: i,
        nftCount: o,
        decimals: s,
        $isLoading: l,
      }) => {
        if (l) return (0, a.jsx)(cm, { $isLoading: l });
        let c =
          t && r && s
            ? (function (e, t, n) {
                let a = parseFloat(e),
                  r = parseFloat(n);
                if (0 === a || 0 === r || Number.isNaN(a) || Number.isNaN(r))
                  return e;
                let i = Math.ceil(-Math.log10(0.01 / (r / a))),
                  o = Math.pow(10, (i = Math.max((i = Math.min(i, t)), 1))),
                  s = +(Math.floor(a * o) / o).toFixed(i).replace(/\.?0+$/, "");
                return Intl.NumberFormat(void 0, {
                  maximumFractionDigits: t,
                }).format(s);
              })(t, s, r)
            : t;
        return (0, a.jsxs)("div", {
          children: [
            (0, a.jsxs)(cm, {
              $isLoading: l,
              children: [
                e && (0, a.jsx)(cw, { src: e, alt: "Token icon" }),
                o && o > 1 ? o + "x" : void 0,
                " ",
                i,
                c,
                " ",
                n,
              ],
            }),
            r && (0, a.jsxs)(cy, { $isLoading: l, children: ["$", r] }),
          ],
        });
      };
      let cm = T.zo.span.withConfig({
          displayName: "Value",
          componentId: "sc-991db279-0",
        })(
          [
            "color:var(--privy-color-foreground);font-size:0.875rem;font-weight:500;line-height:1.375rem;word-break:break-all;text-align:right;display:flex;justify-content:flex-end;",
            "",
          ],
          ch
        ),
        cy = T.zo.span.withConfig({
          displayName: "Subvalue",
          componentId: "sc-991db279-1",
        })(
          [
            "color:var(--privy-color-foreground-2);font-size:12px;font-weight:400;line-height:18px;word-break:break-all;text-align:right;display:flex;justify-content:flex-end;",
            "",
          ],
          ch
        ),
        cw = T.zo.img.withConfig({
          displayName: "TokenIcon",
          componentId: "sc-991db279-2",
        })(["height:14px;width:14px;margin-right:4px;object-fit:contain;"]),
        cv = (e) => {
          let {
              chain: t,
              transactionDetails: n,
              isTokenContractInfoLoading: r,
              symbol: i,
            } = e,
            { action: o, functionName: s } = n;
          return (0, a.jsx)(lO, {
            children: (0, a.jsxs)(cd, {
              children: [
                "transaction" !== o &&
                  (0, a.jsxs)(cu, {
                    children: [
                      (0, a.jsx)(cs, { children: "Action" }),
                      (0, a.jsx)(cg, { children: s }),
                    ],
                  }),
                "mint" === s &&
                  "args" in n &&
                  n.args
                    .filter((e) => e)
                    .map((e, n) =>
                      (0, a.jsxs)(
                        cu,
                        {
                          children: [
                            (0, a.jsx)(cs, { children: `Param ${n}` }),
                            (0, a.jsx)(cg, {
                              children:
                                "string" == typeof e && (0, z.U)(e)
                                  ? (0, a.jsx)(o7, {
                                      address: e,
                                      url: t?.blockExplorers?.default?.url,
                                      showCopyIcon: !1,
                                    })
                                  : e?.toString(),
                            }),
                          ],
                        },
                        n
                      )
                    ),
                "setApprovalForAll" === s &&
                  n.operator &&
                  (0, a.jsxs)(cu, {
                    children: [
                      (0, a.jsx)(cs, { children: "Operator" }),
                      (0, a.jsx)(cg, {
                        children: (0, a.jsx)(o7, {
                          address: n.operator,
                          url: t?.blockExplorers?.default?.url,
                          showCopyIcon: !1,
                        }),
                      }),
                    ],
                  }),
                "setApprovalForAll" === s &&
                  void 0 !== n.approved &&
                  (0, a.jsxs)(cu, {
                    children: [
                      (0, a.jsx)(cs, { children: "Set approval to" }),
                      (0, a.jsx)(cg, {
                        children: n.approved ? "true" : "false",
                      }),
                    ],
                  }),
                "transfer" === s ||
                "transferFrom" === s ||
                "safeTransferFrom" === s ||
                "approve" === s
                  ? (0, a.jsxs)(a.Fragment, {
                      children: [
                        "formattedAmount" in n &&
                          n.formattedAmount &&
                          (0, a.jsxs)(cu, {
                            children: [
                              (0, a.jsx)(cs, { children: "Amount" }),
                              (0, a.jsxs)(cg, {
                                $isLoading: r,
                                children: [n.formattedAmount, " ", i],
                              }),
                            ],
                          }),
                        "tokenId" in n &&
                          n.tokenId &&
                          (0, a.jsxs)(cu, {
                            children: [
                              (0, a.jsx)(cs, { children: "Token ID" }),
                              (0, a.jsx)(cg, {
                                children: n.tokenId.toString(),
                              }),
                            ],
                          }),
                      ],
                    })
                  : null,
                "safeBatchTransferFrom" === s &&
                  (0, a.jsxs)(a.Fragment, {
                    children: [
                      "amounts" in n &&
                        n.amounts &&
                        (0, a.jsxs)(cu, {
                          children: [
                            (0, a.jsx)(cs, { children: "Amounts" }),
                            (0, a.jsx)(cg, { children: n.amounts.join(", ") }),
                          ],
                        }),
                      "tokenIds" in n &&
                        n.tokenIds &&
                        (0, a.jsxs)(cu, {
                          children: [
                            (0, a.jsx)(cs, { children: "Token IDs" }),
                            (0, a.jsx)(cg, { children: n.tokenIds.join(", ") }),
                          ],
                        }),
                    ],
                  }),
                "approve" === s &&
                  n.spender &&
                  (0, a.jsxs)(cu, {
                    children: [
                      (0, a.jsx)(cs, { children: "Spender" }),
                      (0, a.jsx)(cg, {
                        children: (0, a.jsx)(o7, {
                          address: n.spender,
                          url: t?.blockExplorers?.default?.url,
                          showCopyIcon: !1,
                        }),
                      }),
                    ],
                  }),
                ("transferFrom" === s ||
                  "safeTransferFrom" === s ||
                  "safeBatchTransferFrom" === s) &&
                  n.transferFrom &&
                  (0, a.jsxs)(cu, {
                    children: [
                      (0, a.jsx)(cs, { children: "Transferring from" }),
                      (0, a.jsx)(cg, {
                        children: (0, a.jsx)(o7, {
                          address: n.transferFrom,
                          url: t?.blockExplorers?.default?.url,
                          showCopyIcon: !1,
                        }),
                      }),
                    ],
                  }),
                ("transferFrom" === s ||
                  "safeTransferFrom" === s ||
                  "safeBatchTransferFrom" === s) &&
                  n.transferTo &&
                  (0, a.jsxs)(cu, {
                    children: [
                      (0, a.jsx)(cs, { children: "Transferring to" }),
                      (0, a.jsx)(cg, {
                        children: (0, a.jsx)(o7, {
                          address: n.transferTo,
                          url: t?.blockExplorers?.default?.url,
                          showCopyIcon: !1,
                        }),
                      }),
                    ],
                  }),
              ],
            }),
          });
        },
        cx = ({ children: e, theme: t }) =>
          (0, a.jsxs)(cb, {
            $theme: t,
            children: [
              (0, a.jsx)(eT.Z, {
                width: "20px",
                height: "20px",
                color: "var(--privy-color-icon-error)",
                strokeWidth: 2,
                style: { flexShrink: 0 },
              }),
              (0, a.jsx)(cC, { $theme: t, children: e }),
            ],
          }),
        cb = T.zo.div.withConfig({
          displayName: "Container",
          componentId: "sc-34910fd1-0",
        })([
          "display:flex;gap:0.75rem;background-color:var(--privy-color-error-bg);align-items:flex-start;padding:1rem;border-radius:0.75rem;",
        ]),
        cC = T.zo.div.withConfig({
          displayName: "Content",
          componentId: "sc-34910fd1-1",
        })(
          [
            "color:",
            ";font-size:1rem;font-weight:400;line-height:1.5;flex:1;text-align:left;",
          ],
          (e) =>
            "dark" === e.$theme
              ? "var(--privy-color-foreground-2)"
              : "var(--privy-color-foreground)"
        ),
        cj = ({ children: e, theme: t }) =>
          (0, a.jsxs)(ck, {
            $theme: t,
            children: [
              (0, a.jsx)(ej.Z, {
                width: "20px",
                height: "20px",
                color: "var(--privy-color-icon-warning)",
                strokeWidth: 2,
                style: { flexShrink: 0 },
              }),
              (0, a.jsx)(cT, { $theme: t, children: e }),
            ],
          }),
        ck = T.zo.div.withConfig({
          displayName: "Container",
          componentId: "sc-a77c2854-0",
        })([
          "display:flex;gap:0.75rem;background-color:var(--privy-color-warn-bg);align-items:flex-start;padding:1rem;border-radius:0.75rem;",
        ]),
        cT = T.zo.div.withConfig({
          displayName: "Content",
          componentId: "sc-a77c2854-1",
        })(
          [
            "color:",
            ";font-size:1rem;font-weight:400;line-height:1.5;flex:1;text-align:left;",
          ],
          (e) =>
            "dark" === e.$theme
              ? "var(--privy-color-foreground-2)"
              : "var(--privy-color-foreground)"
        ),
        cA = ({
          variant: e,
          setPreventMaliciousTransaction: t,
          colorScheme: n = "light",
          preventMaliciousTransaction: r,
        }) =>
          "warn" === e
            ? (0, a.jsx)(cS, {
                children: (0, a.jsxs)(cj, {
                  theme: n,
                  children: [
                    (0, a.jsx)("span", {
                      style: { fontWeight: "500" },
                      children: "Warning: Suspicious transaction",
                    }),
                    (0, a.jsx)("br", {}),
                    "This has been flagged as a potentially deceptive request. Approving could put your assets or funds at risk.",
                  ],
                }),
              })
            : "error" === e
            ? (0, a.jsx)(a.Fragment, {
                children: (0, a.jsxs)(cS, {
                  children: [
                    (0, a.jsx)(cx, {
                      theme: n,
                      children: (0, a.jsxs)("div", {
                        children: [
                          (0, a.jsx)("strong", {
                            children: "This is a malicious transaction",
                          }),
                          (0, a.jsx)("br", {}),
                          "This transaction transfers tokens to a known malicious address. Proceeding may result in the loss of valuable assets.",
                        ],
                      }),
                    }),
                    (0, a.jsxs)(cI, {
                      children: [
                        (0, a.jsx)(om, {
                          color: "var(--privy-color-error)",
                          checked: !r,
                          readOnly: !0,
                          onClick: () => t(!r),
                        }),
                        (0, a.jsx)("span", {
                          children: "I understand and want to proceed anyways.",
                        }),
                      ],
                    }),
                  ],
                }),
              })
            : null,
        cS = T.zo.div.withConfig({
          displayName: "BannerContainer",
          componentId: "sc-ab8a5a0b-0",
        })(["margin-top:1.5rem;"]),
        cI = T.zo.div.withConfig({
          displayName: "CheckboxContainer",
          componentId: "sc-ab8a5a0b-1",
        })(["display:flex;align-items:center;gap:0.5rem;margin-top:0.75rem;"]),
        cE = ({ transactionIndex: e, maxIndex: t }) =>
          "number" != typeof e || 0 === t ? "" : ` (${e + 1} / ${t + 1})`,
        cN = ({
          img: e,
          submitError: t,
          prepareError: n,
          onClose: r,
          action: i,
          title: o,
          subtitle: s,
          to: l,
          tokenAddress: c,
          network: d,
          missingFunds: u,
          fee: p,
          from: h,
          cta: g,
          disabled: f,
          chain: m,
          isSubmitting: y,
          isPreparing: w,
          isTokenPriceLoading: v,
          isTokenContractInfoLoading: x,
          isSponsored: b,
          symbol: j,
          balance: k,
          onClick: T,
          transactionDetails: A,
          transactionIndex: S,
          maxIndex: I,
          onBack: E,
          chainName: N,
          validation: _,
          hasScanDetails: M,
          setIsScanDetailsOpen: F,
          preventMaliciousTransaction: z,
          setPreventMaliciousTransaction: L,
          tokensSent: P,
          tokensReceived: D,
          isScanning: W,
          isCancellable: R,
          functionName: B,
        }) => {
          let {
              showTransactionDetails: U,
              setShowTransactionDetails: O,
              hasMoreDetails: H,
              isErc20Ish: V,
            } = ((e) => {
              let [t, n] = (0, C.useState)(!1),
                a = !0,
                r = !1;
              return (
                (!e || e.isErc20Ish || "transaction" === e.action) && (a = !1),
                a &&
                  (r = Object.entries(e || {}).some(
                    ([e, t]) =>
                      t && !["action", "isErc20Ish", "isNFTIsh"].includes(e)
                  )),
                {
                  showTransactionDetails: t,
                  setShowTransactionDetails: n,
                  hasMoreDetails: a && r,
                  isErc20Ish: e?.isErc20Ish,
                }
              );
            })(A),
            $ = ar(),
            Z = (V && x) || w || v || W;
          return (0, a.jsxs)(a.Fragment, {
            children: [
              (0, a.jsx)(a4, { onClose: r, backFn: E }),
              e && (0, a.jsx)(cF, { children: e }),
              (0, a.jsxs)(lR, {
                style: { marginTop: e ? "1.5rem" : 0 },
                children: [
                  o,
                  (0, a.jsx)(cE, { maxIndex: I, transactionIndex: S }),
                ],
              }),
              (0, a.jsx)(lW, { children: s }),
              (0, a.jsxs)(cd, {
                style: { marginTop: "2rem" },
                children: [
                  (!!P[0] || Z) &&
                    (0, a.jsxs)(cu, {
                      children: [
                        D.length > 0
                          ? (0, a.jsx)(cs, { children: "Send" })
                          : (0, a.jsx)(cs, {
                              children:
                                "approve" === i ? "Approval amount" : "Amount",
                            }),
                        (0, a.jsx)("div", {
                          className: "flex flex-col",
                          children: P.map((e, t) =>
                            (0, a.jsx)(
                              cf,
                              {
                                iconUrl: e.iconUrl,
                                value:
                                  "setApprovalForAll" === B ? "All" : e.value,
                                usdValue: e.usdValue,
                                symbol: e.symbol,
                                nftName: e.nftName,
                                nftCount: e.nftCount,
                                decimals: e.decimals,
                              },
                              t
                            )
                          ),
                        }),
                      ],
                    }),
                  D.length > 0 &&
                    (0, a.jsxs)(cu, {
                      children: [
                        (0, a.jsx)(cs, { children: "Receive" }),
                        (0, a.jsx)("div", {
                          className: "flex flex-col",
                          children: D.map((e, t) =>
                            (0, a.jsx)(
                              cf,
                              {
                                iconUrl: e.iconUrl,
                                value: e.value,
                                usdValue: e.usdValue,
                                symbol: e.symbol,
                                nftName: e.nftName,
                                nftCount: e.nftCount,
                                decimals: e.decimals,
                              },
                              t
                            )
                          ),
                        }),
                      ],
                    }),
                  A && "spender" in A && A?.spender
                    ? (0, a.jsxs)(cu, {
                        children: [
                          (0, a.jsx)(cs, { children: "Spender" }),
                          (0, a.jsx)(cg, {
                            children: (0, a.jsx)(o7, {
                              address: A.spender,
                              url: m?.blockExplorers?.default?.url,
                            }),
                          }),
                        ],
                      })
                    : null,
                  l &&
                    (0, a.jsxs)(cu, {
                      children: [
                        (0, a.jsx)(cs, { children: "To" }),
                        (0, a.jsx)(cg, {
                          children: (0, a.jsx)(o7, {
                            address: l,
                            url: m?.blockExplorers?.default?.url,
                            showCopyIcon: !0,
                          }),
                        }),
                      ],
                    }),
                  c &&
                    (0, a.jsxs)(cu, {
                      children: [
                        (0, a.jsx)(cs, { children: "Token address" }),
                        (0, a.jsx)(cg, {
                          children: (0, a.jsx)(o7, {
                            address: c,
                            url: m?.blockExplorers?.default?.url,
                          }),
                        }),
                      ],
                    }),
                  (0, a.jsxs)(cu, {
                    children: [
                      (0, a.jsx)(cs, { children: "Network" }),
                      (0, a.jsx)(cg, { children: d }),
                    ],
                  }),
                  (0, a.jsxs)(cu, {
                    children: [
                      (0, a.jsx)(cs, { children: "Estimated fee" }),
                      (0, a.jsx)(cg, {
                        $isLoading: w || v || void 0 === b,
                        children: b
                          ? (0, a.jsxs)(cz, {
                              children: [
                                (0, a.jsxs)(cL, {
                                  children: ["Sponsored by ", $.name],
                                }),
                                (0, a.jsx)(eV.Z, { height: 16, width: 16 }),
                              ],
                            })
                          : p,
                      }),
                    ],
                  }),
                  H &&
                    !M &&
                    (0, a.jsxs)(a.Fragment, {
                      children: [
                        (0, a.jsx)(cu, {
                          className: "cursor-pointer",
                          onClick: () => O(!U),
                          children: (0, a.jsxs)(cl, {
                            className: "flex items-center gap-x-1",
                            children: [
                              "Details",
                              " ",
                              (0, a.jsx)(e$.Z, {
                                style: {
                                  width: "0.75rem",
                                  marginLeft: "0.25rem",
                                  transform: U ? "rotate(180deg)" : void 0,
                                },
                              }),
                            ],
                          }),
                        }),
                        U &&
                          A &&
                          (0, a.jsx)(cv, {
                            action: i,
                            chain: m,
                            transactionDetails: A,
                            isTokenContractInfoLoading: x,
                            symbol: j,
                          }),
                      ],
                    }),
                  M &&
                    (0, a.jsx)(cu, {
                      children: (0, a.jsxs)(cc, {
                        onClick: () => F(!0),
                        children: [
                          (0, a.jsx)("span", {
                            className: "text-color-primary",
                            children: "Details",
                          }),
                          (0, a.jsx)(eZ.Z, {
                            height: "14px",
                            width: "14px",
                            strokeWidth: "2",
                          }),
                        ],
                      }),
                    }),
                ],
              }),
              (0, a.jsx)(av, {}),
              t
                ? (0, a.jsx)(sY, {
                    style: { marginTop: "2rem" },
                    children: t.message,
                  })
                : n && 0 === S
                ? (0, a.jsx)(sY, {
                    style: { marginTop: "2rem" },
                    children: n.shortMessage ?? cM,
                  })
                : null,
              (0, a.jsx)(cA, {
                variant: _,
                preventMaliciousTransaction: z,
                setPreventMaliciousTransaction: L,
              }),
              (0, a.jsx)(c_, {
                $useSmallMargins: !(!n && !t && "warn" !== _ && "error" !== _),
                address: h,
                balance: k,
                errMsg:
                  w || n || t || !u
                    ? void 0
                    : `Add funds on ${m?.name ?? N} to complete transaction.`,
              }),
              (0, a.jsx)(a$, {
                style: { marginTop: "1rem" },
                loading: y,
                disabled: f || w,
                onClick: T,
                children: g,
              }),
              R &&
                (0, a.jsx)(aJ, {
                  style: { marginTop: "1rem" },
                  onClick: r,
                  isSubmitting: !1,
                  children: "Not now",
                }),
              (0, a.jsx)(aF, {}),
            ],
          });
        },
        c_ = (0, T.zo)(lQ).withConfig({
          displayName: "StyledWalletInfoCard",
          componentId: "sc-4e16a794-0",
        })(["", ""], (e) =>
          e.$useSmallMargins ? "margin-top: 0.5rem;" : "margin-top: 2rem;"
        ),
        cM =
          "There was an error preparing your transaction. Your transaction request will likely fail.",
        cF = T.zo.div.withConfig({
          displayName: "ImageContainer",
          componentId: "sc-4e16a794-2",
        })([
          "display:flex;width:100%;justify-content:center;max-height:40px;> img{object-fit:contain;border-radius:var(--privy-border-radius-sm);}",
        ]),
        cz = T.zo.span.withConfig({
          displayName: "SponsoredRow",
          componentId: "sc-4e16a794-3",
        })(["display:inline-flex;align-items:center;gap:0.3rem;"]),
        cL = T.zo.span.withConfig({
          displayName: "SponsoredText",
          componentId: "sc-4e16a794-4",
        })([
          "font-size:14px;font-weight:500;color:var(--privy-color-foreground);",
        ]),
        cP = () =>
          (0, a.jsxs)(cU, {
            children: [(0, a.jsx)(cH, {}), (0, a.jsx)(cO, {})],
          }),
        cD = ({
          transactionError: e,
          chainId: t,
          onClose: n,
          onRetry: r,
          chainType: i,
          transactionHash: o,
        }) => {
          let { chains: s } = (0, j.u)(),
            [l, c] = (0, C.useState)(!1),
            { errorCode: d, errorMessage: u } = ((e, t) => {
              if ("ethereum" === t)
                return {
                  errorCode: e.details ?? e.message,
                  errorMessage: e.shortMessage,
                };
              let n = e.txSignature,
                a = e?.transactionMessage || "Something went wrong.";
              if (Array.isArray(e.logs)) {
                let t = e.logs.find((e) =>
                  /insufficient (lamports|funds)/gi.test(e)
                );
                t && (a = t);
              }
              return { transactionHash: n, errorMessage: a };
            })(e, i),
            p = (({
              chains: e,
              chainId: t,
              chainType: n,
              transactionHash: a,
            }) =>
              "ethereum" === n
                ? e.find((e) => e.id === t)?.blockExplorers?.default.url ??
                  "https://etherscan.io"
                : `https://explorer.solana.com/tx/${a || ""}?chain=${t}`)({
              chains: s,
              chainId: t,
              chainType: i,
              transactionHash: o,
            });
          return (0, a.jsxs)(a.Fragment, {
            children: [
              (0, a.jsx)(a4, { onClose: n }),
              (0, a.jsxs)(cW, {
                children: [
                  (0, a.jsx)(cP, {}),
                  (0, a.jsx)(cR, { children: d }),
                  (0, a.jsx)(cB, { children: "Please try again." }),
                  (0, a.jsxs)(cZ, {
                    children: [
                      (0, a.jsx)(c$, { children: "Error message" }),
                      (0, a.jsx)(cG, { $clickable: !1, children: u }),
                    ],
                  }),
                  o &&
                    (0, a.jsxs)(cZ, {
                      children: [
                        (0, a.jsx)(c$, { children: "Transaction hash" }),
                        (0, a.jsxs)(cq, {
                          children: [
                            "Copy this hash to view details about the transaction on a",
                            " ",
                            (0, a.jsx)("u", {
                              children: (0, a.jsx)("a", {
                                href: p,
                                children: "block explorer",
                              }),
                            }),
                            ".",
                          ],
                        }),
                        (0, a.jsxs)(cG, {
                          $clickable: !0,
                          onClick: async () => {
                            await navigator.clipboard.writeText(o), c(!0);
                          },
                          children: [o, (0, a.jsx)(cK, { clicked: l })],
                        }),
                      ],
                    }),
                  (0, a.jsx)(cV, {
                    onClick: () => r({ resetNonce: !!o }),
                    children: "Retry transaction",
                  }),
                ],
              }),
              (0, a.jsx)(aL, {}),
            ],
          });
        },
        cW = T.zo.div.withConfig({
          displayName: "TransactionErrorScreenContainer",
          componentId: "sc-d58f10e6-0",
        })([
          "display:flex;flex-direction:column;align-items:center;justify-content:center;",
        ]),
        cR = T.zo.span.withConfig({
          displayName: "ErrorCode",
          componentId: "sc-d58f10e6-1",
        })([
          "color:var(--privy-color-foreground);text-align:center;font-size:1.125rem;font-weight:500;line-height:1.25rem;text-align:center;margin:10px;",
        ]),
        cB = T.zo.span.withConfig({
          displayName: "Subtitle",
          componentId: "sc-d58f10e6-2",
        })([
          "margin-top:4px;margin-bottom:10px;color:var(--privy-color-foreground-3);text-align:center;font-size:0.875rem;font-style:normal;font-weight:400;line-height:20px;letter-spacing:-0.008px;",
        ]),
        cU = T.zo.div.withConfig({
          displayName: "CircleContainer",
          componentId: "sc-d58f10e6-3",
        })([
          "position:relative;width:60px;height:60px;margin:10px;display:flex;justify-content:center;align-items:center;",
        ]),
        cO = (0, T.zo)(eT.Z).withConfig({
          displayName: "StyledExclamationCircleIcon",
          componentId: "sc-d58f10e6-4",
        })([
          "position:absolute;width:35px;height:35px;color:var(--privy-color-error);",
        ]),
        cH = T.zo.div.withConfig({
          displayName: "StyledRedCircle",
          componentId: "sc-d58f10e6-5",
        })([
          "position:absolute;width:60px;height:60px;border-radius:50%;background-color:var(--privy-color-error);opacity:0.1;",
        ]),
        cV = (0, T.zo)(a$).withConfig({
          displayName: "RetryButton",
          componentId: "sc-d58f10e6-6",
        })([
          "&&{margin-top:24px;}transition:color 350ms ease,background-color 350ms ease;",
        ]),
        c$ = T.zo.span.withConfig({
          displayName: "TextBoxTitle",
          componentId: "sc-d58f10e6-7",
        })([
          "width:100%;text-align:left;font-size:0.825rem;color:var(--privy-color-foreground);padding:4px;",
        ]),
        cZ = T.zo.div.withConfig({
          displayName: "TextBoxContainer",
          componentId: "sc-d58f10e6-8",
        })([
          "width:100%;margin:5px;display:flex;flex-direction:column;justify-content:center;align-items:center;",
        ]),
        cq = T.zo.text.withConfig({
          displayName: "HelperText",
          componentId: "sc-d58f10e6-9",
        })([
          "position:relative;width:100%;padding:5px;font-size:0.8rem;color:var(--privy-color-foreground-3);text-align:left;word-wrap:break-word;",
        ]),
        cG = T.zo.span.withConfig({
          displayName: "TextBox",
          componentId: "sc-d58f10e6-10",
        })(
          [
            "position:relative;width:100%;background-color:var(--privy-color-background-2);padding:8px 12px;border-radius:10px;margin-top:5px;font-size:14px;color:var(--privy-color-foreground-3);text-align:left;word-wrap:break-word;",
            "",
          ],
          (e) =>
            e.$clickable &&
            "cursor: pointer;\n  transition: background-color 0.3s;\n  padding-right: 45px;\n\n  &:hover {\n    background-color: var(--privy-color-foreground-4);\n  }"
        ),
        cY = (0, T.zo)(e3.Z).withConfig({
          displayName: "StyledClipboardIcon",
          componentId: "sc-d58f10e6-11",
        })(["position:absolute;top:13px;right:13px;width:24px;height:24px;"]),
        cQ = (0, T.zo)(eR.Z).withConfig({
          displayName: "StyledClipboardCheckIcon",
          componentId: "sc-d58f10e6-12",
        })(["position:absolute;top:13px;right:13px;width:24px;height:24px;"]),
        cK = ({ clicked: e }) => (0, a.jsx)(e ? cQ : cY, {}),
        cX = ({ gasUsed: e, effectiveGasPrice: t }) => {
          if (e && t)
            try {
              return (0, L.NC)(e * t);
            } catch (e) {
              return;
            }
        },
        cJ = ({
          txn: e,
          receipt: t,
          transactionInfo: n,
          onClose: r,
          tokenPrice: i,
          tokenSymbol: o,
          receiptHeader: s,
          receiptDescription: l,
        }) =>
          (0, a.jsxs)(a.Fragment, {
            children: [
              (0, a.jsx)(a4, { onClose: r }),
              (0, a.jsx)(iB, {
                title: s ?? "Transaction complete!",
                description: l ?? "You're all set.",
              }),
              (0, a.jsx)(ix, {
                tokenPrice: i,
                from: t.from,
                to: t.to,
                gas: cX(t),
                txn: e,
                transactionInfo: n,
                tokenSymbol: o,
              }),
              (0, a.jsx)(av, {}),
              (0, a.jsx)(c0, { loading: !1, onClick: r, children: "All Done" }),
              (0, a.jsx)(r4, {}),
              (0, a.jsx)(aF, {}),
            ],
          }),
        c0 = (0, T.zo)(a$).withConfig({
          displayName: "SubmitButton",
          componentId: "sc-f70d0f7a-0",
        })([
          "&&{margin-top:24px;}transition:color 350ms ease,background-color 350ms ease;",
        ]),
        c1 = [
          {
            constant: !1,
            inputs: [
              { name: "_salt", type: "bytes32" },
              { name: "_initializer", type: "bytes" },
            ],
            name: "deployAccount",
            outputs: [{ name: "", type: "bool" }],
            payable: !1,
            stateMutability: "nonpayable",
            type: "function",
          },
        ],
        c2 = [
          { name: "from", type: "address" },
          { name: "param2", type: "address" },
          { name: "param3", type: "bytes" },
          { name: "param4", type: "tuple", components: [] },
          {
            type: "tuple",
            components: [
              { name: "param5", type: "address" },
              { name: "param6", type: "uint256" },
              { name: "param7", type: "uint256" },
              { name: "encodedInitData", type: "bytes" },
            ],
          },
        ],
        c3 = [
          {
            constant: !1,
            inputs: [
              { name: "spender", type: "address" },
              { name: "value", type: "uint256" },
            ],
            name: "approve",
            outputs: [{ name: "", type: "bool" }],
            payable: !1,
            stateMutability: "nonpayable",
            type: "function",
          },
        ],
        c4 = [
          {
            constant: !1,
            inputs: [
              { name: "_to", type: "address" },
              { name: "_value", type: "uint256" },
            ],
            name: "transfer",
            outputs: [{ name: "", type: "bool" }],
            payable: !1,
            stateMutability: "nonpayable",
            type: "function",
          },
        ],
        c5 = [
          {
            inputs: [
              { internalType: "address", name: "to", type: "address" },
              { internalType: "uint256", name: "amount", type: "uint256" },
            ],
            name: "mint",
            outputs: [],
            stateMutability: "nonpayable",
            type: "function",
          },
          {
            inputs: [
              { internalType: "address", name: "to", type: "address" },
              { internalType: "uint256", name: "amount", type: "uint256" },
            ],
            name: "mint",
            outputs: [],
            stateMutability: "payable",
            type: "function",
          },
          {
            inputs: [{ internalType: "address", name: "to", type: "address" }],
            name: "mint",
            outputs: [],
            stateMutability: "nonpayable",
            type: "function",
          },
          {
            inputs: [{ internalType: "address", name: "to", type: "address" }],
            name: "mint",
            outputs: [],
            stateMutability: "payable",
            type: "function",
          },
          {
            inputs: [
              { internalType: "address", name: "to", type: "address" },
              { internalType: "uint256", name: "tokenId", type: "uint256" },
              { internalType: "uint256", name: "quantity", type: "uint256" },
              { internalType: "bytes", name: "data", type: "bytes" },
            ],
            name: "mint",
            outputs: [{ internalType: "bool", name: "", type: "bool" }],
            stateMutability: "nonpayable",
            type: "function",
          },
          {
            inputs: [
              { internalType: "address", name: "to", type: "address" },
              { internalType: "uint256", name: "tokenId", type: "uint256" },
              { internalType: "uint256", name: "quantity", type: "uint256" },
              { internalType: "bytes", name: "data", type: "bytes" },
            ],
            name: "mint",
            outputs: [{ internalType: "bool", name: "", type: "bool" }],
            stateMutability: "payable",
            type: "function",
          },
          {
            inputs: [
              { internalType: "address", name: "to", type: "address" },
              {
                internalType: "uint256[]",
                name: "tokenIds",
                type: "uint256[]",
              },
              {
                internalType: "uint256[]",
                name: "quantities",
                type: "uint256[]",
              },
              { internalType: "bytes", name: "data", type: "bytes" },
            ],
            name: "mintBatch",
            outputs: [{ internalType: "bool", name: "", type: "bool" }],
            stateMutability: "nonpayable",
            type: "function",
          },
          {
            inputs: [
              { internalType: "address", name: "to", type: "address" },
              {
                internalType: "uint256[]",
                name: "tokenIds",
                type: "uint256[]",
              },
              {
                internalType: "uint256[]",
                name: "quantities",
                type: "uint256[]",
              },
              { internalType: "bytes", name: "data", type: "bytes" },
            ],
            name: "mintBatch",
            outputs: [{ internalType: "bool", name: "", type: "bool" }],
            stateMutability: "payable",
            type: "function",
          },
          {
            inputs: [
              { internalType: "uint256", name: "quantity", type: "uint256" },
            ],
            name: "mint",
            outputs: [{ internalType: "bool", name: "", type: "bool" }],
            stateMutability: "nonpayable",
            type: "function",
          },
          {
            inputs: [
              { internalType: "uint256", name: "quantity", type: "uint256" },
            ],
            name: "mint",
            outputs: [{ internalType: "bool", name: "", type: "bool" }],
            stateMutability: "payable",
            type: "function",
          },
          {
            inputs: [{ internalType: "address", name: "to", type: "address" }],
            name: "safeMint",
            outputs: [],
            stateMutability: "nonpayable",
            type: "function",
          },
          {
            inputs: [{ internalType: "address", name: "to", type: "address" }],
            name: "safeMint",
            outputs: [],
            stateMutability: "payable",
            type: "function",
          },
          {
            inputs: [
              { internalType: "address", name: "to", type: "address" },
              { internalType: "string", name: "uri", type: "string" },
            ],
            name: "safeMint",
            outputs: [],
            stateMutability: "nonpayable",
            type: "function",
          },
          {
            inputs: [
              { internalType: "address", name: "to", type: "address" },
              { internalType: "string", name: "uri", type: "string" },
            ],
            name: "safeMint",
            outputs: [],
            stateMutability: "payable",
            type: "function",
          },
          {
            inputs: [
              { internalType: "address", name: "to", type: "address" },
              { internalType: "uint256", name: "tokenId", type: "uint256" },
            ],
            name: "safeMint",
            outputs: [],
            stateMutability: "nonpayable",
            type: "function",
          },
          {
            inputs: [
              { internalType: "address", name: "to", type: "address" },
              { internalType: "uint256", name: "tokenId", type: "uint256" },
            ],
            name: "safeMint",
            outputs: [],
            stateMutability: "payable",
            type: "function",
          },
          {
            inputs: [
              { internalType: "address", name: "to", type: "address" },
              { internalType: "uint256", name: "tokenId", type: "uint256" },
              { internalType: "string", name: "uri", type: "string" },
            ],
            name: "safeMint",
            outputs: [],
            stateMutability: "nonpayable",
            type: "function",
          },
          {
            inputs: [
              { internalType: "address", name: "to", type: "address" },
              { internalType: "uint256", name: "tokenId", type: "uint256" },
              { internalType: "string", name: "uri", type: "string" },
            ],
            name: "safeMint",
            outputs: [],
            stateMutability: "payable",
            type: "function",
          },
          {
            inputs: [
              { internalType: "address", name: "to", type: "address" },
              { internalType: "uint256", name: "amount", type: "uint256" },
            ],
            name: "batchMint",
            outputs: [],
            stateMutability: "nonpayable",
            type: "function",
          },
          {
            inputs: [
              { internalType: "address", name: "to", type: "address" },
              { internalType: "uint256", name: "amount", type: "uint256" },
            ],
            name: "batchMint",
            outputs: [],
            stateMutability: "payable",
            type: "function",
          },
        ],
        c6 = [
          {
            constant: !1,
            inputs: [
              { name: "_from", type: "address" },
              { name: "_to", type: "address" },
              { name: "_tokenId", type: "uint256" },
            ],
            name: "safeTransferFrom",
            outputs: [{ name: "", type: "bool" }],
            payable: !1,
            stateMutability: "nonpayable",
            type: "function",
          },
        ],
        c8 = [
          {
            constant: !1,
            inputs: [
              { name: "_operator", type: "address" },
              { name: "_approved", type: "bool" },
            ],
            name: "setApprovalForAll",
            outputs: [{ name: "", type: "bool" }],
            payable: !1,
            stateMutability: "nonpayable",
            type: "function",
          },
        ],
        c7 = [
          {
            constant: !1,
            inputs: [
              { name: "_from", type: "address" },
              { name: "_to", type: "address" },
              { name: "_tokenId", type: "uint256" },
            ],
            name: "transferFrom",
            outputs: [{ name: "", type: "bool" }],
            payable: !1,
            stateMutability: "nonpayable",
            type: "function",
          },
        ],
        c9 = [
          {
            constant: !1,
            inputs: [
              { name: "_from", type: "address" },
              { name: "_to", type: "address" },
              { name: "_tokenIds", type: "uint256[]" },
              { name: "_amounts", type: "uint256[]" },
              { name: "_data", type: "bytes" },
            ],
            name: "safeBatchTransferFrom",
            outputs: [{ name: "", type: "bool" }],
            payable: !1,
            stateMutability: "nonpayable",
            type: "function",
          },
        ],
        de = [
          {
            constant: !1,
            inputs: [
              { name: "_from", type: "address" },
              { name: "_to", type: "address" },
              { name: "_tokenId", type: "uint256" },
              { name: "_amount", type: "uint256" },
              { name: "_data", type: "bytes" },
            ],
            name: "safeTransferFrom",
            outputs: [{ name: "", type: "bool" }],
            payable: !1,
            stateMutability: "nonpayable",
            type: "function",
          },
        ],
        dt = (e, t) => {
          let n = dn(c3, e);
          if (n)
            return {
              action: "approve",
              functionName: "approve",
              isErc20Ish: !0,
              isNFTIsh: !1,
              spender: n.args[0],
              amount: n.args[1],
            };
          let a = dn(c4, e);
          if (a)
            return {
              action: "transfer",
              functionName: "transfer",
              isErc20Ish: !0,
              isNFTIsh: !1,
              transferTo: a.args[0],
              amount: a.args[1],
            };
          if (!t)
            return {
              action: "transaction",
              functionName: "",
              isErc20Ish: !1,
              isNFTIsh: !1,
            };
          let r = dn(c1, e);
          if (r && "string" == typeof r.args[1]) {
            let e = da(r.args[1]);
            if (e && e[4].encodedInitData) return dt(e[4].encodedInitData, t);
          }
          let i = dn(c8, e);
          if (i)
            return {
              action: "approve",
              functionName: "setApprovalForAll",
              isNFTIsh: !0,
              isErc20Ish: !1,
              operator: i.args[0],
              approved: i.args[1],
            };
          let o = dn(c7, e);
          if (o)
            return {
              action: "transfer",
              functionName: "transferFrom",
              isNFTIsh: !0,
              isErc20Ish: !1,
              transferFrom: o.args[0],
              transferTo: o.args[1],
              tokenId: o.args[2],
            };
          let s = dn(c6, e);
          if (s)
            return {
              action: "transfer",
              functionName: "safeTransferFrom",
              isNFTIsh: !0,
              isErc20Ish: !1,
              transferFrom: s.args[0],
              transferTo: s.args[1],
              tokenId: s.args[2],
            };
          let l = dn(de, e);
          if (l)
            return {
              action: "transfer",
              functionName: "safeTransferFrom",
              isNFTIsh: !0,
              isErc20Ish: !1,
              transferFrom: l.args[0],
              transferTo: l.args[1],
              tokenId: l.args[2],
              amount: l.args[3],
            };
          let c = dn(c9, e);
          if (c)
            return {
              action: "batch transfer",
              functionName: "safeBatchTransferFrom",
              isNFTIsh: !0,
              isErc20Ish: !1,
              transferFrom: c.args[0],
              transferTo: c.args[1],
              tokenIds: c.args[2],
              amounts: c.args[3],
            };
          let d = dn(c5, e);
          return d
            ? {
                action: "mint",
                functionName: d.functionName,
                isNFTIsh: !0,
                isErc20Ish: !1,
                args: d.args,
              }
            : { action: "transaction", isErc20Ish: !1, isNFTIsh: !1 };
        },
        dn = (e, t) => {
          try {
            let n = (0, P.p)({ abi: e, data: t });
            return { functionName: n.functionName, args: n.args || [] };
          } catch (e) {
            return null;
          }
        },
        da = (e) => {
          try {
            if ("string" == typeof e) return (0, D.r)(c2, `0x${e.slice(10)}`);
          } catch (e) {
            return null;
          }
        },
        dr = (e) => `${parseFloat(e).toFixed(2)}`,
        di = (e, t, n, a) => {
          let [r, i] = (0, C.useState)(null),
            { walletProxy: o } = (0, j.u)();
          return (
            (0, C.useEffect)(() => {
              r && i(null),
                (async () => {
                  if (!o || !t) return null;
                  let r = [],
                    i = !0,
                    s = await iS(e, n, t, a).catch(
                      (t) => (
                        (t.message &&
                          t.message.includes(
                            "Insufficient balance for transaction"
                          )) ||
                        (t.details && t.details.includes("insufficient funds"))
                          ? (i = !1)
                          : r.push(t),
                        e
                      )
                    );
                  return {
                    tx: s,
                    totalGasEstimate: s.gas,
                    hasFunds: i,
                    errors: r,
                  };
                })().then(i);
            }, [e]),
            r
          );
        },
        ds = new nA(
          new nT(
            "There was an issue preparing your transaction",
            V.M_.E32603_DEFAULT_INTERNAL_ERROR.eipCode
          )
        ),
        dl = (e, t) =>
          e?.sendTransaction
            ? "transactionRequest" in e.sendTransaction
              ? e.sendTransaction.transactionRequest
              : e.sendTransaction.transactionRequests[t]
            : void 0,
        dc = {
          component: () => {
            let {
                data: e,
                onUserCloseViaDialogOrKeybindRef: t,
                setModalData: n,
                navigate: r,
              } = ap(),
              {
                client: i,
                rpcConfig: o,
                chains: s,
                closePrivyModal: l,
                walletProxy: c,
                showFiatPrices: d,
              } = (0, j.u)(),
              { user: u } = (0, k.u)(),
              p = ar(),
              [h, g] = (0, C.useState)(0),
              [f, m] = (0, C.useState)(0),
              [y, w] = (0, C.useState)(dl(e, h)),
              [v, x] = (0, C.useState)(null),
              [b, T] = (0, C.useState)(),
              [A, S] = (0, C.useState)(!1),
              [_, M] = (0, C.useState)(null),
              [F, z] = (0, C.useState)(null),
              [L, P] = (0, C.useState)(null),
              [D, W] = (0, C.useState)(void 0),
              [R, B] = (0, C.useState)(void 0),
              [U, O] = (0, C.useState)(!1),
              [H, $] = (0, C.useState)(!1),
              [Z, q] = (0, C.useState)([]),
              [G, Y] = (0, C.useState)([]),
              [Q, J] = (0, C.useState)("uninitiated"),
              [ee, et] = (0, C.useState)(void 0);
            if (!y || !e?.sendTransaction || !e?.sendTransaction)
              return (0, a.jsx)(sh, {
                error: Error("Invalid transaction request"),
                allowlistConfig: p.allowlistConfig,
                onRetry: () => {
                  e?.sendTransaction?.onFailure(ds),
                    l({ shouldCallAuthOnSuccess: !1 });
                },
              });
            let { transactingWalletAddress: en } = e.sendTransaction,
              ea = (0, C.useMemo)(
                () => s.find((e) => Number(e.id) === Number(y.chainId)),
                [y.chainId]
              ),
              er = ea?.nativeCurrency.symbol ?? "ETH",
              ei = (0, C.useMemo)(
                () => dt(y.data, !!p.embeddedWallets.extendedCalldataDecoding),
                [y.data]
              ),
              {
                action: eo,
                isErc20Ish: es,
                isNFTIsh: el,
                functionName: ec,
              } = ei,
              { toAddress: ed, tokenAddress: eu } = (0, C.useMemo)(
                () => ({
                  toAddress: ei.isErc20Ish ? ei.transferTo : y.to ?? void 0,
                  tokenAddress: ei.isErc20Ish ? y.to : void 0,
                }),
                [ei]
              );
            (0, C.useEffect)(() => {
              y.to &&
                ea &&
                es &&
                l8({
                  address: y.to,
                  chain: ea,
                  rpcConfig: p.rpcConfig,
                  privyAppId: p.id,
                })
                  .then(x)
                  .catch(console.error);
            }, [y.to, ea]);
            let { tokenPrice: ep, isTokenPriceLoading: eh } = ik(y.chainId),
              { balance: eg } = lK({
                rpcConfig: p.rpcConfig,
                appId: p.id,
                address: en,
                chain: ea,
              }),
              ef = (function ({
                rpcConfig: e,
                appId: t,
                address: n,
                chain: a,
                tokenInfo: r,
              }) {
                let { chains: i } = (0, j.u)(),
                  [o, s] = (0, C.useState)(null),
                  [l, c] = (0, C.useState)(!1),
                  d = (0, C.useMemo)(() => {
                    let n = a || i[0];
                    if (n)
                      return (0, I.v)({
                        chain: a,
                        transport: (0, E.d)((0, X.MQ)(n, e, t)),
                      });
                  }, [a, e, t]),
                  u = (0, C.useCallback)(async () => {
                    if (n && d && r.address)
                      try {
                        return (
                          c(!0),
                          await d.readContract({
                            address: r.address,
                            abi: l6,
                            functionName: "balanceOf",
                            args: [n],
                          })
                        );
                      } catch (e) {
                        console.error(e);
                      } finally {
                        c(!1);
                      }
                  }, [d, n, r?.address, a]);
                return (
                  (0, C.useEffect)(() => {
                    u().then((e) => null != e && s(e));
                  }, [u]),
                  {
                    balance: o,
                    isLoading: l && null == o,
                    formattedBalance: (0, K.LH)({
                      amount: o ?? BigInt(0),
                      decimals: r.decimals,
                    }),
                  }
                );
              })({
                rpcConfig: p.rpcConfig,
                appId: p.id,
                address: en,
                tokenInfo: { address: eu || "", decimals: v?.decimals ?? 18 },
                chain: ea,
              }),
              em = (0, C.useMemo)(
                () => t6(Number(y.chainId), s, o, { appId: p.id }),
                [y.chainId, o]
              ),
              ey = di(y, en, em, e?.sendTransaction?.prepareTransactionRequest);
            (0, C.useEffect)(() => {
              w(dl(e, h));
            }, [h]),
              (0, C.useEffect)(() => {
                e.sendTransaction?.getIsSponsored
                  ? e.sendTransaction
                      .getIsSponsored()
                      .then(T)
                      .catch(console.error)
                  : T(!1);
              }, [e.sendTransaction.getIsSponsored]);
            let ew = () => {
              if (!A)
                return (
                  _
                    ? e?.sendTransaction?.onSuccess({ hash: _ })
                    : L || ey?.errors[0]
                    ? e?.sendTransaction?.onFailure(L ?? ey?.errors[0] ?? ds)
                    : e?.sendTransaction?.onFailure(
                        new nA(
                          new nT(
                            "The user rejected the request",
                            V.M_.E4001_USER_REJECTED_REQUEST.eipCode
                          )
                        )
                      ),
                  l({ shouldCallAuthOnSuccess: !1 })
                );
            };
            t.current = ew;
            let ev = !!(e.funding && e.funding.supportedOptions.length > 0),
              ex = rL(BigInt(ey?.totalGasEstimate ?? 0n), er),
              eb =
                d && ep ? rz(BigInt(ey?.totalGasEstimate ?? 0n), ep) : void 0,
              eC = rL(eg ?? 0n, er, void 0, !0),
              ej = d && ep ? rz(eg ?? 0n, ep) : void 0,
              ek =
                v && !ef.isLoading && es && "approve" !== eo
                  ? `${ef.formattedBalance} ${v.symbol}`
                  : void 0,
              eT = e.sendTransaction?.uiOptions?.transactionInfo?.title;
            eT ||
              (eT =
                "approve" === eo
                  ? es
                    ? "Confirm address"
                    : "Confirm action"
                  : `Approve ${eo}`);
            let eA = (0, C.useMemo)(() => {
                if (e.sendTransaction?.uiOptions?.description)
                  return e.sendTransaction?.uiOptions?.description;
                if (
                  "approve" === eo &&
                  "setApprovalForAll" === ec &&
                  ei.approved
                ) {
                  let e = (0, a.jsx)(o7, {
                    address: ei.operator || "",
                    url: ea?.blockExplorers?.default?.url,
                  });
                  return (0, a.jsxs)(a.Fragment, {
                    children: [
                      p.name,
                      " would like your permission for ",
                      e,
                      " to transfer tokens on your behalf.",
                    ],
                  });
                }
                if (
                  "approve" === eo &&
                  "setApprovalForAll" === ec &&
                  !ei.approved
                ) {
                  let e = (0, a.jsx)(o7, {
                    address: ei.operator || "",
                    url: ea?.blockExplorers?.default?.url,
                  });
                  return (0, a.jsxs)(a.Fragment, {
                    children: [
                      p.name,
                      " would like your permission to revoke permissions of ",
                      e,
                      " from transferring tokens on your behalf.",
                    ],
                  });
                }
                return (es && "approve" === eo) || (es && "approve" === eo)
                  ? `${p.name} would like your permission for ${t9(
                      ei.spender
                    )} to spend tokens on your behalf.`
                  : `${p.name} wants your permission to approve the following transaction.`;
              }, [
                p.name,
                es,
                ei,
                e.sendTransaction?.uiOptions.description,
                ec,
              ]),
              eS = e.sendTransaction?.uiOptions?.transactionInfo?.contractInfo
                ?.imgUrl
                ? (0, a.jsx)("img", {
                    src: e.sendTransaction.uiOptions.transactionInfo
                      .contractInfo.imgUrl,
                    alt: e.sendTransaction.uiOptions.transactionInfo
                      .contractInfo.imgAltText,
                  })
                : null,
              eI = !(!ey || ey.errors[0] || ey.hasFunds || !1 !== b),
              eE = eI && ev,
              eN = eE
                ? "Add funds"
                : e.sendTransaction?.uiOptions?.buttonText ||
                  (h < f ? "Continue" : "Approve"),
              e_ = (e) => {
                if (!e) throw Error("Transaction scan failed");
                if (
                  ("Success" === e.validation.status &&
                    ("Benign" === e.validation.result_type
                      ? B("safe")
                      : "Warning" === e.validation.result_type
                      ? B("warn")
                      : "Malicious" === e.validation.result_type &&
                        (B("error"), $(!0))),
                  "Success" !== e.simulation.status)
                )
                  throw Error("Simulation failed");
                {
                  W(e.simulation.params);
                  let { assetsIn: t, assetsOut: n } = (function (e, t) {
                    let n = [],
                      a = new Map();
                    if (e) {
                      for (let t of e)
                        if (t.in[0]) {
                          let e;
                          (e =
                            "ERC721" === t.asset.type ||
                            "approve_for_all" === t.in[0].value
                              ? {
                                  id: `nft:${t.asset.name}`,
                                  nftName: t.asset.name,
                                  nftCount: t.in.length,
                                }
                              : {
                                  id: `token:${t.asset.type}:${t.asset.symbol}:${t.asset.name}`,
                                  iconUrl: t.asset.logo_url,
                                  value: t.in[0].value,
                                  symbol: t.asset.symbol,
                                  usdValue: t.in[0].usd_price
                                    ? dr(t.in[0].usd_price)
                                    : void 0,
                                  decimals: t.asset.decimals,
                                }),
                            n.push(e);
                        } else if (t.out[0]?.value) {
                          let e;
                          (e =
                            "ERC721" === t.asset.type ||
                            "approve_for_all" === t.out[0].value
                              ? {
                                  id: `nft:${t.asset.name}`,
                                  nftName: t.asset.name,
                                }
                              : {
                                  id: `token:${t.asset.type}:${t.asset.symbol}:${t.asset.name}`,
                                  iconUrl: t.asset.logo_url,
                                  value: t.out[0].value,
                                  symbol: t.asset.symbol,
                                  usdValue: t.out[0].usd_price
                                    ? dr(t.out[0].usd_price)
                                    : void 0,
                                  decimals: t.asset.decimals,
                                }),
                            a.has(e.id) || a.set(e.id, e);
                        }
                    }
                    for (let e of t)
                      for (let t of Object.keys(e.spenders)) {
                        let n;
                        (n =
                          "ERC721" === e.asset.type ||
                          "approve_for_all" === e.spenders[t]?.value
                            ? {
                                id: `nft:${e.asset.name}`,
                                nftName: e.asset.name,
                              }
                            : {
                                id: `token:${e.asset.type}:${e.asset.symbol}:${e.asset.name}`,
                                iconUrl: e.asset.logo_url,
                                value: e.spenders[t]?.value,
                                symbol: e.asset.symbol,
                                usdValue: e.spenders[t]?.usd_price
                                  ? dr(e.spenders[t]?.usd_price)
                                  : void 0,
                                decimals: e.asset.decimals,
                              }),
                          a.has(n.id) || a.set(n.id, n);
                      }
                    return { assetsIn: n, assetsOut: Array.from(a.values()) };
                  })(e.simulation.assets_diffs, e.simulation.exposures);
                  if (0 === n.length && 0 === t.length)
                    throw Error("No tokens found");
                  q(n), Y(t);
                }
              };
            if (
              ((0, C.useEffect)(() => {
                e.sendTransaction?.scanTransaction &&
                  p.embeddedWallets.transactionScanning.enabled &&
                  "uninitiated" === Q &&
                  (J("in progress"),
                  e.sendTransaction
                    .scanTransaction()
                    .then((e) => {
                      e_(e), J("completed");
                    })
                    .catch(() => J("failed")));
              }, [!!e.sendTransaction?.scanTransaction]),
              (0, C.useEffect)(() => {
                (e.sendTransaction?.scanTransaction && "failed" !== Q) ||
                  ((t, n, a) => {
                    if (
                      (m(
                        e?.sendTransaction
                          ? "transactionRequest" in e.sendTransaction
                            ? 0
                            : e.sendTransaction.transactionRequests.length - 1
                          : 0
                      ),
                      n.isErc20Ish && n.amount && a)
                    ) {
                      let e = ce({ amount: n.amount, decimals: a.decimals });
                      et(e),
                        q([
                          {
                            value: e,
                            symbol: a?.symbol,
                            decimals: a?.decimals,
                          },
                        ]);
                    } else if (t.value) {
                      let e = BigInt(t.value),
                        n = ep ? rz(e, ep) : void 0;
                      q(
                        d && n
                          ? [{ value: n }]
                          : [
                              {
                                value: rP(e),
                                symbol: er,
                                decimals: 18,
                                usdValue: n,
                              },
                            ]
                      );
                    } else
                      q(
                        d
                          ? [{ value: "$0" }]
                          : [{ value: "0", symbol: er, decimals: 18 }]
                      );
                  })(ey?.tx ?? y, ei, v);
              }, [y, ey?.tx, ei, v, Q]),
              F)
            )
              return (0, a.jsx)(cJ, {
                txn: ey?.tx ?? y,
                onClose: ew,
                receipt: F,
                transactionInfo: e.sendTransaction?.uiOptions.transactionInfo,
                tokenPrice: ep,
                tokenSymbol: er,
                receiptHeader: e.sendTransaction?.uiOptions.successHeader,
                receiptDescription:
                  e.sendTransaction?.uiOptions.successDescription,
              });
            if (L)
              return (0, a.jsx)(cD, {
                transactionError: L,
                transactionHash: _ ?? void 0,
                chainType: "ethereum",
                chainId: ey?.tx.chainId ?? y.chainId,
                onClose: ew,
                onRetry: ({ resetNonce: e }) => {
                  P(null);
                  let t = { ...(ey?.tx ?? y) };
                  e && (t.nonce = void 0), w(t);
                },
              });
            let eM =
              0 !== f && "number" == typeof h && 0 !== h
                ? () => {
                    g(h - 1);
                  }
                : void 0;
            return U && D
              ? (0, a.jsx)(co, { details: D, onBack: () => O(!1) })
              : (0, a.jsx)(cN, {
                  transactionIndex: h,
                  onBack: eM,
                  maxIndex: f,
                  disabled: (eI && !ev) || H,
                  isSubmitting: A,
                  submitError: L,
                  isPreparing: !ey,
                  isTokenPriceLoading: eh,
                  isTokenContractInfoLoading: !el && !v,
                  prepareError: ey?.errors[0],
                  symbol: v?.symbol,
                  chain: ea,
                  img: eS,
                  title: eT,
                  subtitle: eA,
                  txValue: y.value,
                  fee: eb ?? ex,
                  isSponsored: b,
                  from: en ?? "",
                  to: ed,
                  tokenAddress: eu ?? void 0,
                  network: p.chains.find((e) => e.id === y.chainId)?.name ?? "",
                  transactionDetails: { ...ei, formattedAmount: ee },
                  cta: eN,
                  missingFunds: eI,
                  action: eo,
                  balance: ek ?? ej ?? eC,
                  onClose: ew,
                  onClick: eE
                    ? async () => {
                        if (en) {
                          if (!ev) throw Error("Funding wallet is not enabled");
                          n({
                            ...e,
                            funding: {
                              ...e.funding,
                              methodScreen: uI,
                              chainType: "ethereum",
                              amount: (0, N.d)(
                                BigInt(ey?.tx.value ?? 0) +
                                  BigInt(ey?.totalGasEstimate?.toString() ?? 0)
                              ),
                              chain: ea,
                            },
                            solanaFundingData: e?.solanaFundingData,
                          }),
                            r(uI);
                        }
                      }
                    : async () => {
                        if (h < f) g(h + 1);
                        else {
                          S(!0);
                          try {
                            let t = await i.getAccessToken();
                            if (A || !t || !c || !u) return;
                            let n = await e.sendTransaction.onConfirm({
                              transactionRequest: ey?.tx ?? y,
                            });
                            if ((M(n), e.sendTransaction?.signOnly))
                              return (
                                await new Promise((e) => setTimeout(e, th)),
                                e?.sendTransaction?.onSuccess({ hash: n }),
                                l({ shouldCallAuthOnSuccess: !1 })
                              );
                            let a = await em.waitForTransactionReceipt({
                              hash: n,
                            });
                            if ("reverted" === a.status)
                              throw Error("Transaction failed");
                            z(a);
                          } catch (e) {
                            console.warn({
                              transaction: ey?.tx ?? y,
                              error: e,
                            }),
                              P(e);
                          } finally {
                            S(!1);
                          }
                        }
                      },
                  validation: R,
                  hasScanDetails: !!D,
                  setIsScanDetailsOpen: O,
                  preventMaliciousTransaction: H,
                  setPreventMaliciousTransaction: $,
                  tokensSent: Z,
                  tokensReceived: G,
                  isScanning: "in progress" === Q,
                  isCancellable:
                    e.sendTransaction?.uiOptions?.isCancellable ?? !1,
                  functionName: ec,
                });
          },
        };
      function dd({ title: e }) {
        let {
          currentScreen: t,
          navigateBack: n,
          navigate: r,
          data: i,
          setModalData: o,
        } = ap();
        return (0, a.jsx)(a4, {
          title: e,
          backFn:
            t === l4
              ? n
              : t === i?.funding?.methodScreen
              ? i.funding.comingFromSendTransactionScreen
                ? () => r(dc)
                : void 0
              : i?.funding?.methodScreen
              ? () => {
                  let e = i.funding;
                  e.usingDefaultFundingMethod &&
                    (e.usingDefaultFundingMethod = !1),
                    o({ funding: e, solanaFundingData: i?.solanaFundingData }),
                    r(e.methodScreen);
                }
              : void 0,
        });
      }
      let du = (e) =>
          (0, a.jsx)("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 512 210.2",
            xmlSpace: "preserve",
            ...e,
            children: (0, a.jsx)("path", {
              d: "M93.6,27.1C87.6,34.2,78,39.8,68.4,39c-1.2-9.6,3.5-19.8,9-26.1c6-7.3,16.5-12.5,25-12.9  C103.4,10,99.5,19.8,93.6,27.1 M102.3,40.9c-13.9-0.8-25.8,7.9-32.4,7.9c-6.7,0-16.8-7.5-27.8-7.3c-14.3,0.2-27.6,8.3-34.9,21.2  c-15,25.8-3.9,64,10.6,85c7.1,10.4,15.6,21.8,26.8,21.4c10.6-0.4,14.8-6.9,27.6-6.9c12.9,0,16.6,6.9,27.8,6.7  c11.6-0.2,18.9-10.4,26-20.8c8.1-11.8,11.4-23.3,11.6-23.9c-0.2-0.2-22.4-8.7-22.6-34.3c-0.2-21.4,17.5-31.6,18.3-32.2  C123.3,42.9,107.7,41.3,102.3,40.9 M182.6,11.9v155.9h24.2v-53.3h33.5c30.6,0,52.1-21,52.1-51.4c0-30.4-21.1-51.2-51.3-51.2H182.6z   M206.8,32.3h27.9c21,0,33,11.2,33,30.9c0,19.7-12,31-33.1,31h-27.8V32.3z M336.6,169c15.2,0,29.3-7.7,35.7-19.9h0.5v18.7h22.4V90.2  c0-22.5-18-37-45.7-37c-25.7,0-44.7,14.7-45.4,34.9h21.8c1.8-9.6,10.7-15.9,22.9-15.9c14.8,0,23.1,6.9,23.1,19.6v8.6l-30.2,1.8  c-28.1,1.7-43.3,13.2-43.3,33.2C298.4,155.6,314.1,169,336.6,169z M343.1,150.5c-12.9,0-21.1-6.2-21.1-15.7c0-9.8,7.9-15.5,23-16.4  l26.9-1.7v8.8C371.9,140.1,359.5,150.5,343.1,150.5z M425.1,210.2c23.6,0,34.7-9,44.4-36.3L512,54.7h-24.6l-28.5,92.1h-0.5  l-28.5-92.1h-25.3l41,113.5l-2.2,6.9c-3.7,11.7-9.7,16.2-20.4,16.2c-1.9,0-5.6-0.2-7.1-0.4v18.7C417.3,210,423.3,210.2,425.1,210.2z",
            }),
          }),
        dp = (e) =>
          (0, a.jsxs)("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 80 38.1",
            xmlSpace: "preserve",
            ...e,
            children: [
              (0, a.jsx)("path", {
                style: { fill: "#5F6368" },
                d: "M37.8,19.7V29h-3V6h7.8c1.9,0,3.7,0.7,5.1,2c1.4,1.2,2.1,3,2.1,4.9c0,1.9-0.7,3.6-2.1,4.9c-1.4,1.3-3.1,2-5.1,2  L37.8,19.7L37.8,19.7z M37.8,8.8v8h5c1.1,0,2.2-0.4,2.9-1.2c1.6-1.5,1.6-4,0.1-5.5c0,0-0.1-0.1-0.1-0.1c-0.8-0.8-1.8-1.3-2.9-1.2  L37.8,8.8L37.8,8.8z",
              }),
              (0, a.jsx)("path", {
                style: { fill: "#5F6368" },
                d: "M56.7,12.8c2.2,0,3.9,0.6,5.2,1.8s1.9,2.8,1.9,4.8V29H61v-2.2h-0.1c-1.2,1.8-2.9,2.7-4.9,2.7  c-1.7,0-3.2-0.5-4.4-1.5c-1.1-1-1.8-2.4-1.8-3.9c0-1.6,0.6-2.9,1.8-3.9c1.2-1,2.9-1.4,4.9-1.4c1.8,0,3.2,0.3,4.3,1v-0.7  c0-1-0.4-2-1.2-2.6c-0.8-0.7-1.8-1.1-2.9-1.1c-1.7,0-3,0.7-3.9,2.1l-2.6-1.6C51.8,13.8,53.9,12.8,56.7,12.8z M52.9,24.2  c0,0.8,0.4,1.5,1,1.9c0.7,0.5,1.5,0.8,2.3,0.8c1.2,0,2.4-0.5,3.3-1.4c1-0.9,1.5-2,1.5-3.2c-0.9-0.7-2.2-1.1-3.9-1.1  c-1.2,0-2.2,0.3-3,0.9C53.3,22.6,52.9,23.3,52.9,24.2z",
              }),
              (0, a.jsx)("path", {
                style: { fill: "#5F6368" },
                d: "M80,13.3l-9.9,22.7h-3l3.7-7.9l-6.5-14.7h3.2l4.7,11.3h0.1l4.6-11.3H80z",
              }),
              (0, a.jsx)("path", {
                style: { fill: "#4285F4" },
                d: "M25.9,17.7c0-0.9-0.1-1.8-0.2-2.7H13.2v5.1h7.1c-0.3,1.6-1.2,3.1-2.6,4v3.3H22C24.5,25.1,25.9,21.7,25.9,17.7z",
              }),
              (0, a.jsx)("path", {
                style: { fill: "#34A853" },
                d: "M13.2,30.6c3.6,0,6.6-1.2,8.8-3.2l-4.3-3.3c-1.2,0.8-2.7,1.3-4.5,1.3c-3.4,0-6.4-2.3-7.4-5.5H1.4v3.4  C3.7,27.8,8.2,30.6,13.2,30.6z",
              }),
              (0, a.jsx)("path", {
                style: { fill: "#FBBC04" },
                d: "M5.8,19.9c-0.6-1.6-0.6-3.4,0-5.1v-3.4H1.4c-1.9,3.7-1.9,8.1,0,11.9L5.8,19.9z",
              }),
              (0, a.jsx)("path", {
                style: { fill: "#EA4335" },
                d: "M13.2,9.4c1.9,0,3.7,0.7,5.1,2l0,0l3.8-3.8c-2.4-2.2-5.6-3.5-8.8-3.4c-5,0-9.6,2.8-11.8,7.3l4.4,3.4  C6.8,11.7,9.8,9.4,13.2,9.4z",
              }),
            ],
          }),
        dh = (e) => {
          let [t, n] = (0, C.useState)();
          return (
            (0, C.useEffect)(() => {
              e()
                .then((e) => {
                  n(e);
                })
                .catch(() => {});
            }, []),
            t
          );
        },
        dg = ({ children: e, color: t, isLoading: n, isPulsing: r, ...i }) =>
          (0, a.jsx)(df, {
            $color: t,
            $isLoading: n,
            $isPulsing: r,
            ...i,
            children: e,
          }),
        df = T.zo.span.withConfig({
          displayName: "StyledSpan",
          componentId: "sc-80725f4-0",
        })(
          [
            "padding:0.25rem;font-size:0.75rem;font-weight:500;line-height:1rem;border-radius:var(--privy-border-radius-xs);display:flex;align-items:center;",
            " ",
            "",
          ],
          (e) => {
            let t, n;
            "green" === e.$color &&
              ((t = "var(--privy-color-success-dark)"),
              (n = "var(--privy-color-success-light)")),
              "red" === e.$color &&
                ((t = "var(--privy-color-error)"),
                (n = "var(--privy-color-error-light)")),
              "gray" === e.$color &&
                ((t = "var(--privy-color-foreground-2)"),
                (n = "var(--privy-color-background-2)"));
            let a = (0, T.F4)(
              [
                "from,to{background-color:",
                ";}50%{background-color:rgba(",
                ",0.8);}",
              ],
              n,
              n
            );
            return (0, T.iv)(
              ["color:", ";background-color:", ";", ";"],
              t,
              n,
              e.$isPulsing &&
                (0, T.iv)(["animation:", " 3s linear infinite;"], a)
            );
          },
          ch
        ),
        dm = ({ onClick: e, text: t }) =>
          (0, a.jsxs)(aT, {
            onClick: e,
            children: [
              (0, a.jsx)(aA, { children: (0, a.jsx)(f.Z, {}) }),
              (0, a.jsx)(av, { children: t }),
            ],
          }),
        dy = ({ chainType: e, withPadding: t }) => {
          let n = "";
          return (
            (n =
              "ethereum-only" === e || "ethereum-and-solana" === e
                ? "Rainbow, Phantom, or Coinbase Wallet"
                : "Phantom or Solflare"),
            (0, a.jsx)(
              aI,
              {
                $withPadding: t,
                children: (0, a.jsxs)(aE, {
                  children: [
                    (0, a.jsx)(ey.Z, {
                      style: {
                        color: "var(--privy-color-warn)",
                        height: 48,
                        width: 48,
                      },
                    }),
                    (0, a.jsx)("h3", { children: "No wallets available" }),
                    (0, a.jsxs)("p", {
                      children: [
                        "Please download an external wallet provider, like ",
                        n,
                        ".",
                      ],
                    }),
                  ],
                }),
              },
              "empty-wallet-state"
            )
          );
        },
        dw = ({ icon: e, name: t }) =>
          "string" == typeof e
            ? (0, a.jsx)("img", {
                alt: `${t || "wallet"} logo`,
                src: e,
                style: { height: 24, width: 24, borderRadius: 4 },
              })
            : void 0 === e
            ? (0, a.jsx)(ek.Z, { style: { height: 24, width: 24 } })
            : e
            ? (0, a.jsx)(e, {})
            : null;
      function dv(e) {
        let t = e.toLowerCase();
        return (
          !!window?.webkit?.messageHandlers?.ReactNativeWebView ||
          !!window?.ReactNativeWebView ||
          ["fbav", "fban", "instagram", "snapchat", "linkedinapp"].some((e) =>
            t.includes(e)
          )
        );
      }
      let dx = ({
          walletLogo: e,
          success: t,
          errorMessage: n,
          title: r,
          subtitle: i,
          onRetry: o,
          onUseDifferentWallet: s,
          onBack: l,
          numRetries: c,
          maxRetries: d,
        }) =>
          (0, a.jsx)(rS, {
            title: r,
            subtitle: i,
            icon: e,
            iconVariant: "loading",
            iconLoadingStatus: { success: t, fail: !!n },
            primaryCta:
              n === nS.ERROR_USER_EXISTS
                ? { label: "Use a different wallet", onClick: s }
                : !t && n?.retryable && c < d
                ? {
                    label: "Retry",
                    onClick: o,
                    disabled: !n?.retryable || c >= d,
                  }
                : !t && n && c >= d
                ? { label: "Use a different wallet", onClick: s }
                : void 0,
            onBack: l,
            watermark: !0,
          }),
        db = {
          component: () => {
            let e,
              {
                navigateBack: t,
                navigate: n,
                lastScreen: r,
                currentScreen: i,
                data: o,
                setModalData: s,
              } = ap(),
              { walletConnectionStatus: l, closePrivyModal: c } = (0, j.u)(),
              [d, u] = (0, C.useState)(void 0),
              [p, h] = (0, C.useState)(0),
              g = n0(l?.connector?.walletClientType || "unknown"),
              f = "connected" === l?.status,
              m = "switching_to_supported_chain" === l?.status;
            (0, C.useEffect)(() => {
              if (f) {
                let e;
                if (o?.externalConnectWallet?.onCompleteNavigateTo) {
                  let t = o.externalConnectWallet.onCompleteNavigateTo,
                    a = l.connectedWallet?.address;
                  e = setTimeout(() => {
                    o.funding &&
                      s({
                        ...o,
                        funding: { ...o.funding, connectedWalletAddress: a },
                      }),
                      n(
                        t({
                          address: a,
                          walletClientType: l.connector?.walletClientType,
                          walletChainType: l.connector?.chainType,
                        })
                      );
                  }, th);
                } else e = setTimeout(c, th);
                return () => clearTimeout(e);
              }
            }, [f]),
              (0, C.useEffect)(() => {
                l?.connectError && u(lN(l?.connectError));
              }, [l]);
            let y = l?.connector?.connectorType || "injected",
              w = l?.connector?.walletClientType || "unknown",
              v =
                g?.metadata?.shortName ||
                g?.name ||
                l?.connector?.walletBranding.name ||
                "Browser Extension",
              x =
                g?.image_url?.md ||
                l?.connector?.walletBranding.icon ||
                ((e) => (0, a.jsx)(nD, { ...e })),
              b = "Browser Extension" === v ? v.toLowerCase() : v;
            e = f
              ? `Successfully connected with ${b}`
              : d
              ? d.message
              : m
              ? "Switching networks"
              : `Waiting for ${b}`;
            let k = "Don’t see your wallet? Check your other browser windows.";
            return (
              f
                ? (k = "You’re good to go!")
                : p >= 2 && d
                ? (k = "Unable to connect wallet")
                : d
                ? (k = d.detail)
                : m
                ? (k = "Switch your wallet to the requested network.")
                : "metamask" === w && eC.tq
                ? (k = "Click to continue to open and connect MetaMask.")
                : "metamask" === w
                ? (k =
                    "For the best experience, connect only one wallet at a time.")
                : "wallet_connect_v2" === y
                ? (k = "Open your mobile wallet app to continue")
                : "coinbase_wallet" === y &&
                  (k = "Confirm in the Coinbase app/popup to continue."),
              (0, a.jsx)(dx, {
                walletName: v,
                walletLogo: x,
                success: f,
                errorMessage: d,
                title: e,
                subtitle: k,
                onRetry: () => {
                  h(p + 1), u(void 0), l?.connectRetry();
                },
                onUseDifferentWallet: t,
                onBack: i === r ? void 0 : t,
                numRetries: p,
                maxRetries: 2,
              })
            );
          },
        },
        dC = T.zo.div.withConfig({
          displayName: "TodoList",
          componentId: "sc-bcc78743-0",
        })([
          "display:flex;flex-direction:column;justify-content:flex-start;gap:10px;padding-left:8px;",
        ]),
        dj = ({ children: e, variant: t = "default", icon: n }) => {
          let r = () => {
            switch (t) {
              case "success":
                return "var(--privy-color-icon-success)";
              case "error":
                return "var(--privy-color-icon-error)";
              default:
                return "var(--privy-color-icon-muted)";
            }
          };
          return (0, a.jsxs)(dT, {
            children: [
              (0, a.jsx)(dk, {
                $variant: t,
                "data-variant": t,
                children: (() => {
                  if (n)
                    return C.isValidElement(n)
                      ? C.cloneElement(n, { stroke: r(), strokeWidth: 2 })
                      : n;
                  switch (t) {
                    case "success":
                    default:
                      return (0, a.jsx)(o.Z, {
                        size: 12,
                        stroke: r(),
                        strokeWidth: 3,
                      });
                    case "error":
                      return (0, a.jsx)(m.Z, {
                        size: 12,
                        stroke: r(),
                        strokeWidth: 3,
                      });
                  }
                })(),
              }),
              e,
            ],
          });
        },
        dk = T.zo.div.withConfig({
          displayName: "IconBackground",
          componentId: "sc-bcc78743-2",
        })(
          [
            "display:flex;align-items:center;justify-content:center;width:20px;height:20px;border-radius:50%;background-color:",
            ";flex-shrink:0;",
          ],
          ({ $variant: e }) => {
            switch (e) {
              case "success":
                return "var(--privy-color-success-bg, #EAFCEF)";
              case "error":
                return "var(--privy-color-error-bg, #FEE2E2)";
              default:
                return "var(--privy-color-background-2)";
            }
          }
        ),
        dT = T.zo.div.withConfig({
          displayName: "TodoItemWrapper",
          componentId: "sc-bcc78743-3",
        })([
          "display:flex;justify-content:flex-start;align-items:flex-start;text-align:left;gap:8px;&&{a{color:var(--privy-color-accent);}}",
        ]),
        dA = ({
          walletName: e,
          installLink: t,
          title: n,
          subtitle: r = "Follow the instructions below to get started.",
          onReload: i,
          onBack: o,
        }) => {
          let s =
            n || `Create a ${e} wallet`.replace(/wallet wallet/gi, "wallet");
          return (0, a.jsx)(rS, {
            title: s,
            subtitle: r,
            onBack: o,
            showBack: !0,
            primaryCta: {
              label: "Reload the page to use your wallet",
              onClick: i,
            },
            helpText: (0, a.jsxs)(a.Fragment, {
              children: [
                (0, a.jsx)("span", { children: "Still not sure? " }),
                (0, a.jsx)(oJ, {
                  size: "sm",
                  target: "_blank",
                  href: "https://solana.com/docs/intro/wallets",
                  children: "Learn more",
                }),
              ],
            }),
            watermark: !0,
            children: (0, a.jsxs)(dC, {
              children: [
                (0, a.jsx)(dj, {
                  children: (0, a.jsxs)("div", {
                    children: [
                      (0, a.jsx)("span", { children: "Install the " }),
                      " ",
                      (0, a.jsxs)(oJ, {
                        href: t,
                        target: "_blank",
                        children: [e, " browser extension"],
                      }),
                    ],
                  }),
                }),
                (0, a.jsx)(dj, { children: "Set up your first wallet" }),
                (0, a.jsx)(dj, {
                  children: "Store your recovery phrase in a safe place!",
                }),
              ],
            }),
          });
        },
        dS = {
          component: () => {
            let { navigateBack: e, data: t } = ap();
            if (!t?.installWalletModalData)
              throw Error("Wallet data is missing");
            let { walletConfig: n } = t.installWalletModalData;
            return (0, a.jsx)(dA, {
              walletName: n.name,
              installLink: n.installLink,
              onReload: () => {
                window.location.reload();
              },
              onBack: e,
            });
          },
        },
        dI = ({
          title: e,
          subtitle: t,
          buttonText: n,
          buttonHref: r,
          isLoading: i = !1,
          helpText: o,
          onButtonClick: s,
        }) =>
          (0, a.jsx)(rS, {
            title: e,
            subtitle: t,
            primaryCta: {
              label: n,
              onClick: () => {
                r && window.open(r, "_self"), s?.();
              },
              disabled: i,
            },
            helpText: o,
            watermark: !0,
          }),
        dE = {
          component: () => {
            let { ready: e } = (0, k.u)(),
              { data: t } = ap(),
              [n, r] = (0, C.useState)(!1);
            if (!t?.installWalletModalData)
              throw Error("Wallet data is missing");
            let {
                walletConfig: i,
                connectOnly: o,
                chainType: s,
              } = t.installWalletModalData,
              l = i.getMobileRedirect({
                useUniversalLink: !n,
                isSolana: "solana" === s,
                connectOnly: o,
              }),
              c = i.name.replace(/ wallet/gi, ""),
              d = {
                title: `Redirecting to ${c} Mobile Wallet`,
                description: `We'll take you to the ${c} Mobile Wallet app to continue your login experience.`,
                footnote: "",
              };
            return (
              e &&
                ((d.description = `For the best experience, we'll automatically log you into the ${c} Mobile Wallet in-app browser.`),
                (d.footnote =
                  "You can always return here to login via other methods.")),
              n &&
                ((d.title = "Still here?"),
                (d.description = `You may need to install the ${i.name} mobile app.`),
                (d.footnote = `Once you're done, you can connect with ${i.name} wallet to complete the login.`)),
              (0, a.jsx)(dI, {
                title: d.title,
                subtitle: d.description,
                buttonText: n ? "Go to App Store" : "Continue",
                buttonHref: l,
                isLoading: e && !l,
                helpText: d.footnote || void 0,
                onButtonClick: () => {
                  setTimeout(() => r(!0), 1e3);
                },
              })
            );
          },
        },
        dN = ({
          provider: e,
          displayName: t,
          logo: n,
          connectOnly: r,
          connector: i,
        }) => {
          let o,
            { navigate: s, setModalData: l } = ap(),
            { connectWallet: c } = (0, j.u)(),
            d = oq(),
            u = n0(e),
            p =
              "wallet_connect_v2" === i.connectorType ? e : i.walletClientType,
            h = window.matchMedia("(display-mode: standalone)").matches,
            g = nO({ connectorType: i.connectorType, walletClientType: p });
          o =
            g && g.chainTypes.includes(i.chainType)
              ? () => {
                  g.isInstalled ||
                  ("solana" === i.chainType &&
                    "isInstalled" in i &&
                    i.isInstalled)
                    ? (c(i, p), s(r ? db : lM))
                    : eC.tq
                    ? (l({
                        installWalletModalData: {
                          walletConfig: g,
                          chainType: i.chainType,
                          connectOnly: r,
                        },
                      }),
                      s(dE))
                    : (l({
                        installWalletModalData: {
                          walletConfig: g,
                          chainType: i.chainType,
                          connectOnly: r,
                        },
                      }),
                      s(dS));
                }
              : "coinbase_wallet" !== i.connectorType ||
                "eoaOnly" !== i.coinbaseWalletConfig.preference?.options ||
                !eC.tq ||
                h ||
                t5()
              ? () => {
                  (!dv(window.navigator.userAgent) || event?.isTrusted) &&
                    (c(i, p),
                    r
                      ? "wallet_connect_v2" === i.connectorType
                        ? (l((e) => ({
                            ...e,
                            externalConnectWallet: {
                              ...e?.externalConnectWallet,
                              preSelectedWalletId: "wallet_connect_qr",
                            },
                          })),
                          s(uE))
                        : s(db)
                      : s(lM));
                }
              : () => {
                  window.location.href = `https://go.cb-w.com/dapp?cb_url=${encodeURI(
                    window.location.href
                  )}`;
                };
          let f = t || u?.metadata?.shortName || u?.name || i.walletClientType;
          return (0, a.jsxs)(d_, {
            onClick: o,
            children: [
              (0, a.jsx)(dw, { icon: n || u?.image_url?.md, name: f }),
              (0, a.jsx)("span", { children: f }),
              (0, a.jsxs)(dF, {
                id: "chip-container",
                children: [
                  d?.walletClientType === p && d?.chainType === i.chainType
                    ? (0, a.jsx)(dM, { color: "gray", children: "Recent" })
                    : (0, a.jsx)("span", {
                        id: "connect-text",
                        children: "Connect",
                      }),
                  "solana" === i.chainType &&
                    (0, a.jsx)(dM, { color: "gray", children: "Solana" }),
                ],
              }),
            ],
          });
        },
        d_ = (0, T.zo)(aT).withConfig({
          displayName: "ConnectWalletButton",
          componentId: "sc-89605346-0",
        })([
          "> span{color:var(--privy-color-foreground);}> #chip-container > #connect-text{font-weight:500;color:var(--privy-color-accent);opacity:0;transition:opacity 0.1s ease-out;}:hover > #chip-container > #connect-text{opacity:1;}@media (max-width:440px){> #chip-container > #connect-text{display:none;}}",
        ]),
        dM = (0, T.zo)(dg).withConfig({
          displayName: "StyledChip",
          componentId: "sc-89605346-1",
        })(["margin-left:auto;"]),
        dF = T.zo.div.withConfig({
          displayName: "ChipContainer",
          componentId: "sc-89605346-2",
        })(["display:flex;flex-wrap:wrap;gap:8px;margin-left:auto;"]),
        dz = ["coinbase_wallet", "base_account"],
        dL = [
          "metamask",
          "okx_wallet",
          "rainbow",
          "uniswap",
          "bybit_wallet",
          "ronin_wallet",
          "haha_wallet",
          "uniswap_extension",
          "zerion",
          "rabby_wallet",
          "cryptocom",
          "binance",
        ],
        dP = ["safe"],
        dD = ["phantom", "backpack", "solflare", "universal_profile"],
        dW = ({
          walletList: e,
          walletChainType: t,
          connectors: n,
          connectOnly: r,
          ignore: i,
          walletConnectEnabled: o,
          forceWallet: s,
        }) => {
          let l = [],
            c = [],
            d = [],
            u = n.filter((e) =>
              "ethereum-only" === t
                ? "ethereum" === e.chainType
                : "solana-only" !== t || "solana" === e.chainType
            ),
            p = u.find((e) => "wallet_connect_v2" === e.connectorType);
          for (let [n, h] of (s ? [s.wallet] : e).entries()) {
            if ("detected_ethereum_wallets" === h)
              for (let [e, t] of u
                .filter(
                  ({ chainType: e, connectorType: t, walletClientType: n }) =>
                    "solana" !== e &&
                    ("uniswap_wallet_extension" === n ||
                    "uniswap_extension" === n
                      ? !i.includes("uniswap")
                      : "crypto.com_wallet_extension" === n ||
                        "crypto.com_onchain" === n
                      ? !i.includes("cryptocom")
                      : "injected" === t && !i.includes(n))
                )
                .entries()) {
                let {
                  walletClientType: i,
                  walletBranding: o,
                  chainType: s,
                } = t;
                ("unknown" === i ? c : l).push(
                  (0, a.jsx)(
                    dN,
                    {
                      connectOnly: r,
                      provider: i,
                      logo: o.icon,
                      displayName: o.name,
                      connector: t,
                    },
                    `${n}-${h}-${i}-${s}-${e}`
                  )
                );
              }
            if ("detected_solana_wallets" === h)
              for (let [e, o] of u
                .filter(({ chainType: e, walletClientType: n }) => {
                  if ("solana" === e)
                    return "ethereum-only" !== t && !i.includes(n);
                })
                .entries()) {
                let {
                  walletClientType: t,
                  walletBranding: i,
                  chainType: s,
                } = o;
                ("unknown" === t ? c : l).push(
                  (0, a.jsx)(
                    dN,
                    {
                      connectOnly: r,
                      provider: t,
                      logo: i.icon,
                      displayName: i.name,
                      connector: o,
                    },
                    `${n}-${h}-${t}-${s}-${e}`
                  )
                );
              }
            if (dD.includes(h)) {
              let e = u.find(
                (e) =>
                  ("injected" === e.connectorType &&
                    e.walletClientType === h) ||
                  e.connectorType === h
              );
              if (
                (e &&
                  l.push(
                    (0, a.jsx)(
                      dN,
                      { connectOnly: r, provider: h, connector: e },
                      `${n}-${h}`
                    )
                  ),
                "solana-only" === t || "ethereum-and-solana" === t)
              ) {
                let e = u.find(
                  ({ chainType: e, walletClientType: t }) =>
                    "solana" === e && t === h
                );
                e &&
                  l.push(
                    (0, a.jsx)(
                      dN,
                      { connectOnly: r, provider: h, connector: e },
                      `${h}-solana`
                    )
                  );
              }
            } else if (dL.includes(h)) {
              let e = u.find((e) =>
                "uniswap" === h
                  ? "uniswap_wallet_extension" === e.walletClientType ||
                    "uniswap_extension" === e.walletClientType
                  : "cryptocom" === h
                  ? "crypto.com_wallet_extension" === e.walletClientType ||
                    "crypto.com_onchain" === e.walletClientType
                  : "injected" === e.connectorType && e.walletClientType === h
              );
              if (
                (o && !e && (e = p),
                e &&
                  l.push(
                    (0, a.jsx)(
                      dN,
                      {
                        connectOnly: r,
                        provider: h,
                        connector: e,
                        logo:
                          "injected" === e.connectorType
                            ? e.walletBranding.icon
                            : void 0,
                        displayName:
                          "injected" === e.connectorType
                            ? e.walletBranding.name
                            : void 0,
                      },
                      `${n}-${h}`
                    )
                  ),
                "solana-only" === t || "ethereum-and-solana" === t)
              ) {
                let e = u.find(
                  ({ chainType: e, walletClientType: t }) =>
                    "solana" === e && t === h
                );
                e &&
                  l.push(
                    (0, a.jsx)(
                      dN,
                      { connectOnly: r, provider: h, connector: e },
                      `${h}-solana`
                    )
                  );
              }
            } else if (dz.includes(h)) {
              let e = u.find(({ connectorType: e }) => e === h);
              e &&
                l.push(
                  (0, a.jsx)(
                    dN,
                    {
                      connectOnly: r,
                      provider: h,
                      connector: e,
                      displayName:
                        "coinbase_wallet" === e.walletClientType
                          ? "Coinbase"
                          : "Base",
                      logo: "coinbase_wallet" === e.walletClientType ? nb : nC,
                    },
                    `${n}-${h}`
                  )
                );
            } else if (dP.includes(h))
              p &&
                d.push(
                  (0, a.jsx)(
                    dN,
                    { connectOnly: r, provider: h, connector: p },
                    `${n}-${h}`
                  )
                );
            else if ("wallet_connect" === h)
              p &&
                d.push(
                  (0, a.jsx)(
                    dN,
                    {
                      connectOnly: r,
                      provider: h,
                      connector: p,
                      logo: p.walletBranding.icon,
                      displayName: "WalletConnect",
                    },
                    `${n}-${h}`
                  )
                );
            else if (h === s?.wallet) {
              let t =
                  "ethereum" === s.chainType &&
                  e.includes("detected_ethereum_wallets"),
                i =
                  "solana" === s.chainType &&
                  e.includes("detected_solana_wallets");
              if (t || i) {
                let e = u.find(({ walletClientType: e }) => e === h);
                e &&
                  l.push(
                    (0, a.jsx)(
                      dN,
                      {
                        connectOnly: r,
                        provider: h,
                        displayName: e.walletBranding?.name,
                        logo: e.walletBranding?.icon,
                        connector: e,
                      },
                      `${n}-${h}`
                    )
                  );
              }
            }
          }
          return [...c, ...l, ...d];
        },
        dR = ({
          chains: e,
          appId: t,
          address: n,
          rpcConfig: a,
          includeUsdc: r,
        }) =>
          Promise.all(
            e.map(async (e) => {
              let i = (0, I.v)({ chain: e, transport: (0, E.d)(t8(e, a, t)) }),
                o = await i.getBalance({ address: n }).catch(() => 0n),
                s = null,
                l = J.lS[e.id];
              if (r && l) {
                let { balance: r } = await l2({
                  address: n,
                  chain: e,
                  rpcConfig: a,
                  appId: t,
                  erc20Address: l,
                });
                s = r;
              }
              return { balance: o, erc20Balance: s, erc20Address: l, chain: e };
            })
          ),
        dB = (e) =>
          (0, a.jsxs)("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            version: "1.1",
            id: "Layer_1",
            x: "0px",
            y: "0px",
            viewBox: "0 0 397.7 311.7",
            enableBackground: "new 0 0 397.7 311.7",
            xmlSpace: "preserve",
            ...e,
            children: [
              (0, a.jsxs)("linearGradient", {
                id: "SVGID_1_",
                gradientUnits: "userSpaceOnUse",
                x1: "360.8791",
                y1: "351.4553",
                x2: "141.213",
                y2: "-69.2936",
                gradientTransform: "matrix(1 0 0 -1 0 314)",
                children: [
                  (0, a.jsx)("stop", { offset: "0", stopColor: "#00FFA3" }),
                  (0, a.jsx)("stop", { offset: "1", stopColor: "#DC1FFF" }),
                ],
              }),
              (0, a.jsx)("path", {
                d: "M64.6,237.9c2.4-2.4,5.7-3.8,9.2-3.8h317.4c5.8,0,8.7,7,4.6,11.1l-62.7,62.7c-2.4,2.4-5.7,3.8-9.2,3.8H6.5  c-5.8,0-8.7-7-4.6-11.1L64.6,237.9z",
                fill: "url(#SVGID_1_)",
              }),
              (0, a.jsxs)("linearGradient", {
                id: "SVGID_2_",
                gradientUnits: "userSpaceOnUse",
                x1: "264.8291",
                y1: "401.6014",
                x2: "45.163",
                y2: "-19.1475",
                gradientTransform: "matrix(1 0 0 -1 0 314)",
                children: [
                  (0, a.jsx)("stop", { offset: "0", stopColor: "#00FFA3" }),
                  (0, a.jsx)("stop", { offset: "1", stopColor: "#DC1FFF" }),
                ],
              }),
              (0, a.jsx)("path", {
                d: "M64.6,3.8C67.1,1.4,70.4,0,73.8,0h317.4c5.8,0,8.7,7,4.6,11.1l-62.7,62.7c-2.4,2.4-5.7,3.8-9.2,3.8H6.5  c-5.8,0-8.7-7-4.6-11.1L64.6,3.8z",
                fill: "url(#SVGID_2_)",
              }),
              (0, a.jsxs)("linearGradient", {
                id: "SVGID_3_",
                gradientUnits: "userSpaceOnUse",
                x1: "312.5484",
                y1: "376.688",
                x2: "92.8822",
                y2: "-44.061",
                gradientTransform: "matrix(1 0 0 -1 0 314)",
                children: [
                  (0, a.jsx)("stop", { offset: "0", stopColor: "#00FFA3" }),
                  (0, a.jsx)("stop", { offset: "1", stopColor: "#DC1FFF" }),
                ],
              }),
              (0, a.jsx)("path", {
                d: "M333.1,120.1c-2.4-2.4-5.7-3.8-9.2-3.8H6.5c-5.8,0-8.7,7-4.6,11.1l62.7,62.7c2.4,2.4,5.7,3.8,9.2,3.8h317.4  c5.8,0,8.7-7,4.6-11.1L333.1,120.1z",
                fill: "url(#SVGID_3_)",
              }),
            ],
          }),
        dU = {
          [ee.y.id]: (e) =>
            (0, a.jsx)("svg", {
              xmlns: "http://www.w3.org/2000/svg",
              xmlnsXlink: "http://www.w3.org/1999/xlink",
              version: "1.1",
              id: "Layer_1",
              x: "0px",
              y: "0px",
              viewBox: "0 0 2500 2500",
              xmlSpace: "preserve",
              ...e,
              children: (0, a.jsx)("g", {
                id: "Layer_x0020_1",
                children: (0, a.jsxs)("g", {
                  id: "_2405588477232",
                  children: [
                    (0, a.jsx)("rect", {
                      fill: "none",
                      width: "2500",
                      height: "2500",
                    }),
                    (0, a.jsx)("g", {
                      children: (0, a.jsxs)("g", {
                        children: [
                          (0, a.jsx)("path", {
                            fill: "#213147",
                            d: "M226,760v980c0,63,33,120,88,152l849,490c54,31,121,31,175,0l849-490c54-31,88-89,88-152V760      c0-63-33-120-88-152l-849-490c-54-31-121-31-175,0L314,608c-54,31-87,89-87,152H226z",
                          }),
                          (0, a.jsx)("g", {
                            children: (0, a.jsxs)("g", {
                              children: [
                                (0, a.jsx)("g", {
                                  children: (0, a.jsx)("path", {
                                    fill: "#12AAFF",
                                    d: "M1435,1440l-121,332c-3,9-3,19,0,29l208,571l241-139l-289-793C1467,1422,1442,1422,1435,1440z",
                                  }),
                                }),
                                (0, a.jsx)("g", {
                                  children: (0, a.jsx)("path", {
                                    fill: "#12AAFF",
                                    d: "M1678,882c-7-18-32-18-39,0l-121,332c-3,9-3,19,0,29l341,935l241-139L1678,883V882z",
                                  }),
                                }),
                              ],
                            }),
                          }),
                          (0, a.jsx)("g", {
                            children: (0, a.jsx)("path", {
                              fill: "#9DCCED",
                              d: "M1250,155c6,0,12,2,17,5l918,530c11,6,17,18,17,30v1060c0,12-7,24-17,30l-918,530c-5,3-11,5-17,5       s-12-2-17-5l-918-530c-11-6-17-18-17-30V719c0-12,7-24,17-30l918-530c5-3,11-5,17-5l0,0V155z M1250,0c-33,0-65,8-95,25L237,555       c-59,34-95,96-95,164v1060c0,68,36,130,95,164l918,530c29,17,62,25,95,25s65-8,95-25l918-530c59-34,95-96,95-164V719       c0-68-36-130-95-164L1344,25c-29-17-62-25-95-25l0,0H1250z",
                            }),
                          }),
                          (0, a.jsx)("polygon", {
                            fill: "#213147",
                            points: "642,2179 727,1947 897,2088 738,2234     ",
                          }),
                          (0, a.jsxs)("g", {
                            children: [
                              (0, a.jsx)("path", {
                                fill: "#FFFFFF",
                                d: "M1172,644H939c-17,0-33,11-39,27L401,2039l241,139l550-1507c5-14-5-28-19-28L1172,644z",
                              }),
                              (0, a.jsx)("path", {
                                fill: "#FFFFFF",
                                d: "M1580,644h-233c-17,0-33,11-39,27L738,2233l241,139l620-1701c5-14-5-28-19-28V644z",
                              }),
                            ],
                          }),
                        ],
                      }),
                    }),
                  ],
                }),
              }),
            }),
          [et.p.id]: (e) =>
            (0, a.jsxs)("svg", {
              width: "1503",
              height: "1504",
              viewBox: "0 0 1503 1504",
              fill: "none",
              xmlns: "http://www.w3.org/2000/svg",
              ...e,
              children: [
                (0, a.jsx)("rect", {
                  x: "287",
                  y: "258",
                  width: "928",
                  height: "844",
                  fill: "white",
                }),
                (0, a.jsx)("path", {
                  fillRule: "evenodd",
                  clipRule: "evenodd",
                  d: "M1502.5 752C1502.5 1166.77 1166.27 1503 751.5 1503C336.734 1503 0.5 1166.77 0.5 752C0.5 337.234 336.734 1 751.5 1C1166.27 1 1502.5 337.234 1502.5 752ZM538.688 1050.86H392.94C362.314 1050.86 347.186 1050.86 337.962 1044.96C327.999 1038.5 321.911 1027.8 321.173 1015.99C320.619 1005.11 328.184 991.822 343.312 965.255L703.182 330.935C718.495 303.999 726.243 290.531 736.021 285.55C746.537 280.2 759.083 280.2 769.599 285.55C779.377 290.531 787.126 303.999 802.438 330.935L876.42 460.079L876.797 460.738C893.336 489.635 901.723 504.289 905.385 519.669C909.443 536.458 909.443 554.169 905.385 570.958C901.695 586.455 893.393 601.215 876.604 630.549L687.573 964.702L687.084 965.558C670.436 994.693 661.999 1009.46 650.306 1020.6C637.576 1032.78 622.263 1041.63 605.474 1046.62C590.161 1050.86 573.004 1050.86 538.688 1050.86ZM906.75 1050.86H1115.59C1146.4 1050.86 1161.9 1050.86 1171.13 1044.78C1181.09 1038.32 1187.36 1027.43 1187.92 1015.63C1188.45 1005.1 1181.05 992.33 1166.55 967.307C1166.05 966.455 1165.55 965.588 1165.04 964.706L1060.43 785.75L1059.24 783.735C1044.54 758.877 1037.12 746.324 1027.59 741.472C1017.08 736.121 1004.71 736.121 994.199 741.472C984.605 746.453 976.857 759.552 961.544 785.934L857.306 964.891L856.949 965.507C841.69 991.847 834.064 1005.01 834.614 1015.81C835.352 1027.62 841.44 1038.5 851.402 1044.96C860.443 1050.86 875.94 1050.86 906.75 1050.86Z",
                  fill: "#E84142",
                }),
              ],
            }),
          [en.u.id]: (e) =>
            (0, a.jsxs)("svg", {
              width: "146",
              height: "146",
              viewBox: "0 0 146 146",
              fill: "none",
              xmlns: "http://www.w3.org/2000/svg",
              ...e,
              children: [
                (0, a.jsx)("circle", {
                  cx: "73",
                  cy: "73",
                  r: "73",
                  fill: "#0052FF",
                }),
                (0, a.jsx)("path", {
                  d: "M73.323 123.729C101.617 123.729 124.553 100.832 124.553 72.5875C124.553 44.343 101.617 21.4463 73.323 21.4463C46.4795 21.4463 24.4581 42.0558 22.271 68.2887H89.9859V76.8864H22.271C24.4581 103.119 46.4795 123.729 73.323 123.729Z",
                  fill: "white",
                }),
              ],
            }),
          [ea.D.id]: (e) =>
            (0, a.jsxs)("svg", {
              fill: "none",
              height: "400",
              viewBox: "0 0 400 400",
              width: "400",
              xmlns: "http://www.w3.org/2000/svg",
              ...e,
              children: [
                (0, a.jsx)("path", {
                  d: "m0 0h400v400h-400z",
                  fill: "#fcff52",
                }),
                (0, a.jsx)("path", {
                  d: "m300 100h-200v200h199.996v-69.813h-33.191c-11.442 25.468-37.194 43.206-66.665 43.206-40.63 0-73.533-33.187-73.533-73.533s32.903-73.249 73.533-73.249c30.043 0 55.795 18.313 67.24 44.349h32.62z",
                  fill: "#000",
                }),
              ],
            }),
          [er.P.id]: (e) =>
            (0, a.jsxs)("svg", {
              width: "200",
              height: "208",
              viewBox: "0 0 200 208",
              fill: "none",
              xmlns: "http://www.w3.org/2000/svg",
              ...e,
              children: [
                (0, a.jsx)("rect", {
                  width: "199.4",
                  height: "207.623",
                  fill: "#121212",
                }),
                (0, a.jsxs)("g", {
                  "clip-path": "url(#clip0_2303_643)",
                  children: [
                    (0, a.jsx)("path", {
                      d: "M132.369 155.99H49.7001V68.8854H68.6148V139.109H132.369V155.981V155.99Z",
                      fill: "white",
                    }),
                    (0, a.jsx)("path", {
                      d: "M132.369 85.7575C141.687 85.7575 149.241 78.2036 149.241 68.8855C149.241 59.5673 141.687 52.0134 132.369 52.0134C123.05 52.0134 115.497 59.5673 115.497 68.8855C115.497 78.2036 123.05 85.7575 132.369 85.7575Z",
                      fill: "white",
                    }),
                  ],
                }),
                (0, a.jsx)("defs", {
                  children: (0, a.jsx)("clipPath", {
                    id: "clip0_2303_643",
                    children: (0, a.jsx)("rect", {
                      width: "99.5407",
                      height: "103.977",
                      fill: "white",
                      transform: "translate(49.7001 52.0134)",
                    }),
                  }),
                }),
              ],
            }),
          [G.R.id]: (e) =>
            (0, a.jsxs)("svg", {
              version: "1.1",
              id: "Layer_1",
              xmlns: "http://www.w3.org/2000/svg",
              xmlnsXlink: "http://www.w3.org/1999/xlink",
              x: "0px",
              y: "0px",
              viewBox: "0 0 327.5 533.3",
              enableBackground: "new 0 0 327.5 533.3;",
              xmlSpace: "preserve",
              ...e,
              children: [
                (0, a.jsx)("path", {
                  fill: "#8492B2",
                  d: "M163.7,197.2V0L0,271.6L163.7,197.2z",
                }),
                (0, a.jsx)("path", {
                  fill: "#62688F",
                  d: "M163.7,368.4V197.2L0,271.6L163.7,368.4z M163.7,197.2l163.7,74.4L163.7,0V197.2z",
                }),
                (0, a.jsx)("path", {
                  fill: "#454A75",
                  d: "M163.7,197.2v171.2l163.7-96.8L163.7,197.2z",
                }),
                (0, a.jsx)("path", {
                  fill: "#8492B2",
                  d: "M163.7,399.4L0,302.7l163.7,230.7V399.4z",
                }),
                (0, a.jsx)("path", {
                  fill: "#62688F",
                  d: "M327.5,302.7l-163.8,96.7v134L327.5,302.7z",
                }),
              ],
            }),
          [ei.v.id]: (e) =>
            (0, a.jsxs)("svg", {
              width: "500",
              height: "500",
              viewBox: "0 0 500 500",
              fill: "none",
              xmlns: "http://www.w3.org/2000/svg",
              ...e,
              children: [
                (0, a.jsx)("circle", {
                  cx: "250",
                  cy: "250",
                  r: "250",
                  fill: "#FF0420",
                }),
                (0, a.jsx)("path", {
                  d: "M177.133 316.446C162.247 316.446 150.051 312.943 140.544 305.938C131.162 298.808 126.471 288.676 126.471 275.541C126.471 272.789 126.784 269.411 127.409 265.408C129.036 256.402 131.35 245.581 134.352 232.947C142.858 198.547 164.812 181.347 200.213 181.347C209.845 181.347 218.476 182.973 226.107 186.225C233.738 189.352 239.742 194.106 244.12 200.486C248.498 206.74 250.688 214.246 250.688 223.002C250.688 225.629 250.375 228.944 249.749 232.947C247.873 244.08 245.621 254.901 242.994 265.408C238.616 282.546 231.048 295.368 220.29 303.874C209.532 312.255 195.147 316.446 177.133 316.446ZM179.76 289.426C186.766 289.426 192.707 287.362 197.586 283.234C202.59 279.106 206.155 272.789 208.281 264.283C211.158 252.524 213.348 242.266 214.849 233.51C215.349 230.883 215.599 228.194 215.599 225.441C215.599 214.058 209.657 208.366 197.774 208.366C190.768 208.366 184.764 210.43 179.76 214.558C174.882 218.687 171.379 225.004 169.253 233.51C167.001 241.891 164.749 252.149 162.498 264.283C161.997 266.784 161.747 269.411 161.747 272.163C161.747 283.672 167.752 289.426 179.76 289.426Z",
                  fill: "white",
                }),
                (0, a.jsx)("path", {
                  d: "M259.303 314.57C257.927 314.57 256.863 314.132 256.113 313.256C255.487 312.255 255.3 311.13 255.55 309.879L281.444 187.914C281.694 186.538 282.382 185.412 283.508 184.536C284.634 183.661 285.822 183.223 287.073 183.223H336.985C350.87 183.223 362.003 186.1 370.384 191.854C378.891 197.609 383.144 205.927 383.144 216.81C383.144 219.937 382.769 223.19 382.018 226.567C378.891 240.953 372.574 251.586 363.067 258.466C353.685 265.346 340.8 268.786 324.413 268.786H299.082L290.451 309.879C290.2 311.255 289.512 312.38 288.387 313.256C287.261 314.132 286.072 314.57 284.822 314.57H259.303ZM325.727 242.892C330.98 242.892 335.546 241.453 339.424 238.576C343.427 235.699 346.054 231.571 347.305 226.192C347.68 224.065 347.868 222.189 347.868 220.563C347.868 216.935 346.805 214.183 344.678 212.307C342.551 210.305 338.924 209.305 333.795 209.305H311.278L304.148 242.892H325.727Z",
                  fill: "white",
                }),
              ],
            }),
          [eo.y.id]: (e) =>
            (0, a.jsxs)("svg", {
              width: "360",
              height: "360",
              viewBox: "0 0 360 360",
              fill: "none",
              xmlns: "http://www.w3.org/2000/svg",
              ...e,
              children: [
                (0, a.jsx)("rect", {
                  width: "360",
                  height: "360",
                  rx: "180",
                  fill: "#6C00F6",
                }),
                (0, a.jsx)("path", {
                  d: "M157.743 154.241L141.052 144.58L90.9766 173.561V231.519L141.052 260.5L191.13 231.519V141.359L218.948 125.26L246.77 141.359V173.561L218.948 189.66L202.257 180.002V205.759L218.948 215.42L269.024 186.439V128.481L218.948 99.5L168.873 128.481V218.641L141.052 234.74L113.233 218.641V186.439L141.052 170.34L157.743 179.998V154.241Z",
                  fill: "white",
                }),
              ],
            }),
          [es.l.id]: (e) =>
            (0, a.jsxs)("svg", {
              xmlns: "http://www.w3.org/2000/svg",
              width: "30",
              height: "30",
              viewBox: "0 0 30 30",
              fill: "none",
              ...e,
              children: [
                (0, a.jsx)("g", {
                  clipPath: "url(#clip0)",
                  children: (0, a.jsx)("g", {
                    clipPath: "url(#clip1)",
                    children: (0, a.jsx)("path", {
                      d: "M14.9188 29.8373C6.67944 29.8373 0.00012207 23.1581 0.00012207 14.9187C0.00012207 6.67931 6.67944 0 14.9188 0C23.1581 0 29.8373 6.67931 29.8373 14.9187C29.8373 23.1581 23.1581 29.8373 14.9188 29.8373Z",
                      fill: "url(#paint0)",
                    }),
                  }),
                }),
                (0, a.jsxs)("defs", {
                  children: [
                    (0, a.jsxs)("radialGradient", {
                      id: "paint0",
                      cx: "0",
                      cy: "0",
                      r: "1",
                      gradientUnits: "userSpaceOnUse",
                      gradientTransform:
                        "translate(21.6921 8.02215) rotate(180) scale(25.2008)",
                      children: [
                        (0, a.jsx)("stop", {
                          offset: "0.00682297",
                          stopColor: "#F2CEFE",
                        }),
                        (0, a.jsx)("stop", {
                          offset: "0.1913",
                          stopColor: "#AFBAF1",
                        }),
                        (0, a.jsx)("stop", {
                          offset: "0.4982",
                          stopColor: "#4281D3",
                        }),
                        (0, a.jsx)("stop", {
                          offset: "0.666667",
                          stopColor: "#2E427D",
                        }),
                        (0, a.jsx)("stop", {
                          offset: "0.822917",
                          stopColor: "#230101",
                        }),
                        (0, a.jsx)("stop", {
                          offset: "1",
                          stopColor: "#8F6B40",
                        }),
                      ],
                    }),
                    (0, a.jsx)("clipPath", {
                      id: "clip0",
                      children: (0, a.jsx)("rect", {
                        width: "30",
                        height: "30",
                        fill: "white",
                      }),
                    }),
                    (0, a.jsx)("clipPath", {
                      id: "clip1",
                      children: (0, a.jsx)("rect", {
                        width: "30",
                        height: "30",
                        fill: "white",
                      }),
                    }),
                  ],
                }),
              ],
            }),
        },
        dO = ({ chainId: e, ...t }) => {
          if ("solana" === e) return (0, a.jsx)(dB, { ...t });
          let n = dU[e];
          return (0, a.jsx)(n || e6.Z, { ...t });
        },
        dH = ({ balance: e, className: t, chain: n }) =>
          (0, a.jsx)(lO, {
            className: t,
            $state: void 0,
            children: (0, a.jsx)(dV, { balance: e, chain: n }),
          }),
        dV = ({ balance: e, chain: t }) =>
          (0, a.jsxs)(a.Fragment, {
            children: [
              (0, a.jsxs)(d$, {
                children: [
                  (0, a.jsx)(dq, {
                    chainId: "object" == typeof t ? t.id : "solana",
                  }),
                  (0, a.jsx)(cg, {
                    children: "object" == typeof t ? t.name : l0(t),
                  }),
                ],
              }),
              (0, a.jsxs)(dg, {
                isLoading: !1,
                isPulsing: !1,
                color: "gray",
                children: [
                  (0, a.jsx)(dZ, { children: (0, a.jsx)(ek.Z, {}) }),
                  e,
                ],
              }),
            ],
          }),
        d$ = T.zo.div.withConfig({
          displayName: "Container",
          componentId: "sc-63f80cee-0",
        })(["display:flex;align-items:center;"]),
        dZ = T.zo.div.withConfig({
          displayName: "IconContainer",
          componentId: "sc-63f80cee-1",
        })(["height:0.75rem;width:0.75rem;margin-right:0.2rem;"]),
        dq = (0, T.zo)(dO).withConfig({
          displayName: "StyledNetworkIcon",
          componentId: "sc-63f80cee-2",
        })([
          "height:1.25rem;width:1.25rem;display:inline-block;margin-right:0.5rem;border-radius:4px;",
        ]),
        dG = ({ options: e, onSelect: t, selected: n, className: r }) =>
          (0, a.jsxs)(e8.v2, {
            as: dY,
            children: [
              (0, a.jsxs)(e8.j2, {
                as: dJ,
                children: [
                  (0, a.jsx)(dV, { balance: n.balance, chain: n.chain }),
                  (0, a.jsx)(dX, { height: 16 }),
                ],
              }),
              (0, a.jsx)(e8.sd, {
                as: dQ,
                className: r,
                children: e.map((e, n) =>
                  (0, a.jsx)(
                    e8.sN,
                    {
                      as: dK,
                      onClick: () => t(n),
                      children: (0, a.jsx)(dV, {
                        balance: e.balance,
                        chain: e.chain,
                      }),
                    },
                    n
                  )
                ),
              }),
            ],
          }),
        dY = T.zo.div.withConfig({
          displayName: "Wrapper",
          componentId: "sc-31c00f79-0",
        })(["width:100%;position:relative;"]),
        dQ = T.zo.div.withConfig({
          displayName: "Popover",
          componentId: "sc-31c00f79-1",
        })([
          "width:100%;margin-top:0.5rem;position:absolute;background-color:var(--privy-color-background);border-radius:var(--privy-border-radius-md);overflow-x:hidden;overflow-y:auto;box-shadow:0px 1px 2px 0px rgba(16,24,40,0.05);max-height:11.75rem;&&{border:solid 1px var(--privy-color-foreground-4);}z-index:1;",
        ]),
        dK = T.zo.button.withConfig({
          displayName: "Button",
          componentId: "sc-31c00f79-2",
        })([
          "width:100%;display:flex;justify-content:space-between;&&{padding:1rem;}:not(:last-child){border-bottom:solid 1px var(--privy-color-foreground-4);}:hover{background:var(--privy-color-background-2);}",
        ]),
        dX = (0, T.zo)(e$.Z).withConfig({
          displayName: "StyledChevronIcon",
          componentId: "sc-31c00f79-3",
        })(["height:1rem;margin-left:0.5rem;"]),
        dJ = T.zo.button.withConfig({
          displayName: "StyledMenuButton",
          componentId: "sc-31c00f79-4",
        })(
          [
            "",
            " span{margin-left:auto;}",
            "{transition:rotate 100ms ease-in;}&[aria-expanded='true']{",
            "{rotate:-180deg;}}",
          ],
          lU,
          dX,
          dX
        ),
        d0 = T.zo.div.withConfig({
          displayName: "FundingMethodContainer",
          componentId: "sc-eaaa12a-0",
        })([
          "display:flex;flex-direction:column;gap:12px;padding-top:24px;padding-bottom:24px;",
        ]),
        d1 = T.zo.div.withConfig({
          displayName: "IconContainer",
          componentId: "sc-eaaa12a-1",
        })([
          "width:24px;height:24px;display:flex;justify-content:center;align-items:center;svg{border-radius:var(--privy-border-radius-sm);}",
        ]),
        d2 = T.zo.div.withConfig({
          displayName: "FundingQuantityWrapper",
          componentId: "sc-eaaa12a-2",
        })([
          "display:flex;flex-direction:column;justify-content:center;align-items:flex-start;gap:8px;",
        ]),
        d3 = T.zo.div.withConfig({
          displayName: "FundingQuantity",
          componentId: "sc-eaaa12a-3",
        })([
          "display:flex;align-items:center;gap:4px;width:100%;padding:0 16px;border-width:1px !important;border-radius:12px;cursor:text;&:focus-within{border-color:var(--privy-color-accent);}",
        ]),
        d4 = T.zo.input.withConfig({
          displayName: "FundingAmountInput",
          componentId: "sc-eaaa12a-5",
        })([
          "background-color:var(--privy-color-background);width:100%;&:focus{outline:none !important;border:none !important;box-shadow:none !important;}&&{font-size:26px;}",
        ]),
        d5 = (0, T.zo)(d4).withConfig({
          displayName: "FundingAmountInputLarge",
          componentId: "sc-eaaa12a-6",
        })(["&&{font-size:42px;}"]),
        d6 = T.zo.div.withConfig({
          displayName: "FundingCurrency",
          componentId: "sc-eaaa12a-8",
        })(["font-size:18px;"]),
        d8 = T.zo.div.withConfig({
          displayName: "FundingDollars",
          componentId: "sc-eaaa12a-9",
        })([
          "font-size:12px;color:var(--privy-color-foreground-3);height:20px;",
        ]),
        d7 = T.zo.div.withConfig({
          displayName: "InfoButtonText",
          componentId: "sc-eaaa12a-13",
        })([""]),
        d9 = T.zo.a.withConfig({
          displayName: "InfoButtonLink",
          componentId: "sc-eaaa12a-14",
        })(["&&{color:var(--privy-color-accent);}cursor:pointer;"]),
        ue = ({
          displayName: e,
          errorMessage: t,
          configuredFundingChain: n,
          formattedBalance: r,
          fundingAmount: i,
          fundingCurrency: o,
          fundingAmountInUsd: s,
          options: l,
          selectedOption: c,
          isPreparing: d,
          isSubmitting: u,
          addressToFund: p,
          fundingWalletAddress: h,
          onSubmit: g,
          onSelect: f,
          onAmountChange: m,
          erc20ContractInfo: y,
        }) => {
          let w = (0, C.useRef)(null);
          return (0, a.jsxs)(a.Fragment, {
            children: [
              (0, a.jsx)(dd, {}),
              (0, a.jsx)(r3, {}),
              (0, a.jsx)(lR, { children: "Transfer from another network" }),
              (0, a.jsxs)(lW, {
                children: [
                  "You need more funds on the",
                  " ",
                  "object" == typeof n ? n.name : l0(n),
                  " ",
                  "network. Bridge from another blockchain network.",
                ],
              }),
              (0, a.jsxs)(d2, {
                style: { marginTop: "2rem" },
                children: [
                  (0, a.jsxs)(d3, {
                    onClick: () => w.current?.focus(),
                    children: [
                      (0, a.jsx)(d4, {
                        ref: w,
                        value: i,
                        onChange: (e) => {
                          let t = e.target.value;
                          if (
                            /^[0-9.]*$/.test(t) &&
                            t.split(".").length - 1 <= 1
                          ) {
                            let e = /\.$/.test(t) ? "." : "",
                              n = Number(t.replace(/\.$/, "") || "0");
                            if (Number.isNaN(n)) return void m("0");
                            m(n.toString() + e);
                          }
                        },
                      }),
                      (0, a.jsx)(d6, { children: o }),
                    ],
                  }),
                  s && (0, a.jsx)(d8, { children: s }),
                ],
              }),
              (0, a.jsxs)(cu, {
                style: { marginTop: "1.5rem" },
                children: [
                  (0, a.jsx)(cs, { children: "From" }),
                  (0, a.jsx)(cs, { children: (0, K.R1)(h) }),
                ],
              }),
              (0, a.jsx)(dG, {
                selected: {
                  chain: c.chain,
                  balance: c.isErc20Quote
                    ? ce({
                        amount: c.erc20Balance ?? 0n,
                        decimals: y?.decimals ?? 6,
                      }) + ` ${y?.symbol || ""}`
                    : rL(c.balance, c.chain.nativeCurrency.symbol, 3, !0),
                },
                options: l.map(
                  ({
                    chain: e,
                    balance: t,
                    isErc20Quote: n,
                    erc20Balance: a,
                  }) => ({
                    chain: e,
                    balance: n
                      ? ce({ amount: a ?? 0n, decimals: y?.decimals ?? 6 }) +
                        ` ${y?.symbol || ""}`
                      : rL(t, e.nativeCurrency.symbol, 3, !0),
                  })
                ),
                onSelect: f,
              }),
              (0, a.jsxs)(cu, {
                style: { marginTop: "1.5rem" },
                children: [
                  (0, a.jsx)(cs, { children: "To" }),
                  (0, a.jsx)(cs, { children: (0, K.R1)(p) }),
                ],
              }),
              (0, a.jsx)(dH, { chain: n, balance: r }),
              (0, a.jsx)(sY, { style: { marginTop: "1rem" }, children: t }),
              (0, a.jsxs)(aZ, {
                style: { marginTop: "1rem" },
                loading: u || d,
                disabled: d || u,
                onClick: g,
                children: ["Confirm with ", e],
              }),
              (0, a.jsx)(r4, {}),
              (0, a.jsx)(aF, {}),
            ],
          });
        },
        ut = ({
          walletClientType: e,
          displayName: t,
          addressToFund: n,
          chainId: r,
          chainName: i,
          isBridging: o,
          isErc20Flow: s,
          totalPriceInNativeCurrency: l,
          totalPriceInUsd: c,
          gasPriceInNativeCurrency: d,
          gasPriceInUsd: u,
        }) => {
          let p = n0(e);
          return (0, a.jsxs)(a.Fragment, {
            children: [
              (0, a.jsx)(dd, {}),
              (0, a.jsx)(rt, {
                centerIcon: (0, a.jsx)(dw, { icon: p?.image_url?.md, name: e }),
              }),
              (0, a.jsx)(iU, {
                style: { marginTop: "8px", marginBottom: "12px" },
                title: `${o ? "Bridging" : "Confirming"} with ${t}`,
              }),
              !o &&
                !s &&
                (0, a.jsxs)(cd, {
                  children: [
                    (0, a.jsxs)(cu, {
                      children: [
                        (0, a.jsx)(cs, { children: "Total" }),
                        (0, a.jsx)(cg, { children: c || l }),
                      ],
                    }),
                    (0, a.jsxs)(cu, {
                      children: [
                        (0, a.jsx)(cs, { children: "To" }),
                        (0, a.jsx)(cg, {
                          children: (0, a.jsx)(o7, {
                            address: n,
                            showCopyIcon: !1,
                          }),
                        }),
                      ],
                    }),
                    (0, a.jsxs)(cu, {
                      children: [
                        (0, a.jsx)(cs, { children: "Network" }),
                        (0, a.jsx)(cg, {
                          children: (0, a.jsxs)(un, {
                            children: [
                              (0, a.jsx)(dO, {
                                chainId: r,
                                height: 16,
                                width: 16,
                              }),
                              " ",
                              i,
                            ],
                          }),
                        }),
                      ],
                    }),
                    d &&
                      (0, a.jsxs)(cu, {
                        children: [
                          (0, a.jsx)(cs, { children: "Estimated fee" }),
                          (0, a.jsx)(cg, { children: u || d }),
                        ],
                      }),
                  ],
                }),
              (0, a.jsx)(r5, { height: 24 }),
              (0, a.jsx)(aF, {}),
            ],
          });
        },
        un = T.zo.div.withConfig({
          displayName: "NetworkColumn",
          componentId: "sc-5bdbf842-0",
        })(["display:flex;flex-direction:row;align-items:center;gap:4px;"]),
        ua = {
          component: () => {
            let e = ar(),
              {
                rpcConfig: t,
                appId: n,
                closePrivyModal: r,
                createAnalyticsEvent: i,
              } = (0, j.u)(),
              { navigate: o, setModalData: s, data: l } = ap(),
              c = ar(),
              { wallets: d } = iA(),
              [u, p] = (0, C.useState)(null),
              [h, g] = (0, C.useState)(null),
              [f, m] = (0, C.useState)([]),
              [y, w] = (0, C.useState)(0),
              [v, x] = (0, C.useState)(!1),
              [b, k] = (0, C.useState)(!1),
              [T, A] = (0, C.useState)(!1),
              [S, N] = (0, C.useState)(!1),
              [_, M] = (0, C.useState)(),
              [z, L] = (0, C.useState)();
            if (!l?.funding || "solana" !== l.funding.chainType)
              throw Error("Invalid funding data");
            let { address: P, chain: D, connectedWalletAddress: U } = l.funding,
              [O, H] = (0, C.useState)(l.funding.amount),
              V = U ? d.find(({ address: e }) => e === U) : d[0],
              $ = n0(V?.walletClientType || "unknown"),
              Z = $?.name || "wallet",
              [q, G] = (0, C.useState)(null);
            (0, C.useEffect)(() => {
              (async () => {
                if (!V) return;
                let e = await V.getEthereumProvider();
                G(
                  (0, W.K)({
                    account: V.address,
                    transport: (0, R.P)(e),
                  }).extend(B.I)
                );
              })().catch(console.error);
            }, [V]);
            let [Q, K] = (0, C.useState)(0n),
              X = rO(Q);
            (0, C.useEffect)(() => {
              let t = e.solanaRpcs[D];
              t
                ? lJ({ rpc: t.rpc, address: P })
                    .then((e) => K(BigInt(e)))
                    .catch(console.error)
                : console.warn("Unable to load solana rpc, skipping balance");
            }, []);
            let [J, ee] = (0, C.useState)(),
              { tokenPrice: et } = ik("solana"),
              { fundingAmountInBaseUnit: en, fundingAmountInUsd: ea } =
                (function ({ amount: e, fee: t, tokenPrice: n, isUsdc: a }) {
                  let r = BigInt(Math.floor(parseFloat(e) * 10 ** (a ? 6 : 9))),
                    i = a ? r : r + t;
                  return {
                    fundingAmountInBaseUnit: r,
                    fundingAmountInUsd: n ? rB(r, n) : void 0,
                    totalPriceInUsd: n ? rB(i, n) : void 0,
                    totalPriceInNativeCurrency: rO(i),
                    feePriceInNativeCurrency: rO(t),
                    feePriceInUsd: n ? rB(t, n) : void 0,
                  };
                })({
                  amount: O,
                  fee: 0n,
                  tokenPrice: et,
                  isUsdc: l.funding.isUSDC,
                });
            if (
              ((0, C.useEffect)(() => {
                (async () => {
                  if (!q || !V) return;
                  let e = ["solana:testnet", "solana:devnet"].includes(D);
                  e &&
                    console.warn(
                      "Solana testnets are not supported for bridging"
                    );
                  let a = (0, Y.Q)(c.chains).filter(
                      ({ testnet: t }) => !!t === e
                    ),
                    r = (
                      await dR({
                        chains: a,
                        address: V.address,
                        appId: n,
                        rpcConfig: t,
                      })
                    ).filter((e) => e.balance > 0n);
                  if (r.length < 1)
                    return void p(
                      new eh.P(
                        `Wallet ${t9(V.address)} does not have enough funds.`,
                        void 0,
                        eh.h.INSUFFICIENT_BALANCE
                      )
                    );
                  r.sort((e, t) => Number(t.balance - e.balance));
                  let i = (
                    await Promise.allSettled(
                      r.map(async (e) => ({
                        ...e,
                        quote: await sl({
                          isTestnet: !1,
                          input: si({
                            amount: en.toString(),
                            user: V.address,
                            recipient: P,
                            destinationChainId: 792703809,
                            destinationCurrency: sa,
                            originChainId: e.chain.id,
                          }),
                        }),
                      }))
                    )
                  )
                    .filter((e) => "fulfilled" === e.status)
                    .map((e) => e.value);
                  if (i.length < 1)
                    return void p(
                      new eh.P(
                        `Unable to fetch quotes for bridging. Wallet ${t9(
                          V.address
                        )} does not have enough funds.`,
                        void 0,
                        eh.h.INSUFFICIENT_BALANCE
                      )
                    );
                  let o = i
                    .map(({ quote: e, balance: t, chain: n }) => ({
                      bridgeTx: sc(e),
                      balance: t,
                      chain: n,
                      isErc20Quote: !1,
                    }))
                    .filter(({ bridgeTx: e }) => !!e);
                  if (o.length > 1) return void m(o);
                  let s = o.at(0);
                  s
                    ? (k(!0),
                      ee({
                        data: s.bridgeTx.data,
                        to: s.bridgeTx.to,
                        value: s.bridgeTx.value,
                        chain: s.chain,
                      }))
                    : p(
                        new eh.P(
                          `Unable to select bridge option from quotes. Wallet ${t9(
                            V.address
                          )} does not have enough funds.`,
                          void 0,
                          eh.h.INSUFFICIENT_BALANCE
                        )
                      );
                })().catch(console.error);
              }, [q]),
              (0, C.useEffect)(() => {
                (async () => {
                  let e, a;
                  if (!q || !V || v || T || !J) return;
                  x(!0);
                  let r = (0, I.v)({
                    chain: J.chain,
                    transport: (0, E.d)(t8(J.chain, t, n)),
                  });
                  try {
                    e = await r.prepareTransactionRequest({
                      account: V.address,
                      to: J.to,
                      chain: J.chain,
                      data: J.data,
                      value: BigInt(J.value ?? 0),
                    });
                  } catch (e) {
                    console.error(e),
                      f.length > 1 &&
                        g(e.shortMessage ?? "Something went wrong");
                  }
                  if (e) {
                    x(!1), A(!0);
                    try {
                      await q.switchChain({ id: J.chain.id });
                    } catch (e) {
                      await q.addChain({ chain: J.chain }),
                        await q.switchChain({ id: J.chain.id });
                    }
                    try {
                      a = await q.sendTransaction(e);
                    } catch (e) {
                      console.error(e),
                        "TransactionExecutionError" === e.name &&
                          (f.length < 1
                            ? p(
                                new eh.P(
                                  e.shortMessage,
                                  void 0,
                                  eh.h.TRANSACTION_FAILURE
                                )
                              )
                            : g(e.shortMessage ?? "Something went wrong"));
                    }
                    if (a)
                      return (
                        await q.waitForTransactionReceipt({ hash: a }),
                        b
                          ? (L("pending"), void M(a))
                          : (A(!1),
                            N(!0),
                            void i({
                              eventName: lX,
                              payload: {
                                provider: "external",
                                status: "success",
                                txHash: a,
                                address: V.address,
                                chainId: J.chain.id,
                                chainType: "ethereum",
                                value: J.value
                                  ? (0, F.b)(BigInt(J.value), 18)
                                  : void 0,
                                token: "ETH",
                                destination: P,
                                destinationClusterName: "mainnet-beta",
                                destinationChainType: "solana",
                                destinationValue: (0, F.b)(en, 9),
                                destinationToken: "SOL",
                              },
                            }))
                      );
                    A(!1);
                  } else x(!1);
                })().catch(console.error);
              }, [q, J]),
              su({
                transactionHash: _,
                isTestnet: !1,
                bridgingStatus: z,
                setBridgingStatus: L,
                onSuccess({ transactionHash: e }) {
                  k(!1),
                    N(!0),
                    i({
                      eventName: lX,
                      payload: {
                        provider: "external",
                        status: "success",
                        txHash: e,
                        address: V?.address,
                        chainId: J?.chain.id,
                        chainType: "ethereum",
                        value: J?.value
                          ? (0, F.b)(BigInt(J.value), 18)
                          : void 0,
                        token: "ETH",
                        destination: P,
                        destinationClusterName: "mainnet-beta",
                        destinationChainType: "solana",
                        destinationValue: (0, F.b)(en, 9),
                        destinationToken: "SOL",
                      },
                    });
                },
                onFailure({ error: e }) {
                  k(!1), p(e);
                },
              }),
              (0, C.useEffect)(() => {
                u &&
                  (s({
                    funding: l?.funding,
                    solanaFundingData: l?.solanaFundingData,
                    sendTransaction: l?.sendTransaction,
                    errorModalData: { error: u, previousScreen: ul },
                  }),
                  o(sg, !1));
              }, [u]),
              (0, C.useEffect)(() => {
                if (!S) return;
                let e = setTimeout(r, 4e3);
                return () => clearTimeout(e);
              }, [S]),
              S)
            )
              return (0, a.jsxs)(a.Fragment, {
                children: [
                  (0, a.jsx)(dd, {}),
                  (0, a.jsx)(r3, {}),
                  (0, a.jsxs)(rJ, {
                    children: [
                      (0, a.jsx)(e5.Z, {
                        color: "var(--privy-color-success)",
                        width: "64px",
                        height: "64px",
                      }),
                      (0, a.jsx)(iU, {
                        title: "Success!",
                        description: `You’ve successfully added ${O} SOL to your ${c.name} wallet. It may take a minute before the funds are available to use.`,
                      }),
                    ],
                  }),
                  (0, a.jsx)(r4, {}),
                  (0, a.jsx)(aF, {}),
                ],
              });
            let er = f[y];
            return f.length > 1 && er
              ? (0, a.jsx)(ue, {
                  displayName: Z,
                  configuredFundingChain: D,
                  formattedBalance: X,
                  fundingAmount: O,
                  fundingCurrency: "SOL",
                  fundingAmountInUsd: ea,
                  options: f,
                  selectedOption: er,
                  isPreparing: v,
                  isSubmitting: T,
                  addressToFund: P,
                  fundingWalletAddress: V?.address || "",
                  errorMessage: h,
                  onSubmit: () => {
                    l.funding?.amount !== O
                      ? (async function () {
                          if (V && er)
                            try {
                              let e = await sl({
                                  isTestnet: !1,
                                  input: si({
                                    amount: en.toString(),
                                    user: V.address,
                                    recipient: P,
                                    destinationChainId: 792703809,
                                    destinationCurrency: sa,
                                    originChainId: er.chain.id,
                                  }),
                                }),
                                t = sc(e);
                              if (!t)
                                throw Error("Invalid transaction request");
                              k(!0),
                                ee({
                                  data: t.data,
                                  to: t.to,
                                  value: t.value,
                                  chain: er.chain,
                                });
                            } catch (e) {
                              console.error(e),
                                p(
                                  new eh.P(
                                    "Unable to fetch quotes for bridging",
                                    e,
                                    eh.h.INSUFFICIENT_BALANCE
                                  )
                                );
                            }
                        })().catch(console.error)
                      : ee({
                          to: er.bridgeTx.to,
                          data: er.bridgeTx.data,
                          value: er.bridgeTx.value,
                          chain: er.chain,
                        });
                  },
                  onSelect: (e) => {
                    e !== y && (g(null), w(e));
                  },
                  onAmountChange: H,
                })
              : T && V
              ? (0, a.jsx)(ut, {
                  walletClientType: V?.walletClientType || "unknown",
                  displayName: Z,
                  addressToFund: P,
                  isBridging: b,
                  isErc20Flow: !1,
                  chainId: "solana",
                  chainName: l0(D),
                  totalPriceInUsd: void 0,
                  totalPriceInNativeCurrency: void 0,
                  gasPriceInUsd: void 0,
                  gasPriceInNativeCurrency: void 0,
                })
              : (0, a.jsxs)(a.Fragment, {
                  children: [
                    (0, a.jsx)(dd, {}),
                    (0, a.jsx)(rt, {}),
                    (0, a.jsx)("div", { style: { marginTop: "1rem" } }),
                    (0, a.jsx)(aF, {}),
                  ],
                });
          },
        },
        ur = {
          component: () => {
            let {
                rpcConfig: e,
                appId: t,
                closePrivyModal: n,
                createAnalyticsEvent: r,
              } = (0, j.u)(),
              { navigate: i, setModalData: o, data: s } = ap(),
              l = ar(),
              { wallets: c } = iA(),
              [d, u] = (0, C.useState)(!1),
              [p, h] = (0, C.useState)(0n),
              [g, f] = (0, C.useState)(!1),
              [m, y] = (0, C.useState)(null),
              [w, v] = (0, C.useState)(null),
              [x, b] = (0, C.useState)([]),
              [k, T] = (0, C.useState)(0),
              [A, S] = (0, C.useState)(!1),
              [N, _] = (0, C.useState)(!1),
              [M, z] = (0, C.useState)(!1),
              [L, P] = (0, C.useState)(!1),
              [D, H] = (0, C.useState)(),
              [V, $] = (0, C.useState)();
            if (!s?.funding || "ethereum" !== s.funding.chainType)
              throw Error("Invalid funding data");
            let {
                erc20ContractInfo: Z,
                chain: q,
                connectedWalletAddress: G,
              } = s.funding,
              Q = s.funding.address,
              K = s.funding.erc20Address,
              [X, J] = (0, C.useState)(s.funding.amount);
            (0, C.useEffect)(() => {
              K && !Z && y(Error("Unable to fetch token details"));
            }, []);
            let ee = !!K && !!Z,
              et = ee ? BigInt(parseFloat(X) * 10 ** Z.decimals) : (0, U.f)(X),
              en = G ? c.find(({ address: e }) => e === G) : c[0],
              ea = n0(en?.walletClientType || "unknown"),
              er = ea?.name || "wallet",
              [ei, eo] = (0, C.useState)(null);
            (0, C.useEffect)(() => {
              (async () => {
                if (!en) return;
                let e = await en.getEthereumProvider();
                eo(
                  (0, W.K)({
                    account: en.address,
                    transport: (0, R.P)(e),
                  }).extend(B.I)
                );
              })().catch(console.error);
            }, [en]);
            let [es, el] = (0, C.useState)(0n);
            (0, C.useEffect)(() => {
              (0, I.v)({ chain: q, transport: (0, E.d)(t8(q, e, t)) })
                .getBalance({ address: Q })
                .then(el)
                .catch(console.error);
            }, []);
            let [ec, ed] = (0, C.useState)(0n);
            (0, C.useEffect)(() => {
              ee &&
                l2({
                  chain: q,
                  address: Q,
                  appId: t,
                  rpcConfig: e,
                  erc20Address: K,
                })
                  .then((e) => ed(e.balance))
                  .catch(console.error);
            }, []);
            let { tokenPrice: eu } = ik(q.id),
              [ep, eg] = (0, C.useState)({
                to: Q,
                chain: q,
                value: et,
                data: void 0,
              });
            (0, C.useEffect)(() => {
              (async () => {
                let n, a;
                if (!ei || !en || A || M) return;
                S(!0);
                let i = (0, I.v)({
                  chain: ep.chain,
                  transport: (0, E.d)(t8(ep.chain, e, t)),
                });
                if (ee && !ep.data)
                  return (await i
                    .simulateContract({
                      address: K,
                      chain: ep.chain,
                      abi: c4,
                      functionName: "transfer",
                      args: [Q, et],
                      account: en.address,
                    })
                    .catch((e) => {
                      console.warn(
                        "Simulated token transfer failed with error, fetching bridge options.",
                        e
                      );
                    }))
                    ? (S(!1),
                      void eg({
                        to: K,
                        chain: ep.chain,
                        data: (0, O.R)({
                          abi: c4,
                          functionName: "transfer",
                          args: [Q, et],
                        }),
                        value: "0x0",
                      }))
                    : (S(!1), void f(!0));
                try {
                  n = await i.prepareTransactionRequest({
                    account: en.address,
                    to: ep.to,
                    chain: ep.chain,
                    data: ep.data,
                    value: BigInt(ep.value ?? 0),
                  });
                } catch (e) {
                  if ((console.error(e), x.length > 1))
                    v(e.shortMessage ?? "Something went wrong");
                  else if (N && 0 === x.length)
                    return void y(
                      new eh.P(
                        `Wallet ${t9(en.address)} does not have enough funds.`,
                        void 0,
                        eh.h.INSUFFICIENT_BALANCE
                      )
                    );
                }
                if (!n) return S(!1), void f(!0);
                S(!1), z(!0), u(!0), h(n.gas);
                try {
                  await ei.switchChain({ id: ep.chain.id });
                } catch (e) {
                  await ei.addChain({ chain: ep.chain }),
                    await ei.switchChain({ id: ep.chain.id });
                }
                try {
                  a = await ei.sendTransaction(n);
                } catch (e) {
                  if (
                    (console.error(e), "TransactionExecutionError" === e.name)
                  ) {
                    if (x.length < 1) {
                      let t = e.shortMessage;
                      (e.shortMessage.includes("rejected the request") ||
                        e.details.includes("rejected the request")) &&
                        (t = "User rejected the request."),
                        y(new eh.P(t, void 0, eh.h.TRANSACTION_FAILURE));
                    } else v(e.shortMessage ?? "Something went wrong");
                  }
                }
                if (a)
                  return (
                    await ei.waitForTransactionReceipt({ hash: a }),
                    z(!1),
                    N
                      ? (H(a), void $("pending"))
                      : (P(!0),
                        void r({
                          eventName: lX,
                          payload: {
                            provider: "external",
                            status: "success",
                            txHash: a,
                            address: en.address,
                            chainId: ep.chain.id,
                            chainType: "ethereum",
                            value: ep.value
                              ? (0, F.b)(BigInt(ep.value), Z?.decimals ?? 18)
                              : void 0,
                            token: Z?.symbol ?? K ?? "ETH",
                            destinationAddress: Q,
                            destinationChainId: q.id,
                            destinationChainType: "ethereum",
                            destinationValue: et
                              ? (0, F.b)(et, Z?.decimals ?? 18)
                              : void 0,
                            destinationToken:
                              Z?.symbol ?? K ?? q.nativeCurrency.name,
                          },
                        }))
                  );
                z(!1);
              })().catch(console.error);
            }, [ei, ep]),
              (0, C.useEffect)(() => {
                (async () => {
                  if (!g || !ei || !en) return;
                  let n = (0, Y.Q)(l.chains).filter(
                    (e) => e.id !== q.id && !!e.testnet == !!q.testnet
                  );
                  ee && n.unshift(q);
                  let a = await dR({
                      chains: n,
                      address: en.address,
                      appId: t,
                      rpcConfig: e,
                      includeUsdc: s.funding?.isUSDC,
                    }),
                    r = ee
                      ? a.filter((e) => e.balance > 0n)
                      : a.filter((e) => e.balance > et),
                    i = ee && a.every((e) => 0n === e.balance);
                  if (r.length < 1)
                    return void y(
                      new eh.P(
                        i
                          ? `Wallet ${t9(
                              en.address
                            )} doesn't have enough funds to cover gas fees. Top up your wallet and try again.`
                          : `Wallet ${t9(
                              en.address
                            )} does not have enough funds.`,
                        void 0,
                        eh.h.INSUFFICIENT_BALANCE
                      )
                    );
                  r.sort((e, t) =>
                    Number(
                      ee
                        ? (t.erc20Balance ?? 0n) - (e.erc20Balance ?? 0n)
                        : t.balance - e.balance
                    )
                  );
                  let o = r.flatMap((e) => {
                      let t = [
                        {
                          ...e,
                          isErc20Quote: !1,
                          isTestnet: !!q.testnet,
                          input: si({
                            amount: et.toString(),
                            user: en.address,
                            recipient: Q,
                            destinationChainId: q.id,
                            destinationCurrency: K,
                            originChainId: e.chain.id,
                          }),
                        },
                      ];
                      return (
                        ee &&
                          K &&
                          (e.erc20Balance ?? 0n) >= et &&
                          t.push({
                            ...e,
                            isErc20Quote: !0,
                            isTestnet: !!q.testnet,
                            input: si({
                              amount: et.toString(),
                              user: en.address,
                              recipient: Q,
                              destinationChainId: q.id,
                              destinationCurrency: K,
                              originChainId: e.chain.id,
                              originCurrency: e.erc20Address,
                            }),
                          }),
                        t
                      );
                    }),
                    c = (
                      await Promise.allSettled(
                        o.map(async (e) => ({ ...e, quote: await sl(e) }))
                      )
                    )
                      .filter((e) => "fulfilled" === e.status)
                      .map((e) => e.value);
                  if (c.length < 1)
                    return void y(
                      new eh.P(
                        `Wallet ${t9(en.address)} does not have enough funds.`,
                        void 0,
                        eh.h.INSUFFICIENT_BALANCE
                      )
                    );
                  let d = c
                    .map((e) => ({
                      bridgeTx: sc(e.quote),
                      balance: e.balance,
                      chain: e.chain,
                      erc20Balance: e.erc20Balance,
                      isErc20Quote: e.isErc20Quote,
                    }))
                    .filter((e) => !!e.bridgeTx);
                  if (d.length > 1) return void b(d);
                  let u = d[0];
                  u
                    ? (_(!0),
                      eg({
                        data: u.bridgeTx.data,
                        to: u.bridgeTx.to,
                        value: u.bridgeTx.value,
                        chain: u.chain,
                      }))
                    : y(
                        new eh.P(
                          `Wallet ${t9(
                            en.address
                          )} does not have enough funds.`,
                          void 0,
                          eh.h.INSUFFICIENT_BALANCE
                        )
                      );
                })().catch(console.error);
              }, [g]),
              su({
                transactionHash: D,
                isTestnet: !!q.testnet,
                bridgingStatus: V,
                setBridgingStatus: $,
                onSuccess({ transactionHash: e }) {
                  _(!1),
                    P(!0),
                    r({
                      eventName: lX,
                      payload: {
                        provider: "external",
                        status: "success",
                        txHash: e,
                        address: en?.address,
                        chainId: ep.chain.id,
                        chainType: "ethereum",
                        value: ep.value
                          ? (0, F.b)(BigInt(ep.value), Z?.decimals ?? 18)
                          : void 0,
                        token: Z?.symbol ?? K ?? "ETH",
                        destinationAddress: Q,
                        destinationChainId: q.id,
                        destinationChainType: "ethereum",
                        destinationValue: et
                          ? (0, F.b)(et, Z?.decimals ?? 18)
                          : void 0,
                        destinationToken:
                          Z?.symbol ?? K ?? q.nativeCurrency.name,
                      },
                    });
                },
                onFailure({ error: e }) {
                  _(!1), y(e);
                },
              }),
              (0, C.useEffect)(() => {
                m &&
                  (o({
                    funding: s?.funding,
                    solanaFundingData: s?.solanaFundingData,
                    sendTransaction: s?.sendTransaction,
                    errorModalData: { error: m, previousScreen: ul },
                  }),
                  i(sg, !1));
              }, [m]);
            let ef = !ee && eu ? rF(X ?? "0", eu) : void 0,
              em = ee ? p : rD([p, et]),
              ey = em && eu ? rz(em, eu) : void 0,
              ew = em
                ? rL(
                    em,
                    s?.funding?.erc20Address
                      ? s?.funding?.erc20ContractInfo?.symbol || "ETH"
                      : s?.funding?.chain.nativeCurrency.symbol || "ETH"
                  )
                : void 0,
              ev = p && eu ? rz(p, eu) : void 0,
              ex = p ? rL(p, q?.nativeCurrency?.symbol || "ETH") : void 0;
            if (
              ((0, C.useEffect)(() => {
                if (!L) return;
                let e = setTimeout(n, 4e3);
                return () => clearTimeout(e);
              }, [L]),
              L)
            )
              return (0, a.jsxs)(a.Fragment, {
                children: [
                  (0, a.jsx)(dd, {}),
                  (0, a.jsx)(r3, {}),
                  (0, a.jsxs)(rJ, {
                    children: [
                      (0, a.jsx)(e5.Z, {
                        color: "var(--privy-color-success)",
                        width: "64px",
                        height: "64px",
                      }),
                      (0, a.jsx)(iU, {
                        title: "Success!",
                        description: `You’ve successfully added ${X} ${
                          ee ? Z.symbol : q.nativeCurrency.symbol
                        } to your ${
                          l.name
                        } wallet. It may take a minute before the funds are available to use.`,
                      }),
                    ],
                  }),
                  (0, a.jsx)(r4, {}),
                  (0, a.jsx)(aF, {}),
                ],
              });
            let eb = ee
                ? `${ce({ amount: ec, decimals: Z.decimals })}  ${Z.symbol}`
                : rL(es, q.nativeCurrency.symbol, 3, !0),
              eC = x[k];
            return x.length > 1 && eC
              ? (0, a.jsx)(ue, {
                  displayName: er,
                  configuredFundingChain: q,
                  erc20ContractInfo: Z,
                  formattedBalance: eb,
                  fundingAmount: X,
                  fundingCurrency: ee ? Z.symbol : q.nativeCurrency.symbol,
                  fundingAmountInUsd: ef,
                  options: x,
                  selectedOption: eC,
                  isPreparing: A,
                  isSubmitting: M,
                  addressToFund: Q,
                  fundingWalletAddress: en?.address || "",
                  errorMessage: w,
                  onSubmit: () => {
                    s.funding?.amount !== X
                      ? (async function () {
                          if (en && eC)
                            try {
                              let e = await sl({
                                  isTestnet: !!q.testnet,
                                  input: si({
                                    amount: et.toString(),
                                    user: en.address,
                                    recipient: Q,
                                    destinationChainId: q.id,
                                    destinationCurrency: K,
                                    originChainId: eC.chain.id,
                                  }),
                                }),
                                t = sc(e);
                              if (!t)
                                throw Error("Invalid transaction request");
                              _(!0),
                                eg({
                                  data: t.data,
                                  to: t.to,
                                  value: t.value,
                                  chain: eC.chain,
                                });
                            } catch (e) {
                              console.error(e),
                                y(
                                  new eh.P(
                                    "Unable to fetch quotes for bridging",
                                    e,
                                    eh.h.INSUFFICIENT_BALANCE
                                  )
                                );
                            }
                        })().catch(console.error)
                      : eg({
                          to: eC.bridgeTx.to,
                          data: eC.bridgeTx.data,
                          value: eC.bridgeTx.value,
                          chain: eC.chain,
                        });
                  },
                  onSelect: (e) => {
                    e !== k && (v(null), T(e));
                  },
                  onAmountChange: J,
                })
              : d && p && en && s?.funding
              ? (0, a.jsx)(ut, {
                  walletClientType: en?.walletClientType || "unknown",
                  displayName: er,
                  addressToFund: Q,
                  isBridging: N,
                  isErc20Flow: ee,
                  totalPriceInUsd: ey,
                  totalPriceInNativeCurrency: ew,
                  gasPriceInUsd: ev,
                  gasPriceInNativeCurrency: ex,
                  chainId: q.id,
                  chainName: q.name,
                })
              : (0, a.jsxs)(a.Fragment, {
                  children: [
                    (0, a.jsx)(dd, {}),
                    (0, a.jsx)(rt, {}),
                    (0, a.jsx)("div", { style: { marginTop: "1rem" } }),
                    (0, a.jsx)(aF, {}),
                  ],
                });
          },
        },
        ui = Symbol("solana-funding-plugin"),
        uo = {
          component: function () {
            let e = ar(),
              {
                closePrivyModal: t,
                createAnalyticsEvent: n,
                connectors: r,
              } = (0, j.u)(),
              { navigate: i, setModalData: o, data: s } = ap(),
              l = ar(),
              c = (0, C.useRef)(!1),
              d = lm(),
              [u, p] = (0, C.useState)(!1),
              [h, g] = (0, C.useState)(!1),
              [f, m] = (0, C.useState)(null),
              [y, w] = (0, C.useState)(),
              [v, x] = (0, C.useState)();
            if (!s?.funding || "ethereum" !== s.funding.chainType)
              throw Error("Invalid funding data");
            let {
                amount: b,
                connectedWalletAddress: k,
                chain: T,
                solanaChain: A,
                isUSDC: S,
              } = s.funding,
              I = s.funding.address,
              E = s.funding.erc20Address,
              N = s.funding.isUSDC ? "USDC" : T.nativeCurrency.symbol,
              _ = (0, C.useMemo)(
                () =>
                  (function ({ connectors: e, connectedWalletAddress: t }) {
                    let n = e.find(
                        (e) =>
                          "solana" === e.chainType &&
                          e.wallets.some((e) => e.address === t)
                      ),
                      a = n?.wallet.accounts.find((e) => e.address === t);
                    if (!n || !a)
                      throw new eh.P("Unable to find source wallet connector");
                    return new $.O({ wallet: n.wallet, account: a });
                  })({ connectors: r, connectedWalletAddress: k || "" }),
                [r, k]
              ),
              M = (0, C.useMemo)(() => {
                let t = d(ui);
                if (!t) throw new eh.P("Unable to load solana plugin");
                let n = e.solanaRpcs["solana:mainnet"];
                if (!n) throw new eh.P("Unable to load mainnet RPC");
                return t.getSolanaRpcClient({
                  rpc: n.rpc,
                  rpcSubscriptions: n.rpcSubscriptions,
                  chain: "solana:mainnet",
                  blockExplorerUrl:
                    n.blockExplorerUrl ?? "https://explorer.solana.com",
                });
              }, []),
              F = n0(nZ(_?.standardWallet.name || "unknown")),
              z = F?.name || "wallet";
            return (
              (0, C.useEffect)(() => {
                (async function () {
                  if (!_ || !T || c.current) return;
                  let e = d(ui);
                  if (!e) return void m(new eh.P("Unable to solana plugin"));
                  (c.current = !0),
                    T?.testnet &&
                      console.warn(
                        "Solana testnets are not supported for bridging"
                      );
                  let t = S ? 1e6 * parseFloat(b) : (0, U.f)(b),
                    n = await sl({
                      isTestnet: !!T.testnet,
                      input: si({
                        amount: t.toString(),
                        user: _.address,
                        recipient: I,
                        destinationChainId: T.id,
                        originChainId: 792703809,
                        originCurrency: S
                          ? "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
                          : sa,
                        destinationCurrency: S ? E : void 0,
                      }),
                    }).catch(console.error);
                  if (!n)
                    return void m(
                      new eh.P(
                        `Unable to fetch quotes for bridging. Wallet ${ne(
                          _.address
                        )} does not have enough funds.`,
                        void 0,
                        eh.h.INSUFFICIENT_BALANCE
                      )
                    );
                  let a = await e.createTransactionFromRelayQuote({
                    quote: n,
                    source: _.address,
                    solanaClient: M,
                  });
                  if (a)
                    try {
                      p(!0);
                      let t = await e.simulateTransaction({
                        solanaClient: M,
                        tx: a,
                      });
                      if (t.hasError)
                        return t.hasFunds
                          ? (console.error("Transaction failed:", t.error),
                            void m(
                              new eh.P(
                                "Something went wrong",
                                void 0,
                                eh.h.TRANSACTION_FAILURE
                              )
                            ))
                          : void m(
                              new eh.P(
                                `Wallet ${ne(
                                  _?.address
                                )} does not have enough funds. ${
                                  n.details.currencyIn.amountFormatted
                                } ${N} are needed to complete the transaction.`,
                                void 0,
                                eh.h.INSUFFICIENT_BALANCE
                              )
                            );
                      let { signature: r } = await _.signAndSendTransaction({
                          chain: "solana:mainnet",
                          transaction: a,
                        }),
                        i = e.getAddressFromBuffer(r);
                      w(i), x("pending");
                    } catch (e) {
                      if (
                        (console.error(e),
                        /user rejected the request/gi.test(e.message || ""))
                      )
                        return void m(
                          new eh.P(
                            "Transaction was rejected by the user",
                            void 0,
                            eh.h.TRANSACTION_FAILURE
                          )
                        );
                      m(
                        new eh.P(
                          "Something went wrong",
                          void 0,
                          eh.h.TRANSACTION_FAILURE
                        )
                      );
                    }
                  else
                    m(
                      new eh.P(
                        `Unable to select bridge option from quotes. Wallet ${ne(
                          _.address
                        )} does not have enough funds.`,
                        void 0,
                        eh.h.INSUFFICIENT_BALANCE
                      )
                    );
                })().catch(console.error);
              }, []),
              su({
                transactionHash: y,
                isTestnet: !1,
                bridgingStatus: v,
                setBridgingStatus: x,
                onSuccess({ transactionHash: e }) {
                  p(!1),
                    g(!0),
                    n({
                      eventName: lX,
                      payload: {
                        provider: "external",
                        status: "success",
                        txHash: e,
                        address: _.address,
                        chainType: "solana",
                        clusterName: A,
                        token: "SOL",
                        destinationAddress: I,
                        destinationChainId: T.id,
                        destinationChainType: "ethereum",
                        destinationValue: b,
                        destinationToken: S ? "USDC" : "ETH",
                      },
                    });
                },
                onFailure({ error: e }) {
                  p(!1), m(e);
                },
              }),
              (0, C.useEffect)(() => {
                if (!h) return;
                let e = setTimeout(t, 4e3);
                return () => clearTimeout(e);
              }, [h]),
              (0, C.useEffect)(() => {
                f &&
                  (o({
                    funding: s?.funding,
                    solanaFundingData: s?.solanaFundingData,
                    sendTransaction: s?.sendTransaction,
                    errorModalData: { error: f, previousScreen: ul },
                  }),
                  i(sg, !1));
              }, [f]),
              h
                ? (0, a.jsxs)(a.Fragment, {
                    children: [
                      (0, a.jsx)(dd, {}),
                      (0, a.jsx)(r3, {}),
                      (0, a.jsxs)(rJ, {
                        children: [
                          (0, a.jsx)(e5.Z, {
                            color: "var(--privy-color-success)",
                            width: "64px",
                            height: "64px",
                          }),
                          (0, a.jsx)(iU, {
                            title: "Success!",
                            description: `You’ve successfully added ${b} ${N} to your ${l.name} wallet. It may take a minute before the funds are available to use.`,
                          }),
                        ],
                      }),
                      (0, a.jsx)(r4, {}),
                      (0, a.jsx)(aF, {}),
                    ],
                  })
                : u && _
                ? (0, a.jsx)(ut, {
                    walletClientType: nZ(_?.standardWallet.name || "unknown"),
                    displayName: z,
                    addressToFund: I,
                    isBridging: u,
                    isErc20Flow: !1,
                    chainId: T.id,
                    chainName: T.name,
                    totalPriceInUsd: void 0,
                    totalPriceInNativeCurrency: void 0,
                    gasPriceInUsd: void 0,
                    gasPriceInNativeCurrency: void 0,
                  })
                : (0, a.jsxs)(a.Fragment, {
                    children: [
                      (0, a.jsx)(dd, {}),
                      (0, a.jsx)(rt, {}),
                      (0, a.jsx)("div", { style: { marginTop: "1rem" } }),
                      (0, a.jsx)(aF, {}),
                    ],
                  })
            );
          },
        },
        us = {
          component: () => {
            let { data: e, setModalData: t } = ap(),
              n = e?.funding,
              r = "solana" === n.chainType,
              i = (0, C.useRef)(null),
              { tokenPrice: o } = ik(r ? "solana" : n.chain.id),
              s = r ? void 0 : n,
              l = !(!s?.erc20Address || s?.erc20ContractInfo),
              c = r
                ? n.isUSDC
                  ? "USDC"
                  : "SOL"
                : n.erc20Address
                ? n.erc20ContractInfo?.symbol
                : n.chain.nativeCurrency.symbol || "ETH",
              d = parseFloat(n.amount),
              u = !isNaN(d) && d > 0,
              p = o ? rF(n.amount, o) : void 0;
            return (0, a.jsxs)(a.Fragment, {
              children: [
                (0, a.jsx)(dd, {}),
                (0, a.jsx)(lR, { children: "Confirm or edit amount" }),
                (0, a.jsxs)(r0, {
                  style: { marginTop: "32px" },
                  children: [
                    (0, a.jsx)(d2, {
                      children: l
                        ? (0, a.jsx)(rt, { size: "50px" })
                        : (0, a.jsxs)(a.Fragment, {
                            children: [
                              (0, a.jsxs)(d3, {
                                onClick: () => i.current?.focus(),
                                children: [
                                  (0, a.jsx)(d5, {
                                    ref: i,
                                    value: n.amount,
                                    onChange: (a) => {
                                      let r = a.target.value;
                                      /^[0-9.]*$/.test(r) &&
                                        r.split(".").length - 1 <= 1 &&
                                        t({
                                          ...e,
                                          funding: { ...n, amount: r },
                                          solanaFundingData:
                                            e?.solanaFundingData
                                              ? {
                                                  ...e.solanaFundingData,
                                                  amount: r,
                                                }
                                              : void 0,
                                        });
                                    },
                                  }),
                                  (0, a.jsx)(d6, { children: c }),
                                ],
                              }),
                              !s?.erc20Address &&
                                (0, a.jsx)(d8, {
                                  children: p && u ? `${p} USD` : "",
                                }),
                            ],
                          }),
                    }),
                    (0, a.jsx)(aZ, {
                      style: { marginTop: "1rem" },
                      disabled: !u,
                      onClick: n.onContinueWithExternalWallet,
                      children: "Continue",
                    }),
                  ],
                }),
                (0, a.jsx)(aF, {}),
              ],
            });
          },
        },
        ul = {
          component: () => {
            let e,
              { connectors: t } = (0, j.u)(),
              { setModalData: n, data: r, navigate: i } = ap(),
              o = ar(),
              { wallets: s } = iA(),
              l = t.filter(nY).flatMap((e) => e.wallets),
              [c, d] = (0, C.useState)("default"),
              u = "solana" === r?.funding?.chainType,
              p = !!r?.funding?.crossChainBridgingEnabled;
            e =
              "ethereum" === r?.funding?.chainType
                ? r.funding.erc20Address && !r.funding.isUSDC
                  ? "ethereum-only"
                  : p && !r.funding.chain.testnet
                  ? "ethereum-and-solana"
                  : "ethereum-only"
                : p && !r.funding?.isUSDC
                ? "ethereum-and-solana"
                : "solana-only";
            let h = s.filter((e) => "privy" !== e.walletClientType),
              g = h.map((e) => e.walletClientType),
              f = l.filter((e) => "privy" !== e.walletClientType),
              m = f.map((e) => e.walletClientType),
              y = [],
              w = { ...r.funding };
            w.usingDefaultFundingMethod && (w.usingDefaultFundingMethod = !1);
            let v = ({
              address: e,
              walletChainType: t,
              walletClientType: a,
            }) => {
              n({
                ...r,
                funding: {
                  ...w,
                  connectedWalletAddress: e,
                  onContinueWithExternalWallet: () =>
                    i(
                      b({
                        destChainType: u ? "solana" : "ethereum",
                        sourceChainType: t,
                      })
                    ),
                },
                solanaFundingData: r?.solanaFundingData
                  ? {
                      ...r.solanaFundingData,
                      sourceWalletData: { address: e, walletClientType: a },
                    }
                  : void 0,
              }),
                i(us);
            };
            "solana-only" !== e &&
              y.push(
                ...h.map((e, t) =>
                  (0, a.jsx)(
                    uc,
                    {
                      onClick: () =>
                        v({
                          address: e.address,
                          walletChainType: "ethereum",
                          walletClientType: e.walletClientType,
                        }),
                      icon: e.meta.icon,
                      name: e.meta.name,
                      chainType: e.type,
                    },
                    t
                  )
                )
              ),
              "ethereum-only" !== e &&
                y.push(
                  ...f.map((e, t) =>
                    (0, a.jsx)(
                      uc,
                      {
                        onClick: () =>
                          v({
                            address: e.address,
                            walletChainType: "solana",
                            walletClientType: e.walletClientType,
                          }),
                        icon: e.meta.icon,
                        name: e.meta.name,
                        chainType: e.type,
                      },
                      t
                    )
                  )
                ),
              y.push(
                ...dW({
                  walletList: o.appearance.walletList.filter(
                    (e) =>
                      !h.some((t) => t.walletClientType === e) &&
                      !f.some((t) => t.walletClientType === e)
                  ),
                  walletChainType: e,
                  connectors: t,
                  connectOnly: !0,
                  ignore: [...o.appearance.walletList, ...g, ...m],
                  walletConnectEnabled: o.externalWallets.walletConnect.enabled,
                })
              );
            let x = (0, a.jsx)(dm, {
                text: "More wallets",
                onClick: () => d("overflow"),
              }),
              b = ({ sourceChainType: e, destChainType: t }) =>
                "ethereum" === e && "solana" === t
                  ? ua
                  : "ethereum" === e && "ethereum" === t
                  ? ur
                  : "solana" === e && "ethereum" === t
                  ? uo
                  : w.externalSolanaFundingScreen;
            return (
              (0, C.useEffect)(() => {
                n({
                  ...r,
                  externalConnectWallet: {
                    onCompleteNavigateTo: ({
                      address: e,
                      walletClientType: t,
                      walletChainType: a,
                    }) => (
                      n({
                        ...r,
                        funding: {
                          ...w,
                          connectedWalletAddress: e,
                          onContinueWithExternalWallet: () => {
                            i(
                              b({
                                destChainType: u ? "solana" : "ethereum",
                                sourceChainType: a ?? "ethereum",
                              })
                            );
                          },
                        },
                        solanaFundingData: r?.solanaFundingData
                          ? {
                              ...r.solanaFundingData,
                              sourceWalletData: {
                                address: e || "",
                                walletClientType: t || "",
                              },
                            }
                          : void 0,
                      }),
                      us
                    ),
                  },
                });
              }, []),
              (0, a.jsxs)(
                a.Fragment,
                "overflow" === c
                  ? {
                      children: [
                        (0, a.jsx)(
                          a4,
                          { backFn: () => d("default") },
                          "header"
                        ),
                        (0, a.jsxs)(ab, {
                          children: [
                            (0, a.jsx)(lW, {
                              style: {
                                color: "var(--privy-color-foreground-3)",
                                textAlign: "left",
                              },
                              children: "More wallets",
                            }),
                            y,
                          ],
                        }),
                        (0, a.jsx)(aF, {}),
                      ],
                    }
                  : {
                      children: [
                        (0, a.jsx)(dd, {}),
                        (0, a.jsx)(iU, {
                          title: "Transfer from wallet",
                          description:
                            "Connect a wallet to deposit funds or send funds manually to your wallet address.",
                        }),
                        (0, a.jsxs)(ab, {
                          children: [
                            y.length > 4 ? y.slice(0, 3) : y,
                            y.length > 4 && x,
                          ],
                        }),
                        (0, a.jsx)(aF, {}),
                      ],
                    }
              )
            );
          },
        },
        uc = ({ onClick: e, icon: t, name: n, chainType: r }) =>
          (0, a.jsxs)(aT, {
            onClick: e,
            children: [
              (0, a.jsx)(d1, {
                style: { width: 20 },
                children: (0, a.jsx)("img", { src: t }),
              }),
              n,
              (0, a.jsx)(dg, {
                color: "gray",
                style: { marginLeft: "auto" },
                children: "Connected",
              }),
              "solana" === r &&
                (0, a.jsx)(dg, { color: "gray", children: "Solana" }),
            ],
          }),
        ud = {
          component: () => {
            let {
                data: e,
                setModalData: t,
                navigate: n,
                navigateBack: r,
              } = ap(),
              {
                closePrivyModal: i,
                createAnalyticsEvent: o,
                client: s,
              } = (0, j.u)(),
              [l, c] = (0, C.useState)("pending-in-flow"),
              d = (0, C.useRef)(0),
              u = { ...e?.funding, showAlternateFundingMethod: !0 };
            u.usingDefaultFundingMethod && (u.usingDefaultFundingMethod = !1);
            let { partnerUserId: p, popup: h } = e?.coinbaseOnrampStatus ?? {};
            return (
              (0, C.useEffect)(() => {
                if ("pending-in-flow" === l || "pending-after-flow" === l) {
                  let a = setInterval(async () => {
                    if (p)
                      try {
                        let { status: a } = await s.getCoinbaseOnRampStatus({
                          partnerUserId: p,
                        });
                        if ("success" === a) return void c("success");
                        if ("failure" === a)
                          throw Error(
                            "There was an error completing Coinbase Onramp flow."
                          );
                        if (d.current >= 3)
                          return (
                            t({
                              funding: u,
                              solanaFundingData: e?.solanaFundingData,
                            }),
                            void n(uI)
                          );
                        h?.closed &&
                          ((d.current = d.current + 1),
                          c("pending-after-flow"));
                      } catch (a) {
                        console.error(a),
                          c("error"),
                          o({
                            eventName: lX,
                            payload: {
                              status: "failure",
                              provider: "coinbase-onramp",
                              error: a.message,
                            },
                          }),
                          t({
                            funding: {
                              ...u,
                              errorMessage:
                                "Something went wrong adding funds. Please try again or use another method.",
                            },
                            solanaFundingData: e?.solanaFundingData,
                          }),
                          n(uI);
                      }
                  }, 1500);
                  return () => clearInterval(a);
                }
              }, [p, h, l]),
              (0, a.jsxs)(a.Fragment, {
                children: [
                  (0, a.jsx)(
                    a4,
                    {
                      title: "Fund account",
                      backFn: () => {
                        t({
                          funding: u,
                          solanaFundingData: e?.solanaFundingData,
                        }),
                          r();
                      },
                    },
                    "header"
                  ),
                  (0, a.jsx)(uu, { status: l, onClickCta: i }),
                  (0, a.jsx)(aF, {}),
                ],
              })
            );
          },
        },
        uu = ({ status: e, onClickCta: t }) => {
          let {
            title: n,
            body: r,
            cta: i,
          } = (0, C.useMemo)(
            () =>
              ((e) => {
                switch (e) {
                  case "success":
                    return {
                      title: "You've funded your account!",
                      body: "It may take a few minutes for the assets to appear.",
                      cta: "Continue",
                    };
                  case "pending-after-flow":
                    return {
                      title: "In Progress",
                      body: "Almost done. Retrieving transaction status from Coinbase",
                      cta: "",
                    };
                  case "error":
                  case "pending-in-flow":
                    return {
                      title: "In Progress",
                      body: "Go back to Coinbase Onramp to finish funding your account.",
                      cta: "",
                    };
                }
              })(e),
            [e]
          );
          return (0, a.jsxs)(a.Fragment, {
            children: [
              (0, a.jsxs)(ug, {
                children: [
                  (0, a.jsx)(up, { isSucccess: "success" === e }),
                  (0, a.jsxs)(r1, {
                    children: [
                      (0, a.jsx)("h3", { children: n }),
                      (0, a.jsx)(uh, { children: r }),
                    ],
                  }),
                ],
              }),
              i && (0, a.jsx)(a$, { onClick: t, children: i }),
            ],
          });
        },
        up = ({ isSucccess: e }) => {
          if (!e) {
            let e = "var(--privy-color-foreground-4)";
            return (0, a.jsxs)("div", {
              style: { position: "relative" },
              children: [
                (0, a.jsx)(aR, { color: e, style: { position: "absolute" } }),
                (0, a.jsx)(aB, { color: e }),
                (0, a.jsx)(nx, {
                  style: {
                    position: "absolute",
                    width: "2.8rem",
                    height: "2.8rem",
                    top: "1.2rem",
                    left: "1.2rem",
                  },
                }),
              ],
            });
          }
          let t = e
              ? eD.Z
              : () =>
                  (0, a.jsx)(e1.Z, {
                    width: "3rem",
                    height: "3rem",
                    style: {
                      backgroundColor: "var(--privy-color-foreground-4)",
                      color: "var(--privy-color-background)",
                      borderRadius: "100%",
                      padding: "0.5rem",
                      margin: "0.5rem",
                    },
                  }),
            n = e
              ? "var(--privy-color-success)"
              : "var(--privy-color-foreground-4)";
          return (0, a.jsx)("div", {
            style: {
              borderColor: n,
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              borderRadius: "100%",
              borderWidth: 2,
              padding: "0.5rem",
              marginBottom: "0.5rem",
            },
            children:
              t && (0, a.jsx)(t, { width: "4rem", height: "4rem", color: n }),
          });
        },
        uh = T.zo.p.withConfig({
          displayName: "StatusBody",
          componentId: "sc-8428a551-0",
        })([
          "font-size:1rem;color:var(--privy-color-foreground-3);margin-bottom:1rem;display:flex;flex-direction:column;gap:1rem;",
        ]),
        ug = T.zo.div.withConfig({
          displayName: "ConnectContainer",
          componentId: "sc-8428a551-1",
        })([
          "display:flex;flex-direction:column;align-items:center;justify-content:center;margin-left:1.75rem;margin-right:1.75rem;padding:2rem 0;",
        ]),
        uf = {
          [G.R.id]: "ethereum",
          [en.u.id]: "base",
          [ei.v.id]: "optimism",
          [eo.y.id]: "polygon",
          [ee.y.id]: "arbitrum",
          [et.p.id]: "avacchain",
        },
        um = (e, t, n, a, r, i) =>
          new Promise(async (o, s) => {
            let l = iW();
            if (!l) return void s(Error("Unable to initialize flow"));
            let c =
                "ethereum" === t.chainType
                  ? (function (e) {
                      let t = uf[e];
                      if (!t)
                        throw new eh.P(
                          `Unsupported chainId: ${e} for Coinbase Onramp`
                        );
                      return t;
                    })(t.chain.id)
                  : "solana",
              d = t.isUSDC
                ? "USDC"
                : "ethereum" === t.chainType
                ? (0, el.GG)(t.chain.id, "native-currency")
                : "SOL",
              u = await e.initCoinbaseOnRamp({
                addresses: [{ address: t.address, blockchains: [c] }],
                assets: [d],
              }),
              { url: p } = (0, el.CN)({
                appId: e.getAppId(),
                input: u,
                amount: t.amount,
                blockchain: c,
                asset: d,
                experience: i,
              });
            l.location = p.toString();
            let h = { ...r?.funding, showAlternateFundingMethod: !0 };
            t.usingDefaultFundingMethod && (h.usingDefaultFundingMethod = !1),
              n({
                funding: h,
                solanaFundingData: r?.solanaFundingData,
                coinbaseOnrampStatus: { popup: l },
              }),
              a(ud),
              e.createAnalyticsEvent({
                eventName: "sdk_fiat_on_ramp_started",
                payload: {
                  provider: "coinbase-onramp",
                  value: t.amount,
                  chainType: t.chainType,
                  chainId: "ethereum" === t.chainType ? t.chain.id : t.chain,
                },
              }),
              setTimeout(() => {
                n({
                  funding: h,
                  solanaFundingData: r?.solanaFundingData,
                  coinbaseOnrampStatus: {
                    partnerUserId: u.partner_user_id,
                    popup: l,
                  },
                });
              }, 5e3),
              o();
          }),
        uy = "moonpay",
        uw = ({ size: e = 61, ...t }) =>
          (0, a.jsx)("svg", {
            width: e,
            height: e,
            viewBox: "0 0 61 61",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            ...t,
            children: (0, a.jsxs)("g", {
              id: "moonpay_symbol_wht 2",
              children: [
                (0, a.jsx)("rect", {
                  x: "1.3374",
                  y: "1",
                  width: "59",
                  height: "59",
                  rx: "11.5",
                  fill: "#7715F5",
                }),
                (0, a.jsx)("path", {
                  id: "Vector",
                  d: "M43.8884 23.3258C45.0203 23.3258 46.1268 22.9901 47.068 22.3613C48.0091 21.7324 48.7427 20.8386 49.1759 19.7928C49.6091 18.747 49.7224 17.5962 49.5016 16.4861C49.2807 15.3759 48.7357 14.3561 47.9353 13.5557C47.1349 12.7553 46.1151 12.2102 45.0049 11.9893C43.8947 11.7685 42.7439 11.8819 41.6982 12.3151C40.6524 12.7482 39.7585 13.4818 39.1297 14.423C38.5008 15.3641 38.1651 16.4707 38.1651 17.6026C38.165 18.3542 38.3131 19.0985 38.6007 19.7929C38.8883 20.4873 39.3098 21.1182 39.8413 21.6496C40.3728 22.1811 41.0037 22.6027 41.6981 22.8903C42.3925 23.1778 43.1367 23.3259 43.8884 23.3258ZM26.3395 49.1017C23.5804 49.1017 20.8832 48.2836 18.5891 46.7507C16.295 45.2178 14.5069 43.039 13.4511 40.49C12.3952 37.9409 12.1189 35.1359 12.6572 32.4298C13.1955 29.7237 14.5241 27.238 16.4751 25.287C18.4262 23.336 20.9118 22.0074 23.6179 21.4691C26.324 20.9308 29.129 21.2071 31.6781 22.2629C34.2272 23.3189 36.406 25.1069 37.9389 27.401C39.4717 29.6952 40.2899 32.3923 40.2899 35.1514C40.2899 36.9835 39.9291 38.7975 39.2281 40.49C38.527 42.1826 37.4994 43.7205 36.204 45.0159C34.9086 46.3113 33.3707 47.3389 31.6781 48.04C29.9856 48.741 28.1715 49.1018 26.3395 49.1017Z",
                  fill: "white",
                }),
              ],
            }),
          }),
        uv = {
          component: () => {
            let { data: e, setModalData: t, navigateBack: n } = ap(),
              r = ar(),
              { closePrivyModal: i } = (0, j.u)(),
              { externalTransactionId: o } = e?.moonpayStatus,
              s = (function (e, t = !1) {
                let [n, a] = (0, C.useState)(null),
                  { createAnalyticsEvent: r } = (0, j.u)(),
                  { data: i, navigate: o, setModalData: s } = ap(),
                  l = i?.funding,
                  c = (0, C.useRef)(0);
                return (
                  (0, C.useEffect)(() => {
                    let n = setInterval(async () => {
                      if (e)
                        try {
                          let [c] = await (async function (e, t) {
                              return (0, e7.Wg)(
                                `https://api.moonpay.com/v1/transactions/ext/${e}`,
                                {
                                  query: {
                                    apiKey: t
                                      ? "pk_test_fqWjXZMSFwloh7orvJsRfjiUHXJqFzI"
                                      : "pk_live_hirbpu0cVcLHrjktC9l7fbc9ctjv0SL",
                                  },
                                }
                              );
                            })(e, t),
                            d =
                              "waitingAuthorization" === c.status &&
                              "credit_debit_card" === c.paymentMethod
                                ? "pending"
                                : c.status;
                          if (
                            ([
                              "failed",
                              "completed",
                              "awaitingAuthorization",
                            ].includes(d) &&
                              (r({
                                eventName: lX,
                                payload: {
                                  status: d,
                                  provider: uy,
                                  paymentMethod: c.paymentMethod,
                                  cardPaymentType: c.cardPaymentType,
                                  currency: c.currency?.code,
                                  baseCurrencyAmount: c.baseCurrencyAmount,
                                  quoteCurrencyAmount: c.quoteCurrencyAmount,
                                  feeAmount: c.feeAmount,
                                  extraFeeAmount: c.extraFeeAmount,
                                  networkFeeAmount: c.networkFeeAmount,
                                  isSandbox: t,
                                },
                              }),
                              clearInterval(n)),
                            "failed" === d || "serviceFailure" === d)
                          )
                            return (
                              s({
                                funding: {
                                  ...l,
                                  errorMessage:
                                    "Something went wrong adding funds from Moonpay. Please try again or use another method to fund your wallet.",
                                },
                                solanaFundingData: i?.solanaFundingData,
                              }),
                              void o(uI)
                            );
                          a(d);
                        } catch (e) {
                          404 !== e.response?.status && (c.current += 1),
                            c.current >= 3 &&
                              (r({
                                eventName: lX,
                                payload: {
                                  status: "serviceFailure",
                                  provider: uy,
                                },
                              }),
                              clearInterval(n),
                              s({
                                funding: {
                                  ...l,
                                  errorMessage:
                                    "Something went wrong adding funds from Moonpay. Please try again or use another method to fund your wallet.",
                                },
                                solanaFundingData: i?.solanaFundingData,
                              }),
                              o(uI));
                        }
                    }, 3e3);
                    return () => clearInterval(n);
                  }, [e, c]),
                  n
                );
              })(o || null, r.fundingMethodConfig.moonpay.useSandbox ?? !1);
            return (0, a.jsxs)(a.Fragment, {
              children: [
                (0, a.jsx)(a4, {
                  title: "Fund account",
                  backFn: () => {
                    let a = { ...e?.funding, showAlternateFundingMethod: !0 };
                    a.usingDefaultFundingMethod &&
                      (a.usingDefaultFundingMethod = !1),
                      t({
                        funding: a,
                        solanaFundingData: e?.solanaFundingData,
                      }),
                      n();
                  },
                }),
                (0, a.jsx)(ux, { status: s, onClickCta: i }),
                (0, a.jsx)(aF, {}),
              ],
            });
          },
        },
        ux = ({ status: e, onClickCta: t }) => {
          let {
            title: n,
            body: r,
            cta: i,
          } = (0, C.useMemo)(
            () =>
              ((e) => {
                switch (e) {
                  case "completed":
                    return {
                      title: "You've funded your account!",
                      body: "It may take a few minutes for the assets to appear.",
                      cta: "Continue",
                    };
                  case "waitingAuthorization":
                    return {
                      title: "Processing payment",
                      body: "This may take up to a few hours. You will receive an email when the purchase is complete.",
                      cta: "Continue",
                    };
                  default:
                    return {
                      title: "In Progress",
                      body: "Go back to MoonPay to finish funding your account.",
                      cta: "",
                    };
                }
              })(e),
            [e]
          );
          return (0, a.jsxs)(a.Fragment, {
            children: [
              (0, a.jsxs)(uj, {
                children: [
                  (0, a.jsx)(ub, { status: e }),
                  (0, a.jsxs)(r1, {
                    children: [
                      (0, a.jsx)("h3", { children: n }),
                      (0, a.jsx)(uC, { children: r }),
                    ],
                  }),
                ],
              }),
              i && (0, a.jsx)(a$, { onClick: t, children: i }),
            ],
          });
        },
        ub = ({ status: e }) => {
          if (!e || "pending" === e) {
            let e = "var(--privy-color-foreground-4)";
            return (0, a.jsxs)("div", {
              style: { position: "relative" },
              children: [
                (0, a.jsx)(aR, { color: e, style: { position: "absolute" } }),
                (0, a.jsx)(aB, { color: e }),
                (0, a.jsx)(uw, {
                  size: "3rem",
                  style: { position: "absolute", top: "1rem", left: "1rem" },
                }),
              ],
            });
          }
          let t = ((e) => {
              switch (e) {
                case "completed":
                  return eD.Z;
                case "waitingAuthorization":
                  return () =>
                    (0, a.jsx)(e1.Z, {
                      width: "3rem",
                      height: "3rem",
                      style: {
                        backgroundColor: "var(--privy-color-foreground-4)",
                        color: "var(--privy-color-background)",
                        borderRadius: "100%",
                        padding: "0.5rem",
                        margin: "0.5rem",
                      },
                    });
                default:
                  return;
              }
            })(e),
            n = e
              ? {
                  completed: "var(--privy-color-success)",
                  failed: "var(--privy-color-error)",
                  serviceFailure: "var(--privy-color-error)",
                  waitingAuthorization: "var(--privy-color-accent)",
                  pending: "var(--privy-color-foreground-4)",
                }[e]
              : "var(--privy-color-foreground-4)";
          return (0, a.jsx)("div", {
            style: {
              borderColor: n,
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              borderRadius: "100%",
              borderWidth: 2,
              padding: "0.5rem",
              marginBottom: "0.5rem",
            },
            children:
              t && (0, a.jsx)(t, { width: "4rem", height: "4rem", color: n }),
          });
        },
        uC = T.zo.p.withConfig({
          displayName: "StatusBody",
          componentId: "sc-727a5a8d-0",
        })([
          "font-size:1rem;color:var(--privy-color-foreground-3);margin-bottom:1rem;display:flex;flex-direction:column;gap:1rem;",
        ]),
        uj = T.zo.div.withConfig({
          displayName: "ConnectContainer",
          componentId: "sc-727a5a8d-1",
        })([
          "display:flex;flex-direction:column;align-items:center;justify-content:center;margin-left:1.75rem;margin-right:1.75rem;padding:2rem 0;",
        ]),
        uk = async (e, t, n, a, r, i, o, s) => {
          let l = iW();
          if (!l) throw Error("Unable to initialize flow");
          let c =
              "ethereum" === t.chainType
                ? (0, ec.Fy)(t.chain.id, a)
                : t.isUSDC
                ? "USDC_SOL"
                : "SOL",
            { signedUrl: d, externalTransactionId: u } =
              await e.signMoonpayOnRampUrl({
                address: t.address,
                useSandbox: n.fundingMethodConfig.moonpay.useSandbox ?? !1,
                config: {
                  uiConfig: {
                    accentColor: n.appearance.palette.accent,
                    theme: n.appearance.palette.colorScheme,
                  },
                  paymentMethod: s,
                  currencyCode: c,
                  quoteCurrencyAmount: parseFloat(t.amount),
                },
              });
          e.createAnalyticsEvent({
            eventName: "sdk_fiat_on_ramp_started",
            payload: {
              provider: "moonpay",
              value: t.amount,
              chainType: t.chainType,
              chainId: "ethereum" === t.chainType ? t.chain.id : t.chain,
            },
          }),
            (l.location = d);
          let p = { ...o?.funding, showAlternateFundingMethod: !0 };
          t.usingDefaultFundingMethod && (p.usingDefaultFundingMethod = !1),
            r({
              moonpayStatus: {},
              funding: p,
              solanaFundingData: o?.solanaFundingData,
            }),
            i(uv),
            setTimeout(() => {
              r({
                moonpayStatus: { externalTransactionId: u },
                funding: p,
                solanaFundingData: o?.solanaFundingData,
              });
            }, 8e3);
        },
        uT = async (e) =>
          "undefined" != typeof window &&
          "PaymentRequest" in window &&
          (await new window.PaymentRequest([{ supportedMethods: e }], {
            id: "0",
            total: {
              label: "Item",
              amount: { currency: "USD", value: "1.00" },
            },
          }).canMakePayment()),
        uA = () => uT("https://apple.com/apple-pay"),
        uS = () => uT("https://google.com/pay"),
        uI = {
          component: () => {
            let { wallets: e } = iA(),
              { connectors: t } = (0, j.u)(),
              n = t.filter(nY).flatMap((e) => e.wallets),
              { navigate: r, data: i, setModalData: o } = ap(),
              { client: s } = (0, j.u)(),
              l = ar(),
              c = i?.funding,
              d = dh(uA),
              u = dh(uS),
              p = "solana" === c.chainType,
              h = p ? void 0 : c,
              g = (0, C.useMemo)(
                () =>
                  ((e, t, n, a, r, i) => {
                    let o,
                      s,
                      l = "solana" === n.chainType,
                      c = l ? void 0 : n,
                      d = n.isUSDC
                        ? "USDC"
                        : c?.erc20Address
                        ? void 0
                        : "native-currency",
                      u = !!l || (d && (0, ec.OF)(Number(n.chain.id), d)),
                      p = !!l || (d && (0, el.RN)(Number(n.chain.id), d)),
                      h = [];
                    for (let o of (n.preferredCardProvider &&
                      n.supportedOptions.sort((e) =>
                        e.provider === n.preferredCardProvider ? -1 : 1
                      ),
                    n.supportedOptions))
                      "card" === o.method &&
                        "coinbase" === o.provider &&
                        p &&
                        h.push(() => um(t, n, a, r, i, "buy")),
                        "card" === o.method &&
                          "moonpay" === o.provider &&
                          u &&
                          d &&
                          h.push(() =>
                            uk(t, n, e, d, a, r, i, "credit_debit_card")
                          );
                    for (let e of n.supportedOptions)
                      "exchange" === e.method &&
                        "coinbase" === e.provider &&
                        p &&
                        (o = () => um(t, n, a, r, i, "buy"));
                    for (let e of i?.funding?.supportedOptions ?? [])
                      "wallets" === e.method && (s = () => r(ul));
                    return {
                      onFundWithCard: h,
                      onFundWithExchange: o,
                      onFundWithWallet: s,
                    };
                  })(l, s, c, o, r, i),
                [l, s, c, i, o, r]
              ),
              f = p
                ? n.find(({ address: e }) => e === c.address)
                : e.find(
                    ({ address: e }) => (0, M.K)(e) === (0, M.K)(c.address)
                  ),
              m = n0(f?.walletClientType || "unknown"),
              y = m?.name || "wallet",
              w = f && "privy" !== f.walletClientType ? y : l.name,
              v = (0, C.useMemo)(
                () =>
                  c.uiConfig?.landing?.title
                    ? c.uiConfig?.landing?.title
                    : `Add funds to your ${
                        w?.toLowerCase().endsWith("wallet") ? w : w + " wallet"
                      }`,
                [c.uiConfig?.landing?.title, w]
              );
            (0, C.useEffect)(() => {
              if (c?.defaultFundingMethod && c.usingDefaultFundingMethod)
                switch (
                  (o({
                    funding: { ...c, usingDefaultFundingMethod: !1 },
                    solanaFundingData: i?.solanaFundingData,
                  }),
                  c?.defaultFundingMethod)
                ) {
                  case "card":
                    g.onFundWithCard[0] && g.onFundWithCard[0]();
                    break;
                  case "exchange":
                    g.onFundWithExchange && g.onFundWithExchange();
                    break;
                  case "wallet":
                    g.onFundWithWallet && g.onFundWithWallet();
                    break;
                  case "manual":
                    r(l4);
                }
            }, []),
              (0, C.useEffect)(() => {
                h?.erc20Address &&
                  !h.erc20ContractInfo &&
                  l8({
                    address: h.erc20Address,
                    chain: h.chain,
                    rpcConfig: l.rpcConfig,
                    privyAppId: l.id,
                  })
                    .then((e) => {
                      o({
                        ...i,
                        funding: {
                          ...h,
                          erc20ContractInfo: e
                            ? { symbol: e.symbol, decimals: e.decimals }
                            : void 0,
                        },
                      });
                    })
                    .catch(console.error);
              }, [h?.erc20Address, h?.chain]);
            let x = !(!h?.erc20Address || h?.erc20ContractInfo);
            return (0, a.jsxs)(a.Fragment, {
              children: [
                (0, a.jsx)(dd, {}),
                (0, a.jsx)("h3", { children: v }),
                (0, a.jsxs)(d0, {
                  children: [
                    c.errorMessage &&
                      (0, a.jsx)(cx, {
                        theme: l.appearance.palette.colorScheme,
                        children: c.errorMessage,
                      }),
                    g.onFundWithCard?.[0] &&
                      (0, a.jsxs)(aT, {
                        disabled: x,
                        onClick: g.onFundWithCard[0],
                        children: [
                          (0, a.jsx)(d1, {
                            children: (0, a.jsx)(eJ.Z, {
                              style: { width: 24 },
                            }),
                          }),
                          "Pay with card",
                          d
                            ? (0, a.jsx)(du, {
                                style: {
                                  marginLeft: "auto",
                                  maxWidth: "100%",
                                  width: "auto",
                                  height: "0.875rem",
                                },
                              })
                            : u
                            ? (0, a.jsx)(dp, {
                                style: {
                                  marginLeft: "auto",
                                  maxWidth: "100%",
                                  width: "auto",
                                  height: "0.875rem",
                                },
                              })
                            : null,
                        ],
                      }),
                    g.onFundWithExchange &&
                      (0, a.jsxs)(aT, {
                        disabled: x,
                        onClick: g.onFundWithExchange,
                        children: [
                          (0, a.jsx)(d1, {
                            children: (0, a.jsx)(e1.Z, {
                              style: { width: 24 },
                            }),
                          }),
                          "Transfer from an exchange",
                        ],
                      }),
                    g.onFundWithWallet &&
                      (0, a.jsxs)(aT, {
                        disabled: x,
                        onClick: g.onFundWithWallet,
                        children: [
                          (0, a.jsx)(d1, {
                            children: (0, a.jsx)(s0, { style: { width: 24 } }),
                          }),
                          "Transfer from wallet",
                        ],
                      }),
                    (0, a.jsxs)(aT, {
                      disabled: x,
                      onClick: () => r(l4),
                      children: [
                        (0, a.jsx)(d1, {
                          children: (0, a.jsx)(e0.Z, { style: { width: 24 } }),
                        }),
                        "Receive funds",
                      ],
                    }),
                    c?.showAlternateFundingMethod &&
                      g.onFundWithCard?.[1] &&
                      (0, a.jsx)(lL, {
                        theme: l.appearance.palette.colorScheme,
                        children: (0, a.jsxs)(d7, {
                          children: [
                            "Having trouble or facing location restrictions?",
                            " ",
                            (0, a.jsx)(d9, {
                              onClick: g.onFundWithCard[1],
                              children: "Try a different provider.",
                            }),
                          ],
                        }),
                      }),
                  ],
                }),
                (0, a.jsx)(aF, {}),
              ],
            });
          },
        },
        uE = {
          component: () => {
            let { closePrivyModal: e } = (0, j.u)(),
              { data: t, navigate: n } = ap(),
              r = ar(),
              i = aw(),
              o = t?.externalConnectWallet?.description,
              s = (0, C.useRef)(
                t?.externalConnectWallet?.walletList ?? r.appearance.walletList
              ),
              l = (0, C.useRef)(
                t?.externalConnectWallet?.walletChainType ??
                  r.appearance.walletChainType
              );
            return (0, a.jsx)(lr, {
              walletList: s.current,
              walletChainType: l.current,
              preSelectedWalletId:
                t?.externalConnectWallet?.preSelectedWalletId,
              onBack: t?.funding ? () => n(uI) : void 0,
              onClose: () => {
                i(
                  "connectWallet",
                  "onError",
                  eh.h.GENERIC_CONNECT_WALLET_ERROR
                ),
                  e();
              },
              onConnect: ({ connector: a, wallet: r }) => {
                i("connectWallet", "onSuccess", { wallet: r });
                let o = t?.externalConnectWallet?.onCompleteNavigateTo;
                o
                  ? n(
                      o({
                        address: r.address,
                        walletClientType: a?.walletClientType,
                        walletChainType: a?.chainType,
                      })
                    )
                  : e();
              },
              onConnectError: (e) => {
                e instanceof eh.aa
                  ? (console.warn(e.cause ? e.cause : e.message),
                    i(
                      "connectWallet",
                      "onError",
                      e.privyErrorCode || eh.h.GENERIC_CONNECT_WALLET_ERROR
                    ))
                  : (console.warn(e),
                    i(
                      "connectWallet",
                      "onError",
                      eh.h.UNKNOWN_CONNECT_WALLET_ERROR
                    ));
              },
              customDescription: o,
              app: r,
            });
          },
          isUnauthenticatedScreem: !0,
        },
        uN = (e) =>
          (0, a.jsxs)("svg", {
            width: "33",
            height: "32",
            viewBox: "0 0 33 32",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            ...e,
            children: [
              (0, a.jsx)("rect", {
                x: "0.5",
                width: "32",
                height: "32",
                rx: "4",
                fill: "#855DCD",
              }),
              (0, a.jsxs)("g", {
                "clip-path": "url(#clip0_1715_1960)",
                children: [
                  (0, a.jsx)("path", {
                    d: "M4.5 4H28.5V28H4.5V4Z",
                    fill: "#855DCD",
                  }),
                  (0, a.jsx)("path", {
                    d: "M11.1072 8.42105H21.6983V23.5789H20.1437V16.6357H20.1284C19.9566 14.7167 18.3542 13.2129 16.4028 13.2129C14.4514 13.2129 12.849 14.7167 12.6771 16.6357H12.6619V23.5789H11.1072V8.42105Z",
                    fill: "white",
                  }),
                  (0, a.jsx)("path", {
                    d: "M8.28943 10.5725L8.92101 12.7239H9.45542V21.4275C9.1871 21.4275 8.96959 21.6464 8.96959 21.9165V22.5032H8.87242C8.60411 22.5032 8.38659 22.7221 8.38659 22.9922V23.5789H13.8279V22.9922C13.8279 22.7221 13.6104 22.5032 13.3421 22.5032H13.2449V21.9165C13.2449 21.6464 13.0274 21.4275 12.7591 21.4275H12.1761V10.5725H8.28943Z",
                    fill: "white",
                  }),
                  (0, a.jsx)("path", {
                    d: "M20.2408 21.4275C19.9725 21.4275 19.755 21.6464 19.755 21.9165V22.5032H19.6579C19.3895 22.5032 19.172 22.7221 19.172 22.9922V23.5789H24.6133V22.9922C24.6133 22.7221 24.3958 22.5032 24.1275 22.5032H24.0303V21.9165C24.0303 21.6464 23.8128 21.4275 23.5445 21.4275V12.7239H24.0789L24.7105 10.5725H20.8238V21.4275H20.2408Z",
                    fill: "white",
                  }),
                ],
              }),
              (0, a.jsx)("defs", {
                children: (0, a.jsx)("clipPath", {
                  id: "clip0_1715_1960",
                  children: (0, a.jsx)("rect", {
                    width: "24",
                    height: "24",
                    fill: "white",
                    transform: "translate(4.5 4)",
                  }),
                }),
              }),
            ],
          }),
        u_ = (e) => {
          let [t, n] = (0, C.useState)(!1);
          return (0, a.jsx)(uM, {
            color: e.color,
            href: e.url,
            target: "_blank",
            rel: "noreferrer noopener",
            onClick: () => {
              n(!0), setTimeout(() => n(!1), 1500);
            },
            justOpened: t,
            children: e.text,
          });
        },
        uM = T.zo.a.withConfig({
          displayName: "StyledOpenLinkButton",
          componentId: "sc-4e695c83-0",
        })(
          [
            "display:flex;align-items:center;gap:6px;&&{margin:8px 2px;font-size:14px;color:",
            ";font-weight:",
            ";transition:color 350ms ease;:focus,:active{background-color:transparent;border:none;outline:none;box-shadow:none;}:hover{color:",
            ";}:active{color:'var(--privy-color-foreground)';font-weight:medium;}@media (max-width:440px){margin:12px 2px;}}svg{width:14px;height:14px;}",
          ],
          (e) =>
            e.justOpened
              ? "var(--privy-color-foreground)"
              : e.color || "var(--privy-color-foreground-3)",
          (e) => (e.justOpened ? "medium" : "normal"),
          (e) =>
            e.justOpened
              ? "var(--privy-color-foreground)"
              : "var(--privy-color-foreground-2)"
        ),
        uF = T.zo.div.withConfig({
          displayName: "Container",
          componentId: "sc-913deead-0",
        })(["width:100%;"]),
        uz = T.zo.div.withConfig({
          displayName: "InputContainer",
          componentId: "sc-913deead-1",
        })(
          [
            "display:flex;align-items:center;justify-content:space-between;gap:0.75rem;padding:0.75rem;height:56px;background:",
            ";border:1px solid var(--privy-color-foreground-4);border-radius:var(--privy-border-radius-md);&:hover{border-color:",
            ";}",
          ],
          (e) =>
            e.$disabled
              ? "var(--privy-color-background-2)"
              : "var(--privy-color-background)",
          (e) =>
            e.$disabled
              ? "var(--privy-color-foreground-4)"
              : "var(--privy-color-foreground-3)"
        ),
        uL = T.zo.div.withConfig({
          displayName: "TextContainer",
          componentId: "sc-913deead-2",
        })(["flex:1;min-width:0;display:flex;align-items:center;"]),
        uP = T.zo.span.withConfig({
          displayName: "Text",
          componentId: "sc-913deead-3",
        })(
          [
            "display:block;font-size:16px;line-height:24px;color:",
            ";overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:1;-webkit-box-orient:vertical;word-break:break-all;@media (min-width:441px){font-size:14px;line-height:20px;}",
          ],
          (e) =>
            e.$disabled
              ? "var(--privy-color-foreground-2)"
              : "var(--privy-color-foreground)"
        ),
        uD = (0, T.zo)(uP).withConfig({
          displayName: "PlaceholderText",
          componentId: "sc-913deead-4",
        })(["color:var(--privy-color-foreground-3);font-style:italic;"]),
        uW = (0, T.zo)(lB).withConfig({
          displayName: "TitleLabel",
          componentId: "sc-913deead-5",
        })(["margin-bottom:0.5rem;"]),
        uR = (0, T.zo)(aY).withConfig({
          displayName: "CopyButton",
          componentId: "sc-913deead-6",
        })(["&&{gap:0.375rem;font-size:14px;flex-shrink:0;}"]),
        uB = ({
          value: e,
          title: t,
          placeholder: n,
          className: r,
          showCopyButton: i = !0,
          truncate: l,
          maxLength: c = 40,
          disabled: d = !1,
        }) => {
          var u;
          let [p, h] = (0, C.useState)(!1),
            g =
              l && e
                ? (u = (u = e).startsWith("https://") ? u.slice(8) : u)
                    .length <= c
                  ? u
                  : "middle" === l
                  ? `${u.slice(0, Math.ceil(c / 2) - 2)}...${u.slice(
                      -(Math.floor(c / 2) - 1)
                    )}`
                  : `${u.slice(0, c - 3)}...`
                : e;
          return (
            (0, C.useEffect)(() => {
              if (p) {
                let e = setTimeout(() => h(!1), 3e3);
                return () => clearTimeout(e);
              }
            }, [p]),
            (0, a.jsxs)(uF, {
              className: r,
              children: [
                t && (0, a.jsx)(uW, { children: t }),
                (0, a.jsxs)(uz, {
                  $disabled: d,
                  children: [
                    (0, a.jsx)(uL, {
                      children: e
                        ? (0, a.jsx)(uP, {
                            $disabled: d,
                            title: e,
                            children: g,
                          })
                        : (0, a.jsx)(uD, {
                            $disabled: d,
                            children: n || "No value",
                          }),
                    }),
                    i &&
                      e &&
                      (0, a.jsx)(uR, {
                        onClick: function (t) {
                          t.stopPropagation(),
                            navigator.clipboard
                              .writeText(e)
                              .then(() => h(!0))
                              .catch(console.error);
                        },
                        size: "sm",
                        children: (0, a.jsxs)(
                          a.Fragment,
                          p
                            ? {
                                children: [
                                  "Copied",
                                  (0, a.jsx)(o.Z, { size: 14 }),
                                ],
                              }
                            : {
                                children: [
                                  "Copy",
                                  (0, a.jsx)(s.Z, { size: 14 }),
                                ],
                              }
                        ),
                      }),
                  ],
                }),
              ],
            })
          );
        },
        uU = ({
          connectUri: e,
          loading: t,
          success: n,
          errorMessage: r,
          onBack: i,
          onClose: o,
          onOpenFarcaster: s,
        }) =>
          (0, a.jsx)(
            rS,
            eC.tq || t
              ? eC.gn
                ? {
                    title: r ? r.message : "Sign in with Farcaster",
                    subtitle: r
                      ? r.detail
                      : "To sign in with Farcaster, please open the Farcaster app.",
                    icon: uN,
                    iconVariant: "loading",
                    iconLoadingStatus: { success: n, fail: !!r },
                    primaryCta:
                      e && s
                        ? { label: "Open Farcaster app", onClick: s }
                        : void 0,
                    onBack: i,
                    onClose: o,
                    watermark: !0,
                  }
                : {
                    title: r ? r.message : "Signing in with Farcaster",
                    subtitle: r ? r.detail : "This should only take a moment",
                    icon: uN,
                    iconVariant: "loading",
                    iconLoadingStatus: { success: n, fail: !!r },
                    onBack: i,
                    onClose: o,
                    watermark: !0,
                    children:
                      e &&
                      eC.tq &&
                      (0, a.jsx)(uH, {
                        children: (0, a.jsx)(u_, {
                          text: "Take me to Farcaster",
                          url: e,
                          color: "#8a63d2",
                        }),
                      }),
                  }
              : {
                  title: "Sign in with Farcaster",
                  subtitle: "Scan with your phone's camera to continue.",
                  onBack: i,
                  onClose: o,
                  watermark: !0,
                  children: (0, a.jsxs)(uV, {
                    children: [
                      (0, a.jsx)(u$, {
                        children: e
                          ? (0, a.jsx)(sG, {
                              url: e,
                              size: 275,
                              squareLogoElement: uN,
                            })
                          : (0, a.jsx)(uG, { children: (0, a.jsx)(aR, {}) }),
                      }),
                      (0, a.jsxs)(uZ, {
                        children: [
                          (0, a.jsx)(uq, {
                            children:
                              "Or copy this link and paste it into a phone browser to open the Farcaster app.",
                          }),
                          e &&
                            (0, a.jsx)(uB, {
                              value: e,
                              truncate: "end",
                              maxLength: 30,
                              showCopyButton: !0,
                              disabled: !0,
                            }),
                        ],
                      }),
                    ],
                  }),
                }
          ),
        uO = {
          component: () => {
            let { authenticated: e, logout: t, ready: n, user: r } = (0, k.u)(),
              {
                lastScreen: i,
                navigate: o,
                navigateBack: s,
                setModalData: l,
              } = ap(),
              c = ar(),
              {
                getAuthFlow: d,
                loginWithFarcaster: u,
                closePrivyModal: p,
                createAnalyticsEvent: h,
              } = (0, j.u)(),
              [g, f] = (0, C.useState)(void 0),
              [m, y] = (0, C.useState)(!1),
              [w, v] = (0, C.useState)(!1),
              x = (0, C.useRef)([]),
              b = d(),
              T = b?.meta.connectUri;
            return (
              (0, C.useEffect)(() => {
                let e = Date.now(),
                  t = setInterval(async () => {
                    let n = await b.pollForReady.execute(),
                      a = Date.now() - e;
                    if (n) {
                      clearInterval(t), y(!0);
                      try {
                        await u(), v(!0);
                      } catch (t) {
                        let e = {
                          retryable: !1,
                          message: "Authentication failed",
                        };
                        if (t?.privyErrorCode === eh.h.ALLOWLIST_REJECTED)
                          return void o(lv);
                        if (t?.privyErrorCode === eh.h.USER_LIMIT_REACHED)
                          return (
                            console.error(new eh.ab(t).toString()), void o(lE)
                          );
                        if (t?.privyErrorCode === eh.h.USER_DOES_NOT_EXIST)
                          return void o(o6);
                        if (t?.privyErrorCode === eh.h.LINKED_TO_ANOTHER_USER)
                          e.detail =
                            t.message ??
                            "This account has already been linked to another user.";
                        else {
                          if (
                            t?.privyErrorCode ===
                              eh.h.ACCOUNT_TRANSFER_REQUIRED &&
                            t.data?.data?.nonce
                          )
                            return (
                              l({
                                accountTransfer: {
                                  nonce: t.data?.data?.nonce,
                                  account: t.data?.data?.subject,
                                  displayName:
                                    t.data?.data?.account?.displayName,
                                  linkMethod: "farcaster",
                                  embeddedWalletAddress:
                                    t.data?.data?.otherUser
                                      ?.embeddedWalletAddress,
                                  farcasterEmbeddedAddress:
                                    t.data?.data?.otherUser
                                      ?.farcasterEmbeddedAddress,
                                },
                              }),
                              void o(sS)
                            );
                          t?.privyErrorCode === eh.h.INVALID_CREDENTIALS
                            ? ((e.retryable = !0),
                              (e.detail = "Something went wrong. Try again."))
                            : t?.privyErrorCode === eh.h.TOO_MANY_REQUESTS &&
                              (e.detail =
                                "Too many requests. Please wait before trying again.");
                        }
                        f(e);
                      }
                    } else
                      a > 12e4 &&
                        (clearInterval(t),
                        f({
                          retryable: !0,
                          message: "Authentication failed",
                          detail: "The request timed out. Try again.",
                        }));
                  }, 2e3);
                return () => {
                  clearInterval(t), x.current.forEach((e) => clearTimeout(e));
                };
              }, []),
              (0, C.useEffect)(() => {
                if (n && e && w && r) {
                  if (c?.legal.requireUsersAcceptTerms && !r.hasAcceptedTerms) {
                    let e = setTimeout(() => {
                      o(sM);
                    }, th);
                    return () => clearTimeout(e);
                  }
                  w &&
                    (o4(r, c.embeddedWallets)
                      ? x.current.push(
                          setTimeout(() => {
                            l({
                              createWallet: {
                                onSuccess: () => {},
                                onFailure: (e) => {
                                  console.error(e),
                                    h({
                                      eventName:
                                        "embedded_wallet_creation_failure_logout",
                                      payload: {
                                        error: e,
                                        screen: "FarcasterConnectStatusScreen",
                                      },
                                    }),
                                    t();
                                },
                                callAuthOnSuccessOnClose: !0,
                              },
                            }),
                              o(s_);
                          }, th)
                        )
                      : x.current.push(
                          setTimeout(
                            () =>
                              p({ shouldCallAuthOnSuccess: !0, isSuccess: !0 }),
                            th
                          )
                        ));
                }
              }, [w, n, e, r]),
              (0, a.jsx)(uU, {
                connectUri: T,
                loading: m,
                success: w,
                errorMessage: g,
                onBack: i ? s : void 0,
                onClose: p,
                onOpenFarcaster: () => {
                  T && (window.location.href = T);
                },
              })
            );
          },
        },
        uH = T.zo.div.withConfig({
          displayName: "MobileLinkContainer",
          componentId: "sc-6e4b180b-0",
        })(["margin-top:24px;"]),
        uV = T.zo.div.withConfig({
          displayName: "ContentContainer",
          componentId: "sc-6e4b180b-1",
        })(["display:flex;flex-direction:column;align-items:center;gap:24px;"]),
        u$ = T.zo.div.withConfig({
          displayName: "QrContainer",
          componentId: "sc-6e4b180b-2",
        })([
          "display:flex;align-items:center;justify-content:center;min-height:275px;",
        ]),
        uZ = T.zo.div.withConfig({
          displayName: "InstructionsContainer",
          componentId: "sc-6e4b180b-3",
        })(["display:flex;flex-direction:column;align-items:center;gap:16px;"]),
        uq = T.zo.div.withConfig({
          displayName: "InstructionText",
          componentId: "sc-6e4b180b-4",
        })([
          "font-size:0.875rem;text-align:center;color:var(--privy-color-foreground-2);",
        ]),
        uG = T.zo.div.withConfig({
          displayName: "LoaderWrapper",
          componentId: "sc-6e4b180b-5",
        })(["position:relative;width:82px;height:82px;"]),
        uY = () => {
          let [e, t] = (0, C.useState)(!1),
            { currentScreen: n, navigate: r, setModalData: i, data: o } = ap(),
            { enabled: s, token: l } = np(),
            { initLoginWithFarcaster: c } = (0, j.u)(),
            { accountType: d } = oq();
          return (0, a.jsxs)(aT, {
            onClick: async () => {
              t(!0);
              try {
                s && !l
                  ? (i({
                      captchaModalData: {
                        callback: (e) => c(e, o?.login?.disableSignup),
                        userIntentRequired: !0,
                        onSuccessNavigateTo: uO,
                        onErrorNavigateTo: sg,
                      },
                    }),
                    r(lb))
                  : (await c(l, o?.login?.disableSignup), r(uO));
              } catch (e) {
                i({ errorModalData: { error: e, previousScreen: n || pD } }),
                  r(sg);
              } finally {
                t(!1);
              }
            },
            disabled: !1,
            children: [
              (0, a.jsx)(uN, { width: 32, height: 32 }),
              " Farcaster",
              e && (0, a.jsx)(aU, {}),
              "farcaster" === d &&
                (0, a.jsx)(uQ, { color: "gray", children: "Recent" }),
            ],
          });
        },
        uQ = (0, T.zo)(dg).withConfig({
          displayName: "StyledChip",
          componentId: "sc-c6317ff9-0",
        })(["margin-left:auto;"]),
        uK = ({ status: e, passkeySignupFlow: t = !1, error: n, onRetry: r }) =>
          (0, a.jsx)(rS, {
            title: (() => {
              switch (e) {
                case "loading":
                  return "Waiting for passkey";
                case "success":
                  return "Success";
                case "error":
                  return "Something went wrong";
              }
            })(),
            subtitle: (0, a.jsx)(uJ, {
              children: (() => {
                switch (e) {
                  case "loading":
                    return t
                      ? "Please follow prompts to register your passkey."
                      : "Please follow prompts to verify your passkey.\nYou will have to sign up with another method first to register a passkey for your account.";
                  case "success":
                    return "You've successfully logged in with your passkey.";
                  case "error":
                    if (n instanceof eh.aa) {
                      if (n.privyErrorCode === eh.h.CANNOT_LINK_MORE_OF_TYPE)
                        return "Cannot link more passkeys to account.";
                      if (n.privyErrorCode === eh.h.PASSKEY_NOT_ALLOWED)
                        return "Passkey request timed out or rejected by user.\nYou will have to sign up with another method first to register a passkey for your account.";
                    }
                    return "An unknown error occurred.\nYou will have to sign up with another method first to register a passkey for your account.";
                }
              })(),
            }),
            icon: y.Z,
            iconVariant: "loading",
            iconLoadingStatus: {
              success: "success" === e,
              fail: "error" === e,
            },
            primaryCta:
              "error" === e && r
                ? { label: "Retry", onClick: r }
                : "success" === e
                ? { label: "Continue", disabled: !0 }
                : void 0,
            watermark: !0,
          }),
        uX = {
          component: () => {
            let { data: e, setModalData: t, navigate: n } = ap(),
              r = ar(),
              {
                loginWithPasskey: i,
                signupWithPasskey: o,
                closePrivyModal: s,
                createAnalyticsEvent: l,
              } = (0, j.u)(),
              { user: c, logout: d } = (0, k.u)(),
              { passkeySignupFlow: u } = e?.passkeyAuthModalData ?? {},
              [p, h] = (0, C.useState)("loading"),
              [g, f] = (0, C.useState)(null),
              m = (0, C.useRef)([]),
              y = (e) => {
                m.current = [e, ...m.current];
              };
            (0, C.useEffect)(
              () => () => {
                m.current.forEach((e) => clearTimeout(e)), (m.current = []);
              },
              []
            );
            let w = async () => {
              h("loading");
              try {
                u ? await o() : await i(), h("success");
              } catch (e) {
                f(e), h("error");
              }
            };
            return (
              (0, C.useEffect)(() => {
                if ("success" === p && c) {
                  if (r?.legal.requireUsersAcceptTerms && !c.hasAcceptedTerms)
                    return void y(
                      setTimeout(() => {
                        n(sM);
                      }, 900)
                    );
                  if (!o4(c, r?.embeddedWallets))
                    return void y(
                      setTimeout(() => {
                        s({ shouldCallAuthOnSuccess: !0, isSuccess: !0 });
                      }, th)
                    );
                  y(
                    setTimeout(() => {
                      t({
                        createWallet: {
                          onSuccess: () => {},
                          onFailure: (e) => {
                            console.error(e),
                              l({
                                eventName:
                                  "embedded_wallet_creation_failure_logout",
                                payload: {
                                  error: e,
                                  screen: "PasskeyStatusScreen",
                                },
                              }),
                              d();
                          },
                          callAuthOnSuccessOnClose: !0,
                        },
                      }),
                        n(s_);
                    }, 900)
                  );
                }
              }, [c, p]),
              (0, C.useEffect)(() => {
                w();
              }, []),
              (0, a.jsx)(uK, {
                status: p,
                passkeySignupFlow: u,
                error: g,
                onRetry: w,
              })
            );
          },
        },
        uJ = T.zo.span.withConfig({
          displayName: "SubtitleText",
          componentId: "sc-7ff4a13e-0",
        })(["white-space:pre-wrap;"]),
        u0 = ({
          title: e = "Log in or create a new account?",
          subtitle:
            t = "Create a new account with a passkey or use a passkey to log in to an existing account.",
          onSignup: n,
          onLogin: r,
        }) =>
          (0, a.jsx)(rS, {
            title: e,
            subtitle: t,
            icon: y.Z,
            primaryCta: { label: "Create new account", onClick: n },
            secondaryCta: { label: "Log in with a passkey", onClick: r },
            watermark: !0,
          }),
        u1 = {
          component: () => {
            let { enabled: e, token: t } = np(),
              { navigate: n, setModalData: r } = ap(),
              { initSignupWithPasskey: i, initLoginWithPasskey: o } = (0,
              j.u)();
            return (0, a.jsx)(u0, {
              onSignup: async () => {
                e && !t
                  ? (r({
                      passkeyAuthModalData: { passkeySignupFlow: !0 },
                      captchaModalData: {
                        callback: (e) =>
                          i({ captchaToken: e, withPrivyUi: !0 }),
                        userIntentRequired: !1,
                        onSuccessNavigateTo: uX,
                        onErrorNavigateTo: sg,
                      },
                    }),
                    n(lb))
                  : (await i({ withPrivyUi: !0 }),
                    r({ passkeyAuthModalData: { passkeySignupFlow: !0 } }),
                    n(uX));
              },
              onLogin: async () => {
                e && !t
                  ? (r({
                      passkeyAuthModalData: { passkeySignupFlow: !1 },
                      captchaModalData: {
                        callback: (e) =>
                          o({ captchaToken: e, withPrivyUi: !0 }),
                        userIntentRequired: !1,
                        onSuccessNavigateTo: uX,
                        onErrorNavigateTo: sg,
                      },
                    }),
                    n(lb))
                  : (await o({ withPrivyUi: !0 }),
                    r({ passkeyAuthModalData: { passkeySignupFlow: !1 } }),
                    n(uX));
              },
            });
          },
        },
        u2 = () => {
          let { enabled: e, token: t } = np(),
            { navigate: n, setModalData: r, data: i } = ap(),
            o = ar(),
            { initLoginWithPasskey: s } = (0, j.u)(),
            l = () => {
              o.loginConfig.passkeysForSignupEnabled
                ? n(u1)
                : (async () => {
                    e && !t
                      ? (r({
                          passkeyAuthModalData: { passkeySignupFlow: !1 },
                          captchaModalData: {
                            callback: (e) =>
                              s({ captchaToken: e, withPrivyUi: !0 }),
                            userIntentRequired: !1,
                            onSuccessNavigateTo: uX,
                            onErrorNavigateTo: sg,
                          },
                        }),
                        n(lb))
                      : (await s({ withPrivyUi: !0 }),
                        r({ passkeyAuthModalData: { passkeySignupFlow: !1 } }),
                        n(uX));
                  })();
            };
          return 0 ===
            (0, C.useMemo)(() => {
              let e = i?.login?.loginMethods;
              return e
                ? e.filter((e) => "passkey" !== e).length
                : Object.entries(o.loginMethods)
                    .filter(([e, t]) => t)
                    .filter(([e]) => "passkey" !== e).length;
            }, [o.loginMethods, i?.login])
            ? (0, a.jsxs)(aT, {
                onClick: l,
                children: [(0, a.jsx)(e9.Z, {}), " Continue with passkey"],
              })
            : (0, a.jsx)(oJ, {
                as: "button",
                onClick: l,
                size: "sm",
                variant: "navigation",
                style: { width: "100%", justifyContent: "center" },
                children: "I have a passkey",
              });
        },
        u3 = ({ value: e, onChange: t }) =>
          (0, a.jsx)("select", {
            value: e,
            onChange: t,
            children: ed.s5.map((e) =>
              (0, a.jsxs)(
                "option",
                { value: e.code, children: [e.code, " +", e.callCode] },
                e.code
              )
            ),
          }),
        u4 = (0, C.forwardRef)((e, t) => {
          let n = ar(),
            [r, i] = (0, C.useState)(!1),
            { accountType: o } = oq(),
            [s, l] = (0, C.useState)(""),
            [c, d] = (0, C.useState)(n?.intl.defaultCountry ?? "US"),
            u = (0, ed.Y0)(s, c),
            p = (0, ed.KX)(c),
            h = (0, ed.g6)(c),
            g = (0, eu.G)(c),
            f = !u,
            [m, y] = (0, C.useState)(!1),
            w = g.length,
            v = (t) => {
              let n = t.target.value;
              d(n),
                l(""),
                e.onChange &&
                  e.onChange({
                    rawPhoneNumber: s,
                    qualifiedPhoneNumber: (0, ed.un)(s, n),
                    countryCode: n,
                    isValid: (0, ed.Y0)(s, c),
                  });
            },
            x = (t, n) => {
              try {
                let a =
                  t.replace(/\D/g, "") === s.replace(/\D/g, "")
                    ? t
                    : p.input(t);
                l(a),
                  e.onChange &&
                    e.onChange({
                      rawPhoneNumber: a,
                      qualifiedPhoneNumber: (0, ed.un)(t, n),
                      countryCode: n,
                      isValid: (0, ed.Y0)(t, n),
                    });
              } catch (e) {
                console.error("Error processing phone number:", e);
              }
            },
            b = () => {
              y(!0);
              let t = (0, ed.un)(s, c);
              e.onSubmit({
                rawPhoneNumber: s,
                qualifiedPhoneNumber: t,
                countryCode: c,
                isValid: (0, ed.Y0)(s, c),
              }).finally(() => y(!1));
            };
          return (
            (0, C.useEffect)(() => {
              if (e.defaultValue) {
                let t = (0, ed.IS)(e.defaultValue);
                p.reset(),
                  v({ target: { value: t.countryCode } }),
                  x(t.phone, t.countryCode);
              }
            }, [e.defaultValue]),
            (0, a.jsxs)(a.Fragment, {
              children: [
                (0, a.jsx)(u5, {
                  children: (0, a.jsxs)(u6, {
                    $callingCodeLength: w,
                    $stacked: e.stacked,
                    children: [
                      (0, a.jsx)(u3, { value: c, onChange: v }),
                      (0, a.jsx)("input", {
                        ref: t,
                        id: "phone-number-input",
                        className: "login-method-button",
                        type: "tel",
                        placeholder: h,
                        onFocus: () => i(!0),
                        onChange: (e) => {
                          x(e.target.value, c);
                        },
                        onKeyUp: (e) => {
                          "Enter" === e.key && b();
                        },
                        value: s,
                        autoComplete: "tel",
                      }),
                      "phone" !== o || r || e.hideRecent
                        ? e.stacked || e.noIncludeSubmitButton
                          ? (0, a.jsx)("span", {})
                          : (0, a.jsx)(aJ, {
                              isSubmitting: m,
                              onClick: b,
                              disabled: f,
                              children: "Submit",
                            })
                        : (0, a.jsx)(dg, { color: "gray", children: "Recent" }),
                    ],
                  }),
                }),
                e.stacked && !e.noIncludeSubmitButton
                  ? (0, a.jsx)(a$, {
                      loading: m,
                      loadingText: null,
                      onClick: b,
                      disabled: f,
                      children: "Submit",
                    })
                  : null,
              ],
            })
          );
        }),
        u5 = T.zo.div.withConfig({
          displayName: "InputContainer",
          componentId: "sc-545daacd-0",
        })(["width:100%;"]),
        u6 = T.zo.label.withConfig({
          displayName: "PhoneNumberInput",
          componentId: "sc-545daacd-1",
        })(
          [
            "--country-code-dropdown-width:calc(54px + calc(12 * ",
            "px));--phone-input-extra-padding-left:calc(12px + calc(3 * ",
            "px));display:block;position:relative;width:100%;@media (min-width:441px){--country-code-dropdown-width:calc(52px + calc(10 * ",
            "px));}&& > select{font-size:16px;height:24px;position:absolute;margin:13px calc(var(--country-code-dropdown-width) / 4);line-height:24px;width:var(--country-code-dropdown-width);background-color:var(--privy-color-background);background-size:auto;background-position-x:right;cursor:pointer;@media (min-width:441px){font-size:14px;width:var(--country-code-dropdown-width);}:focus{outline:none;box-shadow:none;}}&& > input{font-size:16px;line-height:24px;color:var(--privy-color-foreground);overflow:hidden;white-space:nowrap;text-overflow:ellipsis;width:calc(100% - var(--country-code-dropdown-width));padding:12px 88px 12px calc(var(--country-code-dropdown-width) + var(--phone-input-extra-padding-left));padding-right:",
            ";flex-grow:1;background:var(--privy-color-background);border:1px solid var(--privy-color-foreground-4);border-radius:var(--privy-border-radius-md);width:100%;:focus{outline:none;border-color:var(--privy-color-accent);}:autofill,:-webkit-autofill{background:var(--privy-color-background);}@media (min-width:441px){font-size:14px;padding-right:78px;}}&& > :last-child{right:16px;position:absolute;top:50%;transform:translate(0,-50%);}&& > button:last-child{right:0px;line-height:24px;padding:13px 17px;:focus{outline:none;border-color:var(--privy-color-accent);}}&& > input::placeholder{color:var(--privy-color-foreground-3);}",
          ],
          (e) => e.$callingCodeLength,
          (e) => e.$callingCodeLength,
          (e) => e.$callingCodeLength,
          (e) => (e.$stacked ? "16px" : "88px")
        ),
        u8 = ({ isEditable: e, setIsEditable: t, defaultValue: n }) => {
          let r = (0, C.useRef)(null),
            { authenticated: i } = (0, k.u)(),
            { navigate: o, setModalData: s, currentScreen: l, data: c } = ap(),
            { initLoginWithSms: d } = (0, j.u)(),
            { enabled: u, token: p } = np(),
            { whatsAppEnabled: h } = ar();
          return (0, a.jsxs)(a.Fragment, {
            children: [
              (0, a.jsx)(aS, {
                $if: !e,
                children: (0, a.jsx)(u4, {
                  ref: r,
                  onSubmit: async function ({ qualifiedPhoneNumber: e }) {
                    if (!u || p || i)
                      try {
                        await d({
                          phoneNumber: e,
                          captchaToken: p,
                          withPrivyUi: !0,
                          disableSignup: c?.login?.disableSignup,
                        }),
                          o(pC);
                      } catch (e) {
                        s({
                          errorModalData: { error: e, previousScreen: l || pD },
                        }),
                          o(sg);
                      }
                    else
                      s({
                        captchaModalData: {
                          callback: (t) =>
                            d({
                              phoneNumber: e,
                              captchaToken: t,
                              withPrivyUi: !0,
                              disableSignup: c?.login?.disableSignup,
                            }),
                          userIntentRequired: !1,
                          onSuccessNavigateTo: pC,
                          onErrorNavigateTo: sg,
                        },
                      }),
                        o(lb);
                  },
                  defaultValue: n,
                }),
              }),
              (0, a.jsx)(aS, {
                $if: e,
                children: (0, a.jsxs)(aT, {
                  onClick: () => {
                    t(),
                      setTimeout(() => {
                        r.current?.focus();
                      }, 0);
                  },
                  children: [
                    (0, a.jsx)(aA, { children: (0, a.jsx)(w.Z, {}) }),
                    "Continue with ",
                    h ? "WhatsApp" : "SMS",
                  ],
                }),
              }),
            ],
          });
        },
        u7 = {
          apple: { logo: tU, displayName: "Apple" },
          discord: { logo: tO, displayName: "Discord" },
          github: { logo: tH, displayName: "GitHub" },
          google: { logo: tV, displayName: "Google" },
          linkedin: { logo: tq, displayName: "LinkedIn" },
          spotify: { logo: tG, displayName: "Spotify" },
          instagram: { logo: t$, displayName: "Instagram" },
          twitter: { logo: tK, displayName: "Twitter" },
          tiktok: { logo: tY, displayName: "TikTok" },
          line: { logo: tZ, displayName: "LINE" },
          twitch: { logo: tQ, displayName: "Twitch" },
        },
        u9 = ({ provider: e }) => {
          let { enabled: t, token: n } = np(),
            { navigate: r, setModalData: i, data: o } = ap(),
            [s, l] = (0, C.useState)(!1),
            c = ar(),
            { initLoginWithOAuth: d } = (0, j.u)(),
            { accountType: u } = oq(),
            p = (0, C.useMemo)(
              () =>
                u &&
                "guest" !== u &&
                "authorization_key" !== u &&
                "cross_app" !== u
                  ? oU(u)
                  : null,
              [u]
            ),
            { displayName: h, logo: g } = (0, C.useMemo)(() => {
              if ((0, k.i)(e)) {
                let t = c.customOAuthProviders.find((t) => t.provider === e),
                  n = t.provider_icon_url,
                  r = t.provider_display_name;
                return {
                  displayName: r,
                  logo: ({ style: e }) =>
                    (0, a.jsx)("img", { alt: `${r} logo`, src: n, style: e }),
                };
              }
              return u7[e];
            }, [e, c.customOAuthProviders]);
          return (0, a.jsxs)(aT, {
            onClick: () => {
              l(!0),
                setTimeout(() => {
                  l(!1);
                }, 2e3),
                t && !n
                  ? (i({
                      captchaModalData: {
                        callback: (t) => d(e, t, o?.login?.disableSignup),
                        userIntentRequired: !0,
                        onSuccessNavigateTo: null,
                        onErrorNavigateTo: sg,
                      },
                    }),
                    r(lb))
                  : d(e, void 0, o?.login?.disableSignup);
            },
            disabled: s,
            children: [
              (0, a.jsx)(aA, {
                $fullSize: !0,
                children: (0, a.jsx)(g, {
                  style: { width: "32px", height: "32px" },
                }),
              }),
              h,
              p?.loginMethod === e &&
                (0, a.jsx)(pe, { color: "gray", children: "Recent" }),
            ],
          });
        },
        pe = (0, T.zo)(dg).withConfig({
          displayName: "StyledChip",
          componentId: "sc-45a4e2df-0",
        })(["margin-left:auto;"]);
      function pt(e) {
        return (0, a.jsxs)("svg", {
          xmlns: "http://www.w3.org/2000/svg",
          viewBox: "0 0 512 512",
          ...e,
          children: [
            (0, a.jsx)("rect", {
              width: "512",
              height: "512",
              rx: "15%",
              fill: "#37aee2",
            }),
            (0, a.jsx)("path", {
              fill: "#c8daea",
              d: "M199 404c-11 0-10-4-13-14l-32-105 245-144",
            }),
            (0, a.jsx)("path", {
              fill: "#a9c9dd",
              d: "M199 404c7 0 11-4 16-8l45-43-56-34",
            }),
            (0, a.jsx)("path", {
              fill: "#f6fbfe",
              d: "M204 319l135 99c14 9 26 4 30-14l55-258c5-22-9-32-24-25L79 245c-21 8-21 21-4 26l83 26 190-121c9-5 17-3 11 4",
            }),
          ],
        });
      }
      let pn = ({ success: e, errorMessage: t, onRetry: n }) => {
          let r = e
            ? "Successfully connected with Telegram"
            : t
            ? t.message
            : "Verifying connection to Telegram";
          return (0, a.jsx)(rS, {
            title: r,
            subtitle: e
              ? "You're good to go!"
              : t
              ? t.detail
              : "Just a few moments more",
            icon: pt,
            iconVariant: "loading",
            iconLoadingStatus: { success: e, fail: !!t },
            secondaryCta:
              t?.retryable && n ? { label: "Retry", onClick: n } : void 0,
            watermark: !0,
          });
        },
        pa = {
          component: () => {
            let { authenticated: e, logout: t, ready: n, user: r } = (0, k.u)(),
              {
                setModalData: i,
                navigate: o,
                resetNavigation: s,
                data: l,
              } = ap(),
              c = ar(),
              {
                initLoginWithTelegram: d,
                loginWithTelegram: u,
                updateWallets: p,
                setReadyToTrue: h,
                closePrivyModal: g,
                createAnalyticsEvent: f,
                getAuthMeta: m,
              } = (0, j.u)(),
              [y, w] = (0, C.useState)(!1),
              [v, x] = (0, C.useState)(void 0),
              b = np();
            async function T() {
              try {
                let t = await (async function () {
                  let t;
                  if (!e) {
                    if (b.enabled && "error" === b.status)
                      throw new nd(b.error, null, eh.h.CAPTCHA_FAILURE);
                    return (
                      b.enabled &&
                        "success" !== b.status &&
                        (b.execute(), (t = await b.waitForResult())),
                      t
                    );
                  }
                })();
                await u({ captchaToken: t }), w(!0), h(!0);
              } catch (n) {
                if (n?.privyErrorCode === eh.h.ALLOWLIST_REJECTED)
                  return x(void 0), s(), void o(lv);
                if (n?.privyErrorCode === eh.h.USER_LIMIT_REACHED)
                  return (
                    console.error(new eh.ab(n).toString()),
                    x(void 0),
                    s(),
                    void o(lE)
                  );
                if (n?.privyErrorCode === eh.h.USER_DOES_NOT_EXIST)
                  return x(void 0), s(), void o(o6);
                if (
                  n?.privyErrorCode === eh.h.ACCOUNT_TRANSFER_REQUIRED &&
                  n.data?.data?.nonce
                )
                  return (
                    x(void 0),
                    s(),
                    i({
                      accountTransfer: {
                        nonce: n.data?.data?.nonce,
                        account: n.data?.data?.subject,
                        telegramAuthResult: m()?.telegramAuthResult,
                        telegramWebAppData: m()?.telegramWebAppData,
                        displayName: n.data?.data?.account?.displayName,
                        linkMethod: "telegram",
                        embeddedWalletAddress:
                          n.data?.data?.otherUser?.embeddedWalletAddress,
                      },
                    }),
                    void o(sS)
                  );
                let { retryable: e, detail: t } = ng(n);
                x({
                  retryable: e,
                  detail: t,
                  message: "Authentication failed",
                });
              }
            }
            return (
              (0, C.useEffect)(() => {
                T();
              }, []),
              (0, C.useEffect)(() => {
                if (!(n && e && y && r)) return;
                if (c?.legal.requireUsersAcceptTerms && !r.hasAcceptedTerms) {
                  let e = setTimeout(() => {
                    o(sM);
                  }, th);
                  return () => clearTimeout(e);
                }
                if (o4(r, c.embeddedWallets)) {
                  let e = setTimeout(() => {
                    i({
                      createWallet: {
                        onSuccess: () => {},
                        onFailure: (e) => {
                          console.error(e),
                            f({
                              eventName:
                                "embedded_wallet_creation_failure_logout",
                              payload: {
                                error: e,
                                provider: "telegram",
                                screen: "TelegramAuthScreen",
                              },
                            }),
                            t();
                        },
                        callAuthOnSuccessOnClose: !0,
                      },
                    }),
                      o(s_);
                  }, th);
                  return () => clearTimeout(e);
                }
                p();
                let a = setTimeout(
                  () => g({ shouldCallAuthOnSuccess: !0, isSuccess: !0 }),
                  th
                );
                return () => clearTimeout(a);
              }, [n, e, y, r]),
              (0, a.jsx)(pn, {
                success: y,
                errorMessage: v,
                onRetry: v?.retryable
                  ? async () => {
                      try {
                        x(void 0),
                          l?.telegramAuthModalData?.seamlessAuth ||
                            (await d(void 0, l?.login?.disableSignup)),
                          await T();
                      } catch (n) {
                        let { retryable: e, detail: t } = ng(n);
                        x({
                          retryable: e,
                          detail: t,
                          message: "Authentication failed",
                        });
                      }
                    }
                  : void 0,
              })
            );
          },
          isCaptchaRequired: !0,
        },
        pr = () => {
          let { enabled: e, token: t } = np(),
            { navigate: n, setModalData: r, data: i } = ap(),
            [o, s] = (0, C.useState)(!1),
            { initLoginWithTelegram: l } = (0, j.u)(),
            { accountType: c } = oq();
          async function d(e) {
            try {
              await l(e, i?.login?.disableSignup),
                r({ telegramAuthModalData: { seamlessAuth: !1 } }),
                n(pa);
            } catch (e) {
              console.error(e), s(!1);
            }
          }
          return (0, a.jsxs)(aT, {
            onClick: async function () {
              if ((s(!0), e && !t))
                return (
                  r({
                    captchaModalData: {
                      callback: d,
                      userIntentRequired: !0,
                      onSuccessNavigateTo: null,
                      onErrorNavigateTo: sg,
                    },
                  }),
                  void n(lb)
                );
              await d(t);
            },
            disabled: o,
            children: [
              (0, a.jsx)(pt, { width: 32, height: 32 }),
              "Telegram",
              "telegram" === c &&
                (0, a.jsx)(pi, { color: "gray", children: "Recent" }),
            ],
          });
        },
        pi = (0, T.zo)(dg).withConfig({
          displayName: "StyledChip",
          componentId: "sc-4b233cf1-0",
        })(["margin-left:auto;"]),
        po = ({ onClick: e, text: t, icon: n }) =>
          (0, a.jsxs)(aT, {
            onClick: e,
            children: [
              (0, a.jsx)(aA, { children: n }),
              (0, a.jsx)(av, { children: t }),
            ],
          }),
        ps = ({ connectOnly: e }) => {
          let { closePrivyModal: t } = (0, j.u)(),
            {
              data: n,
              setModalData: r,
              onUserCloseViaDialogOrKeybindRef: i,
              navigate: o,
            } = ap(),
            s = ar(),
            l = n?.login,
            c = s.appearance.walletList,
            d = l?.walletChainType ?? s.appearance.walletChainType,
            { accountType: u, walletClientType: p, chainType: h } = oq(),
            { wallets: g } = lt({ walletList: c, walletChainType: d }),
            f = (0, C.useMemo)(
              () =>
                u &&
                "guest" !== u &&
                "authorization_key" !== u &&
                "cross_app" !== u
                  ? oU(u)
                  : null,
              [u]
            ),
            {
              email: m,
              sms: y,
              google: w,
              twitter: v,
              discord: x,
              github: b,
              spotify: T,
              instagram: A,
              tiktok: S,
              line: I,
              twitch: E,
              linkedin: N,
              apple: _,
              wallet: M,
              farcaster: F,
              telegram: z,
            } = (0, C.useMemo)(
              () => (l?.loginMethods ? (0, ep.W)(l.loginMethods, !0) : null),
              [l]
            ) ?? s.loginMethods,
            L = s.customOAuthProviders,
            { passkey: P } = s.loginMethods,
            D = [
              m && "email",
              y && "sms",
              w && "google",
              v && "twitter",
              x && "discord",
              b && "github",
              T && "spotify",
              A && "instagram",
              S && "tiktok",
              I && "line",
              E && "twitch",
              N && "linkedin",
              _ && "apple",
              F && "farcaster",
              z && "telegram",
              ...L.map((e) => e.provider),
            ].filter((e) => !!e),
            W = D.length > 0,
            R = (0, C.useMemo)(
              () =>
                M && !W
                  ? "web3-first"
                  : (M && s?.appearance.loginGroupPriority) || "web2-first",
              [M, W, s?.appearance.loginGroupPriority]
            ),
            B = s?.appearance.hideDirectWeb2Inputs,
            [U, O] = (0, C.useState)("default"),
            [H, V] = (0, C.useState)(
              ph({
                mostRecentlyUsedAccountType: u,
                smsAvailable: y,
                emailAvailable: m,
                prefilledType: l?.prefill?.type,
              })
            );
          (0, C.useEffect)(() => {
            V(
              ph({
                mostRecentlyUsedAccountType: u,
                smsAvailable: y,
                emailAvailable: m,
                prefilledType: l?.prefill?.type,
              })
            );
          }, [m, y, u]);
          let $ = () => {
            t({ shouldCallAuthOnSuccess: !0 }),
              setTimeout(() => {
                O("default");
              }, 150);
          };
          i.current = $;
          let Z = [];
          p && M
            ? Z.push(p)
            : f?.loginMethod &&
              D.includes(f.loginMethod) &&
              Z.push(f.loginMethod);
          let q = (t) => {
              if ("email" === t)
                return (0, a.jsx)(
                  pF,
                  {
                    isEditable: "email" === H,
                    setIsEditable: () => {
                      V("email");
                    },
                    defaultValue:
                      "email" === l?.prefill?.type ? l.prefill.value : void 0,
                  },
                  t
                );
              if ("sms" === t)
                return (0, a.jsx)(
                  u8,
                  {
                    isEditable: "sms" === H,
                    setIsEditable: () => {
                      V("sms");
                    },
                    defaultValue:
                      "phone" === l?.prefill?.type ? l.prefill.value : void 0,
                  },
                  t
                );
              if ("apple" === t)
                return (0, a.jsx)(u9, { provider: "apple" }, t);
              if ("discord" === t)
                return (0, a.jsx)(u9, { provider: "discord" }, t);
              if ("farcaster" === t) return (0, a.jsx)(uY, {}, t);
              if ("github" === t)
                return (0, a.jsx)(u9, { provider: "github" }, t);
              if ("google" === t)
                return (0, a.jsx)(u9, { provider: "google" }, t);
              if ("linkedin" === t)
                return (0, a.jsx)(u9, { provider: "linkedin" }, t);
              if ("tiktok" === t)
                return (0, a.jsx)(u9, { provider: "tiktok" }, t);
              if ("line" === t) return (0, a.jsx)(u9, { provider: "line" }, t);
              if ("twitch" === t)
                return (0, a.jsx)(u9, { provider: "twitch" }, t);
              if ("spotify" === t)
                return (0, a.jsx)(u9, { provider: "spotify" }, t);
              if ("instagram" === t)
                return (0, a.jsx)(u9, { provider: "instagram" }, t);
              if ("twitter" === t)
                return (0, a.jsx)(u9, { provider: "twitter" }, t);
              if ("telegram" === t) return (0, a.jsx)(pr, {}, t);
              if ((0, k.i)(t)) return (0, a.jsx)(u9, { provider: t }, t);
              let n = g.findIndex(({ id: e }) => e === s2.normalize(t)),
                i = "solana" === h ? "solana-only" : "ethereum-only";
              return (0, a.jsx)(la, {
                recent: !0,
                index: n,
                data: {
                  wallets: g,
                  walletChainType: i,
                  handleWalletClick(t) {
                    r((e) => ({
                      ...e,
                      externalConnectWallet: {
                        walletList: c,
                        walletChainType: i,
                        preSelectedWalletId: t.id,
                      },
                    })),
                      o(e ? uE : lz);
                  },
                },
              });
            },
            G = g.filter((e) => e.id !== s2.normalize(p || "")),
            Y = G.map((t, n) =>
              (0, a.jsx)(
                la,
                {
                  index: n,
                  data: {
                    walletChainType: d,
                    wallets: G,
                    handleWalletClick(t) {
                      r((e) => ({
                        ...e,
                        externalConnectWallet: {
                          walletList: c,
                          walletChainType: d,
                          preSelectedWalletId: t.id,
                        },
                      })),
                        o(e ? uE : lz);
                    },
                  },
                },
                t.id
              )
            ),
            Q = D.filter((e) => e !== f?.loginMethod).flatMap(q),
            K = Z.flatMap(q);
          "web3-first" === R && "default" === U
            ? Y.unshift(...K)
            : "web2-first" === R && Q.unshift(...K);
          let X = "web2-overflow" === U ? () => O("default") : void 0,
            J = D.filter((e) => "email" !== e && "sms" !== e),
            ee = pd({ priority: R, email: m, sms: y, social: J }),
            et = pu({ priority: R, email: m, sms: y, social: J }),
            en = (0, a.jsx)(dm, {
              text: pp({ priority: R }),
              onClick: () => {
                r({
                  ...n,
                  externalConnectWallet: {
                    walletChainType:
                      l?.walletChainType ?? s.appearance.walletChainType,
                  },
                }),
                  o(e ? uE : lz);
              },
            }),
            ea = (0, a.jsx)(po, {
              text: ee,
              icon: et,
              onClick: () => O("web2-overflow"),
            }),
            er = B ? 0 : 1,
            ei = M && Y.length > 0,
            eo = 0 === Q.length && M && 0 === Y.length,
            es = 5 - (ei ? 1 : 0),
            el = "default" === U && s?.appearance.logo,
            ec = "default" === U && s.appearance.loginMessage;
          return (0, a.jsxs)(rS, {
            title: s.appearance.landingHeader,
            icon: el ? (0, a.jsx)(oG, {}) : void 0,
            iconVariant: el ? "logo" : void 0,
            onClose: $,
            showClose: !0,
            onBack: X,
            showBack: !!X,
            helpText:
              s || (P && "default" === U)
                ? (0, a.jsxs)(a.Fragment, {
                    children: [
                      P && "default" === U && (0, a.jsx)(u2, {}),
                      s && (0, a.jsx)(aM, { app: s }),
                    ],
                  })
                : void 0,
            watermark: !0,
            children: [
              ec &&
                ("string" == typeof s.appearance.loginMessage
                  ? (0, a.jsx)(pl, { children: s.appearance.loginMessage })
                  : (0, a.jsx)(pc, { children: s.appearance.loginMessage })),
              (0, a.jsx)(aC, {
                $colorScheme: s.appearance.palette.colorScheme,
                children:
                  "default" === U && "web2-first" === R
                    ? (0, a.jsxs)(a.Fragment, {
                        children: [
                          Q.length > es ? Q.slice(0, es - 1) : Q,
                          Q.length > es && ea,
                          ei && en,
                          eo &&
                            (0, a.jsx)(dy, {
                              chainType: s.appearance.walletChainType,
                            }),
                        ],
                      })
                    : "default" === U && "web3-first" === R
                    ? (0, a.jsxs)(a.Fragment, {
                        children: [
                          M &&
                            (0, a.jsxs)(a.Fragment, {
                              children: [
                                Y.length > es ? Y.slice(0, es - 1) : Y,
                                Y.length > es && en,
                              ],
                            }),
                          Q.length > er && ea,
                          Q.length === er && Q[0],
                          eo &&
                            (0, a.jsx)(dy, {
                              chainType: s.appearance.walletChainType,
                            }),
                        ],
                      })
                    : "web2-overflow" === U
                    ? (0, a.jsx)(a.Fragment, {
                        children: "web3-first" === R ? Q : Q.slice(3),
                      })
                    : null,
              }),
            ],
          });
        },
        pl = T.zo.div.withConfig({
          displayName: "StyledSubtitle",
          componentId: "sc-b9aad528-0",
        })(["text-align:center;font-size:14px;margin-bottom:24px;"]),
        pc = T.zo.div.withConfig({
          displayName: "MessageContainer",
          componentId: "sc-b9aad528-1",
        })(["margin-bottom:24px;"]),
        pd = ({ priority: e, email: t, sms: n, social: a }) =>
          "web2-first" === e
            ? "Other socials"
            : (t && n && a.length > 0) || (t && a.length > 0)
            ? "Log in with email or socials"
            : n && a.length > 0
            ? "Log in with sms or socials"
            : t && n
            ? "Continue with email or sms"
            : t
            ? "Continue with email"
            : n
            ? "Continue with sms"
            : "Log in with a social account",
        pu = ({ priority: e, email: t, sms: n, social: r }) =>
          "web2-first" === e || r.length > 0
            ? (0, a.jsx)(v.Z, {})
            : t && n
            ? (0, a.jsx)(lp, {})
            : t
            ? (0, a.jsx)(x.Z, {})
            : n
            ? (0, a.jsx)(w.Z, {})
            : null,
        pp = ({ priority: e }) =>
          "web2-first" === e ? "Continue with a wallet" : "Other wallets",
        ph = ({
          mostRecentlyUsedAccountType: e,
          smsAvailable: t,
          emailAvailable: n,
          prefilledType: a,
        }) =>
          (n && (("email" === e && "phone" !== a) || "email" === a)) ||
          !t ||
          ("phone" !== e && "phone" !== a)
            ? "email"
            : "sms",
        pg = {
          component: () => {
            let e = ar();
            return e.loginMethodsAndOrder &&
              e.loginMethodsAndOrder.primary.length > 0
              ? (0, a.jsx)(pz, { connectOnly: !0 })
              : (0, a.jsx)(ps, { connectOnly: !0 });
          },
        },
        pf = ({
          contactMethod: e,
          authFlow: t,
          appName: n = "Privy",
          whatsAppEnabled: r = !1,
          onBack: i,
          onCodeSubmit: o,
          onResend: s,
          errorMessage: l,
          success: c = !1,
          resendCountdown: d = 0,
          onInvalidInput: u,
          onClearError: p,
        }) => {
          let [h, g] = (0, C.useState)(py);
          (0, C.useEffect)(() => {
            l || g(py);
          }, [l]);
          let f = async (e) => {
            e.preventDefault();
            let t = e.currentTarget.value.replace(" ", "");
            if ("" === t) return;
            if (isNaN(Number(t))) return void u?.("Code should be numeric");
            p?.();
            let n = Number(e.currentTarget.name?.charAt(5)),
              a = [...(t || [""])].slice(0, pm - n),
              r = [...h.slice(0, n), ...a, ...h.slice(n + a.length)];
            g(r);
            let i = Math.min(Math.max(n + a.length, 0), pm - 1);
            if (!isNaN(Number(e.currentTarget.value))) {
              let e = document.querySelector(`input[name=code-${i}]`);
              e?.focus();
            }
            if (r.every((e) => e && !isNaN(+e))) {
              let e = document.querySelector(`input[name=code-${i}]`);
              e?.blur(), await o?.(r.join(""));
            }
          };
          return (0, a.jsx)(rS, {
            title: "Enter confirmation code",
            subtitle: (0, a.jsxs)(
              "span",
              "email" === t
                ? {
                    children: [
                      "Please check ",
                      (0, a.jsx)(pI, { children: e }),
                      " for an email from privy.io and enter your code below.",
                    ],
                  }
                : {
                    children: [
                      "Please check ",
                      (0, a.jsx)(pI, { children: e }),
                      " for a",
                      r ? " WhatsApp" : "",
                      " message from ",
                      n,
                      " and enter your code below.",
                    ],
                  }
            ),
            icon: "email" === t ? ex.Z : eb.Z,
            onBack: i,
            showBack: !0,
            helpText: (0, a.jsxs)(pA, {
              children: [
                (0, a.jsxs)("span", {
                  children: [
                    "Didn't get ",
                    "email" === t ? "an email" : "a message",
                    "?",
                  ],
                }),
                d
                  ? (0, a.jsxs)(pS, {
                      children: [
                        (0, a.jsx)(ev.Z, {
                          color: "var(--privy-color-foreground)",
                          strokeWidth: 1.33,
                          height: "12px",
                          width: "12px",
                        }),
                        (0, a.jsx)("span", { children: "Code sent" }),
                      ],
                    })
                  : (0, a.jsx)(oJ, {
                      as: "button",
                      size: "sm",
                      onClick: s,
                      children: "Resend code",
                    }),
              ],
            }),
            children: (0, a.jsx)(pj, {
              children: (0, a.jsx)(rK, {
                children: (0, a.jsxs)(pk, {
                  children: [
                    (0, a.jsx)("div", {
                      children: h.map((e, t) =>
                        (0, a.jsx)(
                          "input",
                          {
                            name: `code-${t}`,
                            type: "text",
                            value: h[t],
                            onChange: f,
                            onKeyUp: (e) => {
                              "Backspace" === e.key &&
                                ((e) => {
                                  if (
                                    (p?.(),
                                    g([
                                      ...h.slice(0, e),
                                      "",
                                      ...h.slice(e + 1),
                                    ]),
                                    e > 0)
                                  ) {
                                    let t = document.querySelector(
                                      `input[name=code-${e - 1}]`
                                    );
                                    t?.focus();
                                  }
                                })(t);
                            },
                            inputMode: "numeric",
                            autoFocus: 0 === t,
                            pattern: "[0-9]",
                            className: `${c ? "success" : ""} ${
                              l ? "fail" : ""
                            }`,
                            autoComplete: eC.tq ? "one-time-code" : "off",
                          },
                          t
                        )
                      ),
                    }),
                    (0, a.jsx)(pT, {
                      $fail: !!l,
                      $success: c,
                      children: (0, a.jsx)("span", {
                        children:
                          "Invalid or expired verification code" === l
                            ? "Incorrect code"
                            : l || (c ? "Success!" : ""),
                      }),
                    }),
                  ],
                }),
              }),
            }),
          });
        },
        pm = 6,
        py = Array(6).fill("");
      var pw,
        pv,
        px =
          (((pw = px || {})[(pw.RESET_AFTER_DELAY = 0)] = "RESET_AFTER_DELAY"),
          (pw[(pw.CLEAR_ON_NEXT_VALID_INPUT = 1)] =
            "CLEAR_ON_NEXT_VALID_INPUT"),
          pw),
        pb =
          (((pv = pb || {})[(pv.EMAIL = 0)] = "EMAIL"),
          (pv[(pv.SMS = 1)] = "SMS"),
          pv);
      let pC = {
          component: () => {
            let {
                navigate: e,
                lastScreen: t,
                navigateBack: n,
                setModalData: r,
                onUserCloseViaDialogOrKeybindRef: i,
              } = ap(),
              o = ar(),
              {
                closePrivyModal: s,
                resendEmailCode: l,
                resendSmsCode: c,
                getAuthMeta: d,
                loginWithCode: u,
                updateWallets: p,
                createAnalyticsEvent: h,
              } = (0, j.u)(),
              { authenticated: g, logout: f, user: m } = (0, k.u)(),
              { whatsAppEnabled: y } = ar(),
              [w, v] = (0, C.useState)(!1),
              [x, b] = (0, C.useState)(null),
              [T, A] = (0, C.useState)(null),
              [S, I] = (0, C.useState)(0);
            i.current = () => null;
            let E = d()?.email ? 0 : 1,
              N = 0 === E ? d()?.email || "" : d()?.phoneNumber || "";
            return (
              (0, C.useEffect)(() => {
                if (S) {
                  let e = setTimeout(() => {
                    I(S - 1);
                  }, 1e3);
                  return () => clearTimeout(e);
                }
              }, [S]),
              (0, C.useEffect)(() => {
                if (g && w && m) {
                  if (o?.legal.requireUsersAcceptTerms && !m.hasAcceptedTerms) {
                    let t = setTimeout(() => {
                      e(sM);
                    }, 900);
                    return () => clearTimeout(t);
                  }
                  if (o4(m, o.embeddedWallets)) {
                    let t = setTimeout(() => {
                      r({
                        createWallet: {
                          onSuccess: () => {},
                          onFailure: (e) => {
                            console.error(e),
                              h({
                                eventName:
                                  "embedded_wallet_creation_failure_logout",
                                payload: {
                                  error: e,
                                  screen: "AwaitingPasswordlessCodeScreen",
                                },
                              }),
                              f();
                          },
                          callAuthOnSuccessOnClose: !0,
                        },
                      }),
                        e(s_);
                    }, 900);
                    return () => clearTimeout(t);
                  }
                  {
                    p();
                    let e = setTimeout(
                      () => s({ shouldCallAuthOnSuccess: !0, isSuccess: !0 }),
                      th
                    );
                    return () => clearTimeout(e);
                  }
                }
              }, [g, w, m]),
              (0, C.useEffect)(() => {
                if (x && 0 === T) {
                  let e = setTimeout(() => {
                    b(null), A(null);
                    let e = document.querySelector("input[name=code-0]");
                    e?.focus();
                  }, 1400);
                  return () => clearTimeout(e);
                }
              }, [x, T]),
              (0, a.jsx)(pf, {
                contactMethod: N,
                authFlow: 0 === E ? "email" : "sms",
                appName: o?.name,
                whatsAppEnabled: y,
                onBack: () => n(),
                onCodeSubmit: async (n) => {
                  try {
                    await u(n), v(!0);
                  } catch (n) {
                    if (
                      n instanceof eh.G &&
                      n.privyErrorCode === eh.h.INVALID_CREDENTIALS
                    )
                      b("Invalid or expired verification code"), A(0);
                    else if (
                      n instanceof eh.G &&
                      n.privyErrorCode === eh.h.CANNOT_LINK_MORE_OF_TYPE
                    )
                      b(n.message);
                    else {
                      if (
                        n instanceof eh.G &&
                        n.privyErrorCode === eh.h.USER_LIMIT_REACHED
                      )
                        return (
                          console.error(new eh.ab(n).toString()), void e(lE)
                        );
                      if (
                        n instanceof eh.G &&
                        n.privyErrorCode === eh.h.USER_DOES_NOT_EXIST
                      )
                        return void e(o6);
                      if (
                        n instanceof eh.G &&
                        n.privyErrorCode === eh.h.LINKED_TO_ANOTHER_USER
                      )
                        return (
                          r({
                            errorModalData: {
                              error: n,
                              previousScreen: t ?? pC,
                            },
                          }),
                          void e(sg, !1)
                        );
                      if (
                        n instanceof eh.G &&
                        n.privyErrorCode === eh.h.DISALLOWED_PLUS_EMAIL
                      )
                        return r({ inlineError: { error: n } }), void e(pg, !1);
                      if (
                        n instanceof eh.G &&
                        n.privyErrorCode === eh.h.ACCOUNT_TRANSFER_REQUIRED &&
                        n.data?.data?.nonce
                      )
                        return (
                          r({
                            accountTransfer: {
                              nonce: n.data?.data?.nonce,
                              account: N,
                              displayName: n.data?.data?.account?.displayName,
                              linkMethod: 0 === E ? "email" : "sms",
                              embeddedWalletAddress:
                                n.data?.data?.otherUser?.embeddedWalletAddress,
                            },
                          }),
                          void e(sS)
                        );
                      b("Issue verifying code"), A(0);
                    }
                  }
                },
                onResend: async () => {
                  I(30), 0 === E ? await l() : await c();
                },
                errorMessage: x || void 0,
                success: w,
                resendCountdown: S,
                onInvalidInput: (e) => {
                  b(e), A(1);
                },
                onClearError: () => {
                  1 === T && (b(null), A(null));
                },
              })
            );
          },
        },
        pj = T.zo.div.withConfig({
          displayName: "PasswordlessCodeContainer",
          componentId: "sc-63a7dae3-0",
        })([
          "display:flex;flex-direction:column;align-items:center;justify-content:center;margin:auto;gap:16px;flex-grow:1;width:100%;",
        ]),
        pk = T.zo.div.withConfig({
          displayName: "CodeInput",
          componentId: "sc-63a7dae3-1",
        })([
          "display:flex;flex-direction:column;width:100%;gap:12px;> div:first-child{display:flex;justify-content:center;gap:0.5rem;width:100%;border-radius:var(--privy-border-radius-sm);> input{border:1px solid var(--privy-color-foreground-4);background:var(--privy-color-background);border-radius:var(--privy-border-radius-sm);padding:8px 10px;height:48px;width:40px;text-align:center;font-size:18px;font-weight:600;color:var(--privy-color-foreground);transition:all 0.2s ease;}> input:focus{border:1px solid var(--privy-color-foreground);box-shadow:0 0 0 1px var(--privy-color-foreground);}> input:invalid{border:1px solid var(--privy-color-error);}> input.success{border:1px solid var(--privy-color-border-success);background:var(--privy-color-success-bg);}> input.fail{border:1px solid var(--privy-color-border-error);background:var(--privy-color-error-bg);animation:shake 180ms;animation-iteration-count:2;}}@keyframes shake{0%{transform:translate(1px,0px);}33%{transform:translate(-1px,0px);}67%{transform:translate(-1px,0px);}100%{transform:translate(1px,0px);}}",
        ]),
        pT = T.zo.div.withConfig({
          displayName: "InputHelp",
          componentId: "sc-63a7dae3-2",
        })(
          [
            "line-height:20px;min-height:20px;font-size:14px;font-weight:400;color:",
            ";display:flex;justify-content:center;width:100%;text-align:center;",
          ],
          (e) =>
            e.$success
              ? "var(--privy-color-success-dark)"
              : e.$fail
              ? "var(--privy-color-error-dark)"
              : "transparent"
        ),
        pA = T.zo.div.withConfig({
          displayName: "HelpTextContainer",
          componentId: "sc-63a7dae3-3",
        })([
          "display:flex;gap:8px;align-items:center;justify-content:center;width:100%;color:var(--privy-color-foreground-2);",
        ]),
        pS = T.zo.div.withConfig({
          displayName: "Badge",
          componentId: "sc-63a7dae3-4",
        })([
          "display:flex;align-items:center;justify-content:center;border-radius:var(--privy-border-radius-sm);padding:2px 8px;gap:4px;background:var(--privy-color-background-2);color:var(--privy-color-foreground-2);",
        ]),
        pI = T.zo.span.withConfig({
          displayName: "BoldWrappingSpan",
          componentId: "sc-63a7dae3-5",
        })([
          "font-weight:500;word-break:break-all;color:var(--privy-color-foreground);",
        ]),
        pE = (0, C.forwardRef)((e, t) => {
          let [n, r] = (0, C.useState)(e.defaultValue || ""),
            [i, o] = (0, C.useState)(""),
            [s, l] = (0, C.useState)(!1),
            { authenticated: c } = (0, k.u)(),
            { initLoginWithEmail: d } = (0, j.u)(),
            { navigate: u, setModalData: p, currentScreen: h, data: g } = ap(),
            { enabled: f, token: m } = np(),
            [y, w] = (0, C.useState)(!1),
            { accountType: v } = oq(),
            b = ar();
          (0, C.useEffect)(() => {
            !n &&
              b.disablePlusEmails &&
              g?.inlineError?.error instanceof eh.aa &&
              g?.inlineError?.error.privyErrorCode ===
                eh.h.DISALLOWED_PLUS_EMAIL &&
              !i &&
              o("Please enter a valid email address without a '+'."),
              i && o("");
          }, [n]);
          let T = t7(n),
            A = s || !T,
            S = () => {
              p({ login: g?.login, inlineError: void 0 }),
                !f || m || c
                  ? (l(!0),
                    d({
                      email: n,
                      captchaToken: m,
                      disableSignup: g?.login?.disableSignup,
                      withPrivyUi: !0,
                    })
                      .then(() => {
                        u(pC);
                      })
                      .catch((e) => {
                        p({
                          errorModalData: { error: e, previousScreen: h || pD },
                        }),
                          u(sg);
                      })
                      .finally(() => {
                        l(!1);
                      }))
                  : (p({
                      captchaModalData: {
                        callback: (e) =>
                          d({ email: n, captchaToken: e, withPrivyUi: !0 }),
                        userIntentRequired: !1,
                        onSuccessNavigateTo: pC,
                        onErrorNavigateTo: sg,
                      },
                    }),
                    u(lb));
            };
          return (0, a.jsxs)(a.Fragment, {
            children: [
              (0, a.jsxs)(pN, {
                children: [
                  i &&
                    (0, a.jsx)(sY, {
                      style: {
                        display: "block",
                        marginTop: "0.25rem",
                        textAlign: "left",
                      },
                      children: i,
                    }),
                  (0, a.jsxs)(p_, {
                    stacked: e.stacked,
                    $error: !!i,
                    children: [
                      (0, a.jsx)(pM, { children: (0, a.jsx)(x.Z, {}) }),
                      (0, a.jsx)("input", {
                        ref: t,
                        id: "email-input",
                        className: "login-method-button",
                        type: "email",
                        placeholder: "your@email.com",
                        onFocus: () => w(!0),
                        onChange: (e) => r(e.target.value),
                        onKeyUp: (e) => {
                          "Enter" === e.key && S();
                        },
                        value: n,
                        autoComplete: "email",
                      }),
                      "email" !== v || y
                        ? e.stacked
                          ? (0, a.jsx)("span", {})
                          : (0, a.jsx)(aJ, {
                              isSubmitting: s,
                              onClick: S,
                              disabled: A,
                              children: "Submit",
                            })
                        : (0, a.jsx)(dg, { color: "gray", children: "Recent" }),
                    ],
                  }),
                ],
              }),
              e.stacked
                ? (0, a.jsx)(a$, {
                    loadingText: null,
                    loading: s,
                    disabled: A,
                    onClick: S,
                    style: { width: "100%" },
                    children: "Submit",
                  })
                : null,
            ],
          });
        }),
        pN = sJ,
        p_ = sX,
        pM = (0, T.zo)(aA).withConfig({
          displayName: "StyledLoginMethodIconWrapper",
          componentId: "sc-e33d938a-0",
        })(["display:inline-flex;"]),
        pF = ({ isEditable: e, setIsEditable: t, defaultValue: n }) => {
          let r = (0, C.useRef)(null);
          return (0, a.jsxs)(a.Fragment, {
            children: [
              (0, a.jsx)(aS, {
                $if: !e,
                children: (0, a.jsx)(pE, { ref: r, defaultValue: n }),
              }),
              (0, a.jsx)(aS, {
                $if: e,
                children: (0, a.jsxs)(aT, {
                  onClick: () => {
                    t(),
                      setTimeout(() => {
                        r.current?.focus();
                      }, 0);
                  },
                  children: [
                    (0, a.jsx)(aA, { children: (0, a.jsx)(x.Z, {}) }),
                    "Continue with Email",
                  ],
                }),
              }),
            ],
          });
        },
        pz = ({ connectOnly: e }) => {
          let { closePrivyModal: t, connectors: n } = (0, j.u)(),
            { onUserCloseViaDialogOrKeybindRef: r, data: i } = ap(),
            o = ar(),
            {
              appearance: {
                palette: { colorScheme: s },
              },
            } = ar(),
            { accountType: l, walletClientType: c, chainType: d } = oq(),
            u = (0, C.useMemo)(
              () =>
                l &&
                "guest" !== l &&
                "authorization_key" !== l &&
                "cross_app" !== l
                  ? oU(l)
                  : null,
              [l]
            ),
            p = o.loginMethodsAndOrder?.primary ?? [],
            h = o.loginMethodsAndOrder?.overflow ?? [],
            g = (0, C.useMemo)(() => [...p, ...h], [p, h]),
            f = o.loginMethods.passkey,
            m = i?.login,
            y = [];
          c && g.includes(c)
            ? y.push(c)
            : l && g.includes(u?.loginMethod) && y.push(u?.loginMethod);
          let [w, v] = (0, C.useState)("default"),
            [x, b] = (0, C.useState)(
              ph({
                mostRecentlyUsedAccountType: l,
                smsAvailable: g.includes("sms"),
                emailAvailable: g.includes("email"),
                prefilledType: m?.prefill?.type,
              })
            );
          (0, C.useEffect)(() => {
            b(
              ph({
                mostRecentlyUsedAccountType: l,
                smsAvailable: g.includes("sms"),
                emailAvailable: g.includes("email"),
                prefilledType: m?.prefill?.type,
              })
            );
          }, [g, l]),
            (0, C.useEffect)(() => {
              "phone" === l && b("sms");
              let e = g.indexOf("sms"),
                t = g.indexOf("email");
              e > -1 && e < t && b("sms");
            }, [l, p, h]);
          let k = () => {
            t({ shouldCallAuthOnSuccess: !0 }),
              setTimeout(() => {
                v("default");
              }, 150);
          };
          r.current = k;
          let T = (t) =>
              "email" === t
                ? (0, a.jsx)(
                    pF,
                    {
                      isEditable: "email" === x,
                      setIsEditable: () => {
                        b("email");
                      },
                      defaultValue:
                        "email" === m?.prefill?.type ? m.prefill.value : void 0,
                    },
                    t
                  )
                : "sms" === t
                ? (0, a.jsx)(
                    u8,
                    {
                      isEditable: "sms" === x,
                      setIsEditable: () => {
                        b("sms");
                      },
                      defaultValue:
                        "phone" === m?.prefill?.type ? m.prefill.value : void 0,
                    },
                    t
                  )
                : "apple" === t
                ? (0, a.jsx)(u9, { provider: "apple" }, t)
                : "discord" === t
                ? (0, a.jsx)(u9, { provider: "discord" }, t)
                : "farcaster" === t
                ? (0, a.jsx)(uY, {}, t)
                : "github" === t
                ? (0, a.jsx)(u9, { provider: "github" }, t)
                : "google" === t
                ? (0, a.jsx)(u9, { provider: "google" }, t)
                : "linkedin" === t
                ? (0, a.jsx)(u9, { provider: "linkedin" }, t)
                : "spotify" === t
                ? (0, a.jsx)(u9, { provider: "spotify" }, t)
                : "instagram" === t
                ? (0, a.jsx)(u9, { provider: "instagram" }, t)
                : "tiktok" === t
                ? (0, a.jsx)(u9, { provider: "tiktok" }, t)
                : "line" === t
                ? (0, a.jsx)(u9, { provider: "line" }, t)
                : "twitch" === t
                ? (0, a.jsx)(u9, { provider: "twitch" }, t)
                : "twitter" === t
                ? (0, a.jsx)(u9, { provider: "twitter" }, t)
                : "telegram" === t
                ? (0, a.jsx)(pr, {}, t)
                : t.startsWith("privy:")
                ? (0, a.jsx)(oK, { appId: t.replace("privy:", "") }, t)
                : dW({
                    walletList: o.appearance.walletList,
                    walletChainType:
                      m?.walletChainType ?? o.appearance.walletChainType,
                    connectors: n,
                    connectOnly: e,
                    ignore: g,
                    walletConnectEnabled:
                      o.externalWallets.walletConnect.enabled,
                    forceWallet: { wallet: t, chainType: d ?? "ethereum" },
                  }),
            A = y.flatMap(T),
            S = p.filter((e) => e !== c && e !== u?.loginMethod).flatMap(T),
            I = h.filter((e) => e !== c && e !== u?.loginMethod).flatMap(T),
            [E, N] = ((e, t) => {
              let n = [],
                a = [];
              for (let [r, i] of e.entries()) r < t ? n.push(i) : a.push(i);
              return [n, a];
            })(
              [...A, ...S, ...I],
              pL({ primary: S.length + A.length, overflow: I.length })
            );
          return (0, a.jsxs)(a.Fragment, {
            children: [
              (0, a.jsx)(a4, {
                title: o.appearance.landingHeader,
                onClose: k,
                backFn:
                  "default" === w
                    ? void 0
                    : () => {
                        v("default");
                      },
              }),
              "default" === w && (0, a.jsx)(pP, {}),
              "default" === w &&
                ("string" == typeof o.appearance.loginMessage
                  ? (0, a.jsx)(ak, { children: o.appearance.loginMessage })
                  : o.appearance.loginMessage),
              (0, a.jsx)(ax, {
                style: { overflow: "hidden" },
                children: (0, a.jsxs)(aC, {
                  $colorScheme: s,
                  children: [
                    "default" === w &&
                      (0, a.jsxs)(a.Fragment, {
                        children: [
                          E,
                          N.length > 0 &&
                            (0, a.jsx)(po, {
                              text: "More options",
                              icon: (0, a.jsx)(ef.Z, {}),
                              onClick: () => v("overflow"),
                            }),
                        ],
                      }),
                    "overflow" === w && (0, a.jsx)(a.Fragment, { children: N }),
                    f && "default" === w && (0, a.jsx)(u2, {}),
                  ],
                }),
              }),
              o && (0, a.jsx)(aM, { app: o }),
              (0, a.jsx)(aF, {}),
            ],
          });
        },
        pL = ({ primary: e, overflow: t }) =>
          e < 5 ? e : 5 === e && 0 === t ? 5 : 4,
        pP = (0, T.zo)((e) => {
          let t = ar();
          return t?.appearance.logo
            ? (0, a.jsx)(oY, { ...e, children: (0, a.jsx)(oG, {}) })
            : null;
        }).withConfig({
          displayName: "StyledAppLogoHeader",
          componentId: "sc-7cdadd41-0",
        })(["margin-bottom:16px;"]),
        pD = {
          component: () => {
            let e = ar();
            return e.loginMethodsAndOrder &&
              e.loginMethodsAndOrder.primary.length > 0
              ? (0, a.jsx)(pz, { connectOnly: !1 })
              : (0, a.jsx)(ps, { connectOnly: !1 });
          },
          isCaptchaRequired: !0,
          isUnauthenticatedScreem: !0,
        },
        pW = {
          component: () => {
            let [e, t] = (0, C.useState)(null),
              [n, r] = (0, C.useState)(!1),
              [i, o] = (0, C.useState)(null),
              [s, l] = (0, C.useState)(""),
              { authenticated: c, user: d } = (0, k.u)(),
              {
                client: u,
                walletProxy: p,
                refreshSessionAndUser: h,
                closePrivyModal: g,
                createAnalyticsEvent: f,
              } = (0, j.u)(),
              {
                navigate: m,
                data: y,
                onUserCloseViaDialogOrKeybindRef: w,
              } = ap(),
              v = ar(),
              { onSuccess: x, onFailure: b } = y.setWalletPassword,
              T = (0, k.a)(d),
              A = "user-passcode" === e?.recoveryMethod,
              S = "user-passcode" === T?.recoveryMethod;
            (0, C.useEffect)(() => {
              c ||
                (m(pD),
                b(
                  new eh.aj(
                    "User must be authenticated before setting a password on a Privy wallet"
                  )
                ));
            }, [c]);
            let I = () => (
              i
                ? b(i)
                : A
                ? x(e)
                : b(new eh.ai("Exited before password was added to wallet")),
              void g({ shouldCallAuthOnSuccess: !1 })
            );
            return (
              (w.current = I),
              (0, a.jsx)(oR, {
                appName: v?.name || "privy",
                config: { initiatedBy: "user", onCancel: I },
                error: i ? "An error has occurred, please try again." : void 0,
                buttonLoading: n,
                buttonHideAnimations: !1,
                password: s,
                isResettingPassword: S,
                onPasswordGenerate: () => l(o_()),
                onPasswordChange: l,
                onSubmit: async () => {
                  A
                    ? (x(e), g({ shouldCallAuthOnSuccess: !1 }))
                    : (r(!0),
                      o(null),
                      await (async () => {
                        let e = await u.getAccessToken();
                        if (e && d && T?.address && s && p)
                          try {
                            f({
                              eventName: "embedded_wallet_set_recovery_started",
                              payload: {
                                walletAddress: T.address,
                                existingRecoveryMethod: T.recoveryMethod,
                                targetRecoveryMethod: "user-passcode",
                                isResettingPassword: S,
                              },
                            });
                            let { entropyId: n, entropyIdVerifier: a } = nv(d);
                            if (
                              !(
                                await p.setRecovery({
                                  accessToken: e,
                                  entropyId: n,
                                  entropyIdVerifier: a,
                                  recoveryPassword: s,
                                  recoveryMethod: "user-passcode",
                                })
                              ).entropyId
                            )
                              return (
                                o(
                                  new eh.ai(
                                    "Error setting password on privy wallet"
                                  )
                                ),
                                void f({
                                  eventName:
                                    "embedded_wallet_set_recovery_failed",
                                  payload: {
                                    walletAddress: T.address,
                                    existingRecoveryMethod: T.recoveryMethod,
                                    targetRecoveryMethod: "user-passcode",
                                    isResettingPassword: S,
                                    reason: "error setting password",
                                  },
                                })
                              );
                            let r = await h(),
                              i = (0, k.a)(r);
                            if (!i)
                              return (
                                o(
                                  new eh.ai(
                                    "Error setting password on privy wallet"
                                  )
                                ),
                                void f({
                                  eventName:
                                    "embedded_wallet_set_recovery_failed",
                                  payload: {
                                    walletAddress: T.address,
                                    existingRecoveryMethod: T.recoveryMethod,
                                    targetRecoveryMethod: "user-passcode",
                                    isResettingPassword: S,
                                    reason: "wallet disconnected",
                                  },
                                })
                              );
                            t(i),
                              f({
                                eventName:
                                  "embedded_wallet_set_recovery_completed",
                                payload: {
                                  walletAddress: T.address,
                                  existingRecoveryMethod: T.recoveryMethod,
                                  targetRecoveryMethod: "user-passcode",
                                  isResettingPassword: S,
                                },
                              });
                          } catch (e) {
                            console.warn(e),
                              o(
                                e instanceof Error
                                  ? e
                                  : Error(
                                      "Error setting password on privy wallet"
                                    )
                              ),
                              f({
                                eventName:
                                  "embedded_wallet_set_password_failed",
                                payload: {
                                  walletAddress: T.address,
                                  reason: e,
                                },
                              });
                          }
                      })(),
                      r(!1));
                },
                onClose: I,
              })
            );
          },
        },
        pR = ({ onClose: e, onProceed: t }) =>
          (0, a.jsx)(rS, {
            title: "Secure Your Account",
            subtitle: (0, a.jsxs)(a.Fragment, {
              children: [
                "Please set a password to secure your account.",
                (0, a.jsx)("br", {}),
                "Losing access to this password and this device will make your account inaccessible.",
              ],
            }),
            icon: d.Z,
            primaryCta: { label: "Add password", onClick: t },
            onClose: e,
            watermark: !0,
          }),
        pB = {
          component: () => {
            let { closePrivyModal: e } = (0, j.u)(),
              {
                data: t,
                navigate: n,
                onUserCloseViaDialogOrKeybindRef: r,
              } = ap(),
              { onFailure: i } = t.setWalletPassword,
              o = () => {
                i(new eh.ai("Exited before password was added to wallet")),
                  e({ shouldCallAuthOnSuccess: !1 });
              };
            return (
              (r.current = o),
              (0, a.jsx)(pR, {
                onClose: o,
                onProceed: () => {
                  n(pW);
                },
              })
            );
          },
        },
        pU = {
          component: () => {
            let [e, t] = (0, C.useState)(!0),
              { authenticated: n, user: r } = (0, k.u)(),
              {
                walletProxy: i,
                closePrivyModal: o,
                createAnalyticsEvent: s,
                client: l,
              } = (0, j.u)(),
              {
                navigate: c,
                data: d,
                onUserCloseViaDialogOrKeybindRef: u,
              } = ap(),
              [p, h] = (0, C.useState)(void 0),
              [g, f] = (0, C.useState)(""),
              [m, y] = (0, C.useState)(!1),
              {
                entropyId: w,
                entropyIdVerifier: v,
                onCompleteNavigateTo: x,
                onSuccess: b,
                onFailure: T,
              } = d.recoverWallet,
              A = (
                e = "User exited before their wallet could be recovered"
              ) => {
                o({ shouldCallAuthOnSuccess: !1 }),
                  T("string" == typeof e ? new eh.ai(e) : e);
              };
            return (
              (u.current = A),
              (0, C.useEffect)(() => {
                if (!n)
                  return A(
                    "User must be authenticated and have a Privy wallet before it can be recovered"
                  );
              }, [n]),
              (0, a.jsxs)(rx, {
                children: [
                  (0, a.jsx)(rx.Header, {
                    icon: eO.Z,
                    title: "Enter your password",
                    subtitle:
                      "Please provision your account on this new device. To continue, enter your recovery password.",
                    showClose: !0,
                    onClose: A,
                  }),
                  (0, a.jsx)(rx.Body, {
                    children: (0, a.jsx)(pO, {
                      children: (0, a.jsxs)("div", {
                        children: [
                          (0, a.jsxs)(oi, {
                            children: [
                              (0, a.jsx)(oa, {
                                type: e ? "password" : "text",
                                onChange: (e) => {
                                  var t;
                                  (t = e.target.value) && h(t);
                                },
                                disabled: m,
                                style: { paddingRight: "2.3rem" },
                              }),
                              (0, a.jsx)(od, {
                                style: { right: "0.75rem" },
                                children: e
                                  ? (0, a.jsx)(op, { onClick: () => t(!1) })
                                  : (0, a.jsx)(oh, { onClick: () => t(!0) }),
                              }),
                            ],
                          }),
                          !!g && (0, a.jsx)(pH, { children: g }),
                        ],
                      }),
                    }),
                  }),
                  (0, a.jsxs)(rx.Footer, {
                    children: [
                      (0, a.jsx)(rx.HelpText, {
                        children: (0, a.jsxs)(r2, {
                          children: [
                            (0, a.jsx)("h4", {
                              children: "Why is this necessary?",
                            }),
                            (0, a.jsx)("p", {
                              children:
                                "You previously set a password for this wallet. This helps ensure only you can access it",
                            }),
                          ],
                        }),
                      }),
                      (0, a.jsx)(rx.Actions, {
                        children: (0, a.jsx)(pV, {
                          loading: m || !i,
                          disabled: !p,
                          onClick: async () => {
                            y(!0);
                            let e = await l.getAccessToken(),
                              t = (0, k.f)(r, w);
                            if (!e || !t || null === p)
                              return A(
                                "User must be authenticated and have a Privy wallet before it can be recovered"
                              );
                            try {
                              s({
                                eventName: "embedded_wallet_recovery_started",
                                payload: { walletAddress: t.address },
                              }),
                                await i?.recover({
                                  accessToken: e,
                                  entropyId: w,
                                  entropyIdVerifier: v,
                                  recoveryPassword: p,
                                }),
                                f(""),
                                x ? c(x) : o({ shouldCallAuthOnSuccess: !1 }),
                                b?.(t),
                                s({
                                  eventName:
                                    "embedded_wallet_recovery_completed",
                                  payload: { walletAddress: t.address },
                                });
                            } catch (e) {
                              i_(e) &&
                              ("invalid_recovery_pin" === e.type ||
                                "invalid_request_arguments" === e.type)
                                ? f(
                                    "Invalid recovery password, please try again."
                                  )
                                : f("An error has occurred, please try again.");
                            } finally {
                              y(!1);
                            }
                          },
                          $hideAnimations: !w && m,
                          children: "Recover your account",
                        }),
                      }),
                      (0, a.jsx)(rx.Watermark, {}),
                    ],
                  }),
                ],
              })
            );
          },
        },
        pO = T.zo.div.withConfig({
          displayName: "Content",
          componentId: "sc-f366413c-0",
        })(["display:flex;flex-direction:column;gap:1.5rem;"]),
        pH = T.zo.div.withConfig({
          displayName: "ErrorMessage",
          componentId: "sc-f366413c-1",
        })([
          "line-height:20px;height:20px;font-size:13px;color:var(--privy-color-error);text-align:left;margin-top:0.5rem;",
        ]),
        pV = (0, T.zo)(a$).withConfig({
          displayName: "NoAnimationPrimaryButton",
          componentId: "sc-f366413c-2",
        })(
          ["", ""],
          ({ $hideAnimations: e }) => e && (0, T.iv)(["&&{transition:none;}"])
        ),
        p$ = {
          component: () => {
            let {
                navigate: e,
                data: t,
                onUserCloseViaDialogOrKeybindRef: n,
              } = ap(),
              r = ar(),
              [i, o] = (0, C.useState)(""),
              [s, l] = (0, C.useState)(!1),
              [c, d] = (0, C.useState)(),
              [u, p] = (0, C.useState)(null),
              { create: h } = iK(),
              { authenticated: g, user: f } = (0, k.u)(),
              {
                closePrivyModal: m,
                isNewUserThisSession: y,
                initializeWalletProxy: w,
              } = (0, j.u)(),
              {
                onSuccess: v,
                onFailure: x,
                callAuthOnSuccessOnClose: b,
                shouldCreateEth: T,
                shouldCreateSol: A,
              } = t.createWallet,
              [S, I] = (0, C.useState)(null),
              E = new td(async () => {
                try {
                  let t;
                  if (T && A)
                    (t = await h({
                      recoveryMethod: "user-passcode",
                      recoveryPassword: c,
                      chainType: "ethereum",
                      walletIndex: 0,
                      latestUser: f,
                    })),
                      (t = await h({
                        chainType: "solana",
                        walletIndex: 0,
                        latestUser: t.user,
                      }));
                  else if (A)
                    t = await h({
                      recoveryMethod: "user-passcode",
                      recoveryPassword: c,
                      chainType: "solana",
                      walletIndex: 0,
                      latestUser: f,
                    });
                  else {
                    if (!T) throw Error("Invalid args to create wallet");
                    t = await h({
                      recoveryMethod: "user-passcode",
                      recoveryPassword: c,
                      chainType: "ethereum",
                      walletIndex: 0,
                      latestUser: f,
                    });
                  }
                  I(t), y ? e(iJ) : (v(t), m({ shouldCallAuthOnSuccess: b }));
                } catch (e) {
                  o(e.message);
                }
              });
            return (
              (0, C.useEffect)(() => {
                u || w(3e4).then((e) => p(e));
              }, [u]),
              (0, C.useEffect)(() => {
                if (!g || !f)
                  return (
                    e(pD),
                    void x(
                      Error(
                        "User must be authenticated before creating a Privy wallet"
                      )
                    )
                  );
              }, [g]),
              (n.current = () => null),
              (0, a.jsx)(oR, {
                config: { initiatedBy: "automatic" },
                appName: r?.name || "privy",
                loading: !u,
                buttonLoading: s,
                buttonHideAnimations: !S && s,
                isResettingPassword: !1,
                error: i,
                password: c || "",
                onClose: () => {
                  S && "user-passcode" !== S.account.recoveryMethod
                    ? (x(
                        new eh.ai(
                          "User created a wallet but failed to set a password for it"
                        )
                      ),
                      m({ shouldCallAuthOnSuccess: !1 }))
                    : S
                    ? (v(S), m({ shouldCallAuthOnSuccess: b }))
                    : (x(new eh.ai("User wallet creation failed")),
                      m({ shouldCallAuthOnSuccess: !1 }));
                },
                onPasswordChange: d,
                onPasswordGenerate: () => d(o_()),
                onSubmit: async () => (
                  l(!0),
                  E.execute()
                    .then(() => new Promise((e) => setTimeout(e, 250)))
                    .finally(() => l(!1))
                ),
              })
            );
          },
        },
        pZ = T.zo.div.withConfig({
          displayName: "WithCircleBorder",
          componentId: "sc-e4fc5563-0",
        })(
          [
            "&&{border-width:4px;}display:flex;justify-content:center;align-items:center;padding:1rem;aspect-ratio:1;border-style:solid;border-color:",
            ";border-radius:50%;",
          ],
          (e) => e.$color ?? "var(--privy-color-accent)"
        ),
        pq = {
          component: () => {
            let { user: e } = (0, k.u)(),
              {
                client: t,
                walletProxy: n,
                refreshSessionAndUser: r,
                closePrivyModal: i,
              } = (0, j.u)(),
              o = ap(),
              { entropyId: s, entropyIdVerifier: l } = o.data?.recoverWallet,
              [c, d] = (0, C.useState)(!1),
              [u, p] = (0, C.useState)(null),
              [h, g] = (0, C.useState)(null);
            function f() {
              if (!c) {
                if (h) return o.data?.setWalletPassword?.onFailure(h), void i();
                if (!u)
                  return (
                    o.data?.setWalletPassword?.onFailure(
                      Error("User exited set recovery flow")
                    ),
                    void i()
                  );
              }
            }
            return (
              (o.onUserCloseViaDialogOrKeybindRef.current = f),
              (0, a.jsxs)(
                a.Fragment,
                h
                  ? {
                      children: [
                        (0, a.jsx)(a4, { onClose: f }, "header"),
                        (0, a.jsx)(pZ, {
                          $color: "var(--privy-color-error)",
                          style: { alignSelf: "center" },
                          children: (0, a.jsx)(ej.Z, {
                            height: 38,
                            width: 38,
                            stroke: "var(--privy-color-error)",
                          }),
                        }),
                        (0, a.jsx)(lR, {
                          style: { marginTop: "0.5rem" },
                          children: "Something went wrong",
                        }),
                        (0, a.jsx)(av, { style: { minHeight: "2rem" } }),
                        (0, a.jsx)(aZ, {
                          onClick: () => g(null),
                          children: "Try again",
                        }),
                        (0, a.jsx)(aF, {}),
                      ],
                    }
                  : {
                      children: [
                        (0, a.jsx)(a4, { onClose: f }, "header"),
                        (0, a.jsx)(eN.Z, {
                          style: {
                            width: "3rem",
                            height: "3rem",
                            alignSelf: "center",
                          },
                        }),
                        (0, a.jsx)(lR, {
                          style: { marginTop: "0.5rem" },
                          children: "Automatically secure your account",
                        }),
                        (0, a.jsx)(lW, {
                          style: { marginTop: "1rem" },
                          children:
                            "When you log into a new device, you’ll only need to authenticate to access your account. Never get logged out if you forget your password.",
                        }),
                        (0, a.jsx)(av, { style: { minHeight: "2rem" } }),
                        (0, a.jsx)(aZ, {
                          loading: c,
                          disabled: !(!c && !u),
                          onClick: () =>
                            (async function () {
                              d(!0);
                              try {
                                let a = await t.getAccessToken(),
                                  c = (0, k.f)(e, s);
                                if (!a || !n || !c) return;
                                if (
                                  !(
                                    await n.setRecovery({
                                      accessToken: a,
                                      entropyId: s,
                                      entropyIdVerifier: l,
                                      existingRecoveryMethod: c.recoveryMethod,
                                      recoveryMethod: "privy",
                                    })
                                  ).entropyId
                                )
                                  throw Error(
                                    "Unable to set recovery on wallet"
                                  );
                                let d = await r();
                                if (!d)
                                  throw Error(
                                    "Unable to set recovery on wallet"
                                  );
                                let u = (0, k.f)(d, c.address);
                                if (!u)
                                  throw Error(
                                    "Unabled to set recovery on wallet"
                                  );
                                p(!!d),
                                  setTimeout(() => {
                                    o.data?.setWalletPassword?.onSuccess(u),
                                      i();
                                  }, th);
                              } catch (e) {
                                g(e);
                              } finally {
                                d(!1);
                              }
                            })(),
                          children: u ? "Success" : "Confirm",
                        }),
                        (0, a.jsx)(aF, {}),
                      ],
                    }
              )
            );
          },
        };
      function pG({
        walletAction: e,
        availableRecoveryMethods: t,
        legacySetWalletPasswordFlow: n,
        isResettingPassword: a,
        showAutomaticRecovery: r,
      }) {
        return r
          ? pq
          : n || 1 === t.length
          ? (function ({ isCreatingWallet: e, skipSplashScreen: t }) {
              return e ? p$ : t ? pW : pB;
            })({ isCreatingWallet: "create" === e, skipSplashScreen: a })
          : i8;
      }
      function pY(e) {
        switch (e) {
          case "user-passcode":
            return pU;
          case "google-drive":
          case "icloud":
            return i3;
          default:
            throw Error("Recovery method not supported");
        }
      }
      let pQ = ({
          address: e,
          accessToken: t,
          appConfigTheme: n,
          onClose: r,
          isLoading: i = !1,
          exportButtonProps: o,
        }) =>
          (0, a.jsx)(rS, {
            title: "Export wallet",
            subtitle: (0, a.jsxs)(a.Fragment, {
              children: [
                "Copy either your private key or seed phrase to export your wallet.",
                " ",
                (0, a.jsx)("a", {
                  href: "https://privy-io.notion.site/Transferring-your-account-9dab9e16c6034a7ab1ff7fa479b02828",
                  target: "blank",
                  rel: "noopener noreferrer",
                  children: "Learn more",
                }),
              ],
            }),
            onClose: r,
            watermark: !0,
            children: (0, a.jsxs)(pK, {
              children: [
                (0, a.jsx)(cj, {
                  theme: n,
                  children:
                    "Never share your private key or seed phrase with anyone.",
                }),
                (0, a.jsx)(lQ, {
                  title: "Your wallet",
                  address: e,
                  showCopyButton: !0,
                }),
                (0, a.jsx)("div", {
                  style: { width: "100%" },
                  children: i
                    ? (0, a.jsx)(pX, {})
                    : t &&
                      o &&
                      (0, a.jsx)(p1, {
                        accessToken: t,
                        dimensions: { height: "44px" },
                        ...o,
                      }),
                }),
              ],
            }),
          }),
        pK = T.zo.div.withConfig({
          displayName: "ContentContainer",
          componentId: "sc-39a41d8e-0",
        })(["display:flex;flex-direction:column;gap:1.25rem;text-align:left;"]),
        pX = () =>
          (0, a.jsx)(pJ, {
            children: (0, a.jsx)(p0, { children: "Loading..." }),
          }),
        pJ = T.zo.div.withConfig({
          displayName: "PlaceholderContainer",
          componentId: "sc-39a41d8e-1",
        })(["display:flex;gap:12px;height:44px;"]),
        p0 = T.zo.div.withConfig({
          displayName: "PlaceholderButton",
          componentId: "sc-39a41d8e-2",
        })([
          "display:flex;align-items:center;justify-content:center;width:100%;height:100%;font-size:16px;font-weight:500;border-radius:var(--privy-border-radius-md);background-color:var(--privy-color-background-2);color:var(--privy-color-foreground-3);",
        ]);
      function p1(e) {
        let [t, n] = (0, C.useState)(e.dimensions.width),
          [r, i] = (0, C.useState)(void 0),
          o = (0, C.useRef)(null);
        (0, C.useEffect)(() => {
          if (o.current && void 0 === t) {
            let { width: e } = o.current.getBoundingClientRect();
            n(e);
          }
          let e = getComputedStyle(document.documentElement);
          i({
            background: e.getPropertyValue("--privy-color-background"),
            background2: e.getPropertyValue("--privy-color-background-2"),
            foreground3: e.getPropertyValue("--privy-color-foreground-3"),
            foregroundAccent: e.getPropertyValue(
              "--privy-color-foreground-accent"
            ),
            accent: e.getPropertyValue("--privy-color-accent"),
            accentDark: e.getPropertyValue("--privy-color-accent-dark"),
            success: e.getPropertyValue("--privy-color-success"),
            colorScheme: e.getPropertyValue("color-scheme"),
          });
        }, []);
        let s = "ethereum" === e.chainType && !e.imported && !e.isUnifiedWallet;
        return (0, a.jsx)("div", {
          ref: o,
          children:
            t &&
            (0, a.jsxs)(p3, {
              children: [
                (0, a.jsx)("iframe", {
                  style: { position: "absolute", zIndex: 1 },
                  width: t,
                  height: e.dimensions.height,
                  allow: "clipboard-write self *",
                  src: (0, A.v)({
                    origin: e.origin,
                    path: `/apps/${e.appId}/embedded-wallets/export`,
                    query: e.isUnifiedWallet
                      ? {
                          v: "1-unified",
                          wallet_id: e.walletId,
                          client_id: e.appClientId,
                          width: `${t}px`,
                          caid: e.clientAnalyticsId,
                          phrase_export: s,
                          ...r,
                        }
                      : {
                          v: "1",
                          entropy_id: e.entropyId,
                          entropy_id_verifier: e.entropyIdVerifier,
                          hd_wallet_index: e.hdWalletIndex,
                          chain_type: e.chainType,
                          client_id: e.appClientId,
                          width: `${t}px`,
                          caid: e.clientAnalyticsId,
                          phrase_export: s,
                          ...r,
                        },
                    hash: { token: e.accessToken },
                  }),
                }),
                (0, a.jsx)(p4, { children: "Loading..." }),
                s && (0, a.jsx)(p4, { children: "Loading..." }),
              ],
            }),
        });
      }
      let p2 = {
          component: () => {
            let [e, t] = (0, C.useState)(null),
              { authenticated: n, user: r } = (0, k.u)(),
              {
                closePrivyModal: i,
                createAnalyticsEvent: o,
                clientAnalyticsId: s,
                client: l,
              } = (0, j.u)(),
              c = ar(),
              { data: d, onUserCloseViaDialogOrKeybindRef: u } = ap(),
              {
                onFailure: p,
                onSuccess: h,
                origin: g,
                appId: f,
                appClientId: m,
                entropyId: y,
                entropyIdVerifier: w,
                walletId: v,
                hdWalletIndex: x,
                chainType: b,
                address: T,
                isUnifiedWallet: A,
                imported: S,
              } = d.keyExport,
              I = (e) => {
                i({ shouldCallAuthOnSuccess: !1 }),
                  p("string" == typeof e ? Error(e) : e);
              },
              E = () => {
                i({ shouldCallAuthOnSuccess: !1 }),
                  h(),
                  o({
                    eventName: "embedded_wallet_key_export_completed",
                    payload: { walletAddress: T },
                  });
              };
            return (
              (0, C.useEffect)(() => {
                if (!n)
                  return I(
                    "User must be authenticated before exporting their wallet"
                  );
                l.getAccessToken().then(t).catch(I);
              }, [n, r]),
              (u.current = E),
              (0, a.jsx)(pQ, {
                address: T,
                accessToken: e,
                appConfigTheme: c.appearance.palette.colorScheme,
                onClose: E,
                isLoading: !e,
                exportButtonProps: e
                  ? {
                      origin: g,
                      appId: f,
                      appClientId: m,
                      clientAnalyticsId: s,
                      entropyId: y,
                      entropyIdVerifier: w,
                      walletId: v,
                      hdWalletIndex: x,
                      isUnifiedWallet: A,
                      imported: S,
                      chainType: b,
                    }
                  : void 0,
              })
            );
          },
        },
        p3 = T.zo.div.withConfig({
          displayName: "ButtonContainer",
          componentId: "sc-39a41d8e-3",
        })([
          "overflow:visible;position:relative;overflow:none;height:44px;display:flex;gap:12px;",
        ]),
        p4 = T.zo.div.withConfig({
          displayName: "LoadingButton",
          componentId: "sc-39a41d8e-4",
        })([
          "display:flex;align-items:center;justify-content:center;width:100%;height:100%;font-size:16px;font-weight:500;border-radius:var(--privy-border-radius-md);background-color:var(--privy-color-background-2);color:var(--privy-color-foreground-3);",
        ]),
        p5 = ({ connectionFailed: e, onClose: t }) =>
          (0, a.jsx)(
            rS,
            e
              ? {
                  title: "Something went wrong",
                  subtitle: "We're on it. Please try again later.",
                  icon: u.Z,
                  iconVariant: "error",
                  primaryCta: { label: "Close", onClick: t },
                  watermark: !0,
                }
              : {
                  title: "Connecting to your wallet",
                  subtitle: "Please wait...",
                  iconVariant: "loading",
                  showClose: !0,
                  onClose: t,
                  watermark: !1,
                }
          ),
        p6 = {
          component: () => {
            let { authenticated: e, user: t } = (0, k.u)(),
              {
                client: n,
                closePrivyModal: r,
                createAnalyticsEvent: i,
                walletProxy: o,
              } = (0, j.u)(),
              {
                navigate: s,
                data: l,
                setModalData: c,
                onUserCloseViaDialogOrKeybindRef: d,
              } = ap(),
              u = (0, C.useMemo)(() => Date.now(), []),
              [p, h] = (0, C.useState)(!1),
              {
                onCompleteNavigateTo: g,
                onFailure: f,
                shouldForceMFA: m,
                entropyId: y,
                entropyIdVerifier: w,
                recoveryMethod: v,
                connectingWalletAddress: x,
                isUnifiedWallet: b = !1,
              } = l?.connectWallet,
              T = (e) => {
                p || (h(!0), f("string" == typeof e ? Error(e) : e));
              };
            return (
              (0, C.useEffect)(() => {
                let t;
                return e
                  ? o
                    ? ((async () => {
                        let e = await n.getAccessToken();
                        if (!e)
                          return T(
                            "User must be authenticated and have a Privy wallet before it can be connected"
                          );
                        try {
                          b ||
                            (await o.connect({
                              accessToken: e,
                              entropyId: y,
                              entropyIdVerifier: w,
                            })),
                            m && (await o.verifyMfa({ accessToken: e }));
                          let n = (Date.now() - u) / 1e3;
                          g === p2 && n < 1
                            ? (t = setTimeout(() => {
                                s(g, !1);
                              }, 1e3 * (1 - n)))
                            : s(g, !1);
                        } catch (e) {
                          if (iM(e) && "privy" === v) {
                            let e = await n.getAccessToken();
                            if (!e)
                              return T(
                                "User must be authenticated and have a Privy wallet before it can be recovered"
                              );
                            try {
                              i({
                                eventName:
                                  "embedded_wallet_pinless_recovery_started",
                                payload: { walletAddress: x },
                              });
                              let t = await o?.recover({
                                accessToken: e,
                                entropyId: y,
                                entropyIdVerifier: w,
                              });
                              t?.entropyId ||
                                T(Error("Unable to recover wallet")),
                                g ? s(g) : r({ shouldCallAuthOnSuccess: !1 }),
                                i({
                                  eventName:
                                    "embedded_wallet_recovery_completed",
                                  payload: { walletAddress: x },
                                }),
                                s(g);
                            } catch (e) {
                              T("An error has occurred, please try again.");
                            }
                          } else
                            iM(e) && "privy" !== v && "privy-v2" !== v
                              ? (c({
                                  ...l,
                                  recoverWallet: {
                                    entropyId: y,
                                    entropyIdVerifier: w,
                                    onCompleteNavigateTo: g,
                                    onFailure: f,
                                  },
                                  recoveryOAuthStatus: {
                                    provider: v,
                                    action: "recover",
                                    isInAccountCreateFlow: !1,
                                    shouldCreateEth: !1,
                                    shouldCreateSol: !1,
                                  },
                                }),
                                s(pY(v)))
                              : T(e);
                        }
                      })(),
                      () => clearTimeout(t))
                    : void 0
                  : T(
                      "User must be authenticated and have a Privy wallet before it can be connected"
                    );
              }, [e, t, o]),
              (d.current = () => {
                T("User exited before wallet could be connected"),
                  r({ shouldCallAuthOnSuccess: !1 });
              }),
              (0, a.jsx)(p5, {
                connectionFailed: p,
                onClose: () => r({ shouldCallAuthOnSuccess: !1 }),
              })
            );
          },
        },
        p8 = ({ style: e, color: t, ...n }) =>
          (0, a.jsx)("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            fill: "none",
            viewBox: "0 0 24 24",
            strokeWidth: "1.5",
            stroke: t || "currentColor",
            style: { height: "1.5rem", width: "1.5rem", ...e },
            ...n,
            children: (0, a.jsx)("path", {
              strokeLinecap: "round",
              strokeLinejoin: "round",
              d: "M4.5 12.75l6 6 9-13.5",
            }),
          }),
        p7 = (e) => {
          let [t, n] = (0, C.useState)(!1);
          return (0, a.jsxs)(p9, {
            color: e.color,
            onClick: () => {
              n(!0),
                navigator.clipboard.writeText(e.text),
                setTimeout(() => n(!1), 1500);
            },
            $justCopied: t,
            children: [
              t
                ? (0, a.jsx)(p8, {
                    style: { height: "14px", width: "14px" },
                    strokeWidth: "2",
                  })
                : (0, a.jsx)(sL, { style: { height: "14px", width: "14px" } }),
              t ? "Copied" : "Copy",
              " ",
              e.itemName ? e.itemName : "to Clipboard",
            ],
          });
        },
        p9 = T.zo.button.withConfig({
          displayName: "StyledCopytoClipboardButton",
          componentId: "sc-46f4187f-0",
        })(
          [
            "display:flex;align-items:center;gap:6px;&&{margin:8px 2px;font-size:14px;color:",
            ";font-weight:",
            ";transition:color 350ms ease;:focus,:active{background-color:transparent;border:none;outline:none;box-shadow:none;}:hover{color:",
            ";}:active{color:'var(--privy-color-foreground)';font-weight:medium;}@media (max-width:440px){margin:12px 2px;}}svg{width:14px;height:14px;}",
          ],
          (e) =>
            e.$justCopied
              ? "var(--privy-color-foreground)"
              : e.color || "var(--privy-color-foreground-3)",
          (e) => (e.$justCopied ? "medium" : "normal"),
          (e) =>
            e.$justCopied
              ? "var(--privy-color-foreground)"
              : "var(--privy-color-foreground-2)"
        ),
        he = T.zo.img.withConfig({
          displayName: "StyledLogo",
          componentId: "sc-68c1b1ea-0",
        })(
          ["&&{height:", ";width:", ";border-radius:16px;margin-bottom:12px;}"],
          (e) => ("sm" === e.size ? "65px" : "140px"),
          (e) => ("sm" === e.size ? "65px" : "140px")
        ),
        ht = (e) => {
          if (!(0, _.v)(e)) return e;
          try {
            let t = (0, H.rR)(e);
            return t.includes("�") ? e : t;
          } catch {
            return e;
          }
        },
        hn = (e) => {
          try {
            let t = S.US.decode(e),
              n = new TextDecoder().decode(t);
            return n.includes("�") ? e : n;
          } catch {
            return e;
          }
        },
        ha = (e) => JSON.stringify(e, null, 2),
        hr = (e) => {
          let { types: t, primaryType: n, ...r } = e.typedData;
          return (0, a.jsxs)(a.Fragment, {
            children: [
              (0, a.jsx)(hc, { data: r }),
              (0, a.jsx)(p7, {
                text: ha(e.typedData),
                itemName: "full payload to clipboard",
              }),
              " ",
            ],
          });
        },
        hi = ({
          method: e,
          messageData: t,
          copy: n,
          iconUrl: r,
          isLoading: i,
          success: o,
          walletProxyIsLoading: s,
          errorMessage: l,
          isCancellable: c,
          onSign: d,
          onCancel: u,
          onClose: p,
        }) =>
          (0, a.jsx)(rS, {
            title: n.title,
            subtitle: n.description,
            showClose: !0,
            onClose: p,
            icon: b.Z,
            iconVariant: "subtle",
            helpText: l ? (0, a.jsx)(hl, { children: l }) : void 0,
            primaryCta: {
              label: n.buttonText,
              onClick: d,
              disabled: i || o || s,
              loading: i,
            },
            secondaryCta: c
              ? { label: "Not now", onClick: u, disabled: i || o || s }
              : void 0,
            watermark: !0,
            children: (0, a.jsxs)(r1, {
              children: [
                r
                  ? (0, a.jsx)(he, {
                      style: { alignSelf: "center" },
                      size: "sm",
                      src: r,
                      alt: "app image",
                    })
                  : null,
                (0, a.jsxs)(hs, {
                  children: [
                    "personal_sign" === e &&
                      (0, a.jsx)(hd, { children: ht(t) }),
                    "eth_signTypedData_v4" === e &&
                      (0, a.jsx)(hr, { typedData: t }),
                    "solana_signMessage" === e &&
                      (0, a.jsx)(hd, { children: hn(t) }),
                  ],
                }),
              ],
            }),
          }),
        ho = {
          component: () => {
            let { authenticated: e } = (0, k.u)(),
              { initializeWalletProxy: t, closePrivyModal: n } = (0, j.u)(),
              {
                navigate: r,
                data: i,
                onUserCloseViaDialogOrKeybindRef: o,
              } = ap(),
              [s, l] = (0, C.useState)(!0),
              [c, d] = (0, C.useState)(""),
              [u, p] = (0, C.useState)(),
              [h, g] = (0, C.useState)(null),
              [f, m] = (0, C.useState)(!1);
            (0, C.useEffect)(() => {
              e || r(pD);
            }, [e]),
              (0, C.useEffect)(() => {
                t(3e4).then((e) => {
                  l(!1),
                    e ||
                      (d("An error has occurred, please try again."),
                      p(
                        new nA(
                          new nT(c, V.M_.E32603_DEFAULT_INTERNAL_ERROR.eipCode)
                        )
                      ));
                });
              }, []);
            let {
                method: y,
                data: w,
                confirmAndSign: v,
                onSuccess: x,
                onFailure: b,
                uiOptions: T,
              } = i.signMessage,
              A = {
                title: T?.title || "Sign message",
                description:
                  T?.description ||
                  "Signing this message will not cost you any fees.",
                buttonText: T?.buttonText || "Sign and continue",
              },
              S = (e) => {
                e
                  ? x(e)
                  : b(
                      u ||
                        new nA(
                          new nT(
                            "The user rejected the request.",
                            V.M_.E4001_USER_REJECTED_REQUEST.eipCode
                          )
                        )
                    ),
                  n({ shouldCallAuthOnSuccess: !1 }),
                  setTimeout(() => {
                    g(null), d(""), p(void 0);
                  }, 200);
              };
            return (
              (o.current = () => {
                S(h);
              }),
              (0, a.jsx)(hi, {
                method: y,
                messageData: w,
                copy: A,
                iconUrl:
                  T?.iconUrl && "string" == typeof T.iconUrl
                    ? T.iconUrl
                    : void 0,
                isLoading: f,
                success: null !== h,
                walletProxyIsLoading: s,
                errorMessage: c,
                isCancellable: T?.isCancellable,
                onSign: async () => {
                  m(!0), d("");
                  try {
                    let e = await v();
                    g(e),
                      m(!1),
                      setTimeout(() => {
                        S(e);
                      }, th);
                  } catch (e) {
                    console.error(e),
                      d("An error has occurred, please try again."),
                      p(
                        new nA(
                          new nT(c, V.M_.E32603_DEFAULT_INTERNAL_ERROR.eipCode)
                        )
                      ),
                      m(!1);
                  }
                },
                onCancel: () => S(null),
                onClose: () => S(h),
              })
            );
          },
        },
        hs = T.zo.div.withConfig({
          displayName: "MessageContainer",
          componentId: "sc-e01d451f-0",
        })(["flex:1;display:flex;flex-direction:column;gap:16px;"]),
        hl = T.zo.p.withConfig({
          displayName: "ErrorText",
          componentId: "sc-e01d451f-1",
        })([
          "&&{margin:0;width:100%;text-align:center;color:var(--privy-color-error-dark);font-size:14px;line-height:22px;}",
        ]),
        hc = (0, T.zo)(cr).withConfig({
          displayName: "StyledDisplayJsonTree",
          componentId: "sc-e01d451f-2",
        })(["margin-top:0;"]),
        hd = (0, T.zo)(cn).withConfig({
          displayName: "StyledMessage",
          componentId: "sc-e01d451f-3",
        })(["margin-top:0;"]);
    },
  },
]);
