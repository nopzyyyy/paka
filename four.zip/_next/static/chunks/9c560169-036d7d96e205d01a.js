"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [7229],
  {
    8452: function (e, t, n) {
      let r, a, i, o, s, l, c, d, u;
      n.d(t, {
        rr: function () {
          return r_;
        },
      });
      var h,
        p = n(57437),
        m = n(71941),
        w = n(2265),
        y = n(31095),
        g = n(21693),
        f = n(39803),
        v = n(45008),
        C = n(87364),
        b = n(54266),
        k = n(80027),
        A = n(38822),
        x = n(69647),
        T = n(2487),
        _ = n(36609),
        E = n(51872),
        I = n(79655),
        S = n(41379),
        P = n(54315),
        j = n(11953),
        U = n(70558),
        W = n(17082),
        N = n(14228),
        O = n(11490),
        R = n(59115),
        M = n(26469),
        F = n(39169),
        L = n(94818),
        D = n(65626),
        z = n(80700),
        q = n(91183),
        B = n(25587),
        V = n(32938),
        H = n(81253),
        $ = n(10887),
        Z = n(75786),
        K = n(51060),
        Y = n(18616),
        G = n(84862),
        J = n(74530),
        Q = n(50178),
        X = n(45367),
        ee = n(78063),
        et = n(48395),
        en = n(61195),
        er = n(53711),
        ea = n(69806),
        ei = n(1295),
        eo = n(34424),
        es = n(29538),
        el = n(46250),
        ec = n(97747),
        ed = n(3217),
        eu = n(25788),
        eh = n(76429),
        ep = n(82929),
        em = n(49186),
        ew = n(35785),
        ey = n(20787);
      function eg(e) {
        return e ? { "privy-ui": "t" } : void 0;
      }
      n(10375), n(83179), n(54184), n(75298);
      class ef {
        async authenticate() {
          if (!this.api) throw new T.P("Auth flow has no API instance");
          if (!this.meta.email || !this.meta.emailCode)
            throw new T.P(
              "Email and email code must be set prior to calling authenticate."
            );
          try {
            return await this.api.post(T.p, {
              email: this.meta.email,
              code: this.meta.emailCode,
              mode: this.meta.disableSignup ? "no-signup" : "login-or-sign-up",
            });
          } catch (e) {
            throw (0, T.f)(e);
          }
        }
        async link() {
          if (!this.api) throw new T.P("Auth flow has no API instance");
          if (!this.meta.email || !this.meta.emailCode)
            throw new T.P(
              "Email and email code must be set prior to calling authenticate."
            );
          try {
            return await this.api.post(T.a, {
              email: this.meta.email,
              code: this.meta.emailCode,
            });
          } catch (e) {
            throw (0, T.f)(e);
          }
        }
        async sendCodeEmail({ email: e, captchaToken: t, withPrivyUi: n }) {
          if (!this.api) throw new T.P("Auth flow has no API instance");
          if (
            (e && (this.meta.email = e),
            t && (this.meta.captchaToken = t),
            !this.meta.email)
          )
            throw new T.P("Email must be set when initialzing authentication.");
          let r = eg(n);
          try {
            return await this.api.post(
              T.b,
              { email: this.meta.email, token: this.meta.captchaToken },
              { headers: { ...r } }
            );
          } catch (e) {
            throw (0, T.f)(e);
          }
        }
        constructor({ email: e, captchaToken: t, disableSignup: n }) {
          this.meta = { email: e, captchaToken: t, disableSignup: n ?? !1 };
        }
      }
      class ev extends ef {
        async link() {
          if (!this.api) throw new T.P("Auth flow has no API instance");
          if (!this.meta.email || !this.meta.emailCode || !this.meta.oldAddress)
            throw new T.P(
              "Email, email code, and an old email address must be set prior to calling update."
            );
          try {
            return await this.api.post(T.u, {
              oldAddress: this.meta.oldAddress,
              newAddress: this.meta.email,
              code: this.meta.emailCode,
            });
          } catch (e) {
            throw (0, T.f)(e);
          }
        }
        constructor(e, t, n) {
          super({ email: t, captchaToken: n }),
            (this.meta = {
              email: t,
              captchaToken: n,
              oldAddress: e,
              disableSignup: !1,
            });
        }
      }
      class eC {
        get meta() {
          return this._meta;
        }
        async authenticate() {
          if (!this.api) throw new T.P("Auth flow has no API instance");
          if (!this.meta.channelToken)
            throw new T.P("Auth flow must be initialized first");
          try {
            let e = await this.api.post(T.c, {
              channel_token: this.meta.channelToken,
              message: this.message,
              signature: this.signature,
              fid: this.fid,
              mode: this.meta.disableSignup ? "no-signup" : "login-or-sign-up",
            });
            if (!e) throw new T.P("No response from authentication");
            return e;
          } catch (e) {
            throw (0, T.f)(e);
          }
        }
        async link() {
          if (!this.api) throw new T.P("Auth flow has no API instance");
          try {
            return await this.api.post(T.d, {
              channel_token: this.meta.channelToken,
              message: this.message,
              signature: this.signature,
              fid: this.fid,
            });
          } catch (e) {
            throw (0, T.f)(e);
          }
        }
        async _startChannelOnce() {
          if (!this.api) throw new T.P("Auth flow has no API instance");
          let e = await this.api.post(T.e, { token: this.captchaToken });
          y.tq && !y.gn && e.connect_uri && (0, _.o)(e.connect_uri, "_blank"),
            (this._meta = {
              ...this._meta,
              connectUri: e.connect_uri,
              channelToken: e.channel_token,
            });
        }
        async initializeFarcasterConnect() {
          if (!this.api) throw new T.P("Auth flow has no API instance");
          await this.startChannelOnce.execute();
        }
        async _pollForReady() {
          if (!this.api) throw new T.P("Auth flow has no API instance");
          if (!this.meta.channelToken)
            throw new T.P("Auth flow must be initialized first");
          let e = await this.api.get(T.g, {
            headers: { "farcaster-channel-token": this.meta.channelToken },
          });
          return (
            "completed" === e.state &&
            ((this.message = e.message),
            (this.signature = e.signature),
            (this.fid = e.fid),
            !0)
          );
        }
        constructor(e, t = !1) {
          (this._meta = { disableSignup: !1 }),
            (this.captchaToken = e),
            (this.startChannelOnce = new _.R(
              this._startChannelOnce.bind(this)
            )),
            (this.pollForReady = new _.R(this._pollForReady.bind(this))),
            (this._meta.disableSignup = t);
        }
      }
      function eb() {
        return (
          "undefined" != typeof window &&
          "chrome-extension:" === window.location.protocol &&
          "chrome" in window
        );
      }
      function ek() {
        if (!eb()) return;
        let e = window.chrome;
        return e?.runtime?.id;
      }
      function eA() {
        if (!eb()) return !1;
        let e = window.chrome;
        return "function" == typeof e?.identity?.launchWebAuthFlow;
      }
      async function ex(e) {
        return new Promise((t, n) => {
          eA()
            ? window.chrome.identity.launchWebAuthFlow(
                { url: e, interactive: !0 },
                async (e) => {
                  try {
                    let n = (function () {
                      if (!eb()) return;
                      let e = window.chrome;
                      return e?.runtime?.lastError?.message;
                    })();
                    if (n || !e) {
                      let e = `WebAuthFlow failed: ${
                        n || "Response URI missing"
                      }`;
                      throw Error(e);
                    }
                    let r = new URL(e),
                      a = ek();
                    if (!a) throw Error("Invalid extension context");
                    if ("chrome-extension:" === r.protocol) {
                      if (r.hostname !== a)
                        throw Error("Invalid responseUri origin");
                    } else {
                      if ("https:" !== r.protocol)
                        throw Error("Invalid responseUri protocol");
                      {
                        let e = r.hostname.split(".");
                        if (
                          3 !== e.length ||
                          "chromiumapp" !== e[1] ||
                          "org" !== e[2] ||
                          e[0] !== a
                        )
                          throw Error("Invalid responseUri origin");
                      }
                    }
                    let i = r.searchParams.get("privy_oauth_state"),
                      o = r.searchParams.get("privy_oauth_code");
                    if (!i || !o)
                      throw Error(
                        "Invalid responseUri - missing required parameters"
                      );
                    t({ privyOAuthState: i, privyOAuthCode: o });
                  } catch (e) {
                    n(e);
                  }
                }
              )
            : n(Error("Chrome identity API not available"));
        });
      }
      class eT {
        addCaptchaToken(e) {
          this.meta.captchaToken = e;
        }
        isActive() {
          return !!(
            this.meta.authorizationCode &&
            this.meta.stateCode &&
            this.meta.provider
          );
        }
        async authenticate() {
          if (!this.api) throw new T.P("Auth flow has no API instance");
          if (!this.meta.authorizationCode || !this.meta.stateCode)
            throw new T.P(
              "[OAuth AuthFlow] Authorization and state codes code must be set prior to calling authenticate."
            );
          if ("undefined" === this.meta.authorizationCode)
            throw new T.P("User denied confirmation during OAuth flow");
          let e = (0, _.g)();
          try {
            let t = await this.api.post(T.o, {
              authorization_code: this.meta.authorizationCode,
              state_code: this.meta.stateCode,
              code_verifier: e,
              mode: this.meta.disableSignup ? "no-signup" : "login-or-sign-up",
            });
            return _.s.del(_.C), _.s.del(_.H), _.s.del(_.O), t;
          } catch (t) {
            let e = (0, T.f)(t);
            if (e.privyErrorCode)
              throw new T.P(
                e.message || "Invalid code during OAuth flow.",
                void 0,
                e.privyErrorCode
              );
            if ("User denied confirmation during OAuth flow" === e.message)
              throw new T.P(
                "Invalid code during oauth flow.",
                void 0,
                T.h.OAUTH_USER_DENIED
              );
            throw new T.P(
              "Invalid code during OAuth flow.",
              void 0,
              T.h.UNKNOWN_AUTH_ERROR
            );
          }
        }
        async link() {
          if (!this.api) throw new T.P("Auth flow has no API instance");
          if (!this.meta.authorizationCode || !this.meta.stateCode)
            throw new T.P(
              "[OAuth AuthFlow] Authorization and state codes code must be set prior to calling link."
            );
          if ("undefined" === this.meta.authorizationCode)
            throw new T.P("User denied confirmation during OAuth flow");
          let e = _.s.get(_.C);
          if (!e) throw new T.P("Authentication error.");
          try {
            let t = await this.api.post(T.i, {
              authorization_code: this.meta.authorizationCode,
              state_code: this.meta.stateCode,
              code_verifier: e,
            });
            return _.s.del(_.C), t;
          } catch (e) {
            throw (0, T.f)(e);
          }
        }
        async getAuthorizationUrl() {
          if (!this.api) throw new T.P("Auth flow has no API instance");
          if (!this.meta.provider)
            throw new T.P(
              "Provider must be set when initializing OAuth authentication."
            );
          let e = (0, _.c)();
          _.s.put(_.C, e);
          let t = (0, _.a)();
          _.s.put(_.S, t);
          let n = await (0, _.d)(e);
          this.meta.withPrivyUi || _.s.put(_.H, !0),
            this.meta.disableSignup ? _.s.put(_.O, !0) : _.s.del(_.O);
          let r = eg(this.meta.withPrivyUi),
            a = window.location.href,
            i = (function () {
              let e = ek();
              if (e) return `https://${e}.chromiumapp.org`;
            })();
          i && (a = i);
          try {
            return await this.api.post(
              T.j,
              {
                provider: this.meta.provider,
                redirect_to: this.meta.customOAuthRedirectUrl || a,
                token: this.meta.captchaToken,
                code_challenge: n,
                state_code: t,
              },
              { headers: { ...r } }
            );
          } catch (e) {
            throw (0, T.f)(e);
          }
        }
        constructor(e) {
          this.meta = e;
        }
      }
      let e_ = ({ style: e }) =>
          (0, p.jsx)(ey.Z, {
            style: { color: "var(--privy-color-error)", ...e },
          }),
        eE = {
          google: { name: "Google", component: _.G },
          discord: { name: "Discord", component: _.D },
          github: { name: "Github", component: _.b },
          linkedin: { name: "LinkedIn", component: _.L },
          twitter: { name: "Twitter", component: _.T },
          spotify: { name: "Spotify", component: _.e },
          instagram: { name: "Instagram", component: _.I },
          tiktok: { name: "Tiktok", component: _.f },
          line: { name: "LINE", component: _.h },
          twitch: { name: "Twitch", component: _.i },
          apple: { name: "Apple", component: _.A },
        },
        eI = ({ iconUrl: e, ...t }) =>
          w.createElement(
            "svg",
            {
              width: "33",
              height: "32",
              viewBox: "0 0 33 32",
              fill: "none",
              xmlns: "http://www.w3.org/2000/svg",
              ...t,
            },
            w.createElement(
              "foreignObject",
              { x: "2", y: "2", width: "29", height: "28" },
              w.createElement("img", {
                src: e,
                width: "29",
                height: "28",
                style: {
                  display: "block",
                  objectFit: "contain",
                  borderRadius: "4px",
                },
                alt: "Provider icon",
              })
            )
          ),
        eS = (e, t) => {
          if (e in eE) return eE[e];
          if ((0, P.i)(e) && t) {
            let n = t.find((t) => t.provider === e);
            if (n)
              return {
                name: n.provider_display_name,
                component: (e) =>
                  w.createElement(eI, { ...e, iconUrl: n.provider_icon_url }),
              };
          }
          return { name: "Unknown", component: e_ };
        };
      class eP {
        async initRegisterFlow(e) {
          if (!this.api) throw new T.P("Auth flow has no API instance");
          (this.authenticateForRegistration = !0),
            (this.meta.initRegisterResponse =
              await this.initRegisterOnce.execute(e));
        }
        async initAuthenticationFlow(e) {
          if (!this.api) throw new T.P("Auth flow has no API instance");
          (this.authenticateForRegistration = !1),
            (this.meta.initAuthenticateResponse =
              await this.initAuthenticateOnce.execute(e));
        }
        async initLinkFlow() {
          if (!this.api) throw new T.P("Auth flow has no API instance");
          this.meta.initLinkResponse = await this.initLinkOnce.execute();
        }
        async register() {
          let e = await n.e(2512).then(n.bind(n, 2512));
          if (!this.api) throw new T.P("Auth flow has no API instance");
          if (!e.browserSupportsWebAuthn())
            throw new T.P("WebAuthn is not supported in this browser");
          this.meta.initRegisterResponse ||
            (this.meta.initRegisterResponse =
              await this.initRegisterOnce.execute());
          try {
            let t = this.meta.initRegisterResponse.options,
              n = await e.startRegistration(
                this._transformInitLinkOptionsToCamelCase(t)
              );
            return (
              this.meta.setPasskeyAuthState?.({
                status: "submitting-response",
              }),
              await this.api.post(T.k, {
                relying_party: this.meta.initRegisterResponse.relying_party,
                authenticator_response:
                  this._transformRegistrationResponseToSnakeCase(n),
              })
            );
          } catch (e) {
            if ("NotAllowedError" === e.name)
              throw new T.P(
                "Passkey request timed out or rejected by user.",
                void 0,
                T.h.PASSKEY_NOT_ALLOWED
              );
            throw (0, T.f)(e);
          }
        }
        async authenticate() {
          if (this.authenticateForRegistration) return this.register();
          let e = await n.e(2512).then(n.bind(n, 2512));
          if (!this.api) throw new T.P("Auth flow has no API instance");
          if (!e.browserSupportsWebAuthn())
            throw new T.P("WebAuthn is not supported in this browser");
          this.meta.initAuthenticateResponse ||
            (this.meta.initAuthenticateResponse =
              await this.initAuthenticateOnce.execute());
          let t =
            this.meta.allowedCredentialsIds?.map((e) => ({
              type: "public-key",
              id: e,
            })) ?? this.meta.initAuthenticateResponse.options.allow_credentials;
          try {
            let n = await e.startAuthentication(
              this._transformInitAuthenticateOptionsToCamelCase({
                ...this.meta.initAuthenticateResponse.options,
                allow_credentials: t,
              })
            );
            return (
              this.meta.setPasskeyAuthState?.({
                status: "submitting-response",
              }),
              await this.api.post(T.l, {
                relying_party: this.meta.initAuthenticateResponse.relying_party,
                challenge: this.meta.initAuthenticateResponse.options.challenge,
                authenticator_response:
                  this._transformAuthenticationResponseToSnakeCase(n),
              })
            );
          } catch (e) {
            if ("NotAllowedError" === e.name)
              throw new T.P(
                "Passkey request timed out or rejected by user.",
                void 0,
                T.h.PASSKEY_NOT_ALLOWED
              );
            throw (0, T.f)(e);
          }
        }
        async link() {
          let e = await n.e(2512).then(n.bind(n, 2512));
          if (!this.api) throw new T.P("Auth flow has no API instance");
          if (!e.browserSupportsWebAuthn())
            throw new T.P("WebAuthn is not supported in this browser");
          this.meta.initLinkResponse ||
            (this.meta.initLinkResponse = await this.initLinkOnce.execute());
          try {
            let t = this.meta.initLinkResponse.options,
              n = await e.startRegistration(
                this._transformInitLinkOptionsToCamelCase(t)
              );
            return (
              this.meta.setPasskeyAuthState?.({
                status: "submitting-response",
              }),
              await this.api.post(T.m, {
                relying_party: this.meta.initLinkResponse.relying_party,
                authenticator_response:
                  this._transformRegistrationResponseToSnakeCase(n),
              })
            );
          } catch (e) {
            if ("NotAllowedError" === e.name)
              throw new T.P(
                "Passkey request timed out or rejected by user.",
                void 0,
                T.h.PASSKEY_NOT_ALLOWED
              );
            throw (0, T.f)(e);
          }
        }
        async _initRegisterOnce(e) {
          if (!this.api) throw new T.P("Auth flow has no API instance");
          let t = eg(e);
          return await this.api.post(
            T.n,
            { token: this.meta.captchaToken },
            { headers: { ...t } }
          );
        }
        async _initAuthenticateOnce(e) {
          if (!this.api) throw new T.P("Auth flow has no API instance");
          let t = eg(e);
          return await this.api.post(
            T.q,
            { token: this.meta.captchaToken },
            { headers: { ...t } }
          );
        }
        async _initLinkOnce() {
          if (!this.api) throw new T.P("Auth flow has no API instance");
          return await this.api.post(T.r, {});
        }
        _transformInitLinkOptionsToCamelCase(e) {
          return {
            rp: e.rp,
            user: {
              id: e.user.id,
              name: e.user.name,
              displayName: e.user.display_name,
            },
            challenge: e.challenge,
            pubKeyCredParams: e.pub_key_cred_params.map((e) => ({
              type: e.type,
              alg: e.alg,
            })),
            timeout: e.timeout,
            excludeCredentials: e.exclude_credentials?.map((e) => ({
              id: e.id,
              type: e.type,
              transports: e.transports,
            })),
            authenticatorSelection: {
              authenticatorAttachment:
                e.authenticator_selection?.authenticator_attachment,
              requireResidentKey:
                e.authenticator_selection?.require_resident_key,
              residentKey: e.authenticator_selection?.resident_key,
              userVerification: e.authenticator_selection?.user_verification,
            },
            attestation: e.attestation,
            extensions: {
              appid: e.extensions?.app_id,
              credProps: e.extensions?.cred_props?.rk,
              hmacCreateSecret: e.extensions?.hmac_create_secret,
            },
          };
        }
        _transformRegistrationResponseToSnakeCase(e) {
          return {
            id: e.id,
            raw_id: e.rawId,
            response: {
              client_data_json: e.response.clientDataJSON,
              attestation_object: e.response.attestationObject,
              authenticator_data: e.response.authenticatorData,
            },
            authenticator_attachment: e.authenticatorAttachment,
            client_extension_results: {
              app_id: e.clientExtensionResults.appid,
              cred_props: e.clientExtensionResults.credProps,
              hmac_create_secret: e.clientExtensionResults.hmacCreateSecret,
            },
            type: e.type,
          };
        }
        _transformInitAuthenticateOptionsToCamelCase(e) {
          return {
            rpId: e.rp_id,
            challenge: e.challenge,
            allowCredentials:
              e.allow_credentials?.map((e) => ({
                id: e.id,
                type: e.type,
                transports: e.transports,
              })) || [],
            timeout: e.timeout,
            extensions: {
              appid: e.extensions?.app_id,
              credProps: e.extensions?.cred_props,
              hmacCreateSecret: e.extensions?.hmac_create_secret,
            },
            userVerification: e.user_verification,
          };
        }
        _transformAuthenticationResponseToSnakeCase(e) {
          return {
            id: e.id,
            raw_id: e.rawId,
            response: {
              client_data_json: e.response.clientDataJSON,
              authenticator_data: e.response.authenticatorData,
              signature: e.response.signature,
              user_handle: e.response.userHandle,
            },
            authenticator_attachment: e.authenticatorAttachment,
            client_extension_results: {
              app_id: e.clientExtensionResults.appid,
              cred_props: e.clientExtensionResults.credProps,
              hmac_create_secret: e.clientExtensionResults.hmacCreateSecret,
            },
            type: e.type,
          };
        }
        constructor({ captchaToken: e, setPasskeyAuthState: t }) {
          (this.authenticateForRegistration = !1),
            (this.initRegisterOnce = new _.R(
              this._initRegisterOnce.bind(this)
            )),
            (this.initAuthenticateOnce = new _.R(
              this._initAuthenticateOnce.bind(this)
            )),
            (this.initLinkOnce = new _.R(this._initLinkOnce.bind(this))),
            (this.meta = { captchaToken: e, setPasskeyAuthState: t });
        }
      }
      class ej {
        async authenticate() {
          if (!this.api) throw new T.P("Auth flow has no API instance");
          if (!this.meta.phoneNumber || !this.meta.smsCode)
            throw new T.P(
              "phone number and sms code must be set prior to calling authenticate."
            );
          try {
            return await this.api.post(T.s, {
              phoneNumber: this.meta.phoneNumber,
              code: this.meta.smsCode,
              mode: this.meta.disableSignup ? "no-signup" : "login-or-sign-up",
            });
          } catch (e) {
            throw (0, T.f)(e);
          }
        }
        async link() {
          if (!this.api) throw new T.P("Auth flow has no API instance");
          if (!this.meta.phoneNumber || !this.meta.smsCode)
            throw new T.P(
              "phone number and sms code must be set prior to calling authenticate."
            );
          try {
            return await this.api.post(T.t, {
              phoneNumber: this.meta.phoneNumber,
              code: this.meta.smsCode,
            });
          } catch (e) {
            throw (0, T.f)(e);
          }
        }
        async sendSmsCode({ phoneNumber: e, captchaToken: t, withPrivyUi: n }) {
          if (!this.api) throw new T.P("Auth flow has no API instance");
          if (
            (e && (this.meta.phoneNumber = e),
            t && (this.meta.captchaToken = t),
            !this.meta.phoneNumber)
          )
            throw new T.P(
              "phone nNumber must be set when initialzing authentication."
            );
          let r = eg(n);
          try {
            return await this.api.post(
              T.v,
              {
                phoneNumber: this.meta.phoneNumber,
                token: this.meta.captchaToken,
              },
              { headers: { ...r } }
            );
          } catch (e) {
            throw (0, T.f)(e);
          }
        }
        constructor({ phoneNumber: e, captchaToken: t, disableSignup: n }) {
          this.meta = {
            phoneNumber: e,
            captchaToken: t,
            disableSignup: n ?? !1,
          };
        }
      }
      class eU extends ej {
        async link() {
          if (!this.api) throw new T.P("Auth flow has no API instance");
          if (
            !this.meta.phoneNumber ||
            !this.meta.smsCode ||
            !this.meta.oldPhoneNumber
          )
            throw new T.P(
              "Phone number, sms code, and an old phone number must be set prior to calling update."
            );
          try {
            return await this.api.post(T.w, {
              old_phone_number: this.meta.oldPhoneNumber,
              new_phone_number: this.meta.phoneNumber,
              code: this.meta.smsCode,
            });
          } catch (e) {
            throw (0, T.f)(e);
          }
        }
        constructor(e, t, n) {
          super({ phoneNumber: t, captchaToken: n }),
            (this.meta = {
              phoneNumber: t,
              captchaToken: n,
              oldPhoneNumber: e,
              disableSignup: !1,
            });
        }
      }
      class eW {
        static parse(e) {
          try {
            return new eW(e);
          } catch (e) {
            return null;
          }
        }
        static throwIfNotWellFormedJwt(e) {
          return I.t(e), e;
        }
        get subject() {
          return this._decoded.sub;
        }
        get expiration() {
          return this._decoded.exp;
        }
        get issuer() {
          return this._decoded.iss;
        }
        get audience() {
          return this._decoded.aud;
        }
        isExpired(e = 0) {
          return Date.now() >= 1e3 * (this.expiration - e);
        }
        constructor(e) {
          (this.value = e), (this._decoded = I.t(e));
        }
      }
      class eN extends eW {
        static parse(e) {
          try {
            return new eN(e);
          } catch (e) {
            return null;
          }
        }
        get appId() {
          return this._decoded.aid ? this._decoded.aid : this.audience;
        }
      }
      class eO extends _.E {
        async initialize() {
          await this.importPromise,
            await this.syncAccounts(),
            (this.initialized = !0),
            this.emit("initialized");
        }
        async connect(e) {
          return (
            e.showPrompt && (await this.promptConnection()),
            (await this.isConnected()) ? this.getConnectedWallet() : null
          );
        }
        disconnect() {
          this.proxyProvider.walletProvider.disconnect(), this.onDisconnect();
        }
        get walletBranding() {
          return {
            name: this.displayName,
            icon: _.B,
            id: "com.coinbase.wallet",
          };
        }
        async promptConnection() {
          try {
            await this.importPromise;
            let e = await this.proxyProvider.request({
              method: "eth_requestAccounts",
            });
            if (!e || 0 === e.length || !e[0])
              throw new T.x("Unable to retrieve accounts");
            (this.connected = !0), await this.syncAccounts([e[0]]);
          } catch (e) {
            throw (0, _.k)(e);
          }
        }
        constructor(e, t, a, i, o) {
          super("base_account", e, t, a),
            (this.connectorType = "base_account"),
            (this.walletClientType = "base_account"),
            (this.displayName = "Base"),
            (this.setBaseAccountSdk = o),
            (this.proxyProvider = new _.P(void 0, this.rpcTimeoutDuration)),
            this.subscribeListeners(),
            (this.baseAccountConfig = {
              ...i,
              appChainIds: [t.id].concat(e.map((e) => e.id)),
            }),
            r
              ? (this.proxyProvider.setWalletProvider(r.getProvider()),
                this.setBaseAccountSdk(r),
                console.log("Base Account SDK Initialized"))
              : (this.importPromise = n
                  .e(5966)
                  .then(n.bind(n, 95966))
                  .then(({ createBaseAccountSDK: e }) => {
                    (r = e(this.baseAccountConfig)),
                      this.proxyProvider.setWalletProvider(r.getProvider()),
                      this.setBaseAccountSdk(r),
                      console.log("Base Account SDK Initialized");
                  })
                  .catch(console.error));
        }
      }
      let eR = [1, 11155111, 137, 10, 8453, 84532, 42161, 7777777, 43114, 56];
      class eM extends _.E {
        async initialize() {
          await this.syncAccounts(),
            (this.initialized = !0),
            this.emit("initialized");
        }
        async connect(e) {
          return (
            e.showPrompt && (await this.promptConnection()),
            (await this.isConnected()) ? this.getConnectedWallet() : null
          );
        }
        disconnect() {
          this.proxyProvider.walletProvider.disconnect(), this.onDisconnect();
        }
        get walletBranding() {
          return {
            name: this.displayName,
            icon: _.l,
            id: "com.coinbase.wallet",
          };
        }
        async promptConnection() {
          try {
            let e = await this.proxyProvider.request({
              method: "eth_requestAccounts",
            });
            if (!e || 0 === e.length || !e[0])
              throw new T.x("Unable to retrieve accounts");
            (this.connected = !0), await this.syncAccounts([e[0]]);
          } catch (e) {
            throw (0, _.k)(e);
          }
        }
        updateConnectionPreference(e) {
          (this.coinbaseWalletConfig = {
            ...this.coinbaseWalletConfig,
            preference: { ...this.coinbaseWalletConfig.preference, options: e },
          }),
            (this.walletClientType =
              "smartWalletOnly" === e
                ? "coinbase_smart_wallet"
                : "coinbase_wallet"),
            (a = (0, U.N)({ ...this.coinbaseWalletConfig })),
            this.proxyProvider.setWalletProvider(a.getProvider());
        }
        constructor(e, t, n, r) {
          if (
            (super("coinbase_wallet", e, t, n),
            (this.connectorType = "coinbase_wallet"),
            (this.displayName = "Coinbase Wallet"),
            (this.proxyProvider = new _.P(void 0, this.rpcTimeoutDuration)),
            this.subscribeListeners(),
            (this.coinbaseWalletConfig = {
              ...r,
              appChainIds: [t.id].concat(e.map((e) => e.id)),
            }),
            (this.walletClientType =
              "smartWalletOnly" ===
              this.coinbaseWalletConfig.preference?.options
                ? "coinbase_smart_wallet"
                : "coinbase_wallet"),
            "coinbase_smart_wallet" === this.walletClientType &&
              (this.displayName = "Coinbase Smart Wallet"),
            !a)
          ) {
            let e =
              "eoaOnly" !== this.coinbaseWalletConfig.preference?.options
                ? (this.coinbaseWalletConfig.appChainIds ?? []).filter(
                    (e) => !eR.includes(e)
                  )
                : [];
            e.length > 0 &&
              !e.every((e) => b.e.has(e)) &&
              console.info(
                `The configured chains are not supported by Coinbase Smart Wallet: ${e.join(
                  ", "
                )}`
              ),
              (a = (0, U.N)(this.coinbaseWalletConfig));
          }
          this.proxyProvider.setWalletProvider(a.getProvider());
        }
      }
      class eF extends _.E {
        async initialize() {
          await this.syncAccounts(),
            (this.initialized = !0),
            this.emit("initialized");
        }
        async connect(e) {
          return (await this.isConnected())
            ? (await this.proxyProvider.request({
                method: "wallet_switchEthereumChain",
                params: [(0, _.t)(e?.chainId || "0x1")],
              }),
              this.getConnectedWallet())
            : null;
        }
        get walletBranding() {
          return { name: "Privy Wallet", icon: _.m, id: "io.privy.wallet" };
        }
        disconnect() {
          this.connected = !1;
        }
        async promptConnection() {}
        constructor({
          provider: e,
          chains: t,
          defaultChain: n,
          rpcConfig: r,
          imported: a,
          walletIndex: i,
        }) {
          super("privy", t, n, r),
            (this.connectorType = "embedded"),
            (this.proxyProvider = e),
            (this.walletIndex = i),
            a && (this.connectorType = "embedded_imported"),
            this.subscribeListeners();
        }
      }
      let eL = [
        "eth_sign",
        "eth_populateTransactionRequest",
        "eth_signTransaction",
        "personal_sign",
        "eth_signTypedData_v4",
        "csw_signUserOperation",
        "secp256k1_sign",
      ];
      class eD extends Error {
        constructor(e, t, n) {
          super(e), (this.code = t), (this.data = n);
        }
      }
      class ez extends j.Z {
        async handleSendTransaction(e) {
          if (!e.params || !Array.isArray(e.params))
            throw new eD(`Invalid params for ${e.method}`, 4200);
          let t = e.params[0];
          if (!(await rC()) || !this.address)
            throw new eD("Disconnected", 4900);
          let { hash: n } = await rx(t, { address: this.address });
          return n;
        }
        async handleSignTransaction(e) {
          if (!e.params || !Array.isArray(e.params))
            throw new eD(`Invalid params for ${e.method}`, 4200);
          let t = e.params[0];
          if (!(await rC()) || !this.address)
            throw new eD("Disconnected", 4900);
          let { signature: n } = await rA(t, { address: this.address });
          return n;
        }
        handleSwitchEthereumChain(e) {
          let t;
          if (!e.params || !Array.isArray(e.params))
            throw new eD(`Invalid params for ${e.method}`, 4200);
          if ("string" == typeof e.params[0]) t = e.params[0];
          else {
            if (
              !("chainId" in e.params[0]) ||
              "string" != typeof e.params[0].chainId
            )
              throw new eD(`Invalid params for ${e.method}`, 4200);
            t = e.params[0].chainId;
          }
          (this.chainId = Number(t)),
            (this.publicClient = (0, _.n)(
              this.chainId,
              this.chains,
              this.rpcConfig,
              { appId: this.appId }
            )),
            this.emit("chainChanged", t);
        }
        async handlePersonalSign(e) {
          if (!e.params || !Array.isArray(e.params))
            throw Error("Invalid params for personal_sign");
          let t = e.params[0],
            n = e.params[1],
            { signature: r } = await rb({ message: t }, { address: n });
          return r;
        }
        async handleSignedTypedData(e) {
          if (!e.params || !Array.isArray(e.params))
            throw Error("Invalid params for eth_signTypedData_v4");
          let t = e.params[0],
            n =
              "string" == typeof e.params[1]
                ? JSON.parse(e.params[1])
                : e.params[1],
            { signature: r } = await rk((0, _.p)(n), { address: t });
          return r;
        }
        async handleEstimateGas(e) {
          if (!e.params || !Array.isArray(e.params))
            throw Error("Invalid params for eth_estimateGas");
          delete e.params[0].gasPrice,
            delete e.params[0].maxFeePerGas,
            delete e.params[0].maxPriorityFeePerGas;
          let t = { ...e.params[0], chainId: (0, _.t)(this.chainId) };
          return await this.publicClient.estimateGas({
            account: t.from ?? this.address,
            ...(0, W.b)(t),
          });
        }
        async request(e) {
          var t;
          switch (
            (console.debug(
              "Embedded1193Provider.request() called with args",
              e
            ),
            e.method)
          ) {
            case "eth_accounts":
            case "eth_requestAccounts":
              return this.address ? [this.address] : [];
            case "eth_chainId":
              return (0, _.t)(this.chainId);
            case "eth_estimateGas":
              return this.handleEstimateGas(e);
            case "eth_sendTransaction":
              return this.handleSendTransaction(e);
            case "eth_signTransaction":
              return this.handleSignTransaction(e);
            case "wallet_switchEthereumChain":
              return this.handleSwitchEthereumChain(e);
            case "personal_sign":
              return this.handlePersonalSign(e);
            case "eth_signTypedData_v4":
              return this.handleSignedTypedData(e);
          }
          if (((t = e.method), !eL.includes(t)))
            return this.publicClient.request({
              method: e.method,
              params: e.params,
            });
          {
            let t = await rC();
            if ((await rT({ address: this.address }), !t || !this.address))
              throw new eD("Disconnected", 4900);
            try {
              let n = { method: e.method, params: e.params },
                r = this.walletAccount;
              return r && (0, P.g)(r)
                ? this.handleWalletApiRequest(n, r, t)
                : (
                    await this.walletProxy.rpc({
                      accessToken: t,
                      entropyId: this.entropyId,
                      entropyIdVerifier: this.entropyIdVerifier,
                      chainType: "ethereum",
                      hdWalletIndex: this.walletIndex,
                      request: n,
                    })
                  ).response.data;
            } catch (e) {
              throw (console.error(e), new eD("Disconnected", 4900));
            }
          }
        }
        async handleWalletApiRequest(e, t, n) {
          let r = this.privyClient;
          if (!r) throw new eD("Disconnected", 4900);
          if ("secp256k1_sign" === e.method) {
            let a = await (0, k.f)(
              r,
              async ({ message: e }) =>
                this.walletProxy.signWithUserSigner({
                  accessToken: n,
                  message: e,
                }),
              {
                chain_type: "ethereum",
                method: "secp256k1_sign",
                wallet_id: t.id,
                params: { hash: e.params[0] },
              }
            );
            if ("secp256k1_sign" !== a.method)
              throw new eD(`Invalid params for ${e.method}`, 4200);
            return a.data.signature;
          }
          throw new eD(`Method not supported: ${e.method}`, 4200);
        }
        constructor({
          walletProxy: e,
          address: t,
          entropyId: n,
          entropyIdVerifier: r,
          rpcConfig: a,
          chains: i,
          appId: o,
          chainId: s = 1,
          walletIndex: l,
          privyClient: c,
          walletAccount: d,
        }) {
          super(),
            (this.walletProxy = e),
            (this.address = t),
            (this.entropyId = n),
            (this.entropyIdVerifier = r),
            (this.chainId = s),
            (this.rpcConfig = a),
            (this.chains = i),
            (this.publicClient = (0, _.n)(s, this.chains, a, { appId: o })),
            (this.rpcTimeoutDuration = (0, _.q)(a, "privy")),
            (this.appId = o),
            (this.walletIndex = l),
            (this.privyClient = c),
            (this.walletAccount = d);
        }
      }
      function eq(e, t) {
        if (!Object.prototype.hasOwnProperty.call(e, t))
          throw TypeError("attempted to use private field on non-instance");
        return e;
      }
      var eB = 0;
      class eV extends _.E {
        async initialize() {
          await this.syncAccounts(),
            (this.initialized = !0),
            this.emit("initialized");
        }
        async connect(e) {
          return (
            e.showPrompt && (await this.promptConnection()),
            (await this.isConnected()) ? this.getConnectedWallet() : null
          );
        }
        get walletBranding() {
          return {
            name: this.providerDetail.info.name,
            icon: this.providerDetail.info.icon,
            id: this.providerDetail.info.rdns,
          };
        }
        disconnect() {
          console.warn(
            `Programmatic disconnect with ${this.providerDetail.info.name} is not yet supported.`
          );
        }
        async promptConnection() {
          try {
            let e = await this.proxyProvider.request({
              method: "eth_requestAccounts",
            });
            if (!e || 0 === e.length || !e[0])
              throw new T.x("Unable to retrieve accounts");
            await this.syncAccounts([e[0]]);
          } catch (e) {
            throw (0, _.k)(e);
          }
        }
        constructor(e, t, n, r, a) {
          super(a || "unknown", e, t, n),
            (this.connectorType = "injected"),
            (this.proxyProvider = new _.P(void 0, this.rpcTimeoutDuration)),
            this.subscribeListeners(),
            (this.providerDetail = r);
          let i = r.provider;
          this.proxyProvider.setWalletProvider(i);
        }
      }
      var eH = "__private_" + eB++ + "__walletBranding";
      class e$ extends _.E {
        async initialize() {
          await this.syncAccounts(),
            (this.initialized = !0),
            this.emit("initialized");
        }
        async connect(e) {
          return (
            e.showPrompt && (await this.promptConnection()),
            (await this.isConnected()) ? this.getConnectedWallet() : null
          );
        }
        get walletBranding() {
          return (
            eq(this, eH)[eH] ?? {
              name: "Browser Extension",
              icon: _.r,
              id: "extension",
            }
          );
        }
        disconnect() {
          console.warn(
            "Programmatic disconnect with browser wallets is not yet supported."
          );
        }
        async promptConnection() {
          try {
            let e = await this.proxyProvider.request({
              method: "eth_requestAccounts",
            });
            if (!e || 0 === e.length || !e[0])
              throw new T.x("Unable to retrieve accounts");
            await this.syncAccounts([e[0]]);
          } catch (e) {
            throw (0, _.k)(e);
          }
        }
        constructor(e, t, n, r, a) {
          super(a ?? "unknown", e, t, n),
            Object.defineProperty(this, eH, { writable: !0, value: void 0 }),
            (this.connectorType = "injected"),
            (this.proxyProvider = new _.P(void 0, this.rpcTimeoutDuration)),
            this.subscribeListeners(),
            this.proxyProvider.setWalletProvider(r),
            "metamask" === a
              ? (eq(this, eH)[eH] = {
                  name: "MetaMask",
                  icon: _.M,
                  id: "io.metamask",
                })
              : "phantom" === a &&
                (eq(this, eH)[eH] = {
                  name: "Phantom",
                  icon: _.u,
                  id: "phantom",
                });
        }
      }
      class eZ extends eV {
        disconnect() {
          console.warn("MetaMask does not support programmatic disconnect.");
        }
        async promptConnection() {
          try {
            y.tq ||
              (await this.proxyProvider.request({
                method: "wallet_requestPermissions",
                params: [{ eth_accounts: {} }],
              }));
            let e = await this.proxyProvider.request({
              method: "eth_requestAccounts",
            });
            if (!e || 0 === e.length || !e[0])
              throw new T.x("Unable to retrieve accounts");
            await this.syncAccounts([e[0]]);
          } catch (e) {
            throw (0, _.k)(e);
          }
        }
      }
      class eK extends j.Z {
        get wallets() {
          let e = new Set();
          return this.walletConnectors
            .flatMap((e) => e.wallets)
            .sort((e, t) =>
              e.connectedAt && t.connectedAt ? t.connectedAt - e.connectedAt : 0
            )
            .filter((t) => {
              let n = `${t.address}${t.walletClientType}${t.connectorType}${t.meta.id}`;
              return !e.has(n) && (e.add(n), !0);
            });
        }
        async initialize(e) {
          if (
            (this.initialized && !e) ||
            (e && this.removeAllConnectors(),
            this.externalWalletConfig.disableAllExternalWallets)
          )
            return;
          let t = (0, _.v)({
            store: this.store,
            walletList: this.walletList,
            externalWalletConfig: this.externalWalletConfig,
            walletChainType: this.walletChainType,
          }).then((e) => {
            e.forEach(
              ({
                type: e,
                eip6963InjectedProvider: t,
                legacyInjectedProvider: n,
              }) => {
                this.createEthereumWalletConnector({
                  connectorType: "injected",
                  walletClientType: e,
                  providers: {
                    eip6963InjectedProvider: t,
                    legacyInjectedProvider: n,
                  },
                });
              }
            );
          });
          for (let e of (this.walletList.includes("coinbase_wallet") &&
            this.createEthereumWalletConnector({
              connectorType: "coinbase_wallet",
              walletClientType: "coinbase_wallet",
            }),
          this.walletList.includes("base_account") &&
            this.createEthereumWalletConnector({
              connectorType: "base_account",
              walletClientType: "base_account",
            }),
          Object.values(_.w)))
            !e.isInstalled &&
              this.walletList.includes(e.client) &&
              (["ethereum-only", "ethereum-and-solana"].includes(
                this.walletChainType
              ) &&
                e.chainTypes.includes("ethereum") &&
                this.createEthereumWalletConnector({
                  connectorType: "null",
                  walletClientType: e.client,
                  walletConfig: e,
                }),
              ["ethereum-and-solana", "solana-only"].includes(
                this.walletChainType
              ) &&
                e.chainTypes.includes("solana") &&
                this.addSolanaWalletConnector(
                  new _.x({ id: e.client, name: e.name })
                ));
          this.externalWalletConfig.walletConnect.enabled &&
            this.createEthereumWalletConnector({
              connectorType: "wallet_connect_v2",
              walletClientType: "unknown",
            }),
            this.externalWalletConfig.solana.connectors
              ?.get()
              .forEach(this.addSolanaWalletConnector),
            this.externalWalletConfig.solana.connectors?._setOnConnectorsUpdated?.(
              (e) => {
                e?.forEach(this.addSolanaWalletConnector);
              }
            ),
            await t,
            (this.initialized = !0);
        }
        findWalletConnector(e, t, n) {
          return "wallet_connect_v2" === e
            ? this.walletConnectors
                .filter(_.y)
                .find(
                  (t) =>
                    t.connectorType === e &&
                    (!n || t.wallets.some((e) => e.address === n))
                ) ?? null
            : this.walletConnectors
                .filter(_.y)
                .find(
                  (r) =>
                    r.connectorType === e &&
                    r.walletClientType === t &&
                    (!n || r.wallets.some((e) => e.address === n))
                ) ?? null;
        }
        findSolanaWalletConnector(e) {
          return (
            this.walletConnectors
              .filter(_.z)
              .find((t) =>
                "unknown" === t.walletClientType
                  ? t.walletBranding.id === e
                  : t.walletClientType === e
              ) ?? null
          );
        }
        findEmbeddedWalletConnectors() {
          return this.walletConnectors.filter(
            (e) => "embedded" === e.connectorType
          );
        }
        findImportedWalletConnectors() {
          return this.walletConnectors.filter(
            (e) => "embedded_imported" === e.connectorType
          );
        }
        onInitialized(e) {
          e.wallets.forEach((e) => {
            let t = this.storedConnections.find(
              (t) =>
                t.address === e.address &&
                t.connectorType === e.connectorType &&
                ("solana" === e.type &&
                "unknown" === t.walletClientType &&
                "unknown" === e.walletClientType
                  ? e.meta.id === t.id
                  : t.walletClientType === e.walletClientType)
            );
            t && (e.connectedAt = t.connectedAt);
          }),
            this.emit("walletsUpdated"),
            this.emit("connectorInitialized");
        }
        onWalletsUpdated(e) {
          e.initialized && this.emit("walletsUpdated");
        }
        addEmbeddedWalletConnectors({
          walletProxy: e,
          user: t,
          embeddedWallets: n,
          defaultChain: r,
          appId: a,
          privyClient: i,
        }) {
          let { entropyId: o, entropyIdVerifier: s } = (0, _.F)(t);
          for (let t of n) {
            let n = this.findEmbeddedWalletConnectors().find(
              (e) => e.walletIndex === t.walletIndex
            );
            if (n && (0, _.y)(n)) n.proxyProvider.walletProxy = e;
            else {
              let n = new eF({
                provider: new ez({
                  walletProxy: e,
                  address: t.address,
                  entropyId: o,
                  entropyIdVerifier: s,
                  rpcConfig: this.rpcConfig,
                  chains: this.chains,
                  appId: a,
                  chainId: r.id,
                  walletIndex: t.walletIndex,
                  privyClient: i,
                  walletAccount: t,
                }),
                chains: this.chains,
                defaultChain: r,
                rpcConfig: this.rpcConfig,
                imported: !1,
                walletIndex: t.walletIndex,
              });
              this.addWalletConnector(n);
            }
          }
        }
        addImportedWalletConnector(e, t, n, r) {
          let a = this.findWalletConnector("embedded_imported", "privy", t);
          if (a && (0, _.y)(a)) a.proxyProvider.walletProxy = e;
          else {
            let a = new eF({
              provider: new ez({
                walletProxy: e,
                address: t,
                entropyId: t,
                entropyIdVerifier: "ethereum-address-verifier",
                walletIndex: 0,
                rpcConfig: this.rpcConfig,
                chains: this.chains,
                appId: r,
                chainId: n.id,
              }),
              chains: this.chains,
              walletIndex: 0,
              defaultChain: n,
              rpcConfig: this.rpcConfig,
              imported: !0,
            });
            this.addWalletConnector(a);
          }
        }
        removeEmbeddedWalletConnectors() {
          (this.walletConnectors = this.walletConnectors.filter(
            (e) => "embedded" !== e.connectorType
          )),
            (this.storedConnections = (0, _.J)()),
            this.emit("walletsUpdated");
        }
        removeImportedWalletConnectors() {
          let e = this.findImportedWalletConnectors();
          e.length &&
            (e.forEach((e) => {
              let t = this.walletConnectors.indexOf(e);
              this.walletConnectors.splice(t, 1);
            }),
            (this.storedConnections = (0, _.J)()),
            this.emit("walletsUpdated"));
        }
        async createEthereumWalletConnector({
          connectorType: e,
          walletClientType: t,
          providers: n,
          walletConfig: r,
        }) {
          let a = this.findWalletConnector(e, t);
          if (a && (0, _.y)(a))
            return a instanceof _.W && a.resetConnection(t), a;
          let i =
            "injected" !== e
              ? "coinbase_wallet" === e
                ? new eM(
                    this.chains,
                    this.defaultChain,
                    this.rpcConfig,
                    this.externalWalletConfig.coinbaseWallet.config
                  )
                : "base_account" === e
                ? new eO(
                    this.chains,
                    this.defaultChain,
                    this.rpcConfig,
                    this.externalWalletConfig.baseAccount.config,
                    this.setBaseAccountSdk
                  )
                : "null" !== e
                ? new _.W({
                    walletConnectCloudProjectId:
                      this.walletConnectCloudProjectId,
                    rpcConfig: this.rpcConfig,
                    chains: this.chains,
                    defaultChain: this.defaultChain,
                    shouldEnforceDefaultChainOnConnect:
                      this.shouldEnforceDefaultChainOnConnect,
                    privyAppId: this.privyAppId,
                    privyAppName: this.privyAppName,
                    walletClientType: t,
                  })
                : r
                ? new _.K({
                    id: r.client,
                    name: r.name,
                    defaultChain: this.defaultChain,
                    walletClientType: r.client,
                  })
                : null
              : "metamask" === t && n?.eip6963InjectedProvider
              ? new eZ(
                  this.chains,
                  this.defaultChain,
                  this.rpcConfig,
                  n?.eip6963InjectedProvider,
                  "metamask"
                )
              : "metamask" === t && n?.legacyInjectedProvider
              ? new e$(
                  this.chains,
                  this.defaultChain,
                  this.rpcConfig,
                  n?.legacyInjectedProvider,
                  "metamask"
                )
              : "phantom" === t && n?.legacyInjectedProvider
              ? new e$(
                  this.chains,
                  this.defaultChain,
                  this.rpcConfig,
                  n?.legacyInjectedProvider,
                  "phantom"
                )
              : n?.legacyInjectedProvider && "unknown_browser_extension" === t
              ? new e$(
                  this.chains,
                  this.defaultChain,
                  this.rpcConfig,
                  n?.legacyInjectedProvider
                )
              : n?.eip6963InjectedProvider
              ? new eV(
                  this.chains,
                  this.defaultChain,
                  this.rpcConfig,
                  n?.eip6963InjectedProvider,
                  t
                )
              : void 0;
          return i && this.addWalletConnector(i), i || null;
        }
        addWalletConnector(e) {
          this.walletConnectors.push(e),
            e.on("initialized", () => this.onInitialized(e)),
            e.on("walletsUpdated", () => this.onWalletsUpdated(e)),
            e.initialize().catch((e) => {
              console.debug("Failed to initialize connector", e);
            });
        }
        setWalletList(e) {
          (this.walletList = e),
            this.initialized && this.initialize(!0).catch(console.error);
        }
        removeAllConnectors() {
          for (let e of this.walletConnectors) e.removeAllListeners();
          this.walletConnectors = [];
        }
        constructor(e, t, n, r, a, i, o, s, l, c, d, u) {
          super(),
            (this.addSolanaWalletConnector = async (e) => {
              let t = this.findSolanaWalletConnector(e.walletClientType);
              if (!t || "null" === t.connectorType) {
                if ("null" === t?.connectorType) {
                  let e = this.walletConnectors.indexOf(t);
                  this.walletConnectors.splice(e, 1);
                }
                this.addWalletConnector(e);
              }
            }),
            (this.privyAppId = e),
            (this.walletConnectCloudProjectId = t),
            (this.rpcConfig = n),
            (this.chains = r),
            (this.defaultChain = a),
            (this.walletConnectors = []),
            (this.initialized = !1),
            (this.store = i),
            (this.walletList = o),
            (this.shouldEnforceDefaultChainOnConnect = s),
            (this.externalWalletConfig = l),
            (this.privyAppName = c),
            (this.walletChainType = u || "ethereum-only"),
            (this.setBaseAccountSdk = d),
            (this.storedConnections = (0, _.J)());
        }
      }
      let eY = [T.z, T.A, T.B];
      class eG {
        async get(e, t) {
          try {
            return await this.baseFetch(e, t);
          } catch (e) {
            throw (0, T.f)(e);
          }
        }
        async post(e, t, n) {
          try {
            return await this.baseFetch(e, {
              method: "POST",
              ...(t ? { body: t } : {}),
              ...n,
            });
          } catch (e) {
            throw (0, T.f)(e);
          }
        }
        async delete(e, t) {
          try {
            return await this.baseFetch(e, { method: "DELETE", ...t });
          } catch (e) {
            throw (0, T.f)(e);
          }
        }
        constructor({ appId: e, appClientId: t, client: n, defaults: r }) {
          (this.appId = e),
            (this.appClientId = t),
            (this.clientAnalyticsId = n.clientAnalyticsId),
            (this.sdkVersion = _.V),
            (this.client = n),
            (this.defaults = r),
            (this.fallbackApiUrl = n.fallbackApiUrl),
            (this.baseFetch = N.Wg.create({
              baseURL: this.defaults.baseURL,
              timeout: this.defaults.timeout,
              retry: 3,
              retryDelay: 500,
              retryStatusCodes: [408, 409, 425, 500, 502, 503, 504],
              credentials: "include",
              onRequest: async ({ request: e, options: t }) => {
                let n = new Headers(t.headers);
                n.set("privy-app-id", this.appId),
                  this.appClientId &&
                    n.set("privy-client-id", this.appClientId),
                  n.set("privy-ca-id", this.clientAnalyticsId || ""),
                  n.set("privy-client", `react-auth:${this.sdkVersion}`);
                let r = eY.includes(e.toString());
                if (!n.has("authorization")) {
                  let e = await this.client.getAccessToken({
                    disableAutoRefresh: r,
                  });
                  null !== e && n.set("authorization", `Bearer ${e}`);
                }
                (t.headers = n),
                  t.retryDelay &&
                    "number" == typeof t.retryDelay &&
                    (t.retryDelay = 3 * t.retryDelay);
              },
              onRequestError: ({ error: e }) => {
                if (e instanceof DOMException && "AbortError" === e.name)
                  throw new T.y();
              },
            }));
        }
      }
      let eJ = /paymaster\.biconomy\.io\/api/i,
        eQ = {
          mode: "SPONSORED",
          calculateGasLimits: !0,
          expiryDuration: 300,
          sponsorshipInfo: {
            webhookData: {},
            smartAccountInfo: { name: "BICONOMY", version: "2.0.0" },
          },
        },
        eX = (e, t) =>
          e && eJ.test(e)
            ? eQ
            : t && t.policy_id
            ? { policyId: t.policy_id }
            : void 0,
        e0 = (e) => ({
          rpId: e.rp_id,
          challenge: e.challenge,
          allowCredentials:
            e.allow_credentials?.map((e) => ({
              id: e.id,
              type: e.type,
              transports: e.transports,
            })) || [],
          timeout: e.timeout,
          extensions: {
            appid: e.extensions?.app_id,
            credProps: e.extensions?.cred_props,
            hmacCreateSecret: e.extensions?.hmac_create_secret,
          },
          userVerification: e.user_verification,
        });
      class e1 {
        async authenticate() {
          if (!this.api) throw new T.P("Auth flow has no API instance");
          try {
            return await this.api.post(T.C, { token: this.meta.token });
          } catch (e) {
            throw (0, T.f)(e);
          }
        }
        async link() {
          if (!this.api) throw new T.P("Auth flow has no API instance");
          try {
            return await this.api.post(T.D, { token: this.meta.token });
          } catch (e) {
            throw (0, T.f)(e);
          }
        }
        constructor(e) {
          this.meta = { token: e };
        }
      }
      class e2 {
        getOrCreateGuestCredential(e) {
          let t = (0, _.U)(e);
          if ((0, _.N)()) {
            if (_.s.get(t)) return _.s.get(t);
            {
              let e = S.c((0, _.Q)(32));
              return _.s.put(t, e), e;
            }
          }
          return S.c((0, _.Q)(32));
        }
        async authenticate() {
          if (!this.api) throw new T.P("Auth flow has no API instance");
          try {
            return await this.api.post(T.E, {
              guest_credential: this.meta.guestCredential,
            });
          } catch (e) {
            throw (0, T.f)(e);
          }
        }
        async link() {
          throw Error("Linking is not supported for the guest flow");
        }
        constructor(e) {
          this.meta = { guestCredential: this.getOrCreateGuestCredential(e) };
        }
      }
      function e4() {
        return !(y.G6 && window.location.origin.startsWith("http://localhost"));
      }
      let e3 = (0, R.U)(() => ({ identityToken: null }));
      var e5,
        e6 =
          (((e5 = {}).PRIVY = "privy_access_token"),
          (e5.CUSTOMER = "customer_access_token"),
          e5);
      class e7 {
        get token() {
          return this.privyAccessToken || this.customerAccessToken;
        }
        getToken(e) {
          return "privy_access_token" === e
            ? this.privyAccessToken
            : this.customerAccessToken;
        }
        get customerAccessToken() {
          return this._getToken(_.Y);
        }
        get privyAccessToken() {
          return this._getToken(_.Z);
        }
        _getToken(e) {
          try {
            let t = _.s.get(e);
            return "string" == typeof t ? eW.throwIfNotWellFormedJwt(t) : null;
          } catch (e) {
            return console.error(e), this.destroyLocalState(), null;
          }
        }
        get refreshToken() {
          try {
            let e = _.s.get(_._);
            return "string" == typeof e ? e : null;
          } catch (e) {
            return console.error(e), this.destroyLocalState(), null;
          }
        }
        getProviderAccessToken(e) {
          try {
            let t = _.s.get((0, _.$)(e));
            if ("string" != typeof t) return null;
            {
              let n = new eW(t);
              return n.isExpired() ? (_.s.del((0, _.$)(e)), null) : n.value;
            }
          } catch (e) {
            return console.error(e), null;
          }
        }
        get mightHaveServerCookies() {
          try {
            let e = O.Z.get(_.a0);
            return void 0 !== e && e.length > 0;
          } catch (e) {
            console.error(e);
          }
          return !1;
        }
        hasRefreshCredentials(e = "privy_access_token") {
          let t = "string" == typeof this.getToken(e),
            n =
              "string" == typeof this.refreshToken &&
              this.refreshToken !== _.a1;
          return this.mightHaveServerCookies || (t && n);
        }
        hasActiveAccessToken(e) {
          let t = eW.parse(this.getToken(e));
          return null !== t && !t.isExpired(30);
        }
        authenticate(e) {
          return this.authenticateOnce.execute(e);
        }
        link(e) {
          return this.linkOnce.execute(e);
        }
        refresh() {
          return this.refreshOnce.execute();
        }
        destroy() {
          return this.destroyOnce.execute();
        }
        storeProviderAccessToken(e, t) {
          "string" == typeof t ? _.s.put((0, _.$)(e), t) : _.s.del((0, _.$)(e));
        }
        updateIdentityToken(e) {
          "string" == typeof e
            ? this.storeIdentityToken(e)
            : this.clearIdentityToken();
        }
        async _authenticate(e) {
          try {
            let t = await e.authenticate(),
              { user: n, is_new_user: r, oauth_tokens: a } = t;
            this.handleTokenResponse(t);
            let i = a
              ? {
                  provider: a.provider,
                  accessToken: a.access_token,
                  accessTokenExpiresInSeconds:
                    a.access_token_expires_in_seconds,
                  refreshToken: a.refresh_token,
                  refreshTokenExpiresInSeconds:
                    a.refresh_token_expires_in_seconds,
                  scopes: a.scopes,
                }
              : void 0;
            return (
              this._trackAuthenticateEvents(e, r),
              { user: (0, P.c)(n), isNewUser: r, oAuthTokens: i }
            );
          } catch (e) {
            throw (console.warn("Error authenticating session"), (0, T.F)(e));
          }
        }
        _trackAuthenticateEvents(e, t) {
          let n =
            e instanceof ef
              ? "email"
              : e instanceof ej
              ? "sms"
              : e instanceof _.X
              ? "siwe"
              : e instanceof e2
              ? "guest"
              : e instanceof e1
              ? "custom_auth"
              : e instanceof eT
              ? e.meta.provider
              : null;
          n &&
            this.client &&
            this.client.createAnalyticsEvent({
              eventName: "sdk_authenticate",
              payload: { method: n, isNewUser: t },
            }),
            "siwe" === n &&
              this.client &&
              this.client.createAnalyticsEvent({
                eventName: "sdk_authenticate_siwe",
                payload: {
                  connectorType: e.meta.connectorType,
                  walletClientType: e.meta.walletClientType,
                },
              });
        }
        async _link(e) {
          try {
            let t = await e.link(),
              n = t.oauth_tokens,
              r = n
                ? {
                    provider: n.provider,
                    accessToken: n.access_token,
                    accessTokenExpiresInSeconds:
                      n.access_token_expires_in_seconds,
                    refreshToken: n.refresh_token,
                    refreshTokenExpiresInSeconds:
                      n.refresh_token_expires_in_seconds,
                    scopes: n.scopes,
                  }
                : void 0;
            return { user: (0, P.c)(t), oAuthTokens: r };
          } catch (e) {
            throw (console.warn("Error linking account"), (0, T.F)(e));
          }
        }
        async _refresh() {
          if (!this.api) throw new T.P("Session has no API instance");
          if (!this.client)
            throw new T.P("Session has no PrivyClient instance");
          await this.client.getAccessToken({ disableAutoRefresh: !0 });
          let e = this.token,
            t = this.refreshToken;
          if (
            this.client.useServerCookies &&
            !this.mightHaveServerCookies &&
            this.token &&
            window.location.origin === this.client.apiUrl
          )
            return this.destroyLocalState(), null;
          try {
            let n;
            if (!((e && t) || this.mightHaveServerCookies)) return null;
            {
              let r = {};
              e && (r.authorization = `Bearer ${e}`),
                (n = await this.api.post(T.z, t ? { refresh_token: t } : {}, {
                  headers: r,
                }));
            }
            return this.handleTokenResponse(n), (0, P.c)(n.user);
          } catch (e) {
            if (
              e instanceof T.G &&
              e.privyErrorCode === T.h.MISSING_OR_INVALID_TOKEN
            )
              return (
                console.warn(
                  "Unable to refresh tokens - token is missing or no longer valid"
                ),
                this.destroyLocalState(),
                null
              );
            throw (0, T.F)(e);
          }
        }
        handleTokenResponse(e) {
          e.session_update_action && "set" !== e.session_update_action
            ? "clear" === e.session_update_action
              ? this.destroyLocalState()
              : "ignore" === e.session_update_action &&
                (e.token &&
                  (this.storeCustomerAccessToken(e.token),
                  this.storePrivyAccessToken(e.privy_access_token)),
                e.identity_token && this.storeIdentityToken(e.identity_token))
            : this._storeAllTokens(e);
        }
        _storeAllTokens(e) {
          this.storeRefreshToken(e.refresh_token),
            this.storeCustomerAccessToken(e.token),
            this.storePrivyAccessToken(e.privy_access_token),
            e.identity_token && this.storeIdentityToken(e.identity_token);
        }
        async _destroy() {
          try {
            await this.api?.post(T.A, { refresh_token: this.refreshToken });
          } catch (e) {
            console.warn("Error destroying session");
          }
          this.destroyLocalState();
        }
        destroyLocalState() {
          this.storeRefreshToken(null),
            this.storeCustomerAccessToken(null),
            this.storePrivyAccessToken(null),
            this.clearIdentityToken();
        }
        storeCustomerAccessToken(e) {
          if ("string" == typeof e) {
            let t = _.s.get(_.Y);
            if ((_.s.put(_.Y, e), !this.client?.useServerCookies)) {
              let t = eW.parse(e)?.expiration;
              O.Z.set(_.a2, e, {
                sameSite: "Strict",
                secure: e4(),
                expires: t ? new Date(1e3 * t) : void 0,
              });
            }
            t !== e && this.client?.onStoreCustomerAccessToken?.(e);
          } else
            _.s.del(_.Y),
              O.Z.remove(_.a2),
              this.client?.onDeleteCustomerAccessToken?.();
        }
        storeRefreshToken(e) {
          "string" == typeof e
            ? (_.s.put(_._, e),
              this.client?.useServerCookies ||
                O.Z.set(_.a0, "t", {
                  sameSite: "Strict",
                  secure: e4(),
                  expires: 30,
                }))
            : (_.s.del(_._), O.Z.remove(_.a3), O.Z.remove(_.a0));
        }
        storePrivyAccessToken(e) {
          "string" == typeof e ? _.s.put(_.Z, e) : _.s.del(_.Z);
        }
        storeIdentityToken(e) {
          if (
            (e3.setState({ identityToken: e }), this.client?.useServerCookies)
          )
            return;
          _.s.put(_.a4, e);
          let t = eW.parse(e)?.expiration;
          O.Z.set(_.a5, e, {
            sameSite: "Strict",
            secure: e4(),
            expires: t ? new Date(1e3 * t) : void 0,
          });
        }
        clearIdentityToken() {
          _.s.del(_.a4), e3.setState({ identityToken: null }), O.Z.remove(_.a5);
        }
        constructor() {
          (this.authenticateOnce = new _.R(async (e) => this._authenticate(e))),
            (this.linkOnce = new _.R(async (e) => this._link(e))),
            (this.refreshOnce = new _.R(this._refresh.bind(this))),
            (this.destroyOnce = new _.R(this._destroy.bind(this)));
        }
      }
      var e9 = 0,
        e8 = "__private_" + e9++ + "__getOrGenerateClientAnalyticsId";
      class te {
        getAppId() {
          return this.appId;
        }
        initializeConnectorManager({
          walletConnectCloudProjectId: e,
          rpcConfig: t,
          chains: n,
          defaultChain: r,
          store: a,
          walletList: i,
          shouldEnforceDefaultChainOnConnect: o,
          externalWalletConfig: s,
          appName: l,
          walletChainType: c,
          setBaseAccountSdk: d,
        }) {
          this.connectors ||
            (this.connectors = new eK(
              this.appId,
              e,
              t,
              n,
              r,
              a,
              i,
              o,
              s,
              l,
              d,
              c
            ));
        }
        generateApi() {
          let e = new eG({
            appId: this.appId,
            appClientId: this.appClientId,
            client: this,
            defaults: { baseURL: this.apiUrl, timeout: this.timeout },
          });
          return (this.session.api = e), e;
        }
        updateApiUrl(e) {
          (this.apiUrl = e || this.fallbackApiUrl),
            (this.api = this.generateApi()),
            e && (this.useServerCookies = !0);
        }
        authenticate() {
          if (!this.authFlow) throw new T.P("No auth flow in progress.");
          return this.session.authenticate(this.authFlow);
        }
        async link() {
          if (!this.authFlow) throw new T.P("No auth flow in progress.");
          let { oAuthTokens: e } = await this.session.link(this.authFlow);
          return { user: await this.getAuthenticatedUser(), oAuthTokens: e };
        }
        storeProviderAccessToken(e, t) {
          this.session.storeProviderAccessToken(e, t);
        }
        getProviderAccessToken(e) {
          return this.session.getProviderAccessToken(e);
        }
        async logout() {
          await this.session.destroy(), (this.authFlow = void 0);
        }
        clearProviderAcccessTokens(e) {
          e.linkedAccounts
            .filter((e) => "cross_app" === e.type)
            .forEach((e) => {
              this.storeProviderAccessToken(e.providerApp.id, null);
            });
        }
        startAuthFlow(e) {
          return (e.api = this.api), (this.authFlow = e), this.authFlow;
        }
        async initMfaSmsVerification() {
          try {
            await this.api.post(T.H, { action: "verify" });
          } catch (e) {
            throw (0, T.f)(e);
          }
        }
        async initMfaPasskeyVerification() {
          try {
            let e = await this.api.post(T.I, {});
            return e0(e.options);
          } catch (e) {
            throw (0, T.f)(e);
          }
        }
        async getCrossAppProviderDetails(e) {
          try {
            return (
              this._cachedProviderAppDetails[e] ||
                (this._cachedProviderAppDetails[e] = await this.api.get(
                  `/api/v1/apps/${e}/cross-app/details`
                )),
              this._cachedProviderAppDetails[e]
            );
          } catch (e) {
            console.error("Error fetching cross app provider details", e);
          }
        }
        async acceptTerms() {
          try {
            let e = await this.api.post(T.J, {});
            return (0, P.c)(e);
          } catch (e) {
            throw (0, T.F)(e);
          }
        }
        async unlinkEmail(e) {
          try {
            let t = await this.api.post(T.K, { address: e });
            return (await this.getAuthenticatedUser()) ?? (0, P.c)(t);
          } catch (e) {
            throw (0, T.F)(e);
          }
        }
        async unlinkPhone(e) {
          try {
            let t = await this.api.post(T.L, { phoneNumber: e });
            return (await this.getAuthenticatedUser()) ?? (0, P.c)(t);
          } catch (e) {
            throw (0, T.F)(e);
          }
        }
        async unlinkEthereumWallet(e) {
          try {
            let t = await this.api.post(T.M, { address: e });
            return (await this.getAuthenticatedUser()) ?? (0, P.c)(t);
          } catch (e) {
            throw (0, T.F)(e);
          }
        }
        async unlinkSolanaWallet(e) {
          try {
            let t = await this.api.post(T.N, { address: e });
            return (await this.getAuthenticatedUser()) ?? (0, P.c)(t);
          } catch (e) {
            throw (0, T.F)(e);
          }
        }
        async unlinkOAuth(e, t) {
          try {
            let n = await this.api.post(T.O, { provider: e, subject: t });
            return (await this.getAuthenticatedUser()) ?? (0, P.c)(n);
          } catch (e) {
            throw (0, T.F)(e);
          }
        }
        async unlinkFarcaster(e) {
          try {
            let t = await this.api.post(T.Q, { fid: e });
            return (await this.getAuthenticatedUser()) ?? (0, P.c)(t);
          } catch (e) {
            throw (0, T.F)(e);
          }
        }
        async unlinkTelegram(e) {
          try {
            let t = await this.api.post(T.R, { telegram_user_id: e });
            return (await this.getAuthenticatedUser()) ?? (0, P.c)(t);
          } catch (e) {
            throw (0, T.F)(e);
          }
        }
        async revokeDelegatedWallet() {
          try {
            await this.api.post(T.S, {});
          } catch (e) {
            throw (0, T.F)(e);
          }
        }
        async createAnalyticsEvent({
          eventName: e,
          payload: t,
          timestamp: n,
          options: r,
        }) {
          if ("undefined" != typeof window)
            try {
              this.clientAnalyticsId ||
                console.warn(
                  "No client analytics id set, refusing to send analytics event"
                ),
                await this.api.post(
                  T.B,
                  {
                    event_name: e,
                    client_id: this.clientAnalyticsId,
                    payload: {
                      ...(t || {}),
                      clientTimestamp: n
                        ? n.toISOString()
                        : new Date().toISOString(),
                    },
                  },
                  { retry: -1, keepalive: r?.keepAlive ?? !1 }
                );
            } catch (e) {
              console.log("Unable to submit event. This is not an issue.");
            }
        }
        async signMoonpayOnRampUrl(e) {
          try {
            return this.api.post(T.T, e);
          } catch (e) {
            throw (0, T.F)(e);
          }
        }
        async initCoinbaseOnRamp(e) {
          try {
            return this.api.post(T.U, e);
          } catch (e) {
            throw (0, T.F)(e);
          }
        }
        async getCoinbaseOnRampStatus({ partnerUserId: e }) {
          try {
            return this.api.get(`${T.V}?partnerUserId=${e}`);
          } catch (e) {
            throw (0, T.F)(e);
          }
        }
        async getAuthenticatedUser() {
          return this.session.hasRefreshCredentials()
            ? this.session.refresh()
            : null;
        }
        async getAccessToken(e) {
          return (
            (await this.getPrivyAccessToken(e)) ||
            (await this.getCustomerAccessToken(e))
          );
        }
        async getCustomerAccessToken(e) {
          return await this._getToken(e6.CUSTOMER, e);
        }
        async getPrivyAccessToken(e) {
          return await this._getToken(e6.PRIVY, e);
        }
        async _getToken(e, t) {
          return this.session.getToken(e)
            ? this.session.hasActiveAccessToken(e)
              ? this.session.hasRefreshCredentials(e)
                ? eN.parse(this.session.getToken(e))?.appId !== this.appId
                  ? (await this.logout(), null)
                  : this.session.getToken(e)
                : (this.session.destroyLocalState(), null)
              : !t?.disableAutoRefresh && this.session.hasRefreshCredentials(e)
              ? (await this.session.refresh(), this.session.getToken(e))
              : null
            : null;
        }
        async getSmartWalletsConfig() {
          try {
            let e = {},
              t = this.session.token;
            t && (e.authorization = `Bearer ${t}`);
            let n = await this.api.get(
              `/api/v1/apps/${this.appId}/smart_wallets`,
              { baseURL: this.fallbackApiUrl, headers: e }
            );
            return n.enabled
              ? {
                  enabled: n.enabled,
                  smartWalletVersion: n.smart_wallet_version,
                  smartWalletType: n.smart_wallet_type,
                  configuredNetworks: n.configured_networks.map((e) => ({
                    chainId: e.chain_id,
                    bundlerUrl: e.bundler_url,
                    paymasterUrl: e.paymaster_url,
                    paymasterContext: eX(e.paymaster_url, e.paymaster_context),
                  })),
                }
              : { enabled: n.enabled };
          } catch (e) {
            throw (0, T.F)(e);
          }
        }
        async getUsdTokenPrice(e) {
          try {
            return (
              await this.api.get(
                `/api/v1/token_price?chainId=${e.id}&tokenSymbol=${e.nativeCurrency.symbol}`
              )
            ).usd;
          } catch (t) {
            return void console.error(
              `Unable to fetch token price for chain with id ${e.id}`
            );
          }
        }
        async getUsdPriceForSol() {
          try {
            return (
              await this.api.get(
                "/api/v1/token_price?chainId=0&tokenSymbol=SOL"
              )
            ).usd;
          } catch (e) {
            return void console.error("Unable to fetch token price for SOL");
          }
        }
        async getSplTokenMetadata({ mintAddress: e, cluster: t }) {
          try {
            return await this.api.get(
              `/api/v1/spl_token_info?mint_address=${e}&cluster=${t}`
            );
          } catch (n) {
            return void console.error(
              `Unable to fetch token metadata for ${t}:${e}`
            );
          }
        }
        async requestFarcasterSignerStatus(e) {
          try {
            return await this.api.post("/api/v1/farcaster/signer/status", {
              ed25519_public_key: e,
            });
          } catch (e) {
            throw (console.error("Unable to fetch Farcaster signer status"), e);
          }
        }
        async generateSiweNonce({ address: e, captchaToken: t }) {
          try {
            return (await this.api.post(T.W, { address: e, token: t })).nonce;
          } catch (e) {
            throw (0, T.F)(e);
          }
        }
        async authenticateWithSiweInternal({
          message: e,
          signature: t,
          chainId: n,
          walletClientType: r,
          connectorType: a,
          mode: i,
        }) {
          return await this.api.post(T.X, {
            message: e,
            signature: t,
            chainId: n,
            walletClientType: r,
            connectorType: a,
            mode: i,
          });
        }
        async linkWithSiweInternal({
          message: e,
          signature: t,
          chainId: n,
          walletClientType: r,
          connectorType: a,
        }) {
          return await this.api.post(T.Y, {
            message: e,
            signature: t,
            chainId: n,
            walletClientType: r,
            connectorType: a,
          });
        }
        async linkSmartWallet({
          message: e,
          signature: t,
          smartWalletType: n,
          smartWalletVersion: r,
        }) {
          try {
            let a = await this.api.post(T.Z, {
              message: e,
              signature: t,
              smart_wallet_type: n,
              smart_wallet_version: r,
            });
            return (0, P.c)(a);
          } catch (e) {
            throw (0, T.F)(e);
          }
        }
        async linkWithSiwe({
          message: e,
          signature: t,
          chainId: n,
          walletClientType: r,
          connectorType: a,
        }) {
          try {
            let i = await this.linkWithSiweInternal({
              message: e,
              signature: t,
              chainId: n,
              walletClientType: r,
              connectorType: a,
            });
            return (0, P.c)(i);
          } catch (e) {
            throw (0, T.F)(e);
          }
        }
        async generateSiwsNonce({ address: e, captchaToken: t }) {
          try {
            return (await this.api.post(T._, { address: e, token: t })).nonce;
          } catch (e) {
            throw (0, T.F)(e);
          }
        }
        async authenticateWithSiwsInternal({
          message: e,
          signature: t,
          walletClientType: n,
          connectorType: r,
          mode: a,
          messageType: i = "plain",
        }) {
          return await this.api.post(T.$, {
            message: e,
            signature: t,
            walletClientType: n,
            connectorType: r,
            mode: a,
            message_type: i,
          });
        }
        async authenticateWithSiws({
          message: e,
          signature: t,
          walletClientType: n,
          connectorType: r,
          mode: a,
          messageType: i = "plain",
        }) {
          let o = await this.authenticateWithSiwsInternal({
            message: e,
            signature: t,
            walletClientType: n,
            connectorType: r,
            mode: a,
            messageType: i,
          });
          this.session.handleTokenResponse(o);
          let s = (0, P.c)(o.user);
          if (!s) throw Error("Authentication failed - no user returned");
          return { user: s, isNewUser: o.is_new_user || !1 };
        }
        async sendAccountTransferRequest({
          nonce: e,
          account: t,
          accountType: n,
          externalWalletMetadata: r,
          telegramAuthResult: a,
          telegramWebAppData: i,
          farcasterEmbeddedAddress: o,
          oAuthUserInfo: s,
        }) {
          try {
            let l, c;
            switch (n) {
              case "email":
                (l = T.a6), (c = { nonce: e, email: t });
                break;
              case "sms":
                (l = T.a5), (c = { nonce: e, phoneNumber: t });
                break;
              case "siwe":
                if (((l = T.a4), !r))
                  throw Error("Wallet parameters must be defined");
                c = { nonce: e, address: t, ...r };
                break;
              case "farcaster":
                (l = T.a3),
                  (c = {
                    nonce: e,
                    farcaster_id: t,
                    farcaster_embedded_address: o,
                  });
                break;
              case "telegram":
                (l = T.a2),
                  (c = {
                    nonce: e,
                    telegram_auth_result: a,
                    telegram_web_app_data: i,
                  });
                break;
              case "siws":
                (l = T.a1), (c = { nonce: e, address: t, ...r });
                break;
              case "custom":
              case "guest":
              case "passkey":
                throw Error("Invalid transfer account type");
              default:
                (l = T.a0), (c = { nonce: e, userInfo: s });
            }
            let d = await this.api.post(l, c);
            return (await this.getAuthenticatedUser()) ?? (0, P.c)(d);
          } catch (e) {
            throw (0, T.F)(e);
          }
        }
        async linkWithSiwsInternal({
          message: e,
          signature: t,
          walletClientType: n,
          connectorType: r,
          messageType: a = "plain",
        }) {
          return await this.api.post(T.a7, {
            message: e,
            signature: t,
            walletClientType: n,
            connectorType: r,
            message_type: a,
          });
        }
        async linkWithSiws({
          message: e,
          signature: t,
          walletClientType: n,
          connectorType: r,
          messageType: a = "plain",
        }) {
          try {
            let i = await this.linkWithSiwsInternal({
              message: e,
              signature: t,
              walletClientType: n,
              connectorType: r,
              messageType: a,
            });
            return (0, P.c)(i);
          } catch (e) {
            throw (0, T.F)(e);
          }
        }
        async updateUserAndIdToken() {
          try {
            let e = await this.api.get(T.a8);
            return (
              this.session.updateIdentityToken(e.identity_token),
              (0, P.c)(e.user)
            );
          } catch (e) {
            throw (0, T.F)(e);
          }
        }
        async scanTransaction(e) {
          try {
            return await this.api.post(T.a9, e);
          } catch (e) {
            throw (0, T.F)(e);
          }
        }
        constructor({
          apiUrl: e = _.a6,
          appId: t,
          appClientId: n,
          timeout: r = _.a7,
        }) {
          Object.defineProperty(this, e8, { value: tt }),
            (this._cachedProviderAppDetails = {}),
            (this.apiUrl = e),
            (this.fallbackApiUrl = this.apiUrl),
            (this.useServerCookies =
              e !== _.a6 && e.startsWith("https://privy.")),
            (this.timeout = r),
            (this.appId = t),
            (this.appClientId = n),
            (this.clientAnalyticsId = (function (e, t) {
              if (!Object.prototype.hasOwnProperty.call(e, t))
                throw TypeError(
                  "attempted to use private field on non-instance"
                );
              return e;
            })(this, e8)[e8]()),
            i || (i = new e7()),
            (this.session = i),
            (this.api = this.generateApi()),
            (this.session.client = this);
        }
      }
      function tt() {
        if ("undefined" == typeof window) return null;
        try {
          let e = _.s.get(_.a8);
          if ("string" == typeof e && e.length > 0) return e;
        } catch (e) {}
        let e = (0, E.Z)();
        try {
          return _.s.put(_.a8, e), e;
        } catch (t) {
          return e;
        }
      }
      let tn = ({ delayedExecution: e, ...t }) => {
          let {
              enabled: n,
              siteKey: r,
              appId: a,
              setError: i,
              setToken: o,
              setExecuting: s,
              ref: l,
            } = (0, _.a9)(),
            [, c] = (0, w.useMemo)(() => r?.split("t:") || [], [r]);
          if (((0, w.useEffect)(() => l.current?.remove, []), !n)) return null;
          if (!c) throw Error("Unsupported captcha site key");
          return (0, p.jsx)("div", {
            className: "hidden h-0 w-0",
            children: (0, p.jsx)(M.Nc, {
              ...t,
              ref: l,
              siteKey: c,
              options: {
                action: a,
                size: "invisible",
                ...(e
                  ? { appearance: "execute", execution: "execute" }
                  : { appearance: "always", execution: "render" }),
              },
              onUnsupported: () => {
                t.onUnsupported?.(),
                  console.warn("Browser does not support Turnstile.");
              },
              onError: () => {
                t.onError?.(), i("Captcha failed"), s(!1);
              },
              onSuccess: (e) => {
                t.onSuccess?.(e), o(e), s(!1);
              },
              onExpire: () => {
                t.onExpire?.();
                try {
                  l.current?.reset(), i(void 0), o(void 0);
                } catch (e) {
                  i("expired_and_failed_reset");
                }
              },
            }),
          });
        },
        tr = F.zo.div.withConfig({
          displayName: "AppLogoContainer",
          componentId: "sc-ba98f772-0",
        })([
          "display:flex;flex-direction:column;align-items:center;padding:0px 0px 30px;@media (max-width:440px){padding:10px 10px 20px;}",
        ]),
        ta = F.zo.div.withConfig({
          displayName: "Title",
          componentId: "sc-ba98f772-1",
        })([
          "font-size:18px;line-height:30px;text-align:center;font-weight:600;margin-bottom:10px;",
        ]),
        ti = F.zo.div.withConfig({
          displayName: "SubTitle",
          componentId: "sc-ba98f772-2",
        })(["font-size:0.875rem;text-align:center;"]),
        to = F.zo.div.withConfig({
          displayName: "Container",
          componentId: "sc-ba98f772-3",
        })([
          "display:flex;flex-direction:column;align-items:center;gap:10px;flex-grow:1;padding:20px 0;@media (max-width:440px){padding:10px 10px 20px;}",
        ]),
        ts = F.zo.div.withConfig({
          displayName: "List",
          componentId: "sc-ba98f772-4",
        })([
          "display:flex;flex-direction:column;align-items:stretch;gap:0.75rem;padding:1rem 0rem 0rem;flex-grow:1;width:100%;",
        ]),
        tl = F.zo.div.withConfig({
          displayName: "ListItemIcon",
          componentId: "sc-ba98f772-5",
        })([
          "width:25px;display:flex;align-items:center;justify-content:flex-start;> svg{z-index:2;height:25px !important;width:25px !important;color:var(--privy-color-accent);}",
        ]),
        tc = F.zo.div.withConfig({
          displayName: "ListItem",
          componentId: "sc-ba98f772-6",
        })([
          "display:flex;align-items:center;gap:10px;font-size:0.875rem;line-height:1rem;text-align:left;",
        ]),
        td = F.zo.div.withConfig({
          displayName: "BottomSection",
          componentId: "sc-ba98f772-7",
        })(["display:flex;flex-direction:column;gap:10px;padding-top:20px;"]),
        tu = F.zo.div.withConfig({
          displayName: "MethodList",
          componentId: "sc-ba98f772-8",
        })([
          "display:flex;flex-direction:column;align-items:stretch;gap:1rem;padding:1rem 0rem 0rem;flex-grow:1;width:100%;",
        ]),
        th = F.zo.div.withConfig({
          displayName: "MethodListItem",
          componentId: "sc-ba98f772-9",
        })(["display:flex;gap:5px;width:100%;position:relative;"]),
        tp = F.zo.button.withConfig({
          displayName: "RemoveMethodButton",
          componentId: "sc-ba98f772-10",
        })([
          "&&{background-color:transparent;color:var(--privy-color-foreground-3);padding:0 0.75rem;display:flex;align-items:center;height:100%;> svg{z-index:2;height:20px !important;width:20px !important;}}&&:hover{color:var(--privy-color-error);}",
        ]),
        tm = F.zo.div.withConfig({
          displayName: "MethodText",
          componentId: "sc-ba98f772-11",
        })([
          "display:flex;align-items:center;gap:0.5rem;> svg{z-index:2;height:20px !important;width:20px !important;}",
        ]),
        tw = F.zo.div.withConfig({
          displayName: "ExtraText",
          componentId: "sc-ba98f772-12",
        })(
          [
            "display:flex;align-items:center;gap:6px;font-weight:400 !important;color:",
            ";> svg{z-index:2;height:18px !important;width:18px !important;display:flex !important;align-items:flex-end;}",
          ],
          (e) =>
            e.$isAccent
              ? "var(--privy-color-accent)"
              : "var(--privy-color-foreground-3)"
        ),
        ty = F.zo.div.withConfig({
          displayName: "SmsInsecureText",
          componentId: "sc-ba98f772-13",
        })(["width:100%;display:flex;justify-content:space-between;"]),
        tg = F.zo.p.withConfig({
          displayName: "TermsText",
          componentId: "sc-ba98f772-14",
        })([
          "text-align:left;width:100%;color:var(--privy-color-foreground-3) !important;",
        ]),
        tf = F.zo.button.withConfig({
          displayName: "PrimaryTextButton",
          componentId: "sc-ba98f772-15",
        })(
          [
            "display:flex;flex-direction:row;align-items:center;justify-content:center;user-select:none;&{width:100%;cursor:pointer;border-radius:var(--privy-border-radius-md);font-size:0.875rem;line-height:1rem;font-style:normal;font-weight:500;line-height:22px;letter-spacing:-0.016px;}&&{color:",
            ";background-color:transparent;padding:0.5rem 0px;}&:hover{text-decoration:underline;}",
          ],
          (e) =>
            "dark" === e.theme
              ? "var(--privy-color-foreground-2)"
              : "var(--privy-color-accent)"
        ),
        tv = F.zo.div.withConfig({
          displayName: "IconWrapper",
          componentId: "sc-ba98f772-16",
        })([
          "display:flex;align-items:center;justify-content:center;color:var(--privy-color-accent);width:100%;> svg{z-index:2;width:3rem;height:3rem;}",
        ]),
        tC = F.zo.div.withConfig({
          displayName: "ErrorMessage",
          componentId: "sc-ba98f772-17",
        })(["color:var(--privy-color-error);"]),
        tb = ({ handleClose: e, user: t, onSelect: n }) =>
          (0, p.jsxs)(_.ab, {
            title: "Verify your identity",
            subtitle: "Choose a verification method",
            icon: V.Z,
            iconVariant: "subtle",
            onClose: e,
            showClose: !0,
            watermark: !0,
            children: [
              (0, p.jsxs)(tu, {
                children: [
                  t.mfaMethods.includes("totp") &&
                    (0, p.jsxs)(
                      _.ac,
                      {
                        onClick: () => n("totp"),
                        children: [
                          (0, p.jsx)(_.ad, { children: (0, p.jsx)(z.Z, {}) }),
                          "Authenticator app",
                        ],
                      },
                      "totp"
                    ),
                  t.mfaMethods.includes("sms") &&
                    (0, p.jsxs)(
                      _.ac,
                      {
                        onClick: () => n("sms"),
                        children: [
                          (0, p.jsx)(_.ad, { children: (0, p.jsx)(B.Z, {}) }),
                          "SMS",
                        ],
                      },
                      "sms"
                    ),
                  t.mfaMethods.includes("passkey") &&
                    (0, p.jsxs)(
                      _.ac,
                      {
                        onClick: () => n("passkey"),
                        children: [
                          (0, p.jsx)(_.ad, { children: (0, p.jsx)(q.Z, {}) }),
                          "Passkey",
                        ],
                      },
                      "passkey"
                    ),
                ],
              }),
              (0, p.jsx)(_.ae, {}),
            ],
          }),
        tk = ({ pendingTransaction: e }) => {
          let { wallets: t } = (0, _.af)(),
            {
              walletProxy: n,
              rpcConfig: r,
              chains: a,
              appId: i,
              nativeTokenSymbolForChainId: o,
            } = (0, L.u)(),
            [s, l] = (0, w.useState)(null),
            [c, d] = (0, w.useState)(e),
            { tokenPrice: u } = (0, _.ag)(c.chainId),
            h = o(e.chainId) || "ETH",
            m = (0, w.useMemo)(
              () => t.find((e) => "privy" === e.walletClientType),
              [t]
            );
          return (
            (0, w.useEffect)(() => {
              (async function () {
                if (!n || !m) return c;
                let e = (0, _.n)(c.chainId, a, r, { appId: i }),
                  t = await (0, _.ah)(c, e, m.address);
                return l((0, g.NC)(BigInt(t.gas ?? 0))), t;
              })()
                .then(d)
                .catch(console.error);
            }, [n]),
            m
              ? (0, p.jsx)(tA, {
                  children: (0, p.jsx)(_.ai, {
                    from: m.address,
                    to: c.to,
                    txn: c,
                    gas: s ?? void 0,
                    tokenPrice: u,
                    tokenSymbol: h,
                  }),
                })
              : null
          );
        },
        tA = F.zo.div.withConfig({
          displayName: "TransactionInfoWrapper",
          componentId: "sc-8d9a2f57-0",
        })(["width:100%;padding:1rem 0;"]),
        tx = ({ style: e, ...t }) =>
          (0, p.jsx)("svg", {
            x: 0,
            y: 0,
            width: "65",
            height: "64",
            viewBox: "0 0 65 64",
            style: { height: "64px", width: "65px", ...e },
            fill: "currentColor",
            xmlns: "http://www.w3.org/2000/svg",
            ...t,
            children: (0, p.jsx)("path", {
              fillRule: "evenodd",
              clipRule: "evenodd",
              d: "M3.71369 17.5625V10.375C3.71369 6.44625 6.85845 3.25 10.7238 3.25H17.7953C18.6783 3.25 19.3941 2.52244 19.3941 1.625C19.3941 0.727562 18.6783 0 17.7953 0H10.7238C5.09529 0 0.516113 4.65419 0.516113 10.375V17.5625C0.516113 18.4599 1.23194 19.1875 2.1149 19.1875C2.99787 19.1875 3.71369 18.4599 3.71369 17.5625ZM17.7953 60.7501C18.6783 60.7501 19.3941 61.4777 19.3941 62.3751C19.3941 63.2726 18.6783 64.0001 17.7953 64.0001H10.7238C5.09529 64.0001 0.516113 59.3459 0.516113 53.6251V46.4376C0.516113 45.5402 1.23194 44.8126 2.1149 44.8126C2.99787 44.8126 3.71369 45.5402 3.71369 46.4376V53.6251C3.71369 57.5538 6.85845 60.7501 10.7238 60.7501H17.7953ZM63.4839 46.4376V53.6251C63.4839 59.3459 58.9048 64.0001 53.2763 64.0001H46.2047C45.3217 64.0001 44.6059 63.2726 44.6059 62.3751C44.6059 61.4777 45.3217 60.7501 46.2047 60.7501H53.2763C57.1416 60.7501 60.2864 57.5538 60.2864 53.6251V46.4376C60.2864 45.5402 61.0022 44.8126 61.8851 44.8126C62.7681 44.8126 63.4839 45.5402 63.4839 46.4376ZM63.4839 10.375V17.5625C63.4839 18.4599 62.7681 19.1875 61.8851 19.1875C61.0022 19.1875 60.2864 18.4599 60.2864 17.5625V10.375C60.2864 6.44625 57.1416 3.25 53.2763 3.25H46.2047C45.3217 3.25 44.6059 2.52244 44.6059 1.625C44.6059 0.727562 45.3217 0 46.2047 0H53.2763C58.9048 0 63.4839 4.65419 63.4839 10.375ZM43.0331 47.3022C43.7067 46.6698 43.7483 45.6022 43.1262 44.9176C42.5039 44.233 41.4536 44.1906 40.78 44.823C38.3832 47.0732 35.265 48.3125 31.9997 48.3125C28.7344 48.3125 25.6162 47.0732 23.2194 44.823C22.5457 44.1906 21.4955 44.233 20.8732 44.9176C20.251 45.6022 20.2927 46.6698 20.9663 47.3022C23.9784 50.1301 27.8968 51.6875 31.9997 51.6875C36.1026 51.6875 40.021 50.1301 43.0331 47.3022ZM35.3207 24.1249V36.1249C35.3207 38.5029 33.4173 40.4374 31.0777 40.4374H29.7249C28.8079 40.4374 28.0646 39.6819 28.0646 38.7499C28.0646 37.8179 28.8079 37.0624 29.7249 37.0624H31.0777C31.5863 37.0624 32.0001 36.6419 32.0001 36.1249V24.1249C32.0001 23.1929 32.7434 22.4374 33.6604 22.4374C34.5774 22.4374 35.3207 23.1929 35.3207 24.1249ZM46.7581 28.8437V24.0312C46.7581 23.151 46.056 22.4374 45.19 22.4374C44.324 22.4374 43.622 23.151 43.622 24.0312V28.8437C43.622 29.7239 44.324 30.4374 45.19 30.4374C46.056 30.4374 46.7581 29.7239 46.7581 28.8437ZM17.6109 28.8437C17.6109 29.7239 18.313 30.4374 19.1789 30.4374C20.0449 30.4374 20.747 29.7239 20.747 28.8437V24.0312C20.747 23.151 20.0449 22.4374 19.1789 22.4374C18.313 22.4374 17.6109 23.151 17.6109 24.0312V28.8437Z",
            }),
          }),
        tT = ({
          hasBlockingError: e,
          error: t,
          onClose: n,
          onBack: r,
          handleSubmit: a,
          account: i,
          submitSuccess: o,
        }) => {
          let { pendingTransaction: s } = (0, L.u)();
          return (0, p.jsxs)(p.Fragment, {
            children: [
              (0, p.jsx)(_.aj, { onClose: n }, "header"),
              (0, p.jsx)(_.ak, {
                children: (0, p.jsxs)("div", {
                  children: [
                    (0, p.jsx)(_.al, { success: o, fail: !!t }),
                    (0, p.jsx)(t ? $.Z : tx, {
                      style: { width: "38px", height: "38px" },
                    }),
                  ],
                }),
              }),
              (0, p.jsx)(ta, {
                style: { marginTop: "1rem" },
                children: "Verifying with passkey",
              }),
              (0, p.jsxs)(ts, {
                children: [
                  (0, p.jsxs)(tc, {
                    children: [
                      (0, p.jsx)(tl, { children: (0, p.jsx)(V.Z, {}) }),
                      "Approve this action using your touch, face, PIN, or hardware key.",
                    ],
                  }),
                  (0, p.jsxs)(tc, {
                    children: [
                      (0, p.jsx)(tl, { children: (0, p.jsx)(H.Z, {}) }),
                      "You last added a passkey on",
                      " ",
                      i?.firstVerifiedAt?.toLocaleDateString(void 0, {
                        month: "short",
                        day: "numeric",
                        year: "numeric",
                      }),
                      ".",
                    ],
                  }),
                ],
              }),
              s &&
                (0, p.jsx)(to, {
                  children: (0, p.jsx)(tk, { pendingTransaction: s }),
                }),
              t &&
                (0, p.jsxs)(p.Fragment, {
                  children: [
                    (0, p.jsx)(tC, {
                      style: { marginTop: "1.25rem" },
                      children: t.message,
                    }),
                    (0, p.jsx)(_.am, {
                      disabled: e,
                      onClick: a,
                      style: { margin: "1.25rem auto 0" },
                      children: "Try again",
                    }),
                  ],
                }),
              r &&
                (0, p.jsx)(tf, {
                  style: { marginTop: "1rem" },
                  onClick: r,
                  children: "Choose another method",
                }),
              (0, p.jsx)(_.ae, {}),
            ],
          });
        },
        t_ = Array(6).fill("");
      var tE,
        tI =
          (((tE = tI || {})[(tE.RESET_AFTER_DELAY = 0)] = "RESET_AFTER_DELAY"),
          (tE[(tE.CLEAR_ON_NEXT_VALID_INPUT = 1)] =
            "CLEAR_ON_NEXT_VALID_INPUT"),
          tE);
      function tS(e) {
        return /^[0-9]{1}$/.test(e);
      }
      function tP(e) {
        return 6 === e.length && e.every(tS);
      }
      let tj = ({
          onChange: e,
          disabled: t,
          errorReasonOverride: n,
          success: r,
        }) => {
          let [a, i] = (0, w.useState)(t_),
            [o, s] = (0, w.useState)(null),
            [l, c] = (0, w.useState)(null),
            d = async (t) => {
              t.preventDefault();
              let n = t.currentTarget.value.replace(/\s+/g, "");
              if ("" === n) return;
              let r = a.reduce((e, t) => e + Number(tS(t)), 0),
                o = n.split(""),
                l = !o.every(tS),
                d = o.length + r > 6;
              if (l) return s("Passcode can only be numbers"), void c(1);
              if (d) return s("Passcode must be exactly 6 numbers"), void c(1);
              s(null), c(null);
              let u = Number(t.currentTarget.name?.charAt(4)),
                h = [...(n || [""])].slice(0, 6 - u),
                p = [...a.slice(0, u), ...h, ...a.slice(u + h.length)];
              i(p);
              let m = Math.min(Math.max(u + h.length, 0), 5),
                w = document.querySelector(`input[name=pin-${m}]`);
              if ((w?.focus(), tP(p)))
                try {
                  await e(p.join(""));
                  let t = document.querySelector(`input[name=pin-${m}]`);
                  t?.blur();
                } catch (e) {
                  c(1), s(e.message);
                }
              else
                try {
                  await e(null);
                } catch (e) {
                  c(1), s(e.message);
                }
            },
            u = r ? "success" : n || o ? "fail" : "";
          return (0, p.jsx)(p.Fragment, {
            children: (0, p.jsxs)(tU, {
              children: [
                (0, p.jsx)("div", {
                  children: a.map((n, r) =>
                    (0, p.jsx)(
                      "input",
                      {
                        name: `pin-${r}`,
                        type: "text",
                        value: a[r],
                        onChange: d,
                        onKeyUp: (t) => {
                          "Backspace" === t.key &&
                            ((t) => {
                              1 === l && (s(null), c(null));
                              let n = [...a.slice(0, t), "", ...a.slice(t + 1)];
                              if ((i(n), t > 0)) {
                                let e = document.querySelector(
                                  `input[name=pin-${t - 1}]`
                                );
                                e?.focus();
                              }
                              tP(n) ? e(n.join("")) : e(null);
                            })(r);
                        },
                        inputMode: "numeric",
                        autoFocus: 0 === r,
                        pattern: "[0-9]",
                        className: u,
                        autoComplete: y.tq ? "one-time-code" : "off",
                        disabled: t,
                      },
                      r
                    )
                  ),
                }),
                (0, p.jsx)("div", {
                  children: (0, p.jsx)(tW, {
                    $fail: !!n || !!o,
                    children: n || o,
                  }),
                }),
              ],
            }),
          });
        },
        tU = F.zo.div.withConfig({
          displayName: "PinInputContainer",
          componentId: "sc-7a171f6-0",
        })([
          "display:flex;flex-direction:column;width:100%;gap:8px;@media (max-width:440px){margin-top:8px;margin-bottom:8px;}> div:nth-child(1){display:flex;justify-content:center;gap:0.5rem;width:100%;border-radius:var(--privy-border-radius-md);> input{border:1px solid var(--privy-color-foreground-4);background:var(--privy-color-background);border-radius:var(--privy-border-radius-md);padding:8px 10px;height:58px;width:46px;text-align:center;font-size:18px;}> input:disabled{background:var(--privy-color-background-2);}> input:focus{border:1px solid var(--privy-color-accent);}> input:invalid{border:1px solid var(--privy-color-error);}> input.success{border:1px solid var(--privy-color-success);}> input.fail{border:1px solid var(--privy-color-error);animation:shake 180ms;animation-iteration-count:2;}}@keyframes shake{0%{transform:translate(1px,0px);}33%{transform:translate(-1px,0px);}67%{transform:translate(-1px,0px);}100%{transform:translate(1px,0px);}}",
        ]),
        tW = F.zo.div.withConfig({
          displayName: "InputHelp",
          componentId: "sc-7a171f6-1",
        })(
          [
            "line-height:20px;font-size:13px;display:flex;justify-content:flex-start;width:100%;color:",
            ";",
          ],
          (e) =>
            e.$fail
              ? "var(--privy-color-error)"
              : "var(--privy-color-foreground-3)"
        ),
        tN = ({
          selectedMethod: e,
          submitSuccess: t,
          hasBlockingError: n,
          onClose: r,
          onBack: a,
          handleSubmitCode: i,
        }) => {
          let o = (0, _.an)(),
            { pendingTransaction: s } = (0, L.u)();
          switch (e) {
            case "sms":
              return (0, p.jsxs)(p.Fragment, {
                children: [
                  (0, p.jsx)(_.aj, { onClose: r }, "header"),
                  (0, p.jsx)(tv, {
                    style: { marginBottom: "1.5rem" },
                    children: (0, p.jsx)(B.Z, {}),
                  }),
                  (0, p.jsx)(ta, { children: "Enter verification code" }),
                  (0, p.jsxs)(to, {
                    children: [
                      (0, p.jsx)(tj, { success: t, disabled: n, onChange: i }),
                      (0, p.jsxs)(ti, {
                        children: [
                          "To continue, please enter the 6-digit code sent to your ",
                          (0, p.jsx)("strong", { children: "mobile device" }),
                        ],
                      }),
                      s && (0, p.jsx)(tk, { pendingTransaction: s }),
                    ],
                  }),
                  a &&
                    (0, p.jsx)(tf, {
                      theme: o?.appearance.palette.colorScheme,
                      onClick: a,
                      children: "Choose another method",
                    }),
                  (0, p.jsx)(_.ao, { onClick: r, children: "Cancel" }),
                  (0, p.jsx)(_.ae, {}),
                ],
              });
            case "totp":
              return (0, p.jsxs)(p.Fragment, {
                children: [
                  (0, p.jsx)(_.aj, { onClose: r }, "header"),
                  (0, p.jsx)(tv, {
                    style: { marginBottom: "1.5rem" },
                    children: (0, p.jsx)(z.Z, {}),
                  }),
                  (0, p.jsx)(ta, { children: "Enter verification code" }),
                  (0, p.jsxs)(to, {
                    children: [
                      (0, p.jsx)(tj, { success: t, disabled: n, onChange: i }),
                      (0, p.jsxs)(ti, {
                        children: [
                          "To continue, please enter the 6-digit code generated from your",
                          " ",
                          (0, p.jsx)("strong", {
                            children: "authenticator app",
                          }),
                        ],
                      }),
                      s && (0, p.jsx)(tk, { pendingTransaction: s }),
                    ],
                  }),
                  a &&
                    (0, p.jsx)(tf, {
                      theme: o?.appearance.palette.colorScheme,
                      onClick: a,
                      children: "Choose another method",
                    }),
                  (0, p.jsx)(_.ao, { onClick: r, children: "Cancel" }),
                  (0, p.jsx)(_.ae, {}),
                ],
              });
            default:
              return null;
          }
        },
        tO = (e) =>
          (0, _.ap)(e)
            ? {
                isBlocking: !0,
                error: Error(
                  "You have exceeded the maximum number of attempts. Please close this window and try again in 10 seconds."
                ),
              }
            : (0, _.aq)(e)
            ? {
                isBlocking: !1,
                error: Error("The code you entered is not valid"),
              }
            : (0, _.ar)(e)
            ? {
                isBlocking: !0,
                error: Error(
                  "You have exceeded the time limit for code entry. Please try again in 30 seconds."
                ),
              }
            : (console.error(e),
              { isBlocking: !1, error: Error("Something went wrong.") }),
        tR = {
          component: () => {
            let { user: e } = (0, P.u)(),
              { data: t } = (0, _.as)(),
              [n, r] = (0, w.useState)(e?.mfaMethods[0]),
              [a, i] = (0, w.useState)(!1),
              [o, s] = (0, w.useState)(),
              [l, c] = (0, w.useState)();
            if (
              ((0, w.useEffect)(() => {
                r(e?.mfaMethods[0]);
              }, [e?.mfaMethods]),
              !t?.mfaVerify)
            )
              throw Error("Missing modal data for MFA verification screen.");
            let {
                onFailure: d,
                onSuccess: u,
                generateOptions: h,
                verifyTotpCode: m,
                verifyPasskey: y,
                verifySmsCode: g,
                sendSmsCode: f,
              } = t.mfaVerify,
              v = async (e) => {
                if ("passkey" !== e)
                  try {
                    r(e),
                      "sms" === e && (r(e), await f()),
                      "totp" === e && r(e);
                  } catch (e) {
                    console.error(e);
                  }
                else
                  try {
                    r(e);
                    let t = await h();
                    if (!t) throw Error("something went wrong");
                    s(t), await y(t), i(!0), c(void 0), u();
                  } catch (e) {
                    c(tO(e));
                  }
              },
              C = async (e) => {
                c(void 0);
                try {
                  if (!e || !n) return;
                  if ("passkey" === n) {
                    if (!o) throw Error("Missing passkey challenge");
                    await y(o);
                  } else
                    "sms" === n ? await g(e) : "totp" === n && (await m(e));
                  c(void 0), i(!0), u();
                } catch (e) {
                  throw tO(e).error;
                }
              },
              b = () => {
                l || !a
                  ? d(l?.error ?? Error("Canceled MFA verification."))
                  : u();
              },
              k = (0, w.useRef)(!1);
            return (
              (0, w.useEffect)(() => {
                !k.current &&
                  n &&
                  ((k.current = !0),
                  v(n).finally(() => {
                    k.current = !1;
                  }));
              }, [open]),
              e
                ? "passkey" === n
                  ? (0, p.jsx)(tT, {
                      account: e.linkedAccounts
                        .filter((e) => "passkey" === e.type && e.enrolledInMfa)
                        .sort(
                          (e, t) =>
                            t.firstVerifiedAt.valueOf() -
                            e.firstVerifiedAt.valueOf()
                        )[0],
                      submitSuccess: a,
                      hasBlockingError: l?.isBlocking ?? !1,
                      error: l?.error,
                      onClose: b,
                      onBack: () => {
                        r(void 0), c(void 0);
                      },
                      handleSubmit: () => C(o).catch(c),
                    })
                  : "sms" === n || "totp" === n
                  ? (0, p.jsx)(tN, {
                      selectedMethod: n,
                      submitSuccess: a,
                      hasBlockingError: l?.isBlocking ?? !1,
                      handleSubmitCode: C,
                      onClose: b,
                      onBack:
                        e.mfaMethods.length > 1 ? () => r(void 0) : void 0,
                    })
                  : (0, p.jsx)(tb, { user: e, onSelect: v, handleClose: b })
                : null
            );
          },
        };
      function tM() {
        let {
          promptMfa: e,
          init: t,
          submit: n,
          cancel: r,
          mfaMethods: a,
        } = (0, w.useContext)(P.P);
        return { promptMfa: e, init: t, submit: n, cancel: r, mfaMethods: a };
      }
      let tF = ({ onClose: e }) => {
          let { user: t } = (0, P.u)(),
            [n, r] = (0, w.useState)(t?.mfaMethods[0] ?? null),
            { init: a, cancel: i, submit: o } = tM(),
            [s, l] = (0, w.useState)(!1),
            [c, d] = (0, w.useState)(null),
            [u, h] = (0, w.useState)();
          (0, w.useEffect)(() => {
            r(t?.mfaMethods[0] ?? null);
          }, [t?.mfaMethods]);
          let m = (0, w.useRef)(!1);
          async function y(t) {
            h(void 0);
            try {
              if (!t || !n) return;
              await o(n, t), l(!0), h(void 0), e();
            } catch (e) {
              throw tO(e).error;
            }
          }
          async function g(t) {
            if ("passkey" !== t)
              try {
                r(t), await a(t);
              } catch (e) {
                console.error(e);
              }
            else
              try {
                r(t);
                let n = await a(t);
                if (!n) throw Error("something went wrong");
                d(n), await o(t, n), l(!0), h(void 0), e();
              } catch (e) {
                h(tO(e));
              }
          }
          (0, w.useEffect)(() => {
            !m.current &&
              n &&
              ((m.current = !0),
              g(n).finally(() => {
                m.current = !1;
              }));
          }, []);
          let f = () => {
            r(null), h(void 0), i(), e();
          };
          return t
            ? "passkey" === n
              ? (0, p.jsx)(tT, {
                  account: t.linkedAccounts
                    .filter((e) => "passkey" === e.type && e.enrolledInMfa)
                    .sort(
                      (e, t) =>
                        t.firstVerifiedAt.valueOf() -
                        e.firstVerifiedAt.valueOf()
                    )[0],
                  submitSuccess: s,
                  hasBlockingError: u?.isBlocking ?? !1,
                  error: u?.error,
                  onClose: f,
                  onBack: () => {
                    r(null), h(void 0);
                  },
                  handleSubmit: () => y(c).catch(h),
                })
              : n
              ? (0, p.jsx)(tN, {
                  submitSuccess: s,
                  hasBlockingError: u?.isBlocking ?? !1,
                  handleSubmitCode: y,
                  selectedMethod: n,
                  onClose: f,
                  onBack: t.mfaMethods.length > 1 ? () => r(null) : void 0,
                })
              : (0, p.jsx)(tb, { user: t, onSelect: g, handleClose: f })
            : null;
        },
        tL = (0, R.U)(() => ({ inProgressMfaFlow: void 0 })),
        tD = (0, F.vJ)([":root{", "};"], (e) => tz(e.palette)),
        tz = (e) =>
          (0, F.iv)(
            ["", ""],
            Object.entries({
              "--privy-color-background": e.background,
              "--privy-color-background-2": e.background2,
              "--privy-color-background-3": e.background3,
              "--privy-color-foreground": e.foreground,
              "--privy-color-foreground-2": e.foreground2,
              "--privy-color-foreground-3": e.foreground3,
              "--privy-color-foreground-4": e.foreground4,
              "--privy-color-foreground-accent": e.foregroundAccent,
              "--privy-color-accent": e.accent,
              "--privy-color-accent-light": e.accentLight,
              "--privy-color-accent-hover": e.accentHover,
              "--privy-color-accent-dark": e.accentDark,
              "--privy-color-accent-darkest": e.accentDarkest,
              "--privy-color-success": e.success,
              "--privy-color-success-dark": e.successDark,
              "--privy-color-success-light": e.successLight,
              "--privy-color-success-bg": e.successBg,
              "--privy-color-error": e.error,
              "--privy-color-error-light": e.errorLight,
              "--privy-color-error-bg": e.errorBg,
              "--privy-color-error-bg-hover": e.errorBgHover,
              "--privy-color-warn": e.warn,
              "--privy-color-warn-light": e.warnLight,
              "--privy-color-warn-bg": e.warnBg,
              "--privy-color-warning-dark": e.warningDark,
              "--privy-color-error-dark": e.errorDark,
              "--privy-color-info-bg": e.infoBg,
              "--privy-color-info-bg-hover": e.infoBgHover,
              "--privy-color-border-default": e.borderDefault,
              "--privy-color-border-hover": e.borderHover,
              "--privy-color-border-focus": e.borderFocus,
              "--privy-color-border-error": e.borderError,
              "--privy-color-border-success": e.borderSuccess,
              "--privy-color-border-warning": e.borderWarning,
              "--privy-color-border-info": e.borderInfo,
              "--privy-color-border-interactive": e.borderInteractive,
              "--privy-color-border-interactive-hover":
                e.borderInteractiveHover,
              "--privy-color-background-hover": e.backgroundHover,
              "--privy-color-background-clicked": e.backgroundClicked,
              "--privy-color-background-disabled": e.backgroundDisabled,
              "--privy-color-background-interactive": e.backgroundInteractive,
              "--privy-color-background-interactive-hover":
                e.backgroundInteractiveHover,
              "--privy-color-background-interactive-clicked":
                e.backgroundInteractiveClicked,
              "--privy-color-background-interactive-disabled":
                e.backgroundInteractiveDisabled,
              "--privy-color-foreground-hover": e.foregroundHover,
              "--privy-color-foreground-clicked": e.foregroundClicked,
              "--privy-color-foreground-disabled": e.foregroundDisabled,
              "--privy-color-foreground-interactive": e.foregroundInteractive,
              "--privy-color-foreground-interactive-hover":
                e.foregroundInteractiveHover,
              "--privy-link-navigation-color": e.linkNavigationColor,
              "--privy-link-navigation-decoration": e.linkNavigationDecoration,
              "--privy-accent-has-good-contrast": e.accentHasGoodContrast,
              "--privy-color-icon-default": e.iconDefault,
              "--privy-color-icon-muted": e.iconMuted,
              "--privy-color-icon-subtle": e.iconSubtle,
              "--privy-color-icon-inverse": e.iconInverse,
              "--privy-color-icon-success": e.iconSuccess,
              "--privy-color-icon-warning": e.iconWarning,
              "--privy-color-icon-error": e.iconError,
              "--privy-color-icon-interactive": e.iconInteractive,
              "--privy-color-icon-default-hover": e.iconDefaultHover,
              "--privy-color-icon-muted-hover": e.iconMutedHover,
              "--privy-color-icon-subtle-hover": e.iconSubtleHover,
              "--privy-color-icon-default-clicked": e.iconDefaultClicked,
              "--privy-color-icon-muted-clicked": e.iconMutedClicked,
              "--privy-color-icon-subtle-clicked": e.iconSubtleClicked,
              "--privy-color-icon-default-disabled": e.iconDefaultDisabled,
              "--privy-color-icon-muted-disabled": e.iconMutedDisabled,
              "--privy-color-icon-subtle-disabled": e.iconSubtleDisabled,
              "--privy-color-icon-error-hover": e.iconErrorHover,
              "--privy-color-icon-interactive-hover": e.iconInteractiveHover,
              "--privy-color-icon-error-clicked": e.iconErrorClicked,
              "--privy-color-icon-interactive-clicked":
                e.iconInteractiveClicked,
              "--privy-color-icon-muted-disabled-alt": e.iconMutedDisabledAlt,
              "--privy-color-icon-subtle-disabled-alt": e.iconSubtleDisabledAlt,
              "--privy-border-radius-xs": "6px",
              "--privy-border-radius-sm": "8px",
              "--privy-border-radius-md": "12px",
              "--privy-border-radius-mdlg": "16px",
              "--privy-border-radius-lg": "24px",
              "--privy-border-radius-full": "9999px",
              "--privy-height-modal-full": "620px",
              "--privy-height-modal-compact": "480px",
            })
              .map(([e, t]) => `${e}: ${t};`)
              .join("\n")
          ),
        tq = F.zo.div.withConfig({
          displayName: "StylesWrapper",
          componentId: "sc-188229e4-0",
        })(
          [
            "",
            " color:var(--privy-color-foreground-2);h3{font-size:16px;line-height:24px;font-weight:500;color:var(--privy-color-foreground-2);}h4{font-size:14px;line-height:20px;font-weight:500;color:var(--privy-color-foreground);}p{font-size:13px;line-height:20px;color:var(--privy-color-foreground-2);}button:focus,input:focus,optgroup:focus,select:focus,textarea:focus{outline:none;border-color:var(--privy-color-accent-light);box-shadow:0 0 0 3px var(--privy-color-border-focus);}.mobile-only{@media (min-width:441px){display:none;}}@keyframes fadein{0%{opacity:0;}100%{opacity:1;}}",
          ],
          "\n  *,\n  ::before,\n  ::after {\n    box-sizing: border-box;\n    border-width: 0;\n    border-style: solid;\n  }\n\n  line-height: 1.15;\n  -webkit-text-size-adjust: 100%;\n  -moz-tab-size: 4;\n  tab-size: 4;\n  font-feature-settings: normal;\n\n  margin: 0;\n  font-family: system-ui, -apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif,\n    'Apple Color Emoji', 'Segoe UI Emoji';\n\n  hr {\n    height: 0;\n    color: inherit;\n    border-top-width: 1px;\n  }\n\n  abbr:where([title]) {\n    text-decoration: underline dotted;\n  }\n\n  h1,\n  h2,\n  h3,\n  h4,\n  h5,\n  h6 {\n    font-size: inherit;\n    font-weight: inherit;\n    font-family: system-ui, -apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif,\n    'Apple Color Emoji', 'Segoe UI Emoji';\n    display: inline;\n  }\n\n  a {\n    color: inherit;\n    text-decoration: inherit;\n  }\n\n  b,\n  strong {\n    font-weight: bolder;\n  }\n\n  code,\n  kbd,\n  samp,\n  pre {\n    font-family: ui-monospace, SFMono-Regular, Consolas, 'Liberation Mono', Menlo, monospace;\n    font-size: 1em;\n  }\n\n  small {\n    font-size: 80%;\n  }\n\n  sub,\n  sup {\n    font-size: 75%;\n    line-height: 0;\n    position: relative;\n    vertical-align: baseline;\n  }\n\n  sub {\n    bottom: -0.25em;\n  }\n\n  sup {\n    top: -0.5em;\n  }\n\n  table {\n    text-indent: 0;\n    border-color: inherit;\n    border-collapse: collapse;\n  }\n\n  button,\n  input,\n  optgroup,\n  select,\n  textarea {\n    font-family: inherit;\n    font-size: 100%;\n    font-weight: inherit;\n    line-height: inherit;\n    color: inherit;\n    margin: 0;\n    padding: 0;\n  }\n\n  button,\n  select {\n    text-transform: none;\n  }\n\n  button,\n  [type='button'],\n  [type='reset'],\n  [type='submit'] {\n    -webkit-appearance: button;\n    background-color: transparent;\n    background-image: none;\n  }\n\n  ::-moz-focus-inner {\n    border-style: none;\n    padding: 0;\n  }\n\n  :-moz-focusring {\n    outline: 1px dotted ButtonText;\n  }\n\n  :-moz-ui-invalid {\n    box-shadow: none;\n  }\n\n  legend {\n    padding: 0;\n  }\n\n  progress {\n    vertical-align: baseline;\n  }\n\n  ::-webkit-inner-spin-button,\n  ::-webkit-outer-spin-button {\n    height: auto;\n  }\n\n  [type='search'] {\n    -webkit-appearance: textfield;\n    outline-offset: -2px;\n  }\n\n  ::-webkit-search-decoration {\n    -webkit-appearance: none;\n  }\n\n  ::-webkit-file-upload-button {\n    -webkit-appearance: button;\n    font: inherit;\n  }\n\n  summary {\n    display: list-item;\n  }\n\n  blockquote,\n  dl,\n  dd,\n  h1,\n  h2,\n  h3,\n  h4,\n  h5,\n  h6,\n  hr,\n  figure,\n  p,\n  pre {\n    margin: 0;\n  }\n\n  fieldset {\n    margin: 0;\n    padding: 0;\n  }\n\n  legend {\n    padding: 0;\n  }\n\n  ol,\n  ul,\n  menu {\n    list-style: none;\n    margin: 0;\n    padding: 0;\n  }\n\n  textarea {\n    resize: vertical;\n  }\n\n  input::placeholder,\n  textarea::placeholder {\n    opacity: 1;\n    color: #9ca3af;\n  }\n\n  button,\n  [role='button'] {\n    cursor: pointer;\n  }\n\n  :disabled {\n    cursor: default;\n  }\n\n  img,\n  svg,\n  video,\n  canvas,\n  audio,\n  iframe,\n  embed,\n  object {\n    display: block;\n  }\n\n  img,\n  video {\n    max-width: 100%;\n    height: auto;\n  }\n\n  [hidden] {\n    display: none;\n  }\n"
        ),
        tB = ({ children: e, open: t, onClick: n, ...r }) =>
          (0, p.jsx)(Z.u, {
            show: t,
            as: w.Fragment,
            children: (0, p.jsxs)(K.Vq, {
              onClose: n,
              ...r,
              as: tH,
              children: [
                (0, p.jsx)(Z.x, {
                  as: w.Fragment,
                  enterFrom: "entering",
                  leaveTo: "leaving",
                  children: (0, p.jsx)(tV, {
                    id: "privy-dialog-backdrop",
                    "aria-hidden": "true",
                  }),
                }),
                (0, p.jsx)(t$, {
                  children: (0, p.jsx)(Z.x, {
                    as: w.Fragment,
                    enterFrom: "entering",
                    leaveTo: "leaving",
                    children: (0, p.jsx)(K.EM, { as: tZ, children: e }),
                  }),
                }),
              ],
            }),
          }),
        tV = F.zo.div.withConfig({
          displayName: "Backdrop",
          componentId: "sc-3cfde0b5-0",
        })([
          "position:fixed;inset:0;transition:backdrop-filter 100ms ease;backdrop-filter:blur(3px);-webkit-backdrop-filter:blur(3px);&.entering,&.leaving{backdrop-filter:unset;-webkit-backdrop-filter:unset;}",
        ]),
        tH = F.zo.div.withConfig({
          displayName: "DialogWrapper",
          componentId: "sc-3cfde0b5-1",
        })(["position:relative;z-index:999999;"]),
        t$ = F.zo.div.withConfig({
          displayName: "DialogContainer",
          componentId: "sc-3cfde0b5-2",
        })([
          "position:fixed;inset:0;display:flex;align-items:center;justify-content:center;width:100vw;min-height:100vh;",
        ]),
        tZ = F.zo.div.withConfig({
          displayName: "Panel",
          componentId: "sc-3cfde0b5-3",
        })([
          "padding:0;background:transparent;border:none;width:100%;pointer-events:auto;outline:none;display:block;@media (max-width:440px){opacity:1;transform:translate3d(0,0,0);transition:transform 200ms ease-in;position:fixed;bottom:0;&.entering,&.leaving{opacity:0;transform:translate3d(0,100%,0);transition:transform 150ms ease-in 0ms,opacity 0ms ease 150ms;}}@media (min-width:441px){opacity:1;transition:opacity 100ms ease-in;&.entering,&.leaving{opacity:0;transition-delay:5ms;}margin:auto;width:360px;box-shadow:0px 8px 36px rgba(55,65,81,0.15);border-radius:var(--privy-border-radius-lg);}",
        ]),
        tK = F.zo.div.withConfig({
          displayName: "CenterItem",
          componentId: "sc-3cfde0b5-4",
        })([
          "display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;",
        ]),
        tY = () => {
          let { ready: e, isModalOpen: t } = (0, P.u)(),
            { headless: n } = (0, _.an)(),
            { currentScreen: r } = (0, _.as)(),
            { status: a, execute: i, reset: o, enabled: s } = (0, _.a9)(),
            l = tL((e) => e.inProgressMfaFlow),
            c = () => tL.setState({ inProgressMfaFlow: void 0 }),
            d = t && r && r.isCaptchaRequired && !n && "ready" === a;
          return (
            (0, w.useEffect)(() => {
              d && i();
            }, [d]),
            (0, w.useEffect)(() => {
              !t && s && o();
            }, [t, s]),
            r && !e && r.isShownBeforeReady
              ? (0, p.jsxs)(p.Fragment, {
                  children: [
                    (0, p.jsx)(_.aj, {}),
                    (0, p.jsx)(_.at, {}),
                    (0, p.jsx)(tK, { children: (0, p.jsx)(_.au, {}) }),
                    (0, p.jsx)(_.av, {}),
                    (0, p.jsx)(_.ae, {}),
                  ],
                })
              : r || "txn" !== l
              ? r
                ? (0, p.jsxs)(p.Fragment, {
                    children: [
                      (0, p.jsx)(_.aw, {
                        $if: !!l,
                        children: (0, p.jsx)(r.component, {}),
                      }),
                      "txn" === l && (0, p.jsx)(tF, { onClose: c }),
                      "auth" === l && (0, p.jsx)(tR.component, {}),
                    ],
                  })
                : null
              : (0, p.jsx)(tF, { onClose: c })
          );
        },
        tG = () => {
          let e = (0, w.useRef)(null);
          return (0, p.jsx)(tX, {
            style: { height: (0, D.u)(e) },
            id: "privy-modal-content",
            children: (0, p.jsx)("div", {
              ref: e,
              children: (0, p.jsx)(tY, {}),
            }),
          });
        },
        tJ = ({ open: e }) => {
          let t = (0, _.an)(),
            { gracefulClosePrivyModal: n } = (() => {
              let { closePrivyModal: e } = (0, L.u)(),
                { onUserCloseViaDialogOrKeybindRef: t } = (0, _.as)();
              return {
                gracefulClosePrivyModal: (0, w.useCallback)(() => {
                  if (!t?.current) return e({ shouldCallAuthOnSuccess: !1 });
                  t.current();
                }, [e]),
              };
            })(),
            r = tL((e) => e.inProgressMfaFlow);
          return (
            (0, _.aa)("configureMfa", {
              onMfaRequired: () => {
                t.mfa.noPromptOnMfaRequired ||
                  tL.setState({ inProgressMfaFlow: "txn" });
              },
            }),
            t.render.standalone
              ? (0, p.jsx)(tq, {
                  children: (0, p.jsx)(tQ, {
                    id: "privy-modal-content",
                    children: (0, p.jsx)(tY, {}),
                  }),
                })
              : (0, p.jsx)(tB, {
                  open: !(!e && !r),
                  id: "privy-dialog",
                  "aria-label": "log in or sign up",
                  "aria-labelledby": "privy-dialog-title",
                  onClick: () => n(),
                  children: (0, p.jsx)(tq, { children: (0, p.jsx)(tG, {}) }),
                })
          );
        },
        tQ = F.zo.div.withConfig({
          displayName: "ContentWrapper",
          componentId: "sc-b220e1ee-0",
        })([
          "display:flex;flex-direction:column;text-align:center;font-size:14px;line-height:20px;width:100%;background:var(--privy-color-background);padding:0 16px;",
        ]),
        tX = (0, F.zo)(tQ).withConfig({
          displayName: "BaseModal",
          componentId: "sc-b220e1ee-1",
        })([
          "transition:height 150ms ease-out;overflow-x:hidden;overflow-y:auto;scrollbar-width:none;max-height:calc(100svh - 32px);border-radius:var(--privy-border-radius-lg) var(--privy-border-radius-lg) 0 0;box-shadow:0px 0px 36px rgba(55,65,81,0.15);@media (min-width:441px){box-shadow:0px 8px 36px rgba(55,65,81,0.15);border-radius:var(--privy-border-radius-lg);}",
        ]);
      function t0(e) {
        let t = (0, w.useRef)(null),
          n = (0, w.useRef)();
        return (
          (0, w.useEffect)(() => {
            n.current?.remove(),
              (n.current = (function ({ botUsername: e, scriptHost: t }) {
                let n = document.createElement("script"),
                  { origin: r } = new URL(t);
                return (
                  (n.async = !0),
                  (n.src = `${r}/js/telegram-login.js`),
                  n.setAttribute("data-telegram-login", e),
                  n.setAttribute("data-request-access", "write"),
                  n.setAttribute("data-lang", "en"),
                  n
                );
              })(e)),
              t.current?.after(n.current);
          }, [e]),
          (0, p.jsx)("div", { ref: t, hidden: !0 })
        );
      }
      let t1 = () => {
        let { ready: e } = (0, _.af)(),
          { client: t } = (0, L.u)();
        return (
          (0, w.useEffect)(() => {
            let n = () => {
              if (!t.connectors || !e) return;
              let n = t.connectors.wallets.map((e) => ({
                address: e.address,
                connectorType: e.connectorType,
                walletClientType: e.walletClientType,
                connectedAt: e.connectedAt,
                id: e.meta.id,
              }));
              _.s.put(_.ax, n);
            };
            return (
              t.connectors?.on("walletsUpdated", n),
              () => {
                t.connectors?.off("walletsUpdated", n);
              }
            );
          }, [e, t.connectors]),
          null
        );
      };
      async function t2(e, t, n, r, a, i = !1) {
        let o = i,
          s = async (s) => {
            if (o && t && t.length > 0) {
              s === (i ? 0 : 1)
                ? a("configureMfa", "onMfaRequired", { mfaMethods: t })
                : r.current?.reject(
                    new _.ay(
                      "missing_or_invalid_mfa",
                      "MFA verification failed, retry."
                    )
                  );
              let o = await new Promise((e, t) => {
                (n.current = { resolve: e, reject: t }),
                  setTimeout(() => {
                    let e = new _.ay(
                      "mfa_timeout",
                      "Timed out waiting for MFA code"
                    );
                    r.current?.reject(e), t(e);
                  }, 3e5);
              });
              return await e(o);
            }
            return await e();
          },
          l = null;
        for (let e = 0; e < 4; e++)
          try {
            (l = await s(e)), r.current?.resolve(void 0);
            break;
          } catch (e) {
            if ("missing_or_invalid_mfa" !== e.type)
              throw (r.current?.resolve(void 0), e);
            o = !0;
          }
        if (null === l) {
          let e = new _.ay(
            "mfa_verification_max_attempts_reached",
            "Max MFA verification attempts reached"
          );
          throw (r.current?.reject(e), e);
        }
        return l;
      }
      let t4 = ((h = 0), () => "id-" + h++);
      function t3(e) {
        return void 0 !== e.error;
      }
      let t5 = new (class {
          enqueue(e, t) {
            this.callbacks[e] = t;
          }
          dequeue(e, t) {
            let n = this.callbacks[t];
            if (!n)
              throw Error(
                `cannot dequeue ${e} event: no event found for id ${t}`
              );
            switch ((delete this.callbacks[t], e)) {
              case "privy:iframe:ready":
              case "privy:user-signer:sign":
              case "privy:wallets:add":
              case "privy:wallets:import":
              case "privy:wallets:set-recovery":
              case "privy:wallets:connect":
              case "privy:wallets:recover":
              case "privy:wallets:rpc":
              case "privy:wallet:create":
              case "privy:mfa:verify":
              case "privy:mfa:init-enrollment":
              case "privy:mfa:submit-enrollment":
              case "privy:mfa:unenroll":
              case "privy:mfa:clear":
              case "privy:auth:unlink-passkey":
              case "privy:farcaster:init-signer":
              case "privy:farcaster:sign":
              case "privy:solana-wallet:create":
              case "privy:delegated-actions:consent":
                return n;
              default:
                throw Error(`invalid wallet event type ${e}`);
            }
          }
          constructor() {
            this.callbacks = {};
          }
        })(),
        t6 = new Map(),
        t7 = (e, t) => ("bigint" == typeof t ? t.toString() : t);
      function t9(e, t, n, r) {
        let a = n.contentWindow;
        if (!a) throw Error("iframe not initialized");
        let i = `${e}${JSON.stringify(t, t7)}`;
        if ("privy:wallet:create" === e) {
          let e = t6.get(i);
          if (e) return e;
        }
        let o = new Promise((n, i) => {
          let o = t4();
          t5.enqueue(o, { resolve: n, reject: i }),
            a.postMessage({ id: o, event: e, data: t }, r);
        }).finally(() => {
          t6.delete(i);
        });
        return t6.set(i, o), o;
      }
      function t8(e) {
        let t = (0, _.az)(),
          n = (0, w.useRef)(null),
          r = (0, w.useRef)(e.mfaMethods),
          a = (0, _.aA)(),
          [i, o] = (0, w.useState)(!1);
        return (
          (0, w.useEffect)(() => {
            r.current = e.mfaMethods;
          }, [e.mfaMethods]),
          (0, w.useEffect)(() => {
            if (!i) return;
            let t = n.current;
            if (!t) return;
            function o(t) {
              var n;
              t &&
                t.origin === e.origin &&
                "string" == typeof (n = t.data).event &&
                /^privy:.+/.test(n.event) &&
                (function (e) {
                  switch (e.event) {
                    case "privy:iframe:ready":
                      let t = t5.dequeue(e.event, e.id);
                      return t3(e)
                        ? t.reject(new _.ay(e.error.type, e.error.message))
                        : t.resolve(e.data);
                    case "privy:user-signer:sign": {
                      let t = t5.dequeue(e.event, e.id);
                      return t3(e)
                        ? t.reject(new _.ay(e.error.type, e.error.message))
                        : t.resolve(e.data);
                    }
                    case "privy:wallets:add": {
                      let t = t5.dequeue(e.event, e.id);
                      return t3(e)
                        ? t.reject(new _.ay(e.error.type, e.error.message))
                        : t.resolve(e.data);
                    }
                    case "privy:wallets:set-recovery": {
                      let t = t5.dequeue(e.event, e.id);
                      return t3(e)
                        ? t.reject(new _.ay(e.error.type, e.error.message))
                        : t.resolve(e.data);
                    }
                    case "privy:wallets:connect": {
                      let t = t5.dequeue(e.event, e.id);
                      return t3(e)
                        ? t.reject(new _.ay(e.error.type, e.error.message))
                        : t.resolve(e.data);
                    }
                    case "privy:wallets:recover": {
                      let t = t5.dequeue(e.event, e.id);
                      return t3(e)
                        ? t.reject(new _.ay(e.error.type, e.error.message))
                        : t.resolve(e.data);
                    }
                    case "privy:wallets:rpc": {
                      let t = t5.dequeue(e.event, e.id);
                      return t3(e)
                        ? t.reject(new _.ay(e.error.type, e.error.message))
                        : t.resolve(e.data);
                    }
                    case "privy:wallet:create":
                      let n = t5.dequeue(e.event, e.id);
                      return t3(e)
                        ? n.reject(new _.ay(e.error.type, e.error.message))
                        : n.resolve(e.data);
                    case "privy:wallets:import":
                      let r = t5.dequeue(e.event, e.id);
                      return t3(e)
                        ? r.reject(new _.ay(e.error.type, e.error.message))
                        : r.resolve(e.data);
                    case "privy:mfa:verify":
                      let a = t5.dequeue(e.event, e.id);
                      return t3(e)
                        ? a.reject(new _.ay(e.error.type, e.error.message))
                        : a.resolve(e.data);
                    case "privy:mfa:init-enrollment": {
                      let t = t5.dequeue(e.event, e.id);
                      return t3(e)
                        ? t.reject(new _.ay(e.error.type, e.error.message))
                        : t.resolve(e.data);
                    }
                    case "privy:mfa:submit-enrollment": {
                      let t = t5.dequeue(e.event, e.id);
                      return t3(e)
                        ? t.reject(new _.ay(e.error.type, e.error.message))
                        : t.resolve(e.data);
                    }
                    case "privy:mfa:unenroll": {
                      let t = t5.dequeue(e.event, e.id);
                      return t3(e)
                        ? t.reject(new _.ay(e.error.type, e.error.message))
                        : t.resolve(e.data);
                    }
                    case "privy:mfa:clear": {
                      let t = t5.dequeue(e.event, e.id);
                      return t3(e)
                        ? t.reject(new _.ay(e.error.type, e.error.message))
                        : t.resolve(e.data);
                    }
                    case "privy:auth:unlink-passkey": {
                      let t = t5.dequeue(e.event, e.id);
                      return t3(e)
                        ? t.reject(new _.ay(e.error.type, e.error.message))
                        : t.resolve(e.data);
                    }
                    case "privy:solana-wallet:create":
                      let i = t5.dequeue(e.event, e.id);
                      return t3(e)
                        ? i.reject(new _.ay(e.error.type, e.error.message))
                        : i.resolve(e.data);
                    case "privy:farcaster:init-signer": {
                      let t = t5.dequeue(e.event, e.id);
                      return t3(e)
                        ? t.reject(new _.ay(e.error.type, e.error.message))
                        : t.resolve(e.data);
                    }
                    case "privy:farcaster:sign": {
                      let t = t5.dequeue(e.event, e.id);
                      return t3(e)
                        ? t.reject(new _.ay(e.error.type, e.error.message))
                        : t.resolve(e.data);
                    }
                    case "privy:delegated-actions:consent": {
                      let t = t5.dequeue(e.event, e.id);
                      return t3(e)
                        ? t.reject(new _.ay(e.error.type, e.error.message))
                        : t.resolve(e.data);
                    }
                    default:
                      console.warn("Unsupported wallet proxy method:", e);
                  }
                })(t.data);
            }
            let s = {
              signWithUserSigner: (n) =>
                t2(
                  (r) =>
                    t9("privy:user-signer:sign", { ...n, ...r }, t, e.origin),
                  r.current,
                  e.mfaPromise,
                  e.mfaSubmitPromise,
                  a
                ),
              addWallet: (n) =>
                t2(
                  (r) => t9("privy:wallets:add", { ...n, ...r }, t, e.origin),
                  r.current,
                  e.mfaPromise,
                  e.mfaSubmitPromise,
                  a
                ),
              setRecovery: (n) =>
                t2(
                  (r) =>
                    t9(
                      "privy:wallets:set-recovery",
                      { ...n, ...r },
                      t,
                      e.origin
                    ),
                  r.current,
                  e.mfaPromise,
                  e.mfaSubmitPromise,
                  a
                ),
              connect: (n) =>
                t2(
                  (r) =>
                    t9("privy:wallets:connect", { ...n, ...r }, t, e.origin),
                  r.current,
                  e.mfaPromise,
                  e.mfaSubmitPromise,
                  a
                ),
              recover: (n) =>
                t2(
                  (r) =>
                    t9("privy:wallets:recover", { ...n, ...r }, t, e.origin),
                  r.current,
                  e.mfaPromise,
                  e.mfaSubmitPromise,
                  a,
                  !n.recoveryAccessToken &&
                    !n.recoveryPassword &&
                    !n.recoverySecretOverride
                ),
              rpc: (n) =>
                t2(
                  (r) => t9("privy:wallets:rpc", { ...n, ...r }, t, e.origin),
                  r.current,
                  e.mfaPromise,
                  e.mfaSubmitPromise,
                  a
                ),
              create: (n) => t9("privy:wallet:create", n, t, e.origin),
              importWallet: (n) => t9("privy:wallets:import", n, t, e.origin),
              createSolana: (n) =>
                t2(
                  (r) =>
                    t9(
                      "privy:solana-wallet:create",
                      { ...n, ...r },
                      t,
                      e.origin
                    ),
                  r.current,
                  e.mfaPromise,
                  e.mfaSubmitPromise,
                  a
                ),
              createDelegatedAction: (n) =>
                t9("privy:delegated-actions:consent", n, t, e.origin),
              verifyMfa: (n) =>
                t2(
                  (r) => t9("privy:mfa:verify", { ...n, ...r }, t, e.origin),
                  r.current,
                  e.mfaPromise,
                  e.mfaSubmitPromise,
                  a,
                  !0
                ),
              initEnrollMfa: (n) =>
                t2(
                  (r) =>
                    t9(
                      "privy:mfa:init-enrollment",
                      { ...n, ...r },
                      t,
                      e.origin
                    ),
                  r.current,
                  e.mfaPromise,
                  e.mfaSubmitPromise,
                  a
                ),
              submitEnrollMfa: (n) =>
                t2(
                  (r) =>
                    t9(
                      "privy:mfa:submit-enrollment",
                      { ...n, ...r },
                      t,
                      e.origin
                    ),
                  r.current,
                  e.mfaPromise,
                  e.mfaSubmitPromise,
                  a
                ),
              unenrollMfa: (n) =>
                t2(
                  (r) => t9("privy:mfa:unenroll", { ...n, ...r }, t, e.origin),
                  r.current,
                  e.mfaPromise,
                  e.mfaSubmitPromise,
                  a
                ),
              clearMfa: (n) => t9("privy:mfa:clear", n, t, e.origin),
              unlinkPasskeyAccount: (n) =>
                t2(
                  (r) =>
                    t9(
                      "privy:auth:unlink-passkey",
                      { ...n, ...r },
                      t,
                      e.origin
                    ),
                  r.current,
                  e.mfaPromise,
                  e.mfaSubmitPromise,
                  a
                ),
              initFarcasterSigner: (n) =>
                t9("privy:farcaster:init-signer", n, t, e.origin),
              signFarcasterMessage: (n) =>
                t9("privy:farcaster:sign", n, t, e.origin),
            };
            window.addEventListener("message", o);
            let l = new AbortController();
            return (
              (0, _.aB)(() => t9("privy:iframe:ready", {}, t, e.origin), {
                abortSignal: l.signal,
              }).then(
                () => e.onLoad(s),
                (...t) => {
                  console.warn("Privy iframe failed to load: ", ...t),
                    e.onLoadFailed();
                }
              ),
              () => {
                window.removeEventListener("message", o), l.abort();
              }
            );
          }, [i]),
          t
            ? (0, p.jsx)("iframe", {
                ref: n,
                width: "0",
                height: "0",
                style: { display: "none", height: "0px", width: "0px" },
                onLoad: () => o(!0),
                src: (0, Y.v)({
                  origin: e.origin,
                  path: `/apps/${e.appId}/embedded-wallets`,
                  query: {
                    caid: e.clientAnalyticsId,
                    client_id: e.appClientId,
                  },
                }),
              })
            : null
        );
      }
      let ne = ({ address: e, user: t }) => {
          let n = t.linkedAccounts.find(
            (t) =>
              "wallet" === t.type &&
              "privy" === t.walletClientType &&
              t.address === e
          );
          if (!n)
            throw new T.P(
              "Address to delegate is not associated with current user."
            );
          if (!(0, G.i)(n))
            throw new T.P(
              `useDelegatedActions is not supported for ${n.chainType} wallets. Use the useSessionSigners hook to provision server side access on behalf of your users.`
            );
          return {
            address: n.address,
            chainType: n.chainType,
            walletIndex: n.walletIndex ?? 0,
          };
        },
        nt = ({ address: e, user: t }) => {
          let n = t.linkedAccounts.find(
            (t) =>
              "wallet" === t.type &&
              "privy" === t.walletClientType &&
              t.address === e
          );
          if (!n)
            throw new T.P(
              "Address to delegate is not associated with current user."
            );
          let r = n.imported ? n : (0, P.a)(t);
          if (!r)
            throw new T.P(
              "Unable to determine root address for delegated address."
            );
          if (!(0, G.i)(r))
            throw new T.P(
              `useDelegatedActions is not supported for ${r.chainType} wallets. Use the useSessionSigners hook to provision server side access on behalf of your users.`
            );
          return {
            address: r.address,
            chainType: r.chainType,
            imported: r.imported,
          };
        },
        nn = (e) =>
          e.linkedAccounts.filter(
            (e) =>
              "wallet" === e.type &&
              "privy" === e.walletClientType &&
              e.delegated
          ),
        nr = () => {
          let e = (0, _.an)();
          (0, w.useEffect)(() => {
            (async (e) => {
              let t = new URL(
                "v3/wallets",
                "https://explorer-api.walletconnect.com"
              );
              t.searchParams.append("projectId", e);
              let n = await fetch(t);
              return n.ok
                ? Object.values((await n.json()).listings).sort(
                    ({ slug: e }, { slug: t }) =>
                      "rainbow" === e && "metamask" === t
                        ? 1
                        : "metamask" === e || "rainbow" === e
                        ? -1
                        : 1
                  )
                : (console.debug(
                    `Failed to fetch WalletConnect listings: ${await n
                      .text()
                      .catch(() => "No response.")}`
                  ),
                  []);
            })(e.walletConnectCloudProjectId)
              .then((e) => (0, _.aC)({ listings: e }))
              .catch(console.error);
          }, [e.walletConnectCloudProjectId]);
        },
        na = "popup-privy-oauth",
        ni = "PRIVY_OAUTH_USE_BROADCAST_CHANNEL";
      class no {
        async authenticate() {
          if (!this.api) throw new T.P("Auth flow has no API instance");
          try {
            return await this.api.post(T.o, {
              authorization_code: this.meta.authorizationCode,
              state_code: this.meta.stateCode,
              code_verifier: this.meta.codeVerifier,
              provider: this.meta.provider,
            });
          } catch (e) {
            throw (0, T.f)(e);
          }
        }
        async link() {
          if (!this.api) throw new T.P("Auth flow has no API instance");
          try {
            return await this.api.post(T.i, {
              authorization_code: this.meta.authorizationCode,
              state_code: this.meta.stateCode,
              code_verifier: this.meta.codeVerifier,
              provider: this.meta.provider,
            });
          } catch (e) {
            throw (0, T.f)(e);
          }
        }
        constructor({
          authorizationCode: e,
          stateCode: t,
          codeVerifier: n,
          provider: r,
        }) {
          this.meta = {
            authorizationCode: e,
            stateCode: t,
            codeVerifier: n,
            provider: r,
          };
        }
      }
      async function ns({ api: e, requesterAppId: t, providerAppId: n }) {
        let r = (
          await e.get(`/api/v1/apps/${t}/cross-app/connections`)
        ).connections.find((e) => e.provider_app_id === n);
        if (!r) throw new T.P("Invalid connected app");
        return {
          name: r.provider_app_name,
          logoUrl: r.provider_app_icon_url || void 0,
          apiUrl: r.provider_app_custom_api_url,
          readOnly: r.read_only,
          customAuthAuthorizeUrl: r.provider_app_custom_auth_authorize_url,
          customAuthTransactUrl: r.provider_app_custom_auth_transact_url,
        };
      }
      let nl = async ({
          user: e,
          address: t,
          client: n,
          request: r,
          requesterAppId: a,
          reconnect: i,
        }) => {
          n.createAnalyticsEvent({
            eventName: "cross_app_request_started",
            payload: { address: t, method: r.method },
          });
          let o = e?.linkedAccounts.find(
            (e) =>
              "cross_app" === e.type &&
              (e.embeddedWallets.some((e) => e.address === t) ||
                e.smartWallets.some((e) => e.address === t))
          );
          if (!e || !o)
            throw (
              (n.createAnalyticsEvent({
                eventName: "cross_app_request_error",
                payload: {
                  error: "Cannot request a signature with this wallet address",
                  address: t,
                },
              }),
              new T.P("Cannot request a signature with this wallet address"))
            );
          let s = n.getProviderAccessToken(o.providerApp.id),
            l = await ns({
              api: n.api,
              requesterAppId: a,
              providerAppId: o.providerApp.id,
            });
          if (!s) {
            if (l.readOnly)
              throw (
                (console.error(
                  "cannot transact against a read-only provider app"
                ),
                new T.P("Cannot transact against a read-only provider app"))
              );
            (await i({ appId: o.providerApp.id, action: "link" })) &&
              (s = n.getProviderAccessToken(o.providerApp.id));
          }
          if (!s)
            throw (
              (n.createAnalyticsEvent({
                eventName: "cross_app_request_error",
                payload: {
                  error: "Transactions require a valid token",
                  address: t,
                },
              }),
              new T.P("Transactions require a valid token"))
            );
          let c = (0, _.aD)();
          if (!c)
            throw (
              (n.createAnalyticsEvent({
                eventName: "cross_app_request_error",
                payload: { error: "Missing token", address: t },
              }),
              new T.P("Failed to initialize signature request"))
            );
          let d = new URL(
            l.customAuthTransactUrl || `${l.apiUrl}/oauth/transact`
          );
          return (
            d.searchParams.set("token", s || ""),
            d.searchParams.set("request", nc(r)),
            (c.location = d.href),
            new Promise((e, a) => {
              let i = setTimeout(() => {
                  d(),
                    a(new T.P("Request timeout")),
                    n.createAnalyticsEvent({
                      eventName: "cross_app_request_error",
                      payload: { error: "Request timeout", address: t },
                    });
                }, 12e4),
                s = setInterval(() => {
                  c.closed &&
                    (d(),
                    a(new T.P("User rejected request")),
                    n.createAnalyticsEvent({
                      eventName: "cross_app_request_error",
                      payload: { error: "User rejected request", address: t },
                    }));
                }, 300),
                l = (i) => {
                  i.data &&
                    ("set" === i.data.token?.action &&
                    void 0 !== i.data.token?.value
                      ? n.storeProviderAccessToken(
                          o.providerApp.id,
                          i.data.token.value
                        )
                      : "clear" === i.data.token?.action &&
                        n.storeProviderAccessToken(o.providerApp.id, null),
                    "PRIVY_CROSS_APP_ACTION_RESPONSE" === i.data.type &&
                      i.data.result &&
                      (d(),
                      e(i.data.result),
                      n.createAnalyticsEvent({
                        eventName: "cross_app_request_success",
                        payload: { address: t, method: r.method },
                      })),
                    "PRIVY_CROSS_APP_ACTION_ERROR" === i.data.type &&
                      i.data.error &&
                      (d(),
                      a(i.data.error),
                      n.createAnalyticsEvent({
                        eventName: "cross_app_request_error",
                        payload: { error: i.data.error, address: t },
                      })));
                };
              window.addEventListener("message", l);
              let d = () => {
                c.close(),
                  clearInterval(s),
                  clearTimeout(i),
                  window.removeEventListener("message", l);
              };
            })
          );
        },
        nc = (e) =>
          JSON.stringify({
            content: { request: { request: nd(e, g.NC) } },
            timestamp: Date.now(),
            callbackUrl: window.origin,
          }),
        nd = (e, t) =>
          "bigint" == typeof e
            ? t(e)
            : Array.isArray(e)
            ? e.map((e) => nd(e, t))
            : e && "object" == typeof e
            ? Object.fromEntries(
                Object.entries(e).map(([e, n]) => [e, nd(n, t)])
              )
            : e,
        nu = ({
          passkeys: e,
          isLoading: t,
          errorReason: n,
          success: r,
          expanded: a,
          onLinkPasskey: i,
          onUnlinkPasskey: o,
          onExpand: s,
          onBack: l,
          onClose: c,
        }) =>
          (0, p.jsx)(
            _.ab,
            r
              ? {
                  title: "Passkeys updated",
                  icon: J.Z,
                  iconVariant: "success",
                  primaryCta: { label: "Done", onClick: c },
                  onClose: c,
                  watermark: !0,
                }
              : a
              ? {
                  icon: Q.Z,
                  title: "Your passkeys",
                  onBack: l,
                  onClose: c,
                  watermark: !0,
                  children: (0, p.jsx)(np, {
                    passkeys: e,
                    expanded: a,
                    onUnlink: o,
                    onExpand: s,
                  }),
                }
              : {
                  icon: Q.Z,
                  title: "Set up passkey verification",
                  subtitle: "Verify with passkey",
                  primaryCta: {
                    label: "Add new passkey",
                    onClick: i,
                    loading: t,
                  },
                  onClose: c,
                  watermark: !0,
                  helpText: n || void 0,
                  children:
                    0 === e.length
                      ? (0, p.jsx)(nm, {})
                      : (0, p.jsx)(nh, {
                          children: (0, p.jsx)(np, {
                            passkeys: e,
                            expanded: a,
                            onUnlink: o,
                            onExpand: s,
                          }),
                        }),
                }
          ),
        nh = F.zo.div.withConfig({
          displayName: "ContentContainer",
          componentId: "sc-d4c46a0c-0",
        })(["margin-bottom:12px;"]),
        np = ({ passkeys: e, expanded: t, onUnlink: n, onExpand: r }) => {
          let [a, i] = (0, w.useState)([]),
            o = t ? e.length : 2,
            s = (e) =>
              e.authenticatorName
                ? e.createdWithBrowser
                  ? `${e.authenticatorName} on ${e.createdWithBrowser}`
                  : e.authenticatorName
                : e.createdWithBrowser
                ? e.createdWithOs
                  ? `${e.createdWithBrowser} on ${e.createdWithOs}`
                  : `${e.createdWithBrowser}`
                : "Unknown device";
          return (0, p.jsxs)("div", {
            children: [
              (0, p.jsx)(nC, { children: "Your passkeys" }),
              (0, p.jsxs)(nv, {
                children: [
                  e.slice(0, o).map((e) =>
                    (0, p.jsxs)(
                      nA,
                      {
                        children: [
                          (0, p.jsxs)("div", {
                            children: [
                              (0, p.jsx)(nb, { children: s(e) }),
                              (0, p.jsxs)(nk, {
                                children: [
                                  "Last used:",
                                  " ",
                                  (
                                    e.latestVerifiedAt ?? e.firstVerifiedAt
                                  )?.toLocaleString() ?? "N/A",
                                ],
                              }),
                            ],
                          }),
                          (0, p.jsx)(nT, {
                            disabled: a.includes(e.credentialId),
                            onClick: () =>
                              (async (e) => {
                                i((t) => t.concat([e])),
                                  await n(e),
                                  i((t) => t.filter((t) => t !== e));
                              })(e.credentialId),
                            children: a.includes(e.credentialId)
                              ? (0, p.jsx)(_.aE, {})
                              : (0, p.jsx)(X.Z, { size: 16 }),
                          }),
                        ],
                      },
                      e.credentialId
                    )
                  ),
                  e.length > 2 &&
                    !t &&
                    (0, p.jsx)(nf, { onClick: r, children: "View all" }),
                ],
              }),
            ],
          });
        },
        nm = () =>
          (0, p.jsxs)(_.aF, {
            style: { color: "var(--privy-color-foreground)" },
            children: [
              (0, p.jsx)(_.aG, {
                children: "Verify with Touch ID, Face ID, PIN, or hardware key",
              }),
              (0, p.jsx)(_.aG, { children: "Takes seconds to set up and use" }),
              (0, p.jsx)(_.aG, {
                children:
                  "Use your passkey to verify transactions and login to your account",
              }),
            ],
          }),
        nw = {
          component: () => {
            let { user: e, unlinkPasskey: t } = (0, P.u)(),
              { linkWithPasskey: n, closePrivyModal: r } = (0, L.u)(),
              a = e?.linkedAccounts.filter((e) => "passkey" === e.type),
              [i, o] = (0, w.useState)(!1),
              [s, l] = (0, w.useState)(""),
              [c, d] = (0, w.useState)(!1),
              [u, h] = (0, w.useState)(!1);
            return (
              (0, w.useEffect)(() => {
                0 === a.length && h(!1);
              }, [a.length]),
              (0, p.jsx)(nu, {
                passkeys: a,
                isLoading: i,
                errorReason: s,
                success: c,
                expanded: u,
                onLinkPasskey: () => {
                  o(!0),
                    n()
                      .then(() => d(!0))
                      .catch((e) => {
                        if (e instanceof T.aa) {
                          if (e.privyErrorCode === T.h.CANNOT_LINK_MORE_OF_TYPE)
                            return void l(
                              "Cannot link more passkeys to account."
                            );
                          if (e.privyErrorCode === T.h.PASSKEY_NOT_ALLOWED)
                            return void l(
                              "Passkey request timed out or rejected by user."
                            );
                        }
                        l("Unknown error occurred.");
                      })
                      .finally(() => {
                        o(!1);
                      });
                },
                onUnlinkPasskey: async (e) => (
                  o(!0),
                  await t(e)
                    .then(() => d(!0))
                    .catch((e) => {
                      e instanceof T.aa &&
                      e.privyErrorCode === T.h.MISSING_MFA_CREDENTIALS
                        ? l("Cannot unlink a passkey enrolled in MFA")
                        : l("Unknown error occurred.");
                    })
                    .finally(() => {
                      o(!1);
                    })
                ),
                onExpand: () => h(!0),
                onBack: () => h(!1),
                onClose: () => r(),
              })
            );
          },
        },
        ny = F.zo.div.withConfig({
          displayName: "DoubleIconWrapper",
          componentId: "sc-d4c46a0c-1",
        })([
          "display:flex;align-items:center;justify-content:center;width:180px;height:90px;border-radius:50%;svg + svg{margin-left:12px;}> svg{z-index:2;color:var(--privy-color-accent) !important;stroke:var(--privy-color-accent) !important;fill:var(--privy-color-accent) !important;}",
        ]),
        ng = (0, F.iv)([
          "&&{width:100%;font-size:0.875rem;line-height:1rem;@media (min-width:440px){font-size:14px;}display:flex;gap:12px;justify-content:center;padding:6px 8px;background-color:var(--privy-color-background);transition:background-color 200ms ease;color:var(--privy-color-accent) !important;:focus{outline:none;box-shadow:none;}}",
        ]),
        nf = F.zo.button.withConfig({
          displayName: "LinkButton",
          componentId: "sc-d4c46a0c-2",
        })(["", ""], ng),
        nv = F.zo.div.withConfig({
          displayName: "List",
          componentId: "sc-d4c46a0c-3",
        })([
          "display:flex;flex-direction:column;align-items:stretch;gap:0.8rem;padding:0.5rem 0rem 0rem;flex-grow:1;width:100%;",
        ]),
        nC = F.zo.div.withConfig({
          displayName: "PasskeyListTitle",
          componentId: "sc-d4c46a0c-4",
        })([
          "line-height:20px;height:20px;font-size:1em;font-weight:450;display:flex;justify-content:flex-beginning;width:100%;",
        ]),
        nb = F.zo.div.withConfig({
          displayName: "PasskeyItemTitle",
          componentId: "sc-d4c46a0c-5",
        })([
          "font-size:1em;line-height:1.3em;font-weight:500;color:var(--privy-color-foreground-2);padding:0.2em 0;",
        ]),
        nk = F.zo.div.withConfig({
          displayName: "PasskeyItemSubtitle",
          componentId: "sc-d4c46a0c-6",
        })([
          "font-size:0.875rem;line-height:1rem;color:#64668b;padding:0.2em 0;",
        ]),
        nA = F.zo.div.withConfig({
          displayName: "PasskeyListItem",
          componentId: "sc-d4c46a0c-7",
        })([
          "display:flex;align-items:center;justify-content:space-between;padding:1em;gap:10px;font-size:0.875rem;line-height:1rem;text-align:left;border-radius:8px;border:1px solid #e2e3f0 !important;width:100%;height:5em;",
        ]),
        nx = (0, F.iv)([
          ":focus,:hover,:active{outline:none;}display:flex;width:2em;height:2em;justify-content:center;align-items:center;svg{color:var(--privy-color-error);}svg:hover{color:var(--privy-color-foreground-3);}",
        ]),
        nT = F.zo.button.withConfig({
          displayName: "PasskeyItemUnlinkButton",
          componentId: "sc-d4c46a0c-8",
        })(["", ""], nx),
        n_ = new Map([
          [_.aH, null],
          [_.aI, "external"],
          [_.aJ, "external"],
          [_.aK, "external"],
          [_.aL, "external"],
          [_.aM, "manual"],
          [_.aN, "moonpay"],
        ]),
        nE = () => {
          let e = (0, _.an)(),
            { user: t } = (0, P.u)(),
            {
              client: n,
              refreshSessionAndUser: r,
              walletProxy: a,
            } = (0, L.u)();
          return {
            migrate: (0, w.useCallback)(async () => {
              if ("legacy-embedded-wallets-only" === e.embeddedWallets.mode)
                return { success: !0 };
              if (!t)
                throw new T.P(
                  "User must be authenticated before migrating wallets",
                  T.h.MUST_BE_AUTHENTICATED
                );
              let i = (0, P.a)(t);
              if (!i || (0, P.g)(i) || !(0, G.i)(i)) return { success: !0 };
              if (!a) throw new T.P("Cannot connect to wallet proxy");
              let o = await n.getAccessToken();
              if (!o)
                throw new T.P(
                  "User must be authenticated before migrating wallets",
                  T.h.MUST_BE_AUTHENTICATED
                );
              let s = i.imported
                  ? [i]
                  : t.linkedAccounts
                      .filter(
                        (e) =>
                          "wallet" === e.type &&
                          "privy" === e.walletClientType &&
                          !e.imported
                      )
                      .filter(G.i),
                { entropyId: l, entropyIdVerifier: c } = (0, _.F)(t, i);
              try {
                await a.connect({
                  accessToken: o,
                  entropyId: l,
                  entropyIdVerifier: c,
                });
              } catch (e) {
                if (!(0, _.aO)(e) || "privy" !== i.recoveryMethod) throw e;
                await a.recover({
                  accessToken: o,
                  entropyId: l,
                  entropyIdVerifier: c,
                });
              }
              return (
                await a.createDelegatedAction({
                  accessToken: o,
                  rootWallet: {
                    address: i.address,
                    chainType: i.chainType,
                    imported: i.imported,
                  },
                  delegatedWallets: s,
                }),
                await r(),
                { success: !0 }
              );
            }, [e.embeddedWallets.mode, t, a, n, r]),
          };
        },
        nI = ({ disabled: e }) => {
          let { migrate: t } = nE(),
            { user: n } = (0, P.u)(),
            { walletProxy: r } = (0, L.u)();
          return (
            (0, w.useEffect)(() => {
              !e &&
                n &&
                r &&
                t().catch((e) => {
                  console.debug("Unable to migrate wallets: ", e);
                });
            }, [n, r, e, t]),
            null
          );
        },
        nS = (e) => ({
          id: e.id,
          raw_id: e.rawId,
          response: {
            client_data_json: e.response.clientDataJSON,
            authenticator_data: e.response.authenticatorData,
            signature: e.response.signature,
            user_handle: e.response.userHandle,
          },
          authenticator_attachment: e.authenticatorAttachment,
          client_extension_results: {
            app_id: e.clientExtensionResults.appid,
            cred_props: e.clientExtensionResults.credProps,
            hmac_create_secret: e.clientExtensionResults.hmacCreateSecret,
          },
          type: e.type,
        }),
        nP = ({ providerApp: e, success: t, error: n, onClose: r }) => {
          let { title: a, subtitle: i } = (0, w.useMemo)(
            () =>
              t
                ? {
                    title: `Successfully connected with ${e.name}`,
                    subtitle: "You're good to go!",
                  }
                : n
                ? { title: "Authentication failed", subtitle: n.message }
                : {
                    title: `Connecting to ${e.name}`,
                    subtitle: `Please check the pop-up from ${e.name} to continue`,
                  },
            [t, n, e.name]
          );
          return (0, p.jsx)(_.ab, {
            title: a,
            subtitle: i,
            icon: e.logoUrl,
            iconVariant: "loading",
            iconLoadingStatus: { success: t, fail: !!n },
            onBack: r,
            watermark: !0,
          });
        },
        nj = {
          component: () => {
            let e = (0, _.an)(),
              {
                data: t,
                navigate: n,
                setModalData: r,
                onUserCloseViaDialogOrKeybindRef: a,
              } = (0, _.as)(),
              {
                crossAppAuthFlow: i,
                updateWallets: o,
                closePrivyModal: s,
                createAnalyticsEvent: l,
              } = (0, L.u)(),
              { logout: c } = (0, D.a)(),
              [d, u] = (0, w.useState)({}),
              h = t?.crossAppAuth,
              m = { id: h.appId, name: h.name, logoUrl: h.logoUrl },
              y = new T.P(
                `There was an issue connecting your ${m.name} account. Please try again.`
              ),
              g = new _.R(async (e) => {
                if (h.popup)
                  try {
                    let t = await i({
                      appId: e,
                      popup: h.popup,
                      action: h.action,
                    });
                    u({ data: t });
                  } catch (e) {
                    if (e instanceof T.P) u({ error: e });
                    else if (e instanceof T.G) {
                      if (
                        e.privyErrorCode === T.h.ACCOUNT_TRANSFER_REQUIRED &&
                        e.data?.data?.nonce
                      )
                        return (
                          r({
                            accountTransfer: {
                              nonce: e.data?.data?.nonce,
                              account: e.data?.data?.subject,
                              displayName: e.data?.data?.account?.displayName,
                              linkMethod: `privy:${m.id}`,
                              embeddedWalletAddress:
                                e.data?.data?.otherUser?.embeddedWalletAddress,
                              oAuthUserInfo:
                                e.data?.data?.otherUser?.oAuthUserInfo,
                            },
                          }),
                          void n(_.aT)
                        );
                      h.popup && h.popup.close(), u({ error: y });
                    } else u({ error: y });
                  }
                else u({ error: y });
              }),
              f = () => {
                d.data &&
                  (o(),
                  h.onSuccess(d.data),
                  s({ shouldCallAuthOnSuccess: !0, isSuccess: !0 })),
                  h.onError(d.error ?? new T.P("User canceled flow")),
                  s({ shouldCallAuthOnSuccess: !1, isSuccess: !1 });
              };
            return (
              (a.current = f),
              (0, w.useEffect)(() => {
                m.id.length && g.execute(m.id);
              }, [m.id]),
              (0, w.useEffect)(() => {
                if (!d.data) return;
                let t = d.data;
                if (e.legal.requireUsersAcceptTerms && !t.hasAcceptedTerms) {
                  let e = setTimeout(() => {
                    n(_.aP);
                  }, _.aQ);
                  return () => clearTimeout(e);
                }
                if ((0, _.aR)(t, e.embeddedWallets)) {
                  let e = setTimeout(() => {
                    r({
                      createWallet: {
                        onSuccess: () => {},
                        onFailure: (e) => {
                          console.error(e),
                            l({
                              eventName:
                                "embedded_wallet_creation_failure_logout",
                              payload: {
                                error: e,
                                provider: `privy:${m.id}`,
                                screen: "CrossAppAuthScreen",
                              },
                            }),
                            c();
                        },
                        callAuthOnSuccessOnClose: !0,
                      },
                    }),
                      n(_.aS);
                  }, _.aQ);
                  return () => clearTimeout(e);
                }
                let a = setTimeout(f, _.aQ);
                return () => clearTimeout(a);
              }, [d.data]),
              (0, p.jsx)(nP, {
                providerApp: m,
                success: !!d.data,
                error: d.error,
                onClose: f,
              })
            );
          },
        },
        nU = ({
          appName: e,
          address: t,
          success: n,
          error: r,
          onAccept: a,
          onDecline: i,
          onClose: o,
        }) =>
          (0, p.jsx)(
            _.ab,
            n || r
              ? {
                  title: r ? "Something went wrong" : "Success!",
                  subtitle: r
                    ? "Please try again."
                    : `You've successfully granted delegated action permissions to ${e}.`,
                  icon: r ? ee.Z : J.Z,
                  iconVariant: r ? "error" : "success",
                  onBack: o,
                  watermark: !0,
                }
              : {
                  title: "Enable offline access",
                  subtitle: `By confirming, ${e} will be able to use your wallet for you even when you're not around. You can revoke this later.`,
                  icon: et.Z,
                  primaryCta: { label: "Accept", onClick: a },
                  secondaryCta: { label: "Not now", onClick: i },
                  onBack: o,
                  watermark: !0,
                  children: (0, p.jsx)(_.aV, { address: t, title: "Wallet" }),
                }
          ),
        nW = {
          component: () => {
            let { data: e } = (0, _.as)(),
              t = (0, _.an)(),
              { closePrivyModal: n } = (0, L.u)(),
              [r, a] = (0, w.useState)(!1),
              [i, o] = (0, w.useState)(),
              {
                address: s,
                onDelegate: l,
                onSuccess: c,
                onError: d,
              } = e.delegatedActions.consent,
              u = async () => {
                r ? c() : d(i ?? new T.P("User declined delegating actions.")),
                  n({ shouldCallAuthOnSuccess: !1 });
              };
            return (
              (0, w.useEffect)(() => {
                if (!r && !i) return;
                let e = setTimeout(u, _.aU);
                return () => clearTimeout(e);
              }, [r, i]),
              (0, p.jsx)(nU, {
                appName: t.name,
                address: s,
                success: r,
                error: i,
                onAccept: async () => {
                  try {
                    await l(), a(!0);
                  } catch (e) {
                    o(e);
                  }
                },
                onDecline: () => {
                  u();
                },
                onClose: u,
              })
            );
          },
        },
        nN = ({
          appName: e,
          success: t,
          error: n,
          onRevoke: r,
          onDeny: a,
          onClose: i,
        }) =>
          (0, p.jsx)(
            _.ab,
            t || n
              ? {
                  title: n ? "Something went wrong" : "Success!",
                  subtitle: n
                    ? "Please try again."
                    : "You've successfully revoked permissions.",
                  icon: n ? ee.Z : J.Z,
                  iconVariant: n ? "error" : "success",
                  onBack: i,
                  watermark: !0,
                }
              : {
                  title: "Revoke offline access to wallet",
                  subtitle: `By confirming, ${e} will no longer be able to use this wallet on your behalf when you are not online.`,
                  icon: en.Z,
                  primaryCta: { label: "Confirm", onClick: r },
                  secondaryCta: { label: "Deny", onClick: a },
                  onBack: i,
                  watermark: !0,
                }
          ),
        nO = {
          component: () => {
            let { data: e } = (0, _.as)(),
              t = (0, _.an)(),
              { closePrivyModal: n } = (0, L.u)(),
              [r, a] = (0, w.useState)(!1),
              [i, o] = (0, w.useState)(),
              {
                onRevoke: s,
                onSuccess: l,
                onError: c,
              } = e.delegatedActions.revoke,
              d = async () => {
                r
                  ? l()
                  : c(
                      i ??
                        new T.P(
                          "User declined revoking access to their delegated wallet."
                        )
                    ),
                  n({ shouldCallAuthOnSuccess: !1 });
              };
            return (
              (0, w.useEffect)(() => {
                if (!r && !i) return;
                let e = setTimeout(d, _.aU);
                return () => clearTimeout(e);
              }, [r, i]),
              (0, p.jsx)(nN, {
                appName: t.name,
                success: r,
                error: i,
                onRevoke: async () => {
                  try {
                    await s(), a(!0);
                  } catch (e) {
                    o(e);
                  }
                },
                onDeny: () => {
                  d();
                },
                onClose: d,
              })
            );
          },
        },
        nR = "#8a63d2",
        nM = ({
          appName: e,
          loading: t,
          success: n,
          errorMessage: r,
          connectUri: a,
          onBack: i,
          onClose: o,
          onOpenFarcaster: s,
        }) =>
          (0, p.jsx)(
            _.ab,
            y.tq || t
              ? y.gn
                ? {
                    title: r ? r.message : "Add a signer to Farcaster",
                    subtitle: r
                      ? r.detail
                      : `This will allow ${e} to add casts, likes, follows, and more on your behalf.`,
                    icon: _.aW,
                    iconVariant: "loading",
                    iconLoadingStatus: { success: n, fail: !!r },
                    primaryCta:
                      a && s
                        ? { label: "Open Farcaster app", onClick: s }
                        : void 0,
                    onBack: i,
                    onClose: o,
                    watermark: !0,
                  }
                : {
                    title: r ? r.message : "Requesting signer from Farcaster",
                    subtitle: r ? r.detail : "This should only take a moment",
                    icon: _.aW,
                    iconVariant: "loading",
                    iconLoadingStatus: { success: n, fail: !!r },
                    onBack: i,
                    onClose: o,
                    watermark: !0,
                    children:
                      a &&
                      y.tq &&
                      (0, p.jsx)(nF, {
                        children: (0, p.jsx)(_.aX, {
                          text: "Take me to Farcaster",
                          url: a,
                          color: nR,
                        }),
                      }),
                  }
              : {
                  title: "Add a signer to Farcaster",
                  subtitle: `This will allow ${e} to add casts, likes, follows, and more on your behalf.`,
                  onBack: i,
                  onClose: o,
                  watermark: !0,
                  children: (0, p.jsxs)(nL, {
                    children: [
                      (0, p.jsx)(nD, {
                        children: a
                          ? (0, p.jsx)(_.aY, {
                              url: a,
                              size: 275,
                              squareLogoElement: _.aW,
                            })
                          : (0, p.jsx)(nB, { children: (0, p.jsx)(_.au, {}) }),
                      }),
                      (0, p.jsxs)(nz, {
                        children: [
                          (0, p.jsx)(nq, {
                            children:
                              "Or copy this link and paste it into a phone browser to open the Farcaster app.",
                          }),
                          a &&
                            (0, p.jsx)(_.aZ, {
                              text: a,
                              itemName: "link",
                              color: nR,
                            }),
                        ],
                      }),
                    ],
                  }),
                }
          ),
        nF = F.zo.div.withConfig({
          displayName: "MobileLinkContainer",
          componentId: "sc-75c99bb6-0",
        })(["margin-top:24px;"]),
        nL = F.zo.div.withConfig({
          displayName: "ContentContainer",
          componentId: "sc-75c99bb6-1",
        })(["display:flex;flex-direction:column;align-items:center;gap:24px;"]),
        nD = F.zo.div.withConfig({
          displayName: "QrContainer",
          componentId: "sc-75c99bb6-2",
        })([
          "padding:24px;position:relative;display:flex;align-items:center;justify-content:center;min-height:275px;",
        ]),
        nz = F.zo.div.withConfig({
          displayName: "InstructionsContainer",
          componentId: "sc-75c99bb6-3",
        })(["display:flex;flex-direction:column;align-items:center;gap:16px;"]),
        nq = F.zo.div.withConfig({
          displayName: "InstructionText",
          componentId: "sc-75c99bb6-4",
        })([
          "font-size:0.875rem;text-align:center;color:var(--privy-color-foreground-2);",
        ]),
        nB = F.zo.div.withConfig({
          displayName: "LoaderWrapper",
          componentId: "sc-75c99bb6-5",
        })(["position:relative;width:82px;height:82px;"]),
        nV = {
          component: () => {
            let { lastScreen: e, navigateBack: t, data: n } = (0, _.as)(),
              r = (0, _.an)(),
              { requestFarcasterSignerStatus: a, closePrivyModal: i } = (0,
              L.u)(),
              [o, s] = (0, w.useState)(void 0),
              [l, c] = (0, w.useState)(!1),
              [d, u] = (0, w.useState)(!1),
              h = (0, w.useRef)([]),
              m = n?.farcasterSigner;
            (0, w.useEffect)(() => {
              let e = Date.now(),
                t = setInterval(async () => {
                  if (!m?.public_key)
                    return (
                      clearInterval(t),
                      void s({
                        retryable: !0,
                        message: "Connect failed",
                        detail: "Something went wrong. Please try again.",
                      })
                    );
                  "approved" === m.status &&
                    (clearInterval(t),
                    c(!1),
                    u(!0),
                    h.current.push(
                      setTimeout(
                        () => i({ shouldCallAuthOnSuccess: !1, isSuccess: !0 }),
                        _.aQ
                      )
                    ));
                  let n = await a(m?.public_key),
                    r = Date.now() - e;
                  "approved" === n.status
                    ? (clearInterval(t),
                      c(!1),
                      u(!0),
                      h.current.push(
                        setTimeout(
                          () =>
                            i({ shouldCallAuthOnSuccess: !1, isSuccess: !0 }),
                          _.aQ
                        )
                      ))
                    : r > 3e5
                    ? (clearInterval(t),
                      s({
                        retryable: !0,
                        message: "Connect failed",
                        detail: "The request timed out. Try again.",
                      }))
                    : "revoked" === n.status &&
                      (clearInterval(t),
                      s({
                        retryable: !0,
                        message: "Request rejected",
                        detail: "The request was rejected. Please try again.",
                      }));
                }, 2e3);
              return () => {
                clearInterval(t), h.current.forEach((e) => clearTimeout(e));
              };
            }, []);
            let y =
              "pending_approval" === m?.status ? m.signer_approval_url : void 0;
            return (0, p.jsx)(nM, {
              appName: r.name,
              loading: l,
              success: d,
              errorMessage: o,
              connectUri: y,
              onBack: e ? t : void 0,
              onClose: i,
              onOpenFarcaster: () => {
                y && (window.location.href = y);
              },
            });
          },
        },
        nH = ({ onClose: e }) =>
          (0, p.jsx)(_.ab, {
            title: "Could not log in with provider",
            subtitle:
              "It looks like you're using an in-app browser. To log in, please try again using an external browser.",
            icon: er.Z,
            primaryCta: { label: "Close", onClick: e },
            watermark: !0,
          }),
        n$ = {
          component: () => {
            let { closePrivyModal: e } = (0, L.u)();
            return (0, p.jsx)(nH, { onClose: () => e() });
          },
        },
        nZ = ({
          title: e = "Connect your email",
          subtitle: t = "Add your email to your account",
        }) =>
          (0, p.jsx)(_.ab, {
            title: e,
            subtitle: t,
            icon: eo.Z,
            watermark: !0,
            children: (0, p.jsx)(_.a_, {
              children: (0, p.jsx)(_.a$, { stacked: !0 }),
            }),
          }),
        nK = {
          component: () => {
            let e = (0, _.an)();
            return (0, p.jsx)(nZ, {
              subtitle: `Add your email to your ${e?.name} account`,
            });
          },
        },
        nY = ({
          title: e = "Connect your phone",
          subtitle: t = "Add your number to your account",
          onSubmit: n,
          isSubmitting: r = !1,
        }) => {
          let [a, i] = (0, w.useState)(null),
            o = async () => {
              a?.qualifiedPhoneNumber && (await n(a));
            };
          return (0, p.jsx)(_.ab, {
            title: e,
            subtitle: t,
            icon: B.Z,
            primaryCta: {
              label: r ? "Submitting" : "Submit",
              onClick: o,
              disabled: !a?.isValid || r,
            },
            watermark: !0,
            children: (0, p.jsx)(_.b0, {
              onChange: (e) => {
                i(e);
              },
              onSubmit: o,
              noIncludeSubmitButton: !0,
              hideRecent: !0,
            }),
          });
        },
        nG = {
          component: () => {
            let {
                currentScreen: e,
                data: t,
                navigate: n,
                setModalData: r,
              } = (0, _.as)(),
              a = (0, _.an)(),
              { initLoginWithSms: i } = (0, L.u)(),
              [o, s] = (0, w.useState)(!1);
            return (0, p.jsx)(nY, {
              subtitle: `Add your number to your ${a?.name} account`,
              onSubmit: async (a) => {
                s(!0);
                try {
                  await i({
                    phoneNumber: a.qualifiedPhoneNumber,
                    withPrivyUi: !0,
                  }),
                    n(_.b1);
                } catch (a) {
                  r({
                    errorModalData: {
                      error: a,
                      previousScreen:
                        t?.errorModalData?.previousScreen || e || nG,
                    },
                  }),
                    n(_.b2);
                } finally {
                  s(!1);
                }
              },
              isSubmitting: o,
            });
          },
        },
        nJ = ({
          title: e = "Could not connect with wallet",
          subtitle:
            t = "Please check that Phantom multichain is enabled and try again.",
          primaryCtaText: n = "Try again",
          secondaryCtaText: r = "Cancel",
          onTryAgain: a,
          onCancel: i,
        }) =>
          (0, p.jsx)(_.ab, {
            title: e,
            subtitle: t,
            icon: ea.Z,
            iconVariant: "error",
            primaryCta: { label: n, onClick: a },
            secondaryCta: { label: r, onClick: i },
            watermark: !0,
          }),
        nQ = {
          component: () => {
            let { closePrivyModal: e } = (0, L.u)(),
              { navigate: t } = (0, _.as)();
            return (0, p.jsx)(nJ, {
              onTryAgain: () => {
                t(_.b3);
              },
              onCancel: async () => {
                await e();
              },
            });
          },
        };
      function nX() {
        let {
          initEnrollmentWithSms: e,
          initEnrollmentWithTotp: t,
          initEnrollmentWithPasskey: n,
          submitEnrollmentWithSms: r,
          submitEnrollmentWithTotp: a,
          submitEnrollmentWithPasskey: i,
          unenroll: o,
          enrollInMfa: s,
        } = (0, w.useContext)(P.P);
        return {
          initEnrollmentWithSms: e,
          initEnrollmentWithTotp: t,
          initEnrollmentWithPasskey: n,
          submitEnrollmentWithSms: r,
          submitEnrollmentWithTotp: a,
          submitEnrollmentWithPasskey: i,
          unenrollWithSms: () => o("sms"),
          unenrollWithTotp: () => o("totp"),
          unenrollWithPasskey: (e) => o("passkey", e),
          showMfaEnrollmentModal: () => s(!0),
          closeMfaEnrollmentModal: () => s(!1),
        };
      }
      let n0 = (e) =>
          (0, p.jsxs)(n1, {
            xmlns: "http://www.w3.org/2000/svg",
            fill: "none",
            width: "88",
            height: "89",
            viewBox: "0 0 88 89",
            ...e,
            children: [
              (0, p.jsx)("rect", {
                y: "0.666016",
                width: "88",
                height: "88",
                rx: "44",
              }),
              (0, p.jsx)("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M45.2463 20.9106C44.5473 20.2486 43.4527 20.2486 42.7537 20.9106C37.8798 25.5263 31.3034 28.3546 24.0625 28.3546C23.9473 28.3546 23.8323 28.3539 23.7174 28.3525C22.9263 28.3427 22.2202 28.8471 21.9731 29.5987C20.9761 32.6311 20.4375 35.8693 20.4375 39.2297C20.4375 53.5896 30.259 65.651 43.5482 69.0714C43.8446 69.1477 44.1554 69.1477 44.4518 69.0714C57.741 65.651 67.5625 53.5896 67.5625 39.2297C67.5625 35.8693 67.0239 32.6311 66.0269 29.5987C65.7798 28.8471 65.0737 28.3427 64.2826 28.3525C64.1677 28.3539 64.0527 28.3546 63.9375 28.3546C56.6966 28.3546 50.1202 25.5263 45.2463 20.9106ZM52.7249 40.2829C53.3067 39.4683 53.1181 38.3363 52.3035 37.7545C51.4889 37.1726 50.3569 37.3613 49.7751 38.1759L41.9562 49.1223L38.0316 45.1977C37.3238 44.4899 36.1762 44.4899 35.4684 45.1977C34.7605 45.9056 34.7605 47.0532 35.4684 47.761L40.9059 53.1985C41.2826 53.5752 41.806 53.7671 42.337 53.7232C42.868 53.6792 43.3527 53.4039 43.6624 52.9704L52.7249 40.2829Z",
              }),
            ],
          }),
        n1 = F.zo.svg.withConfig({
          displayName: "StyledSvg",
          componentId: "sc-59fa943f-0",
        })(["height:90px;width:90px;> rect{", "}> path{fill:white;}"], (e) =>
          "success" === e.color
            ? "fill: var(--privy-color-success);"
            : "fill: var(--privy-color-accent);"
        ),
        n2 = ({
          showIntro: e,
          userMfaMethods: t,
          appMfaMethods: n,
          userHasAuthSms: r,
          isTotpLoading: a,
          isPasskeyLoading: i,
          error: o,
          onClose: s,
          onBackToIntro: l,
          handleSelectMethod: c,
          setRemovingMfaMethod: d,
        }) => {
          let u = t.reduce((e, t) => ({ ...e, [t]: !0 }), {}),
            h = n.reduce((e, t) => ({ ...e, [t]: !0 }), {});
          return (0, p.jsxs)(p.Fragment, {
            children: [
              (0, p.jsx)(
                _.aj,
                { backFn: e ? l : void 0, onClose: s },
                "header"
              ),
              (0, p.jsx)(tv, {
                style: { marginBottom: "1.5rem" },
                children: (0, p.jsx)(V.Z, {}),
              }),
              (0, p.jsx)(ta, { children: "Choose a verification method" }),
              t.length > 0
                ? (0, p.jsx)(ti, {
                    children:
                      "To add or delete verification methods, verification is required.",
                  })
                : (0, p.jsx)(ti, {
                    children: "How would you like to verify your identity?",
                  }),
              o &&
                (0, p.jsx)(tC, {
                  style: { marginTop: "1.25rem" },
                  children: o.message,
                }),
              (0, p.jsxs)(tu, {
                children: [
                  (h.passkey || u.passkey) &&
                    (0, p.jsxs)(
                      th,
                      {
                        children: [
                          (0, p.jsx)(_.ac, {
                            style: { justifyContent: "center" },
                            onClick: () => c("passkey"),
                            disabled: u.passkey || i,
                            children: i
                              ? (0, p.jsx)(_.au, {
                                  style: {
                                    height: 24,
                                    width: 24,
                                    borderWidth: 2,
                                  },
                                  color: "var(--privy-color-foreground-3)",
                                })
                              : (0, p.jsxs)(ty, {
                                  children: [
                                    (0, p.jsxs)(tm, {
                                      children: [
                                        (0, p.jsx)(q.Z, {}),
                                        "Passkey",
                                      ],
                                    }),
                                    u.passkey
                                      ? (0, p.jsx)(n4, {
                                          color: "green",
                                          children: "Enabled",
                                        })
                                      : (0, p.jsx)(tw, {
                                          $isAccent: !0,
                                          children: (0, p.jsx)(ed.Z, {}),
                                        }),
                                  ],
                                }),
                          }),
                          u.passkey &&
                            (0, p.jsx)(tp, {
                              style: { position: "absolute", right: 0 },
                              onClick: () => d("passkey"),
                              children: (0, p.jsx)(eu.Z, {}),
                            }),
                        ],
                      },
                      "passkey"
                    ),
                  (h.totp || u.totp) &&
                    (0, p.jsxs)(
                      th,
                      {
                        children: [
                          (0, p.jsx)(_.ac, {
                            style: { justifyContent: "center" },
                            disabled: u.totp || a,
                            onClick: () => c("totp"),
                            children: a
                              ? (0, p.jsx)(_.au, {
                                  style: {
                                    height: 24,
                                    width: 24,
                                    borderWidth: 2,
                                  },
                                  color: "var(--privy-color-foreground-3)",
                                })
                              : (0, p.jsxs)(ty, {
                                  children: [
                                    (0, p.jsxs)(tm, {
                                      children: [
                                        (0, p.jsx)(z.Z, {}),
                                        "Authenticator app",
                                      ],
                                    }),
                                    u.totp &&
                                      (0, p.jsx)(n4, {
                                        color: "green",
                                        children: "Enabled",
                                      }),
                                  ],
                                }),
                          }),
                          u.totp &&
                            (0, p.jsx)(tp, {
                              style: { position: "absolute", right: 0 },
                              onClick: () => d("totp"),
                              children: (0, p.jsx)(eu.Z, {}),
                            }),
                        ],
                      },
                      "totp"
                    ),
                  (h.sms || u.sms) &&
                    (0, p.jsxs)(
                      th,
                      {
                        children: [
                          (0, p.jsx)(_.ac, {
                            disabled: u.sms || r,
                            onClick: () => c("sms"),
                            children: (0, p.jsxs)(ty, {
                              children: [
                                (0, p.jsxs)(tm, {
                                  children: [(0, p.jsx)(B.Z, {}), "SMS"],
                                }),
                                u.sms &&
                                  (0, p.jsx)(n4, {
                                    color: "green",
                                    children: "Enabled",
                                  }),
                                r && (0, p.jsx)(tw, { children: "Disabled" }),
                              ],
                            }),
                          }),
                          u.sms &&
                            (0, p.jsx)(tp, {
                              style: { position: "absolute", right: 0 },
                              onClick: () => d("sms"),
                              children: (0, p.jsx)(eu.Z, {}),
                            }),
                        ],
                      },
                      "sms"
                    ),
                ],
              }),
              (0, p.jsx)(n3, {
                children: "You can always change your selection later",
              }),
              (0, p.jsx)(_.ae, {}),
            ],
          });
        },
        n4 = (0, F.zo)(_.b4).withConfig({
          displayName: "StyledChip",
          componentId: "sc-24f8b314-0",
        })(["margin-right:1.5rem;"]),
        n3 = (0, F.zo)(tg).withConfig({
          displayName: "StyledTerms",
          componentId: "sc-24f8b314-1",
        })(["&&{margin-top:1rem;}text-align:center;"]),
        n5 = ({ style: e, ...t }) =>
          (0, p.jsxs)("svg", {
            x: 0,
            y: 0,
            width: "65",
            height: "64",
            viewBox: "0 0 65 64",
            style: { height: "64px", width: "65px", ...e },
            xmlns: "http://www.w3.org/2000/svg",
            ...t,
            children: [
              (0, p.jsxs)("g", {
                clipPath: "url(#clip0_113_33841)",
                children: [
                  (0, p.jsx)("path", {
                    d: "M39.1193 0.943398C34.636 -0.174912 29.9185 -0.334713 25.328 0.656273C24.9732 0.732859 24.7477 1.08253 24.8243 1.43729C24.9009 1.79205 25.2506 2.01756 25.6053 1.94097C30.0015 0.991934 34.53 1.14842 38.8375 2.22802C49.1385 4.80983 57.7129 12.5548 60.9786 22.6718C62.2416 26.5843 62.7781 30.7505 62.8855 35.1167C62.8945 35.4795 63.1958 35.7664 63.5586 35.7575C63.9215 35.7485 64.2083 35.4472 64.1994 35.0843C64.0905 30.6582 63.5477 26.3849 62.2536 22.3432C58.8621 11.7515 49.9005 3.63265 39.1193 0.943398Z",
                  }),
                  (0, p.jsx)("path", {
                    d: "M21.9931 2.93163C22.343 2.83511 22.5484 2.47325 22.4518 2.12339C22.3553 1.77352 21.9935 1.56815 21.6436 1.66466C16.8429 2.98903 10.0898 7.56519 5.91628 13.6786C5.91465 13.681 5.91304 13.6834 5.91145 13.6858C2.24684 19.2083 -0.0503572 26.1484 0.591012 32.8828C0.591623 32.8892 0.592328 32.8956 0.593127 32.902C0.746837 34.1317 1.00488 35.3591 1.26323 36.5879C1.80735 39.1761 2.35282 41.7706 1.92765 44.4064C1.86986 44.7647 2.11347 45.102 2.47177 45.1598C2.83007 45.2176 3.16738 44.974 3.22518 44.6157C3.66961 41.8605 3.11776 39.173 2.56581 36.4851C2.31054 35.2419 2.05525 33.9987 1.89847 32.7486C1.29525 26.3851 3.46802 19.7466 7.00418 14.416C11.0189 8.5373 17.5201 4.16562 21.9931 2.93163Z",
                  }),
                  (0, p.jsx)("path", {
                    d: "M30.6166 4.39985C38.8671 3.89603 47.1159 7.26314 52.6556 13.7139C52.8921 13.9893 52.8605 14.4042 52.5852 14.6406C52.3099 14.8771 51.895 14.8455 51.6585 14.5702C46.3904 8.43576 38.541 5.23144 30.6927 5.71195C30.6899 5.71212 30.6871 5.71227 30.6843 5.71241C20.7592 6.19265 11.4643 12.9257 8.04547 22.3603C7.92183 22.7016 7.54498 22.8779 7.20375 22.7543C6.86253 22.6306 6.68616 22.2538 6.80981 21.9126C10.4114 11.9735 20.1717 4.90702 30.6166 4.39985Z",
                  }),
                  (0, p.jsx)("path", {
                    d: "M54.6576 16.5848C54.4553 16.2836 54.047 16.2033 53.7457 16.4057C53.4444 16.608 53.3642 17.0163 53.5665 17.3176C56.6376 21.8904 57.9074 26.8665 58.4094 32.7717C58.4401 33.1333 58.7582 33.4016 59.1199 33.3708C59.4815 33.3401 59.7497 33.022 59.719 32.6604C59.206 26.6261 57.8965 21.4076 54.6576 16.5848Z",
                  }),
                  (0, p.jsx)("path", {
                    d: "M59.2796 35.4504C59.6419 35.4277 59.9539 35.703 59.9765 36.0653C60.2242 40.0279 60.2265 44.5112 59.7881 47.8243C59.7405 48.1841 59.4102 48.4372 59.0504 48.3896C58.6906 48.342 58.4376 48.0117 58.4852 47.6519C58.9077 44.4586 58.91 40.0704 58.6648 36.1473C58.6421 35.785 58.9174 35.473 59.2796 35.4504Z",
                  }),
                  (0, p.jsx)("path", {
                    d: "M7.05311 25.5432C7.13829 25.1904 6.92135 24.8354 6.56855 24.7502C6.21576 24.665 5.86071 24.882 5.77553 25.2348C5.2932 27.2325 5.0428 29.2847 5.03288 31.3388C5.02266 33.4559 5.41742 35.5225 5.81234 37.5899C6.1354 39.2811 6.45855 40.9728 6.5602 42.6932C6.69373 44.9531 6.21839 47.2163 5.39698 49.3703C5.26766 49.7094 5.43774 50.0891 5.77685 50.2184C6.11596 50.3477 6.4957 50.1777 6.62502 49.8386C7.49325 47.5617 8.01954 45.1092 7.87221 42.6157C7.77126 40.9071 7.44813 39.2252 7.12512 37.5439C6.73099 35.4925 6.33704 33.442 6.34716 31.3451C6.35659 29.3933 6.59455 27.4425 7.05311 25.5432Z",
                  }),
                  (0, p.jsx)("path", {
                    d: "M24.2964 10.94C24.4317 11.2768 24.2683 11.6595 23.9315 11.7947C17.1187 14.5307 12.0027 20.7047 10.959 27.9852C10.523 31.0269 10.9941 34.0398 11.465 37.052C11.7303 38.7483 11.9954 40.4443 12.0985 42.1451C12.3221 45.833 11.902 49.8839 9.50192 53.5696C9.30387 53.8737 8.89677 53.9597 8.59264 53.7617C8.28851 53.5636 8.20251 53.1565 8.40056 52.8524C10.5873 49.4944 11.0012 45.7644 10.7867 42.2246C10.6821 40.499 10.4185 38.7833 10.1552 37.0686C9.68265 33.9923 9.21067 30.9195 9.65804 27.7987C10.7724 20.025 16.221 13.4748 23.4417 10.5751C23.7785 10.4399 24.1612 10.6032 24.2964 10.94Z",
                  }),
                  (0, p.jsx)("path", {
                    d: "M47.3662 14.6814C41.9915 9.64741 34.2017 7.89046 27.122 9.4433C26.7675 9.52105 26.5432 9.87147 26.6209 10.226C26.6987 10.5805 27.0491 10.8048 27.4036 10.7271C34.1075 9.25665 41.4426 10.934 46.4677 15.6406C50.7033 19.6077 53.1628 25.38 53.8066 31.6779C53.8435 32.0389 54.1661 32.3017 54.5272 32.2648C54.8883 32.2279 55.151 31.9053 55.1141 31.5442C54.4456 25.0047 51.8822 18.9111 47.3662 14.6814Z",
                  }),
                  (0, p.jsx)("path", {
                    d: "M54.9766 34.6738C55.3376 34.6368 55.6604 34.8994 55.6975 35.2604C56.3216 41.337 56.0526 47.9003 55.1104 54.2496C55.0571 54.6086 54.7229 54.8565 54.3639 54.8032C54.0049 54.7499 53.7571 54.4157 53.8103 54.0567C54.7394 47.7957 55.001 41.3439 54.39 35.3947C54.353 35.0336 54.6156 34.7109 54.9766 34.6738Z",
                  }),
                  (0, p.jsx)("path", {
                    d: "M32.0659 13.3553C21.9959 13.3553 13.814 21.3892 13.814 31.3219C13.814 32.3829 13.9081 33.4225 14.0876 34.4334C14.1511 34.7907 14.4922 35.029 14.8495 34.9655C15.2069 34.9021 15.4451 34.561 15.3817 34.2036C15.2155 33.2677 15.1283 32.305 15.1283 31.3219C15.1283 22.1352 22.7014 14.6696 32.0659 14.6696C36.2978 14.6696 40.1642 16.1949 43.1319 18.7152C43.4086 18.9501 43.8233 18.9163 44.0582 18.6396C44.2931 18.363 44.2593 17.9483 43.9827 17.7134C40.7847 14.9975 36.6188 13.3553 32.0659 13.3553Z",
                  }),
                  (0, p.jsx)("path", {
                    d: "M45.455 20.1635C45.717 19.9123 46.133 19.921 46.3842 20.183C49.2843 23.2072 50.2126 27.9605 50.8269 31.9494C51.5188 36.4426 51.6244 40.826 51.6244 42.8585C51.6244 43.2214 51.3302 43.5156 50.9673 43.5156C50.6044 43.5156 50.3101 43.2214 50.3101 42.8585C50.3101 40.8589 50.2055 36.5497 49.5279 32.1494C48.9577 28.4462 48.1356 23.9082 45.4356 21.0927C45.1844 20.8307 45.1931 20.4147 45.455 20.1635Z",
                  }),
                  (0, p.jsx)("path", {
                    d: "M51.4576 46.6219C51.4864 46.2601 51.2165 45.9435 50.8547 45.9146C50.493 45.8858 50.1763 46.1557 50.1474 46.5175C49.8247 50.5654 49.403 54.6088 48.5474 58.3439C48.4663 58.6977 48.6874 59.0502 49.0412 59.1312C49.3949 59.2123 49.7474 58.9912 49.8285 58.6374C50.7067 54.8039 51.134 50.6806 51.4576 46.6219Z",
                  }),
                  (0, p.jsx)("path", {
                    d: "M15.1454 36.852C15.5015 36.7819 15.847 37.0137 15.9171 37.3698C17.3066 44.4257 16.3467 50.8355 12.6672 56.4502C12.4682 56.7537 12.0609 56.8385 11.7573 56.6396C11.4538 56.4407 11.369 56.0333 11.5679 55.7298C15.0299 50.4469 15.9617 44.3985 14.6276 37.6238C14.5575 37.2677 14.7893 36.9221 15.1454 36.852Z",
                  }),
                  (0, p.jsx)("path", {
                    d: "M32.0659 17.631C25.5291 17.631 19.1165 22.691 18.462 29.0504C18.1754 31.8345 18.578 34.5769 18.9807 37.3204C19.3323 39.7159 19.684 42.1124 19.5772 44.5381C19.3328 50.0898 17.7039 54.6726 14.905 58.4471C14.6888 58.7386 14.7499 59.1502 15.0414 59.3663C15.333 59.5825 15.7445 59.5214 15.9607 59.2299C18.9293 55.2266 20.6354 50.386 20.8903 44.5959C20.9966 42.1811 20.6438 39.7923 20.2912 37.4051C19.888 34.6752 19.4851 31.9473 19.7694 29.1849C20.3444 23.5983 26.0946 18.9453 32.0659 18.9453C34.851 18.9453 42.057 20.4534 44.3492 27.9205C45.7856 32.5998 46.1774 38.9326 45.8295 45.0849C45.4816 51.2364 44.3994 57.12 42.9442 60.8928C42.8136 61.2314 42.9822 61.6118 43.3208 61.7424C43.6594 61.873 44.0398 61.7044 44.1704 61.3658C45.6929 57.4186 46.7895 51.386 47.1417 45.1591C47.4938 38.9329 47.1068 32.4249 45.6056 27.5348C43.0612 19.2461 35.0851 17.631 32.0659 17.631Z",
                  }),
                  (0, p.jsx)("path", {
                    d: "M21.9529 56.4512C22.2569 56.6494 22.3426 57.0566 22.1444 57.3606C21.7369 57.9854 21.3784 58.6391 21.0199 59.2928C20.6614 59.9465 20.3028 60.6004 19.8953 61.2253C19.697 61.5293 19.2898 61.615 18.9858 61.4167C18.6819 61.2184 18.5962 60.8113 18.7944 60.5073C19.2019 59.8825 19.5604 59.2288 19.9189 58.5751C20.2774 57.9213 20.636 57.2675 21.0435 56.6426C21.2418 56.3386 21.649 56.2529 21.9529 56.4512Z",
                  }),
                  (0, p.jsx)("path", {
                    d: "M27.5799 24.4525C27.8816 24.2508 27.9625 23.8426 27.7608 23.541C27.559 23.2393 27.1509 23.1583 26.8492 23.3601C24.247 25.1006 22.6505 27.494 22.6505 31.0002C22.6505 33.088 23.0203 34.7946 23.3997 36.5449C23.9674 39.1641 24.3524 41.7777 24.2832 44.468C24.1992 47.7349 23.56 50.7201 22.3313 53.564C22.1873 53.8971 22.3407 54.2839 22.6739 54.4278C23.0071 54.5718 23.3938 54.4184 23.5378 54.0852C24.8369 51.0784 25.509 47.9266 25.5971 44.5018C25.6689 41.7062 25.2732 38.9892 24.6845 36.267C24.3042 34.509 23.9648 32.9394 23.9648 31.0002C23.9648 27.9961 25.2863 25.9866 27.5799 24.4525Z",
                  }),
                  (0, p.jsx)("path", {
                    d: "M30.1447 22.1436C32.8717 21.5877 35.8061 22.2746 37.966 24.0228C41.8241 27.1455 42.3372 32.8403 42.753 37.4549L42.7742 37.69C43.3115 43.6385 42.6964 49.4163 41.4575 55.2186C41.3817 55.5736 41.0326 55.7999 40.6776 55.7241C40.3227 55.6483 40.0964 55.2991 40.1722 54.9442C41.3926 49.2288 41.9873 43.5885 41.4652 37.8082C41.4479 37.6169 41.4307 37.4228 41.4133 37.2264L41.4131 37.2235C41.0438 33.0534 40.5812 27.8304 37.1392 25.0444C35.2926 23.5498 32.7599 22.9518 30.4073 23.4314C30.0517 23.5039 29.7046 23.2744 29.6321 22.9188C29.5596 22.5632 29.7891 22.2161 30.1447 22.1436Z",
                  }),
                  (0, p.jsx)("path", {
                    d: "M40.5287 58.4885C40.6183 58.1368 40.4057 57.7791 40.054 57.6896C39.7023 57.6 39.3446 57.8126 39.2551 58.1643C38.8578 59.7247 38.2456 61.1333 37.4695 62.4301C37.2831 62.7415 37.3844 63.145 37.6958 63.3314C38.0072 63.5178 38.4108 63.4165 38.5972 63.1051C39.4336 61.7075 40.0977 60.1816 40.5287 58.4885Z",
                  }),
                  (0, p.jsx)("path", {
                    d: "M37.3152 48.9521C37.6756 48.9948 37.9332 49.3215 37.8906 49.682C37.2699 54.9267 35.8688 59.6042 33.6205 63.6613C33.4446 63.9787 33.0446 64.0934 32.7272 63.9175C32.4097 63.7416 32.295 63.3417 32.4709 63.0242C34.6226 59.1416 35.9811 54.6339 36.5854 49.5275C36.6281 49.1671 36.9548 48.9095 37.3152 48.9521Z",
                  }),
                  (0, p.jsx)("path", {
                    d: "M37.1798 30.6556C36.7242 28.2212 34.6349 26.3591 32.0985 26.3591C28.6638 26.3591 26.254 29.8212 27.1032 33.0422C28.54 38.7279 28.7759 44.2077 27.8032 49.4855L27.8025 49.4893C26.9584 54.228 25.3374 58.4908 23.1263 62.1031C22.9368 62.4127 23.0342 62.8172 23.3437 63.0067C23.6533 63.1962 24.0578 63.0988 24.2473 62.7893C26.5488 59.0292 28.2249 54.6109 29.0961 49.7218C30.106 44.2403 29.8558 38.5684 28.3765 32.7168L28.3748 32.7099C27.7378 30.3005 29.5133 27.6734 32.0985 27.6734C33.9641 27.6734 35.5393 29.0459 35.8871 30.8929C36.8436 36.4411 37.3418 41.5862 36.9871 46.016C36.9581 46.3778 37.2279 46.6945 37.5897 46.7235C37.9515 46.7525 38.2682 46.4827 38.2972 46.1209C38.6649 41.5294 38.1459 36.2576 37.1815 30.6648C37.1809 30.6617 37.1804 30.6586 37.1798 30.6556Z",
                  }),
                  (0, p.jsx)("path", {
                    d: "M30.1376 59.1171C30.4604 59.283 30.5876 59.6792 30.4217 60.002L28.6804 63.3906C28.5145 63.7134 28.1184 63.8406 27.7956 63.6747C27.4728 63.5088 27.3456 63.1127 27.5114 62.7899L29.2527 59.4013C29.4186 59.0785 29.8147 58.9513 30.1376 59.1171Z",
                  }),
                  (0, p.jsx)("path", {
                    d: "M32.5872 31.2892C32.5042 30.9359 32.1505 30.7168 31.7972 30.7998C31.4439 30.8828 31.2247 31.2365 31.3077 31.5898C33.5238 41.0232 33.2194 49.3066 30.5201 56.363C30.3905 56.702 30.5602 57.0819 30.8991 57.2115C31.2381 57.3412 31.618 57.1715 31.7477 56.8326C34.5622 49.475 34.8483 40.9141 32.5872 31.2892Z",
                  }),
                ],
              }),
              (0, p.jsx)("defs", {
                children: (0, p.jsx)("clipPath", {
                  id: "clip0_113_33841",
                  children: (0, p.jsx)("rect", {
                    width: "64",
                    height: "64",
                    fill: "white",
                    transform: "translate(0.483887)",
                  }),
                }),
              }),
            ],
          }),
        n6 = ({ onClose: e, onReset: t, submitEnrollmentWithPasskey: n }) => {
          let { user: r } = (0, P.u)(),
            { initLinkWithPasskey: a, linkWithPasskey: i } = (0, L.u)(),
            o = (0, _.an)(),
            [s, l] = (0, w.useState)(!1),
            [c, d] = (0, w.useState)(!1),
            [u, h] = (0, w.useState)(null),
            m = (0, w.useMemo)(
              () => r?.linkedAccounts.filter((e) => "passkey" === e.type) ?? [],
              [r]
            ),
            y = async (e) => {
              l(!0);
              try {
                await n(e);
              } catch (e) {
                h(e);
              } finally {
                l(!1);
              }
            },
            g = async () => {
              d(!0), h(null);
              try {
                await a();
                let e = await i(),
                  t =
                    e?.linkedAccounts
                      .filter((e) => "passkey" === e.type)
                      .map((e) => e.credentialId) ?? [];
                await y(t);
              } catch (e) {
                h(e);
              } finally {
                d(!1);
              }
            };
          return 0 === m.length || c
            ? (0, p.jsx)(n7, {
                onReset: t,
                onClose: e,
                onClick: g,
                isCreating: c,
              })
            : u
            ? (0, p.jsx)(_.b5, {
                allowlistConfig: o.allowlistConfig,
                error: u,
                onBack: () => h(null),
                onRetry: () => h(null),
              })
            : (0, p.jsx)(n9, {
                passkeys: m,
                isSubmitting: s,
                isCreating: c,
                onReset: t,
                onClose: e,
                onSubmitEnrollment: () => y(m.map((e) => e.credentialId)),
                onAddPasskey: g,
              });
        },
        n7 = ({ onReset: e, onClose: t, onClick: n, isCreating: r }) =>
          (0, p.jsxs)(p.Fragment, {
            children: [
              (0, p.jsx)(_.aj, { backFn: e, onClose: t }, "header"),
              (0, p.jsx)(tr, {
                children: (0, p.jsxs)(ny, {
                  children: [(0, p.jsx)(tx, {}), (0, p.jsx)(n5, {})],
                }),
              }),
              (0, p.jsx)(ta, { children: "Set up passkey verification" }),
              (0, p.jsxs)(ts, {
                children: [
                  (0, p.jsxs)(tc, {
                    children: [
                      (0, p.jsx)(tl, { children: (0, p.jsx)(V.Z, {}) }),
                      "Verify with Touch ID, Face ID, PIN, or hardware key",
                    ],
                  }),
                  (0, p.jsxs)(tc, {
                    children: [
                      (0, p.jsx)(tl, { children: (0, p.jsx)(ep.Z, {}) }),
                      "Takes seconds to set up and use",
                    ],
                  }),
                  (0, p.jsxs)(tc, {
                    children: [
                      (0, p.jsx)(tl, { children: (0, p.jsx)(eh.Z, {}) }),
                      "Use your passkey to verify transactions and login to your account",
                    ],
                  }),
                ],
              }),
              (0, p.jsx)(_.am, {
                style: { marginTop: "2.25rem" },
                onClick: n,
                loading: r,
                children: "Add a new passkey",
              }),
              (0, p.jsx)(_.ae, {}),
            ],
          }),
        n9 = ({
          onReset: e,
          onClose: t,
          onAddPasskey: n,
          onSubmitEnrollment: r,
          passkeys: a,
          isSubmitting: i,
          isCreating: o,
        }) => {
          let [s, l] = (0, w.useState)(!1),
            c = s ? a.length : a.length > 3 ? 2 : 3;
          return (0, p.jsxs)(p.Fragment, {
            children: [
              (0, p.jsx)(
                _.aj,
                { backFn: s ? () => l(!1) : e, onClose: t },
                "header"
              ),
              !s &&
                (0, p.jsx)(tr, {
                  children: (0, p.jsxs)(ny, {
                    children: [(0, p.jsx)(tx, {}), (0, p.jsx)(n5, {})],
                  }),
                }),
              (0, p.jsx)(ta, {
                children: "Enable your passkeys for verification",
              }),
              (0, p.jsxs)(ts, {
                children: [
                  a
                    .slice(0, c)
                    .map((e) =>
                      (0, p.jsxs)(
                        n8,
                        {
                          children: [
                            (0, p.jsx)(re, { children: rn(e) }),
                            (0, p.jsxs)(rt, {
                              children: [
                                "Last used: ",
                                e.latestVerifiedAt?.toLocaleString(),
                              ],
                            }),
                          ],
                        },
                        e.credentialId
                      )
                    ),
                  !s &&
                    a.length > 3 &&
                    (0, p.jsx)(rr, {
                      onClick: () => l(!0),
                      children: "View All",
                    }),
                ],
              }),
              (0, p.jsx)(_.am, {
                style: { marginTop: "1.5rem" },
                onClick: r,
                loading: i,
                children: "Enable passkeys",
              }),
              a.length < 5 &&
                (0, p.jsx)(rr, {
                  style: { marginTop: "0.5rem" },
                  onClick: n,
                  disabled: o,
                  children: o
                    ? (0, p.jsx)(_.au, {
                        style: {
                          height: "1rem",
                          width: "1rem",
                          borderWidth: 2,
                        },
                      })
                    : "Add new passkey",
                }),
              (0, p.jsx)(_.ae, {}),
            ],
          });
        },
        n8 = F.zo.div.withConfig({
          displayName: "PasskeyItem",
          componentId: "sc-23451ce2-0",
        })([
          "&&{padding:0.75rem 1rem;text-align:left;border-radius:0.5rem;border:1px solid var(--privy-color-foreground-4);width:100%;}",
        ]),
        re = F.zo.div.withConfig({
          displayName: "PasskeyItemTitle",
          componentId: "sc-23451ce2-1",
        })([
          "font-size:0.875rem;line-height:1.375rem;font-weight:500;color:var(--privy-color-foreground-1);",
        ]),
        rt = F.zo.div.withConfig({
          displayName: "PasskeyItemSubtitle",
          componentId: "sc-23451ce2-2",
        })([
          "font-size:0.75rem;font-weight:400;line-height:1.125rem;color:var(--privy-color-foreground-2);",
        ]),
        rn = (e) =>
          e.authenticatorName
            ? e.createdWithBrowser
              ? `${e.authenticatorName} on ${e.createdWithBrowser}`
              : e.authenticatorName
            : e.createdWithBrowser
            ? e.createdWithOs
              ? `${e.createdWithBrowser} on ${e.createdWithOs}`
              : `${e.createdWithBrowser}`
            : "Unknown device",
        rr = F.zo.button.withConfig({
          displayName: "StyledLink",
          componentId: "sc-23451ce2-3",
        })([
          "&&{width:100%;font-size:0.875rem;line-height:1rem;@media (min-width:440px){font-size:14px;}display:flex;gap:12px;justify-content:center;padding:0.75rem 1rem;background-color:var(--privy-color-background);transition:background-color 200ms ease;color:var(--privy-color-accent);:focus{outline:none;box-shadow:none;}}",
        ]),
        ra = ({ appName: e, onComplete: t, onReset: n, onClose: r }) => {
          let [a, i] = (0, w.useState)(""),
            [o, s] = (0, w.useState)(!1),
            [l, c] = (0, w.useState)(null),
            [d, u] = (0, w.useState)("enroll"),
            { initEnrollmentWithSms: h, submitEnrollmentWithSms: m } = nX(),
            { data: y } = (0, _.as)(),
            g = (0, _.an)();
          function f() {
            y?.mfaEnrollmentFlow?.onSuccess(), t();
          }
          return l
            ? (0, p.jsx)(_.b5, {
                allowlistConfig: g.allowlistConfig,
                error: l,
                onBack: () => c(null),
                onRetry: () => c(null),
              })
            : (0, p.jsxs)(
                p.Fragment,
                "enroll" === d
                  ? {
                      children: [
                        (0, p.jsx)(_.aj, { backFn: n, onClose: r }, "header"),
                        (0, p.jsx)(tv, {
                          style: { marginBottom: "1.5rem" },
                          children: (0, p.jsx)(B.Z, {}),
                        }),
                        (0, p.jsx)(ta, { children: "Set up SMS verification" }),
                        (0, p.jsxs)(ti, {
                          children: [
                            "We'll text a verification code to this mobile device whenever you use your ",
                            e,
                            " ",
                            "wallet.",
                          ],
                        }),
                        (0, p.jsxs)(to, {
                          children: [
                            (0, p.jsx)(_.b0, {
                              onSubmit: async function ({
                                qualifiedPhoneNumber: e,
                              }) {
                                try {
                                  await h({ phoneNumber: e }),
                                    i(e),
                                    u("verify");
                                } catch (e) {
                                  c(e);
                                }
                              },
                              hideRecent: !0,
                            }),
                            (0, p.jsxs)(tg, {
                              children: [
                                "By providing your mobile number, you agree to receive text messages from ",
                                g?.name,
                                ". Some carrier charges may apply",
                              ],
                            }),
                          ],
                        }),
                        (0, p.jsx)(_.ae, {}),
                      ],
                    }
                  : o
                  ? {
                      children: [
                        (0, p.jsx)(_.aj, { onClose: f }, "header"),
                        (0, p.jsx)(tv, {
                          style: { marginBottom: "1.5rem" },
                          children: (0, p.jsx)(em.Z, {}),
                        }),
                        (0, p.jsx)(ta, { children: "SMS verification added" }),
                        (0, p.jsxs)(ti, {
                          children: [
                            "From now on, you'll enter the verification code sent to your mobile device whenever you use your ",
                            e,
                            " wallet.",
                          ],
                        }),
                        (0, p.jsx)(td, {
                          children: (0, p.jsx)(_.am, {
                            onClick: f,
                            children: "Done",
                          }),
                        }),
                        (0, p.jsx)(_.ae, {}),
                      ],
                    }
                  : {
                      children: [
                        (0, p.jsx)(
                          _.aj,
                          {
                            backFn: function () {
                              "verify" === d ? u("enroll") : n();
                            },
                            onClose: r,
                          },
                          "header"
                        ),
                        (0, p.jsx)(tv, {
                          style: { marginBottom: "1.5rem" },
                          children: (0, p.jsx)(B.Z, {}),
                        }),
                        (0, p.jsx)(ta, { children: "Enter enrollment code" }),
                        (0, p.jsxs)(to, {
                          children: [
                            (0, p.jsx)(tj, {
                              onChange: async function (e) {
                                try {
                                  if (!e) return;
                                  await m({ phoneNumber: a, mfaCode: e }),
                                    s(!0);
                                } catch (e) {
                                  if ((0, _.b6)(e))
                                    throw Error(
                                      "You have exceeded the maximum number of attempts. Please close this window and try again in 10 seconds."
                                    );
                                  if ((0, _.aq)(e))
                                    throw Error(
                                      "The code you entered is not valid"
                                    );
                                  if ((0, _.ar)(e))
                                    throw Error(
                                      "You have exceeded the time limit for code entry. Please try again in 30 seconds."
                                    );
                                  throw (0, _.b7)(e)
                                    ? Error("Verification canceled")
                                    : Error("Unknown error");
                                }
                              },
                            }),
                            (0, p.jsxs)(ti, {
                              children: [
                                "To continue, enter the 6-digit code sent to ",
                                (0, p.jsx)("strong", {
                                  children: (0, A.eW)(a),
                                }),
                              ],
                            }),
                          ],
                        }),
                        (0, p.jsx)(_.ae, {}),
                      ],
                    }
              );
        },
        ri = ({ size: e, authUrl: t }) =>
          (0, p.jsx)(_.aY, {
            url: t,
            squareLogoElement: ew.Z,
            size: e,
            fgColor: "#1F1F1F",
          }),
        ro = ({
          onClose: e,
          onReset: t,
          totpInfo: n,
          submitEnrollmentWithTotp: r,
          error: a,
        }) => {
          let [i, o] = (0, w.useState)("enroll");
          return (0, p.jsxs)(
            p.Fragment,
            "enroll" === i
              ? {
                  children: [
                    (0, p.jsx)(_.aj, { backFn: t, onClose: e }, "header"),
                    (0, p.jsx)(_.b8, { children: "Scan QR code" }),
                    (0, p.jsx)(_.b9, {
                      children:
                        "Open your authenticator app and scan this code to continue",
                    }),
                    (0, p.jsx)(_.ba, {
                      children: (0, p.jsx)(ri, {
                        authUrl: n.authUrl,
                        size: 240,
                      }),
                    }),
                    (0, p.jsx)(_.bb, {
                      style: { textAlign: "left" },
                      children: "Setup key",
                    }),
                    (0, p.jsxs)(_.bc, {
                      style: { marginTop: "0.25rem" },
                      children: [
                        (0, p.jsx)(D.C, { children: "•".repeat(16) }),
                        (0, p.jsx)(_.aZ, { itemName: " ", text: n.secret }),
                      ],
                    }),
                    (0, p.jsx)(_.am, {
                      style: { marginTop: "1rem" },
                      onClick: function () {
                        o("verify");
                      },
                      children: "Continue",
                    }),
                    (0, p.jsx)(_.ae, {}),
                  ],
                }
              : {
                  children: [
                    (0, p.jsx)(
                      _.aj,
                      {
                        backFn: function () {
                          "verify" === i ? o("enroll") : t();
                        },
                        onClose: e,
                      },
                      "header"
                    ),
                    (0, p.jsx)(tv, {
                      style: { marginBottom: "1.5rem" },
                      children: (0, p.jsx)(z.Z, {}),
                    }),
                    (0, p.jsx)(_.b8, { children: "Enter enrollment code" }),
                    (0, p.jsx)(_.b9, {
                      children:
                        "To continue, enter the 6-digit code generated from your authenticator app",
                    }),
                    (0, p.jsx)(to, {
                      children: (0, p.jsx)(tj, {
                        onChange: async function (e) {
                          try {
                            if (!e) return;
                            await r({ mfaCode: e });
                          } catch (e) {
                            if ((0, _.b6)(e))
                              throw Error(
                                "You have exceeded the maximum number of attempts. Please close this window and try again in 10 seconds."
                              );
                            if ((0, _.aq)(e))
                              throw Error("The code you entered is not valid");
                            if ((0, _.ar)(e))
                              throw Error(
                                "You have exceeded the time limit for code entry. Please try again in 30 seconds."
                              );
                            throw (0, _.b7)(e)
                              ? Error("Verification canceled")
                              : Error("Unknown error");
                          }
                        },
                        errorReasonOverride: a?.message,
                      }),
                    }),
                    (0, p.jsx)(_.ae, {}),
                  ],
                }
          );
        },
        rs = {
          component: () => {
            let { user: e, enrollInMfa: t, ready: n } = (0, P.u)(),
              [r, a] = (0, w.useState)(null),
              {
                unenrollWithSms: i,
                unenrollWithTotp: o,
                unenrollWithPasskey: s,
                submitEnrollmentWithTotp: l,
                initEnrollmentWithPasskey: c,
                submitEnrollmentWithPasskey: d,
                initEnrollmentWithTotp: u,
              } = nX(),
              { data: h, onUserCloseViaDialogOrKeybindRef: m } = (0, _.as)(),
              y = (0, _.an)(),
              { closePrivyModal: g } = (0, L.u)(),
              { promptMfa: f } = tM(),
              [v, C] = (0, w.useState)(!1),
              [b, k] = (0, w.useState)(null),
              [A, x] = (0, w.useState)(null),
              T = () => {
                g({ shouldCallAuthOnSuccess: !0 }),
                  t(!1),
                  setTimeout(() => {
                    a(null), k(null);
                  }, 500);
              },
              [E, I] = (0, w.useState)(!1),
              [S, j] = (0, w.useState)();
            m.current = T;
            let U = e?.mfaMethods.includes("sms"),
              W = !!e?.phone,
              N = e?.mfaMethods.includes("totp"),
              O = e?.mfaMethods.includes("passkey"),
              R = U || N || O,
              M =
                e?.linkedAccounts
                  .filter((e) => "passkey" === e.type)
                  .map((e) => e.credentialId) ?? [];
            function F() {
              a(null), k(null);
            }
            async function D(e = M) {
              I(!0);
              try {
                return (
                  await c(),
                  await d(
                    { credentialIds: e },
                    {
                      removeForLogin:
                        h?.mfaEnrollmentFlow?.shouldUnlinkOnUnenrollMfa,
                    }
                  ),
                  h?.mfaEnrollmentFlow?.onSuccess(),
                  T()
                );
              } catch (e) {
                j(e);
              } finally {
                I(!1);
              }
            }
            if (
              ((0, w.useEffect)(() => {
                R && C(!0);
              }, [R]),
              !n || !e || !y)
            )
              return (0, p.jsxs)(p.Fragment, {
                children: [
                  (0, p.jsx)(_.aj, { onClose: T }, "header"),
                  (0, p.jsx)(tr, { children: (0, p.jsx)(n0, {}) }),
                  (0, p.jsx)(to, { children: (0, p.jsx)(_.au, {}) }),
                  (0, p.jsx)(_.ae, {}),
                ],
              });
            if ("sms" === r)
              return (0, p.jsxs)(p.Fragment, {
                children: [
                  (0, p.jsx)(_.aj, { backFn: F, onClose: T }, "header"),
                  (0, p.jsx)(tv, {
                    style: { marginBottom: "1.5rem" },
                    children: (0, p.jsx)(es.Z, {}),
                  }),
                  (0, p.jsx)(ta, { children: "Remove SMS verification?" }),
                  (0, p.jsxs)(ti, {
                    children: [
                      "MFA adds an extra layer of security to your ",
                      y?.name,
                      " account. Make sure you have other methods to secure your account.",
                    ],
                  }),
                  (0, p.jsx)(td, {
                    children: (0, p.jsx)(_.am, {
                      $warn: !0,
                      onClick: async function () {
                        a(null);
                        try {
                          await i();
                        } catch (e) {
                          a(null);
                        }
                      },
                      children: "Remove",
                    }),
                  }),
                  (0, p.jsx)(_.ae, {}),
                ],
              });
            if ("totp" === r)
              return (0, p.jsxs)(p.Fragment, {
                children: [
                  (0, p.jsx)(_.aj, { backFn: F, onClose: T }, "header"),
                  (0, p.jsx)(tv, {
                    style: { marginBottom: "1.5rem" },
                    children: (0, p.jsx)(es.Z, {}),
                  }),
                  (0, p.jsx)(ta, {
                    children: "Remove authenticator app verification?",
                  }),
                  (0, p.jsxs)(ti, {
                    children: [
                      "MFA adds an extra layer of security to your ",
                      y?.name,
                      " account. Make sure you have other methods to secure your account.",
                    ],
                  }),
                  (0, p.jsx)(td, {
                    children: (0, p.jsx)(_.am, {
                      $warn: !0,
                      onClick: async function () {
                        a(null);
                        try {
                          await o();
                        } catch (e) {
                          a(null);
                        }
                      },
                      children: "Remove",
                    }),
                  }),
                  (0, p.jsx)(_.ae, {}),
                ],
              });
            if ("passkey" === r) {
              let e = h?.mfaEnrollmentFlow?.shouldUnlinkOnUnenrollMfa ?? !0;
              return (0, p.jsxs)(p.Fragment, {
                children: [
                  (0, p.jsx)(_.aj, { backFn: F, onClose: T }, "header"),
                  (0, p.jsx)(tv, {
                    style: { marginBottom: "1.5rem" },
                    children: (0, p.jsx)(es.Z, {}),
                  }),
                  (0, p.jsx)(ta, {
                    children: "Are you sure you want to remove this passkey?",
                  }),
                  (0, p.jsx)(ti, {
                    children: e
                      ? "Removing your passkey will remove as both a verification method and a login method."
                      : "Removing your passkey will remove as a verification method.",
                  }),
                  (0, p.jsx)(td, {
                    children: (0, p.jsx)(_.am, {
                      $warn: !0,
                      onClick: async function () {
                        a(null);
                        try {
                          await s({
                            removeForLogin:
                              h?.mfaEnrollmentFlow?.shouldUnlinkOnUnenrollMfa,
                          });
                        } catch (e) {
                          a(null);
                        }
                      },
                      children: "Remove",
                    }),
                  }),
                  (0, p.jsx)(_.ae, {}),
                ],
              });
            }
            if (0 === h.mfaEnrollmentFlow.mfaMethods.length && !R)
              return (0, p.jsxs)(p.Fragment, {
                children: [
                  (0, p.jsx)(_.aj, { onClose: T }, "header"),
                  (0, p.jsx)(tv, {
                    style: { marginBottom: "1.5rem" },
                    children: (0, p.jsx)(V.Z, {}),
                  }),
                  (0, p.jsx)(ta, { children: "Add more security" }),
                  (0, p.jsxs)(ti, {
                    children: [
                      y?.name,
                      " does not have any verification methods enabled.",
                    ],
                  }),
                  (0, p.jsx)(td, {
                    children: (0, p.jsx)(_.am, {
                      onClick: T,
                      children: "Close",
                    }),
                  }),
                  (0, p.jsx)(_.ae, {}),
                ],
              });
            let z = !R && !v;
            return z
              ? (0, p.jsxs)(p.Fragment, {
                  children: [
                    (0, p.jsx)(_.aj, { onClose: T }, "header"),
                    (0, p.jsx)(tv, {
                      style: { marginBottom: "1.5rem" },
                      children: (0, p.jsx)(V.Z, {}),
                    }),
                    (0, p.jsx)(ta, { children: "Transaction Protection" }),
                    (0, p.jsx)(ti, {
                      children:
                        "Set up transaction protection to add an extra layer of security to your account",
                    }),
                    (0, p.jsxs)(ts, {
                      children: [
                        (0, p.jsxs)(tc, {
                          children: [
                            (0, p.jsx)(tl, { children: (0, p.jsx)(el.Z, {}) }),
                            "Enable 2-Step verification for your ",
                            y?.name,
                            " wallet.",
                          ],
                        }),
                        (0, p.jsxs)(tc, {
                          children: [
                            (0, p.jsx)(tl, { children: (0, p.jsx)(ec.Z, {}) }),
                            "You'll be prompted to authenticate to complete transactions.",
                          ],
                        }),
                      ],
                    }),
                    (0, p.jsxs)(td, {
                      children: [
                        (0, p.jsx)(_.am, {
                          onClick: () => C(!0),
                          children: "Continue",
                        }),
                        (0, p.jsx)(_.ao, { onClick: T, children: "Not now" }),
                      ],
                    }),
                    (0, p.jsx)(_.ae, {}),
                  ],
                })
              : "sms" === b
              ? (0, p.jsx)(ra, {
                  appName: y?.name || "Privy",
                  onComplete: T,
                  onReset: F,
                  onClose: T,
                })
              : "totp" === b && A
              ? (0, p.jsx)(ro, {
                  onClose: T,
                  onReset: F,
                  submitEnrollmentWithTotp: ({ mfaCode: e }) =>
                    (async function (e) {
                      try {
                        return (
                          j(void 0),
                          await l({ mfaCode: e }),
                          h?.mfaEnrollmentFlow?.onSuccess(),
                          T()
                        );
                      } catch (e) {
                        j(e);
                      } finally {
                        a(null);
                      }
                    })(e),
                  totpInfo: { ...A, appName: y?.name || "Privy" },
                })
              : "passkey" === b
              ? (0, p.jsx)(n6, {
                  onReset: F,
                  onClose: T,
                  submitEnrollmentWithPasskey: D,
                })
              : (0, p.jsx)(n2, {
                  showIntro: z,
                  userMfaMethods: e.mfaMethods,
                  appMfaMethods: y.mfa.methods,
                  userHasAuthSms: W,
                  onBackToIntro: function () {
                    C(!1);
                  },
                  handleSelectMethod: async function (e) {
                    try {
                      await f();
                    } catch (e) {
                      return void j(e);
                    }
                    return "totp" === e
                      ? (k(e),
                        x(null),
                        void u()
                          .then((e) => {
                            x(e);
                          })
                          .catch(() => {
                            x(null), F();
                          }))
                      : "passkey" === e && 1 === M.length
                      ? await D()
                      : void k(e);
                  },
                  isTotpLoading: "totp" === b && !A,
                  isPasskeyLoading: E,
                  error: S,
                  onClose: T,
                  setRemovingMfaMethod: async (e) => {
                    try {
                      await f();
                    } catch (e) {
                      return void j(e);
                    }
                    a(e);
                  },
                });
          },
        },
        rl = ({
          providerName: e,
          ProviderLogo: t,
          success: n,
          errorMessage: r,
          onRetry: a,
        }) => {
          let i = n
            ? `Successfully connected with ${e}`
            : r
            ? r.message
            : `Verifying connection to ${e}`;
          return (0, p.jsx)(_.ab, {
            title: i,
            subtitle: n
              ? "You're good to go!"
              : r
              ? r.detail
              : "Just a few moments more",
            icon: t,
            iconVariant: "loading",
            iconLoadingStatus: { success: n, fail: !!r },
            secondaryCta:
              r?.retryable && a ? { label: "Retry", onClick: a } : void 0,
            watermark: !0,
          });
        },
        rc = {
          component: () => {
            let { authenticated: e, logout: t, ready: n, user: r } = (0, P.u)(),
              {
                setModalData: a,
                navigate: i,
                resetNavigation: o,
              } = (0, _.as)(),
              s = (0, _.an)(),
              {
                getAuthMeta: l,
                initLoginWithOAuth: c,
                loginWithOAuth: d,
                updateWallets: u,
                setReadyToTrue: h,
                closePrivyModal: m,
                createAnalyticsEvent: y,
              } = (0, L.u)(),
              [g, f] = (0, w.useState)(!1),
              [v, C] = (0, w.useState)(void 0),
              b = l()?.provider || "google",
              { name: k, component: A } = eS(b, s.customOAuthProviders);
            return (
              (0, w.useEffect)(() => {
                d(b)
                  .then(() => {
                    f(!0), h(!0);
                  })
                  .catch((e) => {
                    if ((h(!1), e?.privyErrorCode === T.h.ALLOWLIST_REJECTED))
                      return C(void 0), o(), void i(_.bd);
                    if (e?.privyErrorCode === T.h.USER_LIMIT_REACHED)
                      return (
                        console.error(new T.ab(e).toString()),
                        C(void 0),
                        o(),
                        void i(_.be)
                      );
                    if (e?.privyErrorCode === T.h.USER_DOES_NOT_EXIST)
                      return C(void 0), o(), void i(_.bf);
                    if (
                      e?.privyErrorCode === T.h.ACCOUNT_TRANSFER_REQUIRED &&
                      e.data?.data?.nonce
                    )
                      return (
                        C(void 0),
                        o(),
                        a({
                          accountTransfer: {
                            nonce: e.data?.data?.nonce,
                            account: e.data?.data?.subject,
                            displayName: e.data?.data?.account?.displayName,
                            linkMethod: l()?.provider,
                            embeddedWalletAddress:
                              e.data?.data?.otherUser?.embeddedWalletAddress,
                            oAuthUserInfo:
                              e.data?.data?.otherUser?.oAuthUserInfo,
                          },
                        }),
                        void i(_.aT)
                      );
                    let { retryable: t, detail: n } = (function (e, t, n) {
                      let r = { detail: "", retryable: !1 },
                        a = (0, _.j)(t);
                      if (
                        (e?.privyErrorCode === T.h.LINKED_TO_ANOTHER_USER &&
                          (r.detail =
                            "This account has already been linked to another user."),
                        e?.privyErrorCode === T.h.INVALID_CREDENTIALS &&
                          ((r.retryable = !0),
                          (r.detail = "Something went wrong. Try again.")),
                        e.privyErrorCode === T.h.OAUTH_USER_DENIED &&
                          ((r.detail = `Retry and check ${a} to finish connecting your account.`),
                          (r.retryable = !0)),
                        e?.privyErrorCode === T.h.TOO_MANY_REQUESTS &&
                          (r.detail =
                            "Too many requests. Please wait before trying again."),
                        e?.privyErrorCode === T.h.TOO_MANY_REQUESTS &&
                          e.message.includes("provider rate limit"))
                      ) {
                        let e = eS(t, n).name;
                        r.detail = `Request limit reached for ${e}. Please wait a moment and try again.`;
                      }
                      if (e?.privyErrorCode === T.h.OAUTH_ACCOUNT_SUSPENDED) {
                        let e = eS(t, n).name;
                        r.detail = `Your ${e} account is suspended. Please try another login method.`;
                      }
                      return (
                        e?.privyErrorCode === T.h.CANNOT_LINK_MORE_OF_TYPE &&
                          (r.detail =
                            "You cannot authorize more than one account for this user."),
                        e?.privyErrorCode === T.h.OAUTH_UNEXPECTED &&
                          t.startsWith("privy:") &&
                          (r.detail =
                            "Something went wrong. Please try again."),
                        r
                      );
                    })(e, b, s.customOAuthProviders);
                    C({
                      retryable: t,
                      detail: n,
                      message: "Authentication failed",
                    });
                  })
                  .finally(() => {
                    (0, _.bg)();
                  });
              }, [k, b]),
              (0, w.useEffect)(() => {
                if (n && e && g && r) {
                  if (s?.legal.requireUsersAcceptTerms && !r.hasAcceptedTerms) {
                    let e = setTimeout(() => {
                      i(_.aP);
                    }, _.aQ);
                    return () => clearTimeout(e);
                  }
                  if ((0, _.aR)(r, s.embeddedWallets)) {
                    let e = setTimeout(() => {
                      a({
                        createWallet: {
                          onSuccess: () => {},
                          onFailure: (e) => {
                            console.error(e),
                              y({
                                eventName:
                                  "embedded_wallet_creation_failure_logout",
                                payload: {
                                  error: e,
                                  provider: b,
                                  screen: "OAuthStatusScreen",
                                },
                              }),
                              t();
                          },
                          callAuthOnSuccessOnClose: !0,
                        },
                      }),
                        i(_.aS);
                    }, _.aQ);
                    return () => clearTimeout(e);
                  }
                  {
                    let e = setTimeout(
                      () => m({ shouldCallAuthOnSuccess: !0, isSuccess: !0 }),
                      _.aQ
                    );
                    return u(), () => clearTimeout(e);
                  }
                }
              }, [n, e, g, r]),
              (0, p.jsx)(rl, {
                providerName: k,
                ProviderLogo: A,
                success: g,
                errorMessage: v,
                onRetry: v?.retryable
                  ? () => {
                      (0, _.bg)(), c(b), C(void 0);
                    }
                  : void 0,
              })
            );
          },
        },
        rd = (0, w.forwardRef)((e, t) => {
          let [n, r] = (0, w.useState)(""),
            [a, i] = (0, w.useState)(""),
            [o, s] = (0, w.useState)(!1),
            { authenticated: l, user: c } = (0, P.u)(),
            { initUpdateEmail: d } = (0, L.u)(),
            { navigate: u, setModalData: h, currentScreen: m } = (0, _.as)(),
            { enabled: y, token: g } = (0, _.a9)(),
            f = (0, _.an)(),
            v =
              (0, _.bh)(n) &&
              (f.disablePlusEmails && n.includes("+")
                ? (a || i("Please enter a valid email address without a '+'."),
                  !1)
                : (a && i(""), !0)),
            C = o || !v,
            b = () => {
              !y || g || l
                ? (async (e) => {
                    if (!c?.email)
                      throw Error(
                        "User is required to have an email address to update it."
                      );
                    s(!0);
                    try {
                      await d({
                        oldAddress: c.email.address,
                        newAddress: n,
                        captchaToken: e,
                      }),
                        u(_.b1);
                    } catch (e) {
                      h({
                        errorModalData: { error: e, previousScreen: m || _.b3 },
                      });
                    }
                    s(!1);
                  })(g)
                : (h({
                    captchaModalData: {
                      callback: (e) => {
                        if (!c?.email)
                          throw Error(
                            "User is required to have an email address to update it."
                          );
                        return d({
                          oldAddress: c.email.address,
                          newAddress: n,
                          captchaToken: e,
                        });
                      },
                      userIntentRequired: !1,
                      onSuccessNavigateTo: _.b1,
                      onErrorNavigateTo: _.b2,
                    },
                  }),
                  u(_.bm));
            };
          return (0, p.jsxs)(p.Fragment, {
            children: [
              (0, p.jsxs)(ru, {
                children: [
                  a &&
                    (0, p.jsx)(_.bi, {
                      style: { marginTop: "0.25rem", textAlign: "left" },
                      children: a,
                    }),
                  (0, p.jsxs)(rh, {
                    $error: !!a,
                    children: [
                      (0, p.jsx)(_.ad, { children: (0, p.jsx)(ei.Z, {}) }),
                      (0, p.jsx)("input", {
                        ref: t,
                        id: "email-input",
                        type: "email",
                        placeholder: "your@email.com",
                        onChange: (e) => r(e.target.value),
                        onKeyUp: (e) => {
                          "Enter" === e.key && b();
                        },
                        value: n,
                        autoComplete: "email",
                      }),
                      e.stacked
                        ? null
                        : (0, p.jsx)(_.bj, {
                            isSubmitting: o,
                            onClick: b,
                            disabled: C,
                            children: "Submit",
                          }),
                    ],
                  }),
                ],
              }),
              e.stacked
                ? (0, p.jsx)(_.am, {
                    loadingText: null,
                    loading: o,
                    disabled: C,
                    onClick: b,
                    style: { width: "100%" },
                    children: "Submit",
                  })
                : null,
            ],
          });
        }),
        ru = _.bk,
        rh = _.bl,
        rp = ({
          title: e = "Update your email",
          subtitle:
            t = "Add the email address you'd like to use going forward. We'll send you a confirmation code",
        }) =>
          (0, p.jsx)(_.ab, {
            title: e,
            subtitle: t,
            icon: eo.Z,
            watermark: !0,
            children: (0, p.jsx)(_.a_, {
              children: (0, p.jsx)(rd, { stacked: !0 }),
            }),
          }),
        rm = { component: () => (0, p.jsx)(rp, {}) },
        rw = ({
          title: e = "Update your phone number",
          subtitle:
            t = "Add the phone number you'd like to use going forward. We'll send you a confirmation code",
          onSubmit: n,
          isSubmitting: r = !1,
        }) => {
          let [a, i] = (0, w.useState)(null);
          return (0, p.jsx)(_.ab, {
            title: e,
            subtitle: t,
            icon: B.Z,
            primaryCta: {
              label: r ? "Submitting" : "Update",
              onClick: async () => {
                a?.qualifiedPhoneNumber && (await n(a));
              },
              disabled: !a?.isValid || r,
            },
            watermark: !0,
            children: (0, p.jsx)(_.b0, {
              onChange: (e) => {
                i(e);
              },
              onSubmit: async () => {},
              noIncludeSubmitButton: !0,
              hideRecent: !0,
            }),
          });
        },
        ry = {
          component: () => {
            let {
                currentScreen: e,
                data: t,
                navigate: n,
                setModalData: r,
              } = (0, _.as)(),
              { user: a } = (0, P.u)(),
              { initUpdatePhone: i } = (0, L.u)(),
              [o, s] = (0, w.useState)(!1);
            return (0, p.jsx)(rw, {
              onSubmit: async (o) => {
                s(!0);
                try {
                  if (!a?.phone?.number)
                    throw Error(
                      "User is required to have an phone number to update it."
                    );
                  await i(a?.phone?.number, o.qualifiedPhoneNumber), n(_.b1);
                } catch (a) {
                  r({
                    errorModalData: {
                      error: a,
                      previousScreen:
                        t?.errorModalData?.previousScreen || e || nG,
                    },
                  }),
                    n(_.b2);
                } finally {
                  s(!1);
                }
              },
              isSubmitting: o,
            });
          },
        },
        rg = (0, R.U)(() => ({ jwtAuthFlowState: { status: "not-enabled" } }));
      function rf({ customAuth: e }) {
        let { jwtAuthFlowState: t } = (function ({ customAuth: e }) {
          let t = (0, _.aA)(),
            n = (0, w.useRef)(),
            r = (0, w.useCallback)(
              (e) => (
                (n.current = e),
                () => {
                  n.current = void 0;
                }
              ),
              []
            ),
            a = e?.getCustomAccessToken ?? (() => Promise.resolve(void 0)),
            { state: i } = (function ({
              subscribe: e,
              getExternalJwt: t,
              enabled: n = !0,
              onAuthenticated: r,
              onUnauthenticated: a,
              onError: i,
            }) {
              let { client: o, onCustomAuthAuthenticated: s } = (0, L.u)(),
                { logout: l, authenticated: c, ready: d } = (0, G.u)();
              if (!o)
                throw new T.P(
                  "`useSyncJwtBasedAuthState` must be used within a `PrivyProvider`"
                );
              let [u, h] = (0, w.useState)({ status: "initial" }),
                p = (0, w.useRef)(),
                m = (0, w.useRef)(!1),
                y = (0, w.useRef)(t);
              (0, w.useEffect)(() => {
                y.current = t;
              }, [t]);
              let g = (0, w.useRef)(r);
              (0, w.useEffect)(() => {
                g.current = r;
              }, [r]);
              let f = (0, w.useRef)(a);
              (0, w.useEffect)(() => {
                f.current = a;
              }, [a]);
              let v = (0, w.useRef)(i);
              return (
                (0, w.useEffect)(() => {
                  v.current = i;
                }, [i]),
                (0, w.useEffect)(() => {
                  if (!n || !d) return;
                  let t = async () => {
                    if (!m.current) {
                      m.current = !0;
                      try {
                        h({ status: "loading" });
                        let e = await y.current();
                        if (void 0 !== p.current && p.current === e)
                          return void h({ status: "done" });
                        if (!e)
                          return (
                            c && (await l(), f.current?.()),
                            (p.current = e),
                            void h({ status: "done" })
                          );
                        o.startAuthFlow(new e1(e));
                        let { user: t, isNewUser: n = !1 } =
                          await o.authenticate();
                        if (!t)
                          throw new T.P(
                            "Failed to sync with custom auth provider"
                          );
                        g.current?.({ user: t, isNewUser: n }),
                          s(t, n),
                          (p.current = e),
                          h({ status: "done" });
                      } catch (e) {
                        if (
                          (console.warn(e),
                          await l().catch(() => {}),
                          f.current?.(),
                          e instanceof T.G &&
                            e.privyErrorCode === T.h.LINKED_TO_ANOTHER_USER)
                        )
                          return (
                            h({ status: "initial" }),
                            void setTimeout(() => {
                              t();
                            }, 0)
                          );
                        v.current?.(e), h({ status: "error", error: e });
                      } finally {
                        m.current = !1;
                      }
                    }
                  };
                  return t(), e(t);
                }, [e, o, s, c, l, n, d]),
                n ? { state: u } : { state: { status: "not-enabled" } }
              );
            })({
              enabled: !0 === e?.enabled,
              subscribe: r,
              getExternalJwt: a,
              onAuthenticated: ({ user: e, isNewUser: n }) => {
                t("login", "onComplete", {
                  user: e,
                  isNewUser: n,
                  wasAlreadyAuthenticated: !1,
                  loginMethod: "custom",
                  loginAccount: null,
                }),
                  t("customAuth", "onAuthenticated", { user: e });
              },
              onUnauthenticated: () => {
                t("customAuth", "onUnauthenticated");
              },
              onError: (e) => {
                t(
                  "login",
                  "onError",
                  e.privyErrorCode || T.h.UNKNOWN_AUTH_ERROR
                );
              },
            });
          return (
            (0, w.useEffect)(() => {
              (async () => {
                e && !e.isLoading && n.current?.();
              })();
            }, [e?.enabled, e?.getCustomAccessToken, e?.isLoading]),
            { jwtAuthFlowState: i }
          );
        })({ customAuth: e });
        return (
          (0, w.useEffect)(() => {
            rg.setState({ jwtAuthFlowState: t });
          }, [t]),
          null
        );
      }
      let rv = (0, w.createContext)(!1);
      async function rC() {
        return o
          ? o.getAccessToken()
          : Promise.resolve(_.s.get(_.Z) || _.s.get(_.Y) || null);
      }
      let rb = (e, t) => s(e, t),
        rk = (e, t) => l(e, t),
        rA = (e, t) => c(e, t),
        rx = (e, t) => d(e, t),
        rT = (e) => u(e),
        r_ = ({ config: e, ...t }) => {
          var n;
          if (
            ((() => {
              if ((0, w.useContext)(rv))
                throw new T.P(
                  "Multiple PrivyProvider instances found",
                  "Found multiple instances of PrivyProvider, ensure there is only one mounted in your application tree."
                );
            })(),
            "undefined" != typeof window &&
              0 >
                ["localhost", "127.0.0.1"].indexOf(window.location.hostname) &&
              "https:" !== window.location.protocol &&
              "chrome-extension:" !== window.location.protocol)
          )
            throw new T.P("Embedded wallet is only available over HTTPS");
          if ("string" != typeof (n = t.appId) || 25 !== n.length)
            throw new T.P(
              "Cannot initialize the Privy provider with an invalid Privy app ID"
            );
          o ||
            (o = new te({
              appId: t.appId,
              appClientId: t.clientId,
              apiUrl: t.apiUrl,
            }));
          let r = Object.assign({}, e),
            a = (0, w.useMemo)(
              () =>
                new x.Z({
                  appId: t.appId,
                  clientId: t.clientId,
                  storage: _.s,
                  baseUrl: t.apiUrl,
                  sdkVersion: "react-auth:3.3.0",
                }),
              []
            );
          return (0, p.jsx)(_.bn, {
            client: a,
            legacyClient: o,
            appClientId: t.clientId,
            clientConfig: r,
            children: (0, p.jsx)(_.bo, {
              children: (0, p.jsx)(rE, { ...t, client: o, privy: a }),
            }),
          });
        },
        rE = (e) => {
          let t = e.client,
            r = e.privy,
            a = (0, _.bp)();
          nr();
          let [i, o] = (0, w.useState)(!1),
            h = tL((e) => e.inProgressMfaFlow),
            [b, A] = (0, w.useState)(!1),
            [x, E] = (0, w.useState)(!1),
            [I, S] = (0, w.useState)(null),
            [j, U] = (0, w.useState)([]),
            [W, N] = (0, w.useState)(void 0),
            [O, R] = (0, w.useState)(!1),
            [M, F] = (0, w.useState)(null),
            [D, z] = (0, w.useState)(!1),
            [q, B] = (0, w.useState)({
              status: "disconnected",
              connectedWallet: null,
              connectError: null,
              connector: null,
              connectRetry: L.n,
            }),
            [V, H] = (0, w.useState)({ status: "initial" }),
            [$, Z] = (0, w.useState)({ status: "initial" }),
            [K, Y] = (0, w.useState)({ status: "initial" }),
            [J, Q] = (0, w.useState)({ status: "initial" }),
            [X, ee] = (0, w.useState)({ status: "initial" }),
            [et, en] = (0, w.useState)({ status: "initial" }),
            [er, ea] = (0, w.useState)(null),
            ei = (0, _.an)(),
            eo = (0, _.az)(),
            [es, el] = (0, w.useState)({}),
            [ec, ed] = (0, w.useState)(null),
            eu = (0, w.useRef)(null),
            [eh, ep] = (0, w.useState)(!1),
            [em, ew] = (0, w.useState)(!1),
            ey = (0, w.useRef)(null),
            eg = (0, w.useRef)(null),
            eb = (0, w.useRef)(_.bq),
            [ek, e_] = (0, w.useState)(!1);
          (t.onStoreCustomerAccessToken = (e) => {
            e &&
              (0, _.br)(eb, "accessToken", "onAccessTokenGranted", {
                accessToken: e,
              });
          }),
            (t.onDeleteCustomerAccessToken = () => {
              S(null),
                E(!1),
                (0, _.br)(eb, "accessToken", "onAccessTokenRemoved");
            });
          let eE = (0, w.useRef)(null),
            eI = (0, w.useRef)(null),
            eS = (0, w.useRef)(!1),
            eW = ({ showWalletUIs: e }) =>
              eS.current
                ? eS.current
                : void 0 !== e
                ? !e
                : !ei.embeddedWallets.showWalletUIs,
            eN = (e) => {
              F(e),
                setTimeout(() => {
                  o(!0);
                }, 15);
            };
          (0, w.useEffect)(() => {
            if (!I) return void t.connectors?.removeEmbeddedWalletConnectors();
            let n = (0, P.b)(I),
              a = (0, P.d)(I),
              i = (0, P.e)(I);
            (n && a.length) || t.connectors?.removeEmbeddedWalletConnectors(),
              i.length || t.connectors?.removeImportedWalletConnectors(),
              t.connectors
                ? er
                  ? (n &&
                      t.connectors.addEmbeddedWalletConnectors({
                        walletProxy: er,
                        user: I,
                        embeddedWallets: a,
                        defaultChain: ei.defaultChain,
                        appId: e.appId,
                        privyClient: r,
                      }),
                    i.forEach((n) =>
                      t.connectors?.addImportedWalletConnector(
                        er,
                        n.address,
                        ei.defaultChain,
                        e.appId
                      )
                    ))
                  : console.debug(
                      "Failed to add embedded wallet connector: Wallet proxy not initialized"
                    )
                : console.debug(
                    "Failed to add embedded wallet connector: Client connectors not initialized"
                  );
          }, [er, I]),
            (0, w.useEffect)(() => {
              er && eu.current?.(er);
            }, [er]);
          let eO = (0, w.useCallback)((e, t) => {
            S(e), R(t), E(!0), ew(!0);
          }, []);
          (0, w.useEffect)(() => {
            em &&
              er &&
              I &&
              (async () => {
                let e = (0, _.bs)(I, ei.embeddedWallets.ethereum.createOnLogin),
                  t = (0, _.bt)(I, ei.embeddedWallets.solana.createOnLogin),
                  n = await rC();
                if (n) {
                  if (e && t) {
                    let e = await er.create({ accessToken: n });
                    return (
                      await er.createSolana({
                        accessToken: n,
                        ethereumAddress: e?.address,
                      }),
                      void ew(!1)
                    );
                  }
                  if (t)
                    return (
                      await er.createSolana({
                        accessToken: n,
                        ethereumAddress: P.b(I)?.address,
                      }),
                      await eX.refreshSessionAndUser(),
                      void ew(!1)
                    );
                  if (e)
                    return await er.create({ accessToken: n }), void ew(!1);
                }
              })().catch(console.error);
          }, [em && er && I]),
            (0, w.useEffect)(() => {
              if (ei.externalWallets.solana.connectors)
                return (
                  ei.externalWallets.solana.connectors.onMount(),
                  () => ei.externalWallets.solana.connectors?.onUnmount()
                );
            }, [ei.externalWallets.solana.connectors]),
            (0, w.useEffect)(() => {
              !b &&
                eo &&
                (async function () {
                  let e,
                    n = eR(),
                    r = eM(),
                    a = (0, m.M)();
                  t.initializeConnectorManager({
                    walletConnectCloudProjectId: ei.walletConnectCloudProjectId,
                    rpcConfig: ei.rpcConfig,
                    chains: ei.chains,
                    defaultChain: ei.defaultChain,
                    store: a,
                    walletList: ei.appearance.walletList,
                    shouldEnforceDefaultChainOnConnect:
                      ei.shouldEnforceDefaultChainOnConnect,
                    externalWalletConfig: ei.externalWallets,
                    appName: ei.name ?? "Privy",
                    walletChainType: ei.appearance.walletChainType,
                    setBaseAccountSdk: N,
                  }),
                    t.connectors?.on("connectorInitialized", () => {
                      e && clearTimeout(e);
                      let n = t.connectors.walletConnectors.length,
                        r = t.connectors.walletConnectors.reduce(
                          (e, t) => e + (t.initialized ? 1 : 0),
                          0
                        );
                      r === n
                        ? e_(!0)
                        : (e = setTimeout(() => {
                            console.debug({
                              message:
                                "Unable to initialize all expected connectors before timeout",
                              initialized: r,
                              expected: n,
                            }),
                              e_(!0);
                          }, 1500));
                    }),
                    t.connectors?.initialize().then(() => {
                      eq();
                    });
                  let i = await t.getAuthenticatedUser(),
                    o = !!i;
                  ei.legal.requireUsersAcceptTerms && i && !i.hasAcceptedTerms
                    ? (await t.logout(),
                      eX.setReadyToTrue(!0),
                      (0, _.br)(eb, "logout", "onSuccess"))
                    : (ei.customAuth?.enabled ||
                        (E(!!i),
                        i &&
                          (0, _.br)(eb, "login", "onComplete", {
                            user: i,
                            isNewUser: !1,
                            wasAlreadyAuthenticated: !0,
                            loginMethod: null,
                            loginAccount: null,
                          }),
                        S(i)),
                      n
                        ? (eI.current = o ? "link" : "login")
                        : r && !o
                        ? ((eI.current = "login"),
                          el({ telegramAuthModalData: { seamlessAuth: !0 } }),
                          eN(_.bL))
                        : eX.setReadyToTrue(!!i));
                })();
            }, [t, ec, b, eo]),
            (0, w.useEffect)(() => {
              if (b) {
                if (
                  !I ||
                  !I.linkedAccounts.find(
                    (e) => "wallet" === e.type && "privy" === e.walletClientType
                  )
                )
                  return void ep(!!er);
                if ([...j].some((e) => "privy" === e.walletClientType))
                  return void ep(!0);
                ep(!!er);
              }
            }, [b, I, j, er]),
            (0, w.useEffect)(() => {
              t.connectors?.setWalletList(ei.appearance.walletList);
            }, [ei.appearance.walletList.join()]);
          let eR = () => {
              let e = (function () {
                let e = new URLSearchParams(window.location.search),
                  t = e.get("privy_oauth_code"),
                  n = e.get("privy_oauth_state"),
                  r = e.get("privy_oauth_provider");
                if (!t || !n || !r) return { inProgress: !1 };
                let a = !1;
                try {
                  a = !!window.opener.location.origin;
                } catch {}
                return {
                  inProgress: !0,
                  authorizationCode: t,
                  stateCode: n,
                  provider: r,
                  withPrivyUi: !_.s.get(_.H),
                  popupFlow: null !== window.opener && a,
                  disableSignup: !!_.s.get(_.O),
                };
              })();
              return e.inProgress && e.popupFlow
                ? window.opener.location.origin !== window.location.origin
                  ? void window.opener.postMessage({
                      type: "PRIVY_OAUTH_ERROR",
                      error:
                        "Origins between parent and child windows do not match.",
                    })
                  : "error" === e.authorizationCode
                  ? void window.opener.postMessage({
                      type: "PRIVY_OAUTH_ERROR",
                      error: "Something went wrong. Try again.",
                    })
                  : void window.opener.postMessage({
                      type: "PRIVY_OAUTH_RESPONSE",
                      stateCode: e.stateCode,
                      authorizationCode: e.authorizationCode,
                    })
                : (e.inProgress &&
                    e.provider.startsWith("privy:") &&
                    !e.popupFlow &&
                    (new BroadcastChannel(na).postMessage({
                      type: "PRIVY_OAUTH_RESPONSE",
                      stateCode: e.stateCode,
                      authorizationCode: e.authorizationCode,
                    }),
                    window.close()),
                  !!e.inProgress &&
                    !!e.withPrivyUi &&
                    (t.startAuthFlow(
                      new eT({
                        ...e,
                        customOAuthRedirectUrl: ei.customOAuthRedirectUrl,
                      })
                    ),
                    eN(rc),
                    !0));
            },
            eM = () => {
              let e = (0, _.bM)();
              if (
                !e ||
                !ei.loginMethods.telegram ||
                !ei.loginConfig.telegramAuthConfiguration?.seamlessAuthEnabled
              )
                return;
              let n = new _.bu();
              return (
                t.startAuthFlow(n),
                "login-url" === e.flowType &&
                  ((n.meta.telegramWebAppData = void 0),
                  (n.meta.telegramAuthResult = e.authData)),
                "web-app" === e.flowType &&
                  ((n.meta.telegramAuthResult = void 0),
                  (n.meta.telegramWebAppData = e.authData)),
                !0
              );
            },
            eF = async (e, n, r, a) => {
              if ("solana_adapter" !== e)
                eL(
                  (await t.connectors?.createEthereumWalletConnector({
                    connectorType: e,
                    walletClientType: n,
                  })) || null,
                  n,
                  r,
                  a
                );
              else {
                let e = t.connectors?.findSolanaWalletConnector(n);
                if (!e) return;
                eL(e, n, r, a);
              }
            };
          async function eL(e, t, n, r) {
            if (!e)
              return (
                B({
                  status: "disconnected",
                  connectedWallet: null,
                  connectError: new T.x("Unable to connect to wallet."),
                  connector: null,
                  connectRetry: L.n,
                }),
                r?.(null, n)
              );
            B({
              status: "disconnected",
              connectedWallet: null,
              connectError: null,
              connector: e,
              connectRetry: L.n,
            }),
              e instanceof _.W && t && (await e.resetConnection(t)),
              B({
                connector: e,
                status: "connecting",
                connectedWallet: null,
                connectError: null,
                connectRetry: () => eL(e, t, n, r),
              });
            try {
              let t = await e.connect({ showPrompt: !0 });
              if (
                (!t || (0, _.bB)(t)) &&
                ei.shouldEnforceDefaultChainOnConnect &&
                !ei.chains.find(
                  (e) => e.id === Number(t?.chainId.replace("eip155:", ""))
                ) &&
                ("wallet_connect_v2" !== t?.connectorType ||
                  "metamask" !== t?.walletClientType)
              ) {
                B((t) => ({
                  ...t,
                  connector: e,
                  status: "switching_to_supported_chain",
                  connectedWallet: null,
                  connectError: null,
                  connectRetry: L.n,
                }));
                try {
                  await t?.switchChain(ei.defaultChain.id),
                    t && (t.chainId = (0, _.bN)((0, g.NC)(ei.defaultChain.id)));
                } catch {
                  console.warn(
                    `Unable to switch to default chain: ${ei.defaultChain.id}`
                  );
                }
              }
              return (
                B((e) => ({
                  ...e,
                  status: "connected",
                  connectedWallet: t,
                  connectError: null,
                  connectRetry: L.n,
                })),
                t && (0, _.br)(eb, "connectWallet", "onSuccess", { wallet: t }),
                r?.(t, n)
              );
            } catch (e) {
              return (
                e instanceof T.aa
                  ? (console.warn(e.cause ? e.cause : e.message),
                    (0, _.br)(
                      eb,
                      "connectWallet",
                      "onError",
                      e.privyErrorCode || T.h.GENERIC_CONNECT_WALLET_ERROR
                    ))
                  : (console.warn(e),
                    (0, _.br)(
                      eb,
                      "connectWallet",
                      "onError",
                      T.h.UNKNOWN_CONNECT_WALLET_ERROR
                    )),
                B((t) => ({
                  ...t,
                  status: "disconnected",
                  connectedWallet: null,
                  connectError: e,
                })),
                r?.(null, n)
              );
            }
          }
          let eD = async (e, n, r) => {
              if (null === e || !(0, _.bB)(e)) return;
              let a = new _.X(t, e, n, r);
              t.startAuthFlow(a);
            },
            ez = async (e, n, r, i = "plain") => {
              let o = a(_.bO);
              if ("transaction" === i && !o)
                throw new T.P("useSolanaLedger plugin hook must be mounted");
              if (null === e || !(0, _.bP)(e)) return;
              let s = new _.bC(e, t, n, r, i, o);
              t.startAuthFlow(s);
            },
            eq = () => {
              let e = new URLSearchParams(window.location.search),
                n = e.get("privy_connector"),
                r = e.get("privy_wallet_client"),
                a = "true" === e.get("privy_connect_only");
              if (!n || !r) return;
              let i = (0, _.bQ)({ connectorType: n, walletClientType: r });
              if (!i || !i.isInstalled) return eN(nQ);
              if (!t.connectors) throw new T.P("Connector not initialized");
              eN(a ? _.bR : _.bS);
              let o = new URL(window.location.href);
              o.searchParams.delete("privy_connector"),
                o.searchParams.delete("privy_wallet_client"),
                o.searchParams.delete("privy_connect_only"),
                window.history.pushState({}, "", o),
                eF(n, r, void 0, a ? void 0 : "solana_adapter" === n ? ez : eD);
            };
          (0, w.useEffect)(() => {
            b && x && null === I && t.getAuthenticatedUser().then(S);
          }, [b, x, I, t]);
          let eB = (e) => {
              if (!x)
                throw (
                  ((0, _.br)(
                    eb,
                    "linkAccount",
                    "onError",
                    T.h.MUST_BE_AUTHENTICATED,
                    { linkMethod: e }
                  ),
                  new T.P(
                    "User must be authenticated before linking an account."
                  ))
                );
            },
            eV = (e) => {
              if (!x || !I) return !1;
              if ("privy" === e.walletClientType) return !0;
              for (let t of I.linkedAccounts)
                if (
                  "wallet" === t.type &&
                  t.address === e.address &&
                  "privy" !== t.walletClientType
                )
                  return !0;
              return !1;
            },
            eH = () => {
              U((e) => {
                let n =
                  t.connectors?.wallets.filter(_.bB).map((e) => ({
                    ...e,
                    linked: eV(e),
                    loginOrLink: async () => {
                      if (!(await e.isConnected()))
                        throw new T.P("Wallet is not connected");
                      if (
                        "embedded" === e.connectorType &&
                        "privy" === e.walletClientType
                      )
                        throw new T.P(
                          "Cannot link or login with embedded wallet"
                        );
                      (async (e) => {
                        let n;
                        if (!t.connectors)
                          throw new T.P("Connector not initialized");
                        (n =
                          "ethereum" === e.type
                            ? t.connectors.findWalletConnector(
                                e.connectorType,
                                e.walletClientType
                              ) || null
                            : t.connectors.findSolanaWalletConnector(
                                e.walletClientType
                              ) || null),
                          B((t) => ({
                            ...t,
                            connector: n,
                            status: "connected",
                            connectedWallet: e,
                            connectError: null,
                            connectRetry: L.n,
                          })),
                          ei.captchaEnabled && !x
                            ? (el({
                                captchaModalData: {
                                  callback: (t) =>
                                    _.bB(e) ? eD(e, t) : ez(e, t),
                                  userIntentRequired: !1,
                                  onSuccessNavigateTo: _.bS,
                                  onErrorNavigateTo: _.b2,
                                },
                              }),
                              eN(_.bm))
                            : (_.bB(e) ? await eD(e) : await ez(e), eN(_.bS));
                      })(e);
                    },
                    fund: async (t) => {
                      await eX.fundWallet(e.address, t);
                    },
                    unlink: async () => {
                      if (!x) throw new T.P("User is not authenticated.");
                      if (
                        "embedded" === e.connectorType &&
                        "privy" === e.walletClientType
                      )
                        throw new T.P("Cannot unlink an embedded wallet");
                      S(await t.unlinkEthereumWallet(e.address));
                    },
                  })) || [];
                return (0, _.bT)(e, n) ? e : n;
              });
            };
          (0, w.useEffect)(() => {
            eH();
          }, [I?.linkedAccounts, x, b]),
            (0, w.useEffect)(() => {
              if (b) {
                if (!t.connectors) throw new T.P("Connector not initialized");
                eH(), t.connectors.on("walletsUpdated", eH);
              }
            }, [b]),
            (0, w.useEffect)(() => {
              [
                ...(ei.loginMethodsAndOrder?.primary ?? []),
                ...(ei.loginMethodsAndOrder?.overflow ?? []),
              ]
                .filter((e) => e.startsWith("privy:"))
                .forEach((e) =>
                  t.getCrossAppProviderDetails(e.replace("privy:", ""))
                );
            }, [!!t]);
          let e$ = ({
            transaction: n,
            sponsor: a,
            uiOptions: i,
            fundWalletConfig: o,
            address: s,
            signOnly: l,
          }) =>
            new Promise(async (c, d) => {
              let { requesterAppId: u } = i || {},
                h = l ? "signTransaction" : "sendTransaction",
                p = s ? (0, P.f)(I, s) : (0, P.b)(I);
              if (!p && s) {
                let e = (0, P.h)(j, s);
                if (e) {
                  if (a)
                    throw new T.P(
                      "Cannot sponsor transactions for externally connected wallet."
                    );
                  try {
                    let t = await e.getEthereumProvider(),
                      r = {
                        ...n,
                        from: s,
                        chainId:
                          n.chainId || Number(e.chainId.replace("eip155:", "")),
                        value: void 0 !== n.value ? (0, g.NC)(n.value) : void 0,
                      },
                      a = await t.request({
                        method:
                          "sendTransaction" === h
                            ? "eth_sendTransaction"
                            : "eth_signTransaction",
                        params: [r],
                      });
                    return (
                      (0, _.br)(eb, h, "onSuccess", { hash: a }),
                      void c({ hash: a })
                    );
                  } catch (e) {
                    return (
                      (0, _.br)(eb, h, "onError", T.h.TRANSACTION_FAILURE),
                      void d(e ?? new _.bw("Unable to " + h + e))
                    );
                  }
                }
              }
              if (!p)
                return (
                  (0, _.br)(eb, h, "onError", T.h.EMBEDDED_WALLET_NOT_FOUND),
                  void d(
                    new T.P(
                      "No embedded or connected wallet found for address."
                    )
                  )
                );
              if (!x || !I)
                return (
                  (0, _.br)(eb, h, "onError", T.h.MUST_BE_AUTHENTICATED),
                  void d(
                    Error(
                      "User must be authenticated before signing with a Privy wallet"
                    )
                  )
                );
              let m = p.address,
                w = p.walletIndex ?? 0,
                { entropyId: y, entropyIdVerifier: C } = (0, _.F)(I, p),
                b = e0.wallets.find(
                  (e) =>
                    "privy" === e.walletClientType &&
                    (0, f.K)(e.address) === (0, f.K)(m)
                );
              if (!b)
                return (
                  (0, _.br)(eb, h, "onError", T.h.EMBEDDED_WALLET_NOT_FOUND),
                  void d(Error("Must have a Privy wallet before signing"))
                );
              let A = await b.getEthereumProvider(),
                E = await A.request({ method: "eth_chainId" }),
                S = n.chainId ? Number(n.chainId) : (0, G.e)(E);
              ((e) => {
                if (!ei.chains.map((e) => e.id).includes(e))
                  throw new T.x(
                    `Chain ID ${e} is not supported. It must be added to the config.supportedChains property of the PrivyProvider.`,
                    T.h.UNSUPPORTED_CHAIN_ID
                  );
              })(S);
              let U = { ...n, from: n.from ?? m, chainId: S },
                W = await rC();
              if (!W || !er)
                return (
                  (0, _.br)(eb, h, "onError", T.h.EMBEDDED_WALLET_NOT_FOUND),
                  void d(
                    Error(
                      "Must have valid access token and Privy wallet to send transaction"
                    )
                  )
                );
              let N = (0, _.n)(U.chainId, ei.chains, ei.rpcConfig, {
                  appId: e.appId,
                }),
                O = (0, P.g)(p),
                R = async ({ transactionRequest: e }) => {
                  try {
                    let t;
                    if (!(await eX.recoverEmbeddedWallet({ address: m })))
                      throw (
                        ((0, _.br)(
                          eb,
                          h,
                          "onError",
                          T.h.UNKNOWN_CONNECT_WALLET_ERROR
                        ),
                        d(Error("Unable to connect to wallet")),
                        Error("Unable to connect to wallet"))
                      );
                    if (a) {
                      let t = await (async ({ transactionRequest: e }) => {
                        if (!O)
                          throw new T.P(
                            "Sponsoring is only supported for wallets on the TEE stack"
                          );
                        if (l)
                          throw new T.P(
                            "Cannot sponsor a sign transaction request"
                          );
                        let t = (e) => (null == e ? void 0 : (0, g.NC)(e)),
                          n = await (0, k.f)(
                            r,
                            async ({ message: e }) =>
                              await er.signWithUserSigner({
                                accessToken: W,
                                requesterAppId: u,
                                message: e,
                              }),
                            {
                              chain_type: "ethereum",
                              method: "eth_sendTransaction",
                              caip2: (0, _.bN)((0, g.NC)(e.chainId)),
                              sponsor: !0,
                              params: {
                                transaction: {
                                  from: e.from,
                                  to: e.to,
                                  chain_id: t(e.chainId),
                                  data: (0, v.v)(e.data)
                                    ? e.data
                                      ? e.data
                                      : (0, g.NC)(Uint8Array.from(e.data))
                                    : void 0,
                                  value: t(e.value),
                                },
                              },
                              wallet_id: p.id,
                            }
                          );
                        if (n.data && "hash" in n.data) return n.data.hash;
                        throw new _.bw("Unable to sign transaction");
                      })({ transactionRequest: e });
                      return (
                        (0, _.br)(eb, "sendTransaction", "onSuccess", {
                          hash: t,
                        }),
                        t
                      );
                    }
                    if (O) {
                      let n = (e) => (null == e ? void 0 : (0, g.NC)(e)),
                        a = await (0, k.f)(
                          r,
                          async ({ message: e }) =>
                            await er.signWithUserSigner({
                              accessToken: W,
                              requesterAppId: u,
                              message: e,
                            }),
                          {
                            chain_type: "ethereum",
                            method: "eth_signTransaction",
                            params: {
                              transaction: {
                                from: e.from,
                                to: e.to,
                                nonce: n(e.nonce),
                                chain_id: n(e.chainId),
                                data: (0, v.v)(e.data)
                                  ? e.data
                                    ? e.data
                                    : (0, g.NC)(Uint8Array.from(e.data))
                                  : void 0,
                                value: n(e.value),
                                type: e.type,
                                gas_limit: n(e.gasLimit ?? e.gas),
                                gas_price: n(e.gasPrice ?? e.gas),
                                max_fee_per_gas: n(e.maxFeePerGas),
                                max_priority_fee_per_gas: n(
                                  e.maxPriorityFeePerGas
                                ),
                              },
                            },
                            wallet_id: p.id,
                          }
                        );
                      if (!a.data || !("signed_transaction" in a.data))
                        throw new _.bw("Unable to sign transaction");
                      t = a.data.signed_transaction;
                    } else
                      t = await (async function ({
                        accessToken: e,
                        entropyId: t,
                        entropyIdVerifier: n,
                        transactingWalletIndex: r,
                        walletProxy: a,
                        transactionRequest: i,
                        requesterAppId: o,
                      }) {
                        return (
                          await a.rpc({
                            entropyId: t,
                            entropyIdVerifier: n,
                            hdWalletIndex: r ?? 0,
                            chainType: "ethereum",
                            accessToken: e,
                            requesterAppId: o,
                            request: {
                              method: "eth_signTransaction",
                              params: [i],
                            },
                          })
                        ).response.data;
                      })({
                        accessToken: W,
                        entropyId: y,
                        entropyIdVerifier: C,
                        transactingWalletIndex: w,
                        walletProxy: er,
                        transactionRequest: e,
                        requesterAppId: u,
                      });
                    if (l)
                      return (
                        (0, _.br)(eb, "signTransaction", "onSuccess", {
                          signature: t,
                        }),
                        t
                      );
                    {
                      let e = await N.sendRawTransaction({
                        serializedTransaction: t,
                      });
                      return (
                        (0, _.br)(eb, "sendTransaction", "onSuccess", {
                          hash: e,
                        }),
                        e
                      );
                    }
                  } catch (e) {
                    throw (
                      ((0, _.br)(eb, h, "onError", T.h.TRANSACTION_FAILURE), e)
                    );
                  }
                };
              if (eW({ showWalletUIs: i?.showWalletUIs })) {
                let e = l || a ? U : await (0, _.ah)(U, N, U.from);
                try {
                  let t = await R({ transactionRequest: e });
                  l
                    ? (0, _.br)(eb, "signTransaction", "onSuccess", {
                        signature: t,
                      })
                    : (0, _.br)(eb, "sendTransaction", "onSuccess", {
                        hash: t,
                      }),
                    c({ hash: t });
                } catch (e) {
                  (0, _.br)(eb, h, "onError", T.h.TRANSACTION_FAILURE), d(e);
                }
              } else {
                let e = {
                    connectingWalletAddress: m,
                    recoveryMethod: p.recoveryMethod,
                    entropyId: y,
                    entropyIdVerifier: C,
                    onCompleteNavigateTo: _.bU,
                    isUnifiedWallet: O,
                    onFailure: (e) => {
                      (0, _.br)(
                        eb,
                        h,
                        "onError",
                        T.h.UNKNOWN_CONNECT_WALLET_ERROR
                      ),
                        d(e);
                    },
                  },
                  n =
                    ei.fundingConfig &&
                    (0, G.f)(ei.fundingConfig.options).length >= 1
                      ? (0, G.p)({
                          address: m,
                          appConfig: ei,
                          fundWalletConfig: o,
                          methodScreen: _.aH,
                          chainIdOverride: U.chainId,
                          comingFromSendTransactionScreen: !0,
                        })
                      : void 0;
                el({
                  connectWallet: e,
                  sendTransaction: {
                    transactionRequest: U,
                    transactingWalletIndex: w,
                    transactingWalletAddress: m,
                    entropyId: y,
                    entropyIdVerifier: C,
                    signOnly: l,
                    scanTransaction: async () => {
                      let e = await (0, _.ah)(U, N, U.from);
                      return await t.scanTransaction({
                        metadata: {
                          domain: ei.embeddedWallets.transactionScanning.domain,
                        },
                        chain_id: e.chainId.toString(),
                        request: {
                          method: "eth_sendTransaction",
                          params: [
                            {
                              from: e.from,
                              to: e.to,
                              value: e.value?.toString(),
                              gas: e.gas?.toString(),
                              gasPrice: e.gasPrice?.toString(),
                              nonce: e.nonce?.toString(),
                              data: e.data,
                            },
                          ],
                        },
                      });
                    },
                    getIsSponsored: async () => !!a,
                    onConfirm: ({ transactionRequest: e }) =>
                      R({ transactionRequest: e }),
                    onSuccess: (e) => {
                      l
                        ? (0, _.br)(eb, "signTransaction", "onSuccess", {
                            signature: e.hash,
                          })
                        : (0, _.br)(eb, "sendTransaction", "onSuccess", {
                            hash: e.hash,
                          }),
                        c(e);
                    },
                    onFailure: (e) => {
                      (0, _.br)(eb, h, "onError", T.h.TRANSACTION_FAILURE),
                        d(e);
                    },
                    uiOptions: i || {},
                    fundWalletConfig: o,
                    requesterAppId: u,
                  },
                  funding: n,
                }),
                  eN(_.bV);
              }
            });
          function eZ() {
            return new Promise(async (e, t) => {
              let n = await rC();
              if (!n || !er)
                throw Error("Must have valid access token to enroll in MFA");
              try {
                await er.verifyMfa({ accessToken: n }), e();
              } catch (e) {
                t(e);
              }
            });
          }
          let eK = (e) =>
              e?.linkedAccounts
                .filter(
                  (e) =>
                    null !== e.latestVerifiedAt &&
                    !("wallet" === e.type && "privy" === e.walletClientType)
                )
                .sort(
                  (e, t) =>
                    t.latestVerifiedAt.getTime() - e.latestVerifiedAt.getTime()
                )[0],
            eY = (e) => {
              let t = I?.linkedAccounts.filter((t) => t.type === e).length ?? 0,
                { displayName: n, loginMethod: r } = (0, _.bW)(e);
              if (("passkey" === e && t >= 5) || ("passkey" !== e && t >= 1))
                throw (
                  ((0, _.br)(
                    eb,
                    "linkAccount",
                    "onError",
                    T.h.CANNOT_LINK_MORE_OF_TYPE,
                    { linkMethod: r }
                  ),
                  new T.P(`User already has an account of type ${n} linked.`))
                );
            };
          async function eG({
            showAutomaticRecovery: e = !1,
            legacySetWalletPasswordFlow: t = !1,
          }) {
            F(null);
            let n = t ? "setWalletPassword" : "setWalletRecovery";
            if (!x || !I)
              throw (
                ((0, _.br)(eb, n, "onError", T.h.MUST_BE_AUTHENTICATED),
                Error(
                  "User must be authenticated before adding recovery method to Privy wallet"
                ))
              );
            let r = (0, P.a)(I);
            if (!r || !er)
              throw (
                ((0, _.br)(eb, n, "onError", T.h.EMBEDDED_WALLET_NOT_FOUND),
                Error("Must have a Privy wallet to add a recovery method"))
              );
            let a = (0, P.g)(r);
            if (a)
              throw (
                ((0, _.br)(eb, n, "onError", T.h.UNSUPPORTED_WALLET_TYPE),
                new T.P(
                  "User owned wallet recovery is only supported for on-device execution and this app uses TEE execution. Learn more https://docs.privy.io/recipes/tee-wallet-migration-guide"
                ))
              );
            try {
              await eZ();
            } catch (e) {
              throw (
                ((0, _.br)(eb, n, "onError", T.h.MISSING_MFA_CREDENTIALS), e)
              );
            }
            return new Promise((i, o) => {
              let s = "user-passcode" === r.recoveryMethod,
                l = (0, _.bX)({
                  walletAction: "update",
                  availableRecoveryMethods:
                    ei.embeddedWallets.userOwnedRecoveryOptions,
                  legacySetWalletPasswordFlow: t,
                  isResettingPassword: s,
                  showAutomaticRecovery: e,
                }),
                { entropyId: c, entropyIdVerifier: d } = (0, _.F)(I),
                u = {
                  recoveryMethod: r.recoveryMethod,
                  connectingWalletAddress: r.address,
                  onCompleteNavigateTo: l,
                  shouldForceMFA: !1,
                  entropyId: c,
                  isUnifiedWallet: a,
                  entropyIdVerifier: d,
                  onFailure: (e) => {
                    (0, _.br)(
                      eb,
                      n,
                      "onError",
                      T.h.UNKNOWN_CONNECT_WALLET_ERROR
                    ),
                      o(e);
                  },
                };
              el({
                setWalletPassword: {
                  onSuccess: (e) => {
                    (0, _.br)(eb, n, "onSuccess", {
                      method: "user-passcode",
                      wallet: e,
                    }),
                      i(e);
                  },
                  onFailure: (e) => {
                    (0, _.br)(
                      eb,
                      n,
                      "onError",
                      T.h.USER_EXITED_SET_PASSWORD_FLOW
                    ),
                      o(e);
                  },
                  callAuthOnSuccessOnClose: !1,
                },
                recoverWallet: {
                  entropyId: c,
                  entropyIdVerifier: d,
                  onFailure: o,
                },
                connectWallet: u,
                recoverySelection: {
                  isInAccountCreateFlow: !1,
                  isResettingPassword: s,
                  shouldCreateEth: !1,
                  shouldCreateSol: !1,
                },
              }),
                eN(_.bV);
            });
          }
          async function eJ({ appId: e, action: n }) {
            let r = await rC();
            if ("link" === n && !r)
              throw (
                ((0, _.br)(
                  eb,
                  "linkAccount",
                  "onError",
                  T.h.MUST_BE_AUTHENTICATED,
                  { linkMethod: `privy:${e}` }
                ),
                new T.P(
                  "User must be authenticated before linking an account."
                ))
              );
            if ("login" === n && r)
              throw (
                ((0, _.br)(eb, "login", "onError", T.h.UNKNOWN_AUTH_ERROR),
                new T.P(
                  "Attempted to log in, but user is already logged in. Use a `link` helper instead."
                ))
              );
            (eE.current = `privy:${e}`), (eI.current = n);
            let a = (0, _.aD)();
            return (
              t.createAnalyticsEvent({
                eventName: "cross_app_auth_started",
                payload: { providerAppId: e },
              }),
              new Promise(async (r, i) => {
                let { name: o, logoUrl: s } = await ns({
                  api: t.api,
                  providerAppId: e,
                  requesterAppId: ei.id,
                });
                el({
                  crossAppAuth: {
                    appId: e,
                    name: o,
                    logoUrl: s,
                    action: n,
                    popup: a,
                    onSuccess: r,
                    onError: i,
                  },
                }),
                  eN(nj);
              })
            );
          }
          let eQ = {
            ready: b,
            authenticated: x,
            user: I,
            walletConnectors: t.connectors || null,
            connectWallet: (e) => {
              e && "target" in e && e && (e = void 0),
                el({
                  externalConnectWallet: {
                    walletList:
                      e?.walletList && e?.walletList.length > 0
                        ? e.walletList
                        : void 0,
                    walletChainType: e?.walletChainType,
                    description: e?.description,
                  },
                }),
                eN(_.bY);
            },
            linkWallet: (e) => {
              e && "target" in e && e && (e = void 0),
                eB("siwe"),
                (eE.current = "siwe"),
                (eI.current = "link"),
                el({
                  ...es,
                  externalConnectWallet: {
                    ...es.externalConnectWallet,
                    walletList: e?.walletList,
                    walletChainType: e?.walletChainType,
                    description:
                      e?.description ||
                      `Link a wallet to your ${ei?.name} account`,
                  },
                }),
                eN(_.bZ);
            },
            startCrossAppAuthFlow: eJ,
            linkEmail: () => {
              eB("email"),
                eY("email"),
                (eE.current = "email"),
                (eI.current = "link"),
                eN(nK);
            },
            linkPhone: () => {
              eB("sms"),
                eY("phone"),
                (eE.current = "sms"),
                (eI.current = "link"),
                eN(nG);
            },
            linkGoogle: async () => {
              eB("google"),
                eY("google_oauth"),
                (eI.current = "link"),
                await eX.initLoginWithOAuth("google");
            },
            linkTwitter: async () => {
              eB("twitter"),
                eY("twitter_oauth"),
                (eI.current = "link"),
                await eX.initLoginWithOAuth("twitter");
            },
            linkTwitch: async () => {
              eB("twitch"),
                eY("twitch_oauth"),
                (eI.current = "link"),
                await eX.initLoginWithOAuth("twitch");
            },
            linkDiscord: async () => {
              eB("discord"),
                eY("discord_oauth"),
                (eI.current = "link"),
                await eX.initLoginWithOAuth("discord");
            },
            linkGithub: async () => {
              eB("github"),
                eY("github_oauth"),
                (eI.current = "link"),
                await eX.initLoginWithOAuth("github");
            },
            linkSpotify: async () => {
              eB("spotify"),
                eY("spotify_oauth"),
                (eI.current = "link"),
                await eX.initLoginWithOAuth("spotify");
            },
            linkInstagram: async () => {
              eB("instagram"),
                eY("instagram_oauth"),
                (eI.current = "link"),
                await eX.initLoginWithOAuth("instagram");
            },
            linkTiktok: async () => {
              eB("tiktok"),
                eY("tiktok_oauth"),
                (eI.current = "link"),
                await eX.initLoginWithOAuth("tiktok");
            },
            linkLine: async () => {
              eB("line"),
                eY("line_oauth"),
                (eI.current = "link"),
                await eX.initLoginWithOAuth("line");
            },
            linkLinkedIn: async () => {
              eB("linkedin"),
                eY("linkedin_oauth"),
                (eI.current = "link"),
                await eX.initLoginWithOAuth("linkedin");
            },
            linkApple: async () => {
              eB("apple"),
                eY("apple_oauth"),
                (eI.current = "link"),
                await eX.initLoginWithOAuth("apple");
            },
            linkPasskey: async () => {
              eB("passkey"),
                eY("passkey"),
                await eX.initLinkWithPasskey(),
                eN(nw);
            },
            linkTelegram: async (e) => {
              if (
                (eB("telegram"),
                eY("telegram"),
                (eI.current = "link"),
                (eE.current = "telegram"),
                e?.launchParams)
              ) {
                if (e.launchParams.initDataRaw) {
                  let n = new _.bu();
                  t.startAuthFlow(n),
                    (n.meta.telegramAuthResult = void 0),
                    (n.meta.telegramWebAppData = (0, _.bv)(
                      e.launchParams.initDataRaw
                    )),
                    el({ telegramAuthModalData: { seamlessAuth: !0 } }),
                    eN(_.bL);
                } else
                  (0, _.br)(eb, "linkAccount", "onError", T.h.INVALID_DATA, {
                    linkMethod: "telegram",
                  });
              } else await eX.initLoginWithTelegram();
              eN(_.bL);
            },
            linkFarcaster: async () => {
              eB("farcaster"),
                eY("farcaster"),
                await eX.initLoginWithFarcaster(),
                (eI.current = "link"),
                (eE.current = "farcaster"),
                eN(_.b_);
            },
            updateEmail: () => {
              if ((eB("email"), !I?.email))
                throw new T.P(
                  "User does not have an email linked to their account."
                );
              (eI.current = "update"), (eE.current = "email"), eN(rm);
            },
            updatePhone: () => {
              if ((eB("sms"), !I?.phone))
                throw new T.P(
                  "User does not have a phone number linked to their account."
                );
              (eI.current = "update"), (eE.current = "sms"), eN(ry);
            },
            login: async (e) => {
              e && "target" in e && e && (e = void 0);
              let t =
                "Attempted to log in, but user is already logged in. Use a `link` helper instead.";
              if (!b) {
                let e = await new Promise((e) => {
                  ed((t) => e.bind(t));
                });
                if ((ed(null), e)) return void console.warn(t);
              }
              !I || I.isGuest
                ? ((eI.current = "login"), el({ login: e }), eN(_.b3))
                : console.warn(t);
            },
            connectOrCreateWallet: async () => {
              b ||
                (await new Promise((e) => {
                  ed(() => e);
                }),
                ed(null)),
                x
                  ? console.warn(
                      "User must be unauthenticated to `connectOrCreateWallet`"
                    )
                  : ((eI.current = "connect-or-create"), eN(_.b$));
            },
            logout: async () => {
              if (
                ((eI.current = null),
                (eE.current = null),
                I && t.clearProviderAcccessTokens(I),
                F(null),
                await t.logout(),
                I && er)
              )
                try {
                  await er.clearMfa({ userId: I.id });
                } catch (e) {}
              S(null),
                E(!1),
                (0, _.br)(eb, "logout", "onSuccess"),
                o(!1),
                _.s.del(_.a8),
                _.s.del((0, _.U)(ei.id));
            },
            getAccessToken: (0, w.useCallback)(
              () => t.getCustomerAccessToken(),
              [t]
            ),
            unlinkWallet: async (e) => {
              let n;
              return (
                S(
                  (n = e.startsWith("0x")
                    ? await t.unlinkEthereumWallet(e)
                    : await t.unlinkSolanaWallet(e))
                ),
                n
              );
            },
            unlinkEmail: async (e) => {
              let n = await t.unlinkEmail(e);
              return S(n), n;
            },
            unlinkPhone: async (e) => {
              let n = await t.unlinkPhone(e);
              return S(n), n;
            },
            unlinkGoogle: async (e) => {
              let n = await t.unlinkOAuth("google", e);
              return S(n), n;
            },
            unlinkTwitter: async (e) => {
              let n = await t.unlinkOAuth("twitter", e);
              return S(n), n;
            },
            unlinkTwitch: async (e) => {
              let n = await t.unlinkOAuth("twitch", e);
              return S(n), n;
            },
            unlinkDiscord: async (e) => {
              let n = await t.unlinkOAuth("discord", e);
              return S(n), n;
            },
            unlinkGithub: async (e) => {
              let n = await t.unlinkOAuth("github", e);
              return S(n), n;
            },
            unlinkSpotify: async (e) => {
              let n = await t.unlinkOAuth("spotify", e);
              return S(n), n;
            },
            unlinkInstagram: async (e) => {
              let n = await t.unlinkOAuth("instagram", e);
              return S(n), n;
            },
            unlinkTiktok: async (e) => {
              let n = await t.unlinkOAuth("tiktok", e);
              return S(n), n;
            },
            unlinkLine: async (e) => {
              let n = await t.unlinkOAuth("line", e);
              return S(n), n;
            },
            unlinkLinkedIn: async (e) => {
              let n = await t.unlinkOAuth("linkedin", e);
              return S(n), n;
            },
            unlinkApple: async (e) => {
              let n = await t.unlinkOAuth("apple", e);
              return S(n), n;
            },
            unlinkFarcaster: async (e) => {
              let n = await t.unlinkFarcaster(e);
              return S(n), n;
            },
            unlinkTelegram: async (e) => {
              let n = await t.unlinkTelegram(e);
              return S(n), n;
            },
            unlinkPasskey: async (e) => {
              let n = await rC();
              if (!n)
                throw Error("Must have valid access token to enroll in MFA");
              if (!er) throw Error("Wallet proxy not initialized.");
              let r = ei.passkeys.shouldUnenrollMfaOnUnlink;
              await er.unlinkPasskeyAccount({
                credentialId: e,
                accessToken: n,
                removeAsMfa: r,
              });
              let a = await t.getAuthenticatedUser();
              return S(a), a;
            },
            unlinkCrossAppAccount: async ({ subject: e }) => {
              let n = I?.linkedAccounts.find(
                (t) => "cross_app" === t.type && t.subject === e
              )?.providerApp;
              if (!n) throw new T.P("Invalid subject");
              t.storeProviderAccessToken(n.id, null);
              let r = await t.unlinkOAuth(`privy:${n.id}`, e);
              return S(r), r;
            },
            setWalletRecovery: async (e) =>
              eG({
                legacySetWalletPasswordFlow: !1,
                showAutomaticRecovery: e?.showAutomaticRecovery ?? !1,
              }),
            setWalletPassword: async () =>
              eG({
                legacySetWalletPasswordFlow: !0,
                showAutomaticRecovery: !1,
              }),
            signMessage: (e, n) =>
              new Promise(async (a, i) => {
                let { requesterAppId: o } = n?.uiOptions || {},
                  s = e.message,
                  l = n?.address ? (0, P.f)(I, n.address) : (0, P.b)(I);
                if (!l && void 0 !== n?.address) {
                  let e = (0, P.h)(j, n.address);
                  if (e)
                    try {
                      let t = await e.getEthereumProvider(),
                        n = await t.request({
                          method: "personal_sign",
                          params: [s, e.address],
                        });
                      return (
                        (0, _.br)(eb, "signMessage", "onSuccess", {
                          signature: n,
                        }),
                        void a({ signature: n })
                      );
                    } catch (e) {
                      return (
                        (0, _.br)(
                          eb,
                          "signMessage",
                          "onError",
                          T.h.UNABLE_TO_SIGN
                        ),
                        void i(e ?? new _.bw("Unable to sign message"))
                      );
                    }
                }
                if (!l)
                  throw new T.P(
                    "No embedded or connected wallet found for address."
                  );
                if (!x || !I)
                  return (
                    (0, _.br)(
                      eb,
                      "signMessage",
                      "onError",
                      T.h.MUST_BE_AUTHENTICATED
                    ),
                    void i(
                      Error(
                        "User must be authenticated before signing with a Privy wallet"
                      )
                    )
                  );
                let c = l.address,
                  d = l.walletIndex ?? 0,
                  { entropyId: u, entropyIdVerifier: h } = (0, _.F)(I, l),
                  p = (0, P.g)(l);
                if ("string" != typeof s || s.length < 1)
                  return (
                    (0, _.br)(
                      eb,
                      "signMessage",
                      "onError",
                      T.h.INVALID_MESSAGE
                    ),
                    void i(Error("Message must be a non-empty string"))
                  );
                let m = async () => {
                  let n;
                  if (!x)
                    throw Error(
                      "User must be authenticated before signing with a Privy wallet"
                    );
                  let a = await rC();
                  if (
                    !er ||
                    !a ||
                    !(await eX.recoverEmbeddedWallet({ address: c }))
                  )
                    throw Error("Unable to connect to wallet");
                  if (
                    (t.createAnalyticsEvent({
                      eventName: "embedded_wallet_sign_message_started",
                      payload: { walletAddress: c, requesterAppId: o },
                    }),
                    p)
                  ) {
                    let t = (0, v.v)(e.message, { strict: !0 }),
                      i = await (0, k.f)(
                        r,
                        async ({ message: e }) =>
                          await er.signWithUserSigner({
                            accessToken: a,
                            requesterAppId: o,
                            message: e,
                          }),
                        {
                          chain_type: "ethereum",
                          method: "personal_sign",
                          params: t
                            ? { message: s.slice(2), encoding: "hex" }
                            : { message: s, encoding: "utf-8" },
                          wallet_id: l.id,
                        }
                      );
                    if (!i.data || !("signature" in i.data))
                      throw new _.bw("Unable to sign message");
                    n = i.data.signature;
                  } else {
                    let { response: e } = await er.rpc({
                      accessToken: a,
                      entropyId: u,
                      entropyIdVerifier: h,
                      chainType: "ethereum",
                      hdWalletIndex: d,
                      requesterAppId: o,
                      request: { method: "personal_sign", params: [s, c] },
                    });
                    n = e.data;
                  }
                  return (
                    t.createAnalyticsEvent({
                      eventName: "embedded_wallet_sign_message_completed",
                      payload: { walletAddress: c, requesterAppId: o },
                    }),
                    n
                  );
                };
                if (eW({ showWalletUIs: n?.uiOptions?.showWalletUIs }))
                  try {
                    let e = await m();
                    (0, _.br)(eb, "signMessage", "onSuccess", { signature: e }),
                      a({ signature: e });
                  } catch (e) {
                    (0, _.br)(eb, "signMessage", "onError", T.h.UNABLE_TO_SIGN),
                      i(e ?? new _.bw("Unable to sign message"));
                  }
                else
                  el({
                    signMessage: {
                      method: "personal_sign",
                      data: s,
                      confirmAndSign: m,
                      onSuccess: (e) => {
                        (0, _.br)(eb, "signMessage", "onSuccess", {
                          signature: e,
                        }),
                          a({ signature: e });
                      },
                      onFailure: (e) => {
                        (0, _.br)(
                          eb,
                          "signMessage",
                          "onError",
                          T.h.UNABLE_TO_SIGN
                        ),
                          i(e);
                      },
                      uiOptions: n?.uiOptions || {},
                    },
                    connectWallet: {
                      recoveryMethod: l.recoveryMethod,
                      connectingWalletAddress: c,
                      entropyId: u,
                      entropyIdVerifier: h,
                      onCompleteNavigateTo: _.bx,
                      isUnifiedWallet: p,
                      onFailure: (e) => {
                        (0, _.br)(
                          eb,
                          "signMessage",
                          "onError",
                          T.h.UNKNOWN_CONNECT_WALLET_ERROR
                        ),
                          i(e);
                      },
                    },
                  }),
                    eN(_.bV);
              }),
            signTypedData: (e, n) =>
              new Promise(async (a, i) => {
                let { requesterAppId: o } = n?.uiOptions || {},
                  s = n?.address ? (0, P.f)(I, n.address) : (0, P.b)(I);
                if (!s && n?.address) {
                  let t = (0, P.h)(j, n.address);
                  if (t)
                    try {
                      let n = await t.getEthereumProvider(),
                        r = (0, _.p)(e),
                        i = await n.request({
                          method: "eth_signTypedData_v4",
                          params: [t.address, r],
                        });
                      return (
                        (0, _.br)(eb, "signTypedData", "onSuccess", {
                          signature: i,
                        }),
                        void a({ signature: i })
                      );
                    } catch (e) {
                      return (
                        (0, _.br)(
                          eb,
                          "signTypedData",
                          "onError",
                          T.h.UNABLE_TO_SIGN
                        ),
                        void i(e ?? new _.bw("Unable to sign typed data " + e))
                      );
                    }
                }
                if (!s)
                  throw new T.P(
                    "No embedded or connected wallet found for address."
                  );
                if (!x || !I)
                  return (
                    (0, _.br)(
                      eb,
                      "signTypedData",
                      "onError",
                      T.h.MUST_BE_AUTHENTICATED
                    ),
                    void i(
                      Error(
                        "User must be authenticated before signing with a Privy wallet"
                      )
                    )
                  );
                let l = s.address,
                  c = s.walletIndex ?? 0,
                  { entropyId: d, entropyIdVerifier: u } = (0, _.F)(I, s),
                  h = (0, P.g)(s),
                  p = (0, _.p)(e),
                  m = async () => {
                    let e;
                    if (!x)
                      throw Error(
                        "User must be authenticated before signing with a Privy wallet"
                      );
                    let n = await rC();
                    if (
                      !er ||
                      !n ||
                      !(await eX.recoverEmbeddedWallet({ address: l }))
                    )
                      throw Error("Unable to connect to wallet");
                    if (
                      (t.createAnalyticsEvent({
                        eventName: "embedded_wallet_sign_typed_data_started",
                        payload: { walletAddress: l, requesterAppId: o },
                      }),
                      h)
                    ) {
                      let {
                          domain: t,
                          types: a,
                          primaryType: i,
                          message: l,
                        } = p,
                        c = await (0, k.f)(
                          r,
                          async ({ message: e }) =>
                            await er.signWithUserSigner({
                              accessToken: n,
                              requesterAppId: o,
                              message: e,
                            }),
                          {
                            chain_type: "ethereum",
                            method: "eth_signTypedData_v4",
                            params: {
                              typed_data: {
                                domain: t,
                                types: a,
                                primary_type: i,
                                message: l,
                              },
                            },
                            wallet_id: s.id,
                          }
                        );
                      if (!c.data || !("signature" in c.data))
                        throw new _.bw("Unable to sign message");
                      e = c.data.signature;
                    } else {
                      let { response: t } = await er.rpc({
                        accessToken: n,
                        entropyId: d,
                        entropyIdVerifier: u,
                        chainType: "ethereum",
                        hdWalletIndex: c,
                        requesterAppId: o,
                        request: {
                          method: "eth_signTypedData_v4",
                          params: [l, p],
                        },
                      });
                      e = t.data;
                    }
                    return (
                      t.createAnalyticsEvent({
                        eventName: "embedded_wallet_sign_typed_data_completed",
                        payload: { walletAddress: l, requesterAppId: o },
                      }),
                      e
                    );
                  };
                if (eW({ showWalletUIs: n?.uiOptions?.showWalletUIs }))
                  try {
                    let e = await m();
                    (0, _.br)(eb, "signTypedData", "onSuccess", {
                      signature: e,
                    }),
                      a({ signature: e });
                  } catch (e) {
                    (0, _.br)(
                      eb,
                      "signTypedData",
                      "onError",
                      T.h.UNABLE_TO_SIGN
                    ),
                      i(e ?? new _.bw("Unable to sign message"));
                  }
                else
                  el({
                    signMessage: {
                      method: "eth_signTypedData_v4",
                      data: p,
                      confirmAndSign: m,
                      onSuccess: (e) => {
                        (0, _.br)(eb, "signTypedData", "onSuccess", {
                          signature: e,
                        }),
                          a({ signature: e });
                      },
                      onFailure: (e) => {
                        (0, _.br)(
                          eb,
                          "signTypedData",
                          "onError",
                          T.h.UNABLE_TO_SIGN
                        ),
                          i(e);
                      },
                      uiOptions: n?.uiOptions || {},
                    },
                    connectWallet: {
                      recoveryMethod: s.recoveryMethod,
                      connectingWalletAddress: s.address,
                      entropyId: d,
                      isUnifiedWallet: h,
                      entropyIdVerifier: u,
                      onCompleteNavigateTo: _.bx,
                      onFailure: (e) => {
                        (0, _.br)(
                          eb,
                          "signMessage",
                          "onError",
                          T.h.UNKNOWN_CONNECT_WALLET_ERROR
                        ),
                          i(e);
                      },
                    },
                  }),
                    eN(_.bV);
              }),
            sendTransaction: async (e, t) =>
              await e$({
                transaction: e,
                sponsor: t?.sponsor,
                uiOptions: t?.uiOptions,
                fundWalletConfig: t?.fundWalletConfig,
                address: t?.address,
                signOnly: !1,
              }),
            signTransaction: async (e, t) => ({
              signature: (
                await e$({
                  transaction: e,
                  uiOptions: t?.uiOptions,
                  address: t?.address,
                  signOnly: !0,
                })
              ).hash,
            }),
            exportWallet: (n) =>
              new Promise(async (r, a) => {
                if (!x || !I)
                  return void a(
                    Error(
                      "User must be authenticated before exporting their Privy wallet"
                    )
                  );
                n && "target" in n && n && (n = void 0);
                let i = n?.address ? (0, P.f)(I, n.address) : (0, P.b)(I);
                if (!i)
                  return void a(new T.P("User must have an embedded wallet."));
                let o = i.address,
                  { entropyId: s, entropyIdVerifier: l } = (0, _.F)(I, i),
                  c = (0, P.g)(i);
                if (!o)
                  return void a(
                    Error(
                      "User does not have an HD Ethereum wallet. To export an imported wallet, pass the `address` of the wallet to `exportWallet`."
                    )
                  );
                if (!(0, C.U)(o))
                  return void a(
                    Error("Must provide a valid Ethereum address.")
                  );
                let d = {
                  recoveryMethod: i.recoveryMethod,
                  connectingWalletAddress: i.address,
                  isUnifiedWallet: c,
                  entropyId: s,
                  entropyIdVerifier: l,
                  onCompleteNavigateTo: _.by,
                  onFailure: a,
                  shouldForceMFA: !0,
                };
                el(es),
                  (await rC()) && er
                    ? er
                      ? (0, G.i)(i)
                        ? (el({
                            keyExport: {
                              appId: e.appId,
                              appClientId: e.clientId,
                              origin: t.apiUrl,
                              address: i.address,
                              entropyId: s,
                              entropyIdVerifier: l,
                              hdWalletIndex: i.walletIndex,
                              chainType: i.chainType,
                              walletId: i.id,
                              isUnifiedWallet: c,
                              imported: i.imported,
                              onSuccess: r,
                              onFailure: a,
                            },
                            connectWallet: d,
                          }),
                          eN(_.bV))
                        : a(
                            Error(
                              `Export is not supported for ${i.chainType} wallets`
                            )
                          )
                      : a(Error("Must have a Privy wallet before exporting"))
                    : a(Error("Must have valid access token to enroll in MFA"));
              }),
            promptMfa: eZ,
            async init(e) {
              switch (e) {
                case "sms":
                  return void (await t.initMfaSmsVerification());
                case "passkey":
                  return await t.initMfaPasskeyVerification();
                case "totp":
                  return;
                default:
                  throw Error(`Unsupported MFA method: ${e}`);
              }
            },
            async submit(e, t) {
              switch (e) {
                case "totp":
                case "sms":
                  if ("string" != typeof t) throw new T.P("Invalid MFA code");
                  ey.current?.resolve({
                    mfaMethod: e,
                    mfaCode: t,
                    relyingParty: window.origin,
                  }),
                    await new Promise((e, t) => {
                      eg.current = { resolve: e, reject: t };
                    });
                  break;
                case "passkey":
                  if ("string" == typeof t)
                    throw new T.P("Invalid authenticator response");
                  let r = await n.e(2512).then(n.bind(n, 2512)),
                    a = nS(await r.startAuthentication(t));
                  ey.current?.resolve({
                    mfaMethod: e,
                    mfaCode: a,
                    relyingParty: window.origin,
                  }),
                    await new Promise((e, t) => {
                      eg.current = { resolve: e, reject: t };
                    });
                  break;
                default:
                  throw (
                    (ey.current?.reject(new T.P("Unsupported MFA method")),
                    new T.P(`Unsupported MFA method: ${e}`))
                  );
              }
            },
            cancel() {
              ey.current?.reject(new T.P("MFA canceled"));
            },
            async initEnrollmentWithSms(e) {
              let t = await rC();
              if (!t || !er)
                throw Error("Must have valid access token to enroll in MFA");
              await er.initEnrollMfa({
                method: "sms",
                accessToken: t,
                phoneNumber: e.phoneNumber,
              });
            },
            enrollInMfa: (e) =>
              new Promise((t, n) => {
                if (!e) return eX.closePrivyModal(), void t();
                ei.mfa.noPromptOnMfaRequired &&
                  console.warn(
                    "[Privy Warning] Triggering the 'showMfaEnrollmentModal' function when 'noPromptOnMfaRequired' is set to true is unexpected. If this is intentional, ensure that you are building custom UIs for MFA verification."
                  ),
                  el({
                    mfaEnrollmentFlow: {
                      mfaMethods: ei.mfa.methods,
                      shouldUnlinkOnUnenrollMfa:
                        ei.passkeys.shouldUnlinkOnUnenrollMfa,
                      onSuccess: t,
                      onFailure: n,
                    },
                  }),
                  eN(rs);
              }),
            async initEnrollmentWithTotp() {
              let e = await rC();
              if (!e || !er)
                throw Error("Must have valid access token to enroll in MFA");
              let t = await er.initEnrollMfa({
                method: "totp",
                accessToken: e,
              });
              return { secret: t.secret, authUrl: t.authUrl };
            },
            async submitEnrollmentWithSms(e) {
              let n = await rC();
              if (!n || !er)
                throw Error("Must have valid access token to enroll in MFA");
              await er.submitEnrollMfa({
                method: "sms",
                accessToken: n,
                phoneNumber: e.phoneNumber,
                code: e.mfaCode,
              }),
                S(await t.getAuthenticatedUser());
            },
            async submitEnrollmentWithTotp(e) {
              let n = await rC();
              if (!n || !er)
                throw Error("Must have valid access token to enroll in MFA");
              await er.submitEnrollMfa({
                method: "totp",
                accessToken: n,
                code: e.mfaCode,
              }),
                S(await t.getAuthenticatedUser());
            },
            async initEnrollmentWithPasskey() {},
            async submitEnrollmentWithPasskey({ credentialIds: e }, n = {}) {
              let r = await rC();
              if (!r || !er)
                throw Error("Must have valid access token to enroll in MFA");
              await er.submitEnrollMfa({
                method: "passkey",
                accessToken: r,
                credentialIds: e,
                removeForLogin: n.removeForLogin,
              }),
                S(await t.getAuthenticatedUser());
            },
            async unenroll(e, n = {}) {
              let r = await rC();
              if (!r || !er)
                throw Error("Must have valid access token to remove MFA");
              "passkey" === e
                ? await er.submitEnrollMfa({
                    method: "passkey",
                    accessToken: r,
                    credentialIds: [],
                    removeForLogin: n.removeForLogin,
                  })
                : await er.unenrollMfa({ method: e, accessToken: r }),
                S(await t.getAuthenticatedUser());
            },
            requestFarcasterSignerFromWarpcast: async () => {
              let e = await rC(),
                n = I?.linkedAccounts.find(
                  (e) => "wallet" === e.type && "privy" === e.walletClientType
                );
              if (!e)
                throw Error(
                  "Must have valid access token to connect with Farcaster"
                );
              if (!er || !n)
                throw Error(
                  "Must have an embedded wallet to use Farcaster signers"
                );
              if ((0, P.g)(n))
                throw new T.P(
                  "Farcaster signers are only supported for on-device execution and this app uses TEE execution. Learn more at https://docs.privy.io/recipes/tee-wallet-migration-guide"
                );
              if (!I?.farcaster?.fid)
                throw Error(
                  "Must have Farcaster account to use Farcaster signers"
                );
              if (!(await eX.recoverEmbeddedWallet({ address: n.address })))
                throw Error("Unable to connect to wallet");
              let r = await er.initFarcasterSigner({
                address: n.address,
                hdWalletIndex: null,
                accessToken: e,
                mfaCode: null,
                mfaMethod: null,
                relyingParty: window.origin,
              });
              "approved" === r.status &&
                S((await t.getAuthenticatedUser()) || I || null),
                el({ farcasterSigner: r }),
                eN(nV);
            },
            getFarcasterSignerPublicKey: async () => {
              let e,
                t = await rC(),
                n = I?.linkedAccounts.find(
                  (e) => "wallet" === e.type && "privy" === e.walletClientType
                );
              if (!t)
                throw Error(
                  "Must have valid access token to connect with Farcaster"
                );
              if (!er || !n)
                throw Error(
                  "Must have an embedded wallet to use Farcaster signers"
                );
              if ((0, P.g)(n))
                throw new T.P(
                  "Farcaster signers are only supported for on-device execution and this app uses TEE execution. Learn more at https://docs.privy.io/recipes/tee-wallet-migration-guide"
                );
              if (!I?.farcaster?.fid)
                throw Error(
                  "Must have Farcaster account to use Farcaster signers"
                );
              if (!(await eX.recoverEmbeddedWallet({ address: n.address })))
                throw Error("Unable to connect to wallet");
              if (!I.farcaster?.signerPublicKey)
                throw Error("Must have a Farcaster signer public key to sign");
              return (
                (e = I.farcaster.signerPublicKey.slice(2)),
                Uint8Array.from(e.match(/.{1,2}/g).map((e) => parseInt(e, 16)))
              );
            },
            signFarcasterMessage: async (e) => {
              let t = await rC(),
                r = I?.linkedAccounts.find(
                  (e) => "wallet" === e.type && "privy" === e.walletClientType
                );
              if (!t)
                throw Error(
                  "Must have valid access token to connect with Farcaster"
                );
              if (!er || !r)
                throw Error(
                  "Must have an embedded wallet to use Farcaster signers"
                );
              if ((0, P.g)(r))
                throw new T.P(
                  "Farcaster signers are only supported for on-device execution and this app uses TEE execution. Learn more at https://docs.privy.io/recipes/tee-wallet-migration-guide"
                );
              if (!I?.farcaster?.fid)
                throw Error(
                  "Must have Farcaster account to use Farcaster signers"
                );
              if (!(await eX.recoverEmbeddedWallet({ address: r.address })))
                throw Error("Unable to connect to wallet");
              if (!I.farcaster?.signerPublicKey)
                throw Error("Must have a Farcaster signer public key to sign");
              let a = await n.e(2512).then(n.bind(n, 2512)),
                i = await er.signFarcasterMessage({
                  address: r.address,
                  hdWalletIndex: null,
                  accessToken: t,
                  mfaCode: null,
                  mfaMethod: null,
                  payload: { hash: a.bufferToBase64URLString(e) },
                  fid: BigInt(I.farcaster.fid),
                  relyingParty: window.origin,
                });
              return new Uint8Array(a.base64URLStringToBuffer(i.signature));
            },
            signMessageWithCrossAppWallet(e, { address: n, chainId: r }) {
              let a = I?.linkedAccounts.some(
                (e) =>
                  "cross_app" === e.type &&
                  e.smartWallets.some((e) => e.address === n)
              );
              return nl({
                user: I,
                client: t,
                address: n,
                requesterAppId: ei.id,
                request: {
                  method: a ? "privy_signSmartWalletMessage" : "personal_sign",
                  params: [e, n],
                  chainId: r,
                },
                reconnect: eJ,
              });
            },
            signTypedDataWithCrossAppWallet(e, { address: n, chainId: r }) {
              let a = I?.linkedAccounts.some(
                  (e) =>
                    "cross_app" === e.type &&
                    e.smartWallets.some((e) => e.address === n)
                ),
                i = (0, _.p)(e);
              return nl({
                user: I,
                client: t,
                address: n,
                requesterAppId: ei.id,
                request: {
                  method: a
                    ? "privy_signSmartWalletTypedData"
                    : "eth_signTypedData_v4",
                  params: [n, i],
                  chainId: r,
                },
                reconnect: eJ,
              });
            },
            sendTransactionWithCrossAppWallet(e, { address: n }) {
              let r = I?.linkedAccounts.some(
                (e) =>
                  "cross_app" === e.type &&
                  e.smartWallets.some((e) => e.address === n)
              );
              return nl({
                user: I,
                client: t,
                address: n,
                requesterAppId: ei.id,
                request: {
                  method: r ? "privy_sendSmartWalletTx" : "eth_sendTransaction",
                  params: [e],
                  chainId: e.chainId,
                },
                reconnect: eJ,
              });
            },
            signTransactionWithCrossAppWallet(e, { address: n }) {
              let r = I?.linkedAccounts.some(
                (e) =>
                  "cross_app" === e.type &&
                  e.smartWallets.some((e) => e.address === n)
              );
              return nl({
                user: I,
                client: t,
                address: n,
                requesterAppId: ei.id,
                request: {
                  method: r ? "privy_signSmartWalletTx" : "eth_signTransaction",
                  params: [e],
                  chainId: e.chainId,
                },
                reconnect: eJ,
              });
            },
            isModalOpen: i || !!h,
            mfaMethods: ei.mfa.methods,
          };
          (s = eQ.signMessage),
            (l = eQ.signTypedData),
            (d = async (e, t) =>
              await e$({ transaction: e, ...t, signOnly: !1 })),
            (c = async (e, t) => ({
              signature: (await e$({ transaction: e, ...t, signOnly: !0 }))
                .hash,
            }));
          let eX = {
            privy: r,
            setAuthenticated: E,
            setUser: S,
            setIsNewUser: R,
            isNewUserThisSession: O,
            pendingTransaction: null,
            walletConnectionStatus: q,
            setWalletConnectionStatus: B,
            connectors: t.connectors?.walletConnectors ?? [],
            rpcConfig: ei.rpcConfig,
            chains: ei.chains,
            appId: e.appId,
            showFiatPrices:
              "native-token" !== ei.embeddedWallets.priceDisplay.primary,
            clientAnalyticsId: t.clientAnalyticsId,
            onCustomAuthAuthenticated: eO,
            hideWalletUIs: eS,
            isHeadlessSigning: (0, w.useCallback)(eW, [
              ei.embeddedWallets.showWalletUIs,
            ]),
            emailOtpState: $,
            setEmailOtpState: Z,
            smsOtpState: K,
            setSmsOtpState: Y,
            oAuthState: X,
            setOAuthState: ee,
            telegramAuthState: et,
            setTelegramAuthState: en,
            siweState: J,
            setSiweState: Q,
            isHeadlessOAuthLoading: D,
            baseAccountSdk: W,
            setBaseAccountSdk: N,
            nativeTokenSymbolForChainId: (e) =>
              ei.chains.find((t) => t.id === Number(e))?.nativeCurrency.symbol,
            initializeWalletProxy: async (e) => {
              if (er) return er;
              let t = new Promise((e) => {
                  eu.current = e;
                }),
                n = new Promise((t) => setTimeout(() => t(null), e)),
                r = await Promise.race([t, n]);
              return (eu.current = null), r;
            },
            getAuthFlow: () => t.authFlow,
            getAuthMeta: () => t.authFlow?.meta,
            client: t,
            closePrivyModal: async (
              n = { shouldCallAuthOnSuccess: !0, isSuccess: !1 }
            ) => {
              let r,
                i = b && x && I;
              i && eE.current && (r = eK(I)),
                "login" === eI.current
                  ? n.shouldCallAuthOnSuccess && i && eE.current
                    ? (0, _.br)(eb, "login", "onComplete", {
                        user: I,
                        isNewUser: O,
                        wasAlreadyAuthenticated: !1,
                        loginMethod: eE.current,
                        loginAccount: r ?? null,
                      })
                    : (0, _.br)(
                        eb,
                        "login",
                        "onError",
                        T.h.USER_EXITED_AUTH_FLOW
                      )
                  : "link" === eI.current && r
                  ? n.isSuccess && i && eE.current
                    ? (0, _.br)(eb, "linkAccount", "onSuccess", {
                        user: I,
                        linkMethod: eE.current,
                        linkedAccount: r,
                      })
                    : eE.current &&
                      (0, _.br)(
                        eb,
                        "linkAccount",
                        "onError",
                        T.h.USER_EXITED_LINK_FLOW,
                        { linkMethod: eE.current }
                      )
                  : "update" === eI.current && r
                  ? n.isSuccess && i && eE.current
                    ? (0, _.br)(eb, "update", "onSuccess", {
                        user: I,
                        updateMethod: eE.current,
                        updatedAccount: r,
                      })
                    : eE.current &&
                      (0, _.br)(
                        eb,
                        "update",
                        "onError",
                        T.h.USER_EXITED_UPDATE_FLOW,
                        { linkMethod: eE.current }
                      )
                  : "connect-or-create" === eI.current &&
                    (j[0]
                      ? (0, _.br)(eb, "connectOrCreateWallet", "onSuccess", {
                          wallet: j[0],
                        })
                      : (0, _.br)(
                          eb,
                          "connectOrCreateWallet",
                          "onError",
                          T.h.USER_EXITED_AUTH_FLOW
                        ));
              let s = M && n_.has(M),
                l =
                  M === _.b2 &&
                  es.errorModalData &&
                  n_.has(es.errorModalData.previousScreen);
              if ((s || l) && es.funding) {
                let t,
                  n = n_.get(M) ?? null;
                if ("solana" === es.funding.chainType) {
                  let e = ei.solanaRpcs[es.funding.chain];
                  if (!e)
                    return void console.warn(
                      "Unable to load solana rpc, skipping balance"
                    );
                  if (a(_.bz))
                    try {
                      t = await (0, _.bA)({
                        rpc: e.rpc,
                        address: es.funding.address,
                      });
                    } catch {
                      console.error("Unable to pull wallet balance");
                    }
                  else
                    console.warn(
                      "Unable to load solana plugin, skipping balance"
                    );
                  (0, _.br)(eb, "fundSolanaWallet", "onUserExited", {
                    address: es.funding.address,
                    fundingMethod: n,
                    chain: es.funding.chain,
                    balance: t,
                  });
                } else {
                  let r = (0, _.n)(
                    es.funding.chain.id,
                    ei.chains,
                    ei.rpcConfig,
                    { appId: e.appId }
                  );
                  try {
                    t = await r.getBalance({ address: es.funding.address });
                  } catch {
                    console.error("Unable to pull wallet balance");
                  }
                  (0, _.br)(eb, "fundWallet", "onUserExited", {
                    address: es.funding.address,
                    chain: es.funding.chain,
                    fundingMethod: n,
                    balance: t,
                  });
                }
              }
              el((e) => ({ ...e, externalConnectWallet: {} })),
                (eI.current = null),
                (eE.current = null),
                R(!1),
                o(!1),
                setTimeout(() => {
                  t.authFlow = void 0;
                }, 200);
            },
            openPrivyModal: eN,
            connectWallet: eL,
            initLoginWithWallet: async (e, t, n, r) => {
              (0, _.bB)(e)
                ? ((eE.current = "siwe"), eD(e, t, n))
                : ((eE.current = "siws"), ez(e, t, n, r));
            },
            loginWithWallet: async () => {
              let e, n, r;
              if (!b) throw new T.ac();
              if (
                (t.authFlow instanceof _.X
                  ? (e = "siwe")
                  : t.authFlow instanceof _.bC && (e = "siws"),
                !e)
              )
                throw new T.P("Must initialize SIWE/SIWS flow first.");
              if (null !== (await t.getAccessToken()))
                try {
                  ({ user: n } = await t.link()), (eE.current = e);
                } catch (t) {
                  throw (
                    ((0, _.br)(
                      eb,
                      "linkAccount",
                      "onError",
                      t.privyErrorCode || T.h.FAILED_TO_LINK_ACCOUNT,
                      { linkMethod: e }
                    ),
                    t)
                  );
                }
              else
                try {
                  ({ user: n, isNewUser: r } = await t.authenticate()),
                    (eE.current = e);
                } catch (e) {
                  throw (
                    ((0, _.br)(
                      eb,
                      "login",
                      "onError",
                      e.privyErrorCode || T.h.GENERIC_CONNECT_WALLET_ERROR
                    ),
                    e)
                  );
                }
              S(n || I || null), R(r || !1), E(!0);
            },
            delegateWallet: async ({
              address: e,
              chainType: t,
              showDelegationUIs: n,
            }) =>
              new Promise(async (r, a) => {
                let i = await rC();
                if (!x || !I || !i)
                  throw new T.P(
                    "User must be authenticated and have an embedded wallet to delegate actions."
                  );
                if ("solana" !== t && "ethereum" !== t)
                  throw new T.P(
                    "Only Solana and Ethereum embedded wallets are supported for delegation and revocation."
                  );
                let o =
                  eX.walletProxy ?? (await eX.initializeWalletProxy(15e3));
                if (!o) throw new T.P("Wallet proxy not initialized.");
                if (
                  (({ address: e, user: t }) =>
                    !!nn(t).find((t) => t.address === e))({
                    address: e,
                    user: I,
                  })
                )
                  return r();
                let s = (0, P.f)(I, e);
                if (!s)
                  throw new T.P(
                    "Address to delegate is not associated with current user."
                  );
                if ((0, P.g)(s))
                  throw new T.P(
                    "useDelegatedActions is only supported for on-device execution and this app uses TEE execution. Use the useSessionSigners hook to provision server side access on behalf of your users. Learn more at https://docs.privy.io/recipes/tee-wallet-migration-guide"
                  );
                let l = ne({ address: e, user: I }),
                  c = nt({ address: e, user: I }),
                  d = async () => {
                    await o.createDelegatedAction({
                      accessToken: i,
                      rootWallet: c,
                      delegatedWallets: [l],
                    }),
                      await eX.refreshSessionAndUser();
                  };
                if ((await eX.recoverEmbeddedWallet({ address: e }), n))
                  el({
                    delegatedActions: {
                      consent: {
                        address: e,
                        onDelegate: d,
                        onSuccess: async () => {
                          r();
                        },
                        onError: async (e) => {
                          a(e);
                        },
                      },
                    },
                  }),
                    eN(nW);
                else
                  try {
                    await d(), r();
                  } catch (e) {
                    a(e);
                  }
              }),
            revokeDelegatedWallets: async ({ showDelegationUIs: e }) =>
              new Promise(async (n, r) => {
                if (!x || !I)
                  throw new T.P(
                    "User must be authenticated and have an embedded wallet to revoke a delegated wallet."
                  );
                let a = nn(I);
                if (0 === a.length)
                  throw new T.P("User has no delegated wallets to revoke.");
                if (a.some(P.g))
                  throw new T.P(
                    "useDelegatedActions is only supported for on-device execution and this app uses TEE execution. Use the useSessionSigners hook to provision server side access on behalf of your users. Learn more at https://docs.privy.io/recipes/tee-wallet-migration-guide"
                  );
                let i = async () => {
                  await t.revokeDelegatedWallet(),
                    await eX.refreshSessionAndUser();
                };
                if (e)
                  el({
                    delegatedActions: {
                      revoke: {
                        onRevoke: i,
                        onSuccess: async () => {
                          n();
                        },
                        onError: async (e) => {
                          r(e);
                        },
                      },
                    },
                  }),
                    eN(nO);
                else
                  try {
                    await i(), n();
                  } catch (e) {
                    r(e);
                  }
              }),
            initLoginWithFarcaster: async (e, n) => {
              let r = new eC(e, n);
              t.startAuthFlow(r);
              try {
                (eE.current = "farcaster"),
                  await r.initializeFarcasterConnect();
              } catch (e) {
                throw (
                  ("login" === eI.current
                    ? (0, _.br)(
                        eb,
                        "login",
                        "onError",
                        e.privyErrorCode || T.h.UNKNOWN_AUTH_ERROR
                      )
                    : "link" === eI.current &&
                      (0, _.br)(
                        eb,
                        "linkAccount",
                        "onError",
                        e.privyErrorCode || T.h.UNKNOWN_AUTH_ERROR,
                        { linkMethod: "farcaster" }
                      ),
                  e)
                );
              }
            },
            loginWithFarcaster: async () => {
              let e, n;
              if (!b) throw new T.ac();
              if (!(t.authFlow instanceof eC))
                throw new T.P("Must initialize Farcaster flow first.");
              if (null !== (await t.getAccessToken()))
                try {
                  ({ user: e } = await t.link()), (eE.current = "farcaster");
                } catch (e) {
                  throw (
                    ((0, _.br)(
                      eb,
                      "linkAccount",
                      "onError",
                      e.privyErrorCode || T.h.FAILED_TO_LINK_ACCOUNT,
                      { linkMethod: "farcaster" }
                    ),
                    e)
                  );
                }
              else
                try {
                  ({ user: e, isNewUser: n } = await t.authenticate()),
                    (eE.current = "farcaster");
                } catch (e) {
                  throw (
                    ((0, _.br)(
                      eb,
                      "login",
                      "onError",
                      e.privyErrorCode || T.h.UNKNOWN_AUTH_ERROR
                    ),
                    e)
                  );
                }
              S(e || null), R(n || !1), E(!0);
            },
            async crossAppAuthFlow({ appId: e, popup: n, action: r }) {
              let a = `privy:${e}`;
              eE.current = a;
              let {
                url: i,
                stateCode: o,
                codeVerifier: s,
              } = await (async function ({ api: e, appId: t }) {
                let n = (0, _.c)(),
                  r = (0, _.a)(),
                  a = await (0, _.d)(n);
                try {
                  let { url: i } = await e.post(T.j, {
                    provider: `privy:${t}`,
                    redirect_to: window.location.href,
                    code_challenge: a,
                    state_code: r,
                  });
                  return { url: i, stateCode: r, codeVerifier: n };
                } catch (e) {
                  throw (0, T.f)(e);
                }
              })({ api: t.api, appId: e });
              if (!i)
                throw (
                  (t.createAnalyticsEvent({
                    eventName: "cross_app_auth_error",
                    payload: {
                      error: "Unable to open cross-app auth popup",
                      appId: e,
                    },
                  }),
                  new T.P("No authorization URL returned for cross-app auth."))
                );
              try {
                let l = await (async function ({ url: e, popup: t }) {
                    return (
                      (t.location = e),
                      new Promise((e, n) => {
                        let r,
                          a = setTimeout(() => {
                            n(
                              new T.P(
                                "Authorization request timed out after 2 minutes."
                              )
                            ),
                              i();
                          }, 12e4);
                        function i() {
                          t?.close(), window.removeEventListener("message", s);
                        }
                        let o = setInterval(() => {
                          t?.closed &&
                            !r &&
                            (i(),
                            clearInterval(o),
                            clearTimeout(a),
                            n(new T.P("User rejected request")));
                        }, 300);
                        function s(t) {
                          t.data &&
                            ("PRIVY_OAUTH_RESPONSE" === t.data.type &&
                              t.data.stateCode &&
                              t.data.authorizationCode &&
                              (clearTimeout(a), e(t.data), i()),
                            "PRIVY_OAUTH_ERROR" === t.data.type &&
                              (clearTimeout(a), n(new T.P(t.data.error)), i()),
                            t.data.type === ni &&
                              ((r = new BroadcastChannel(na)).onmessage = s));
                        }
                        window.addEventListener("message", s);
                      })
                    );
                  })({ url: i, popup: n, provider: a }),
                  c = l.stateCode,
                  d = l.authorizationCode;
                if (c !== o)
                  throw (
                    (t.createAnalyticsEvent({
                      eventName: "possible_phishing_attempt",
                      payload: {
                        provider: a,
                        storedStateCode: o ?? "",
                        returnedStateCode: c ?? "",
                      },
                    }),
                    new T.P(
                      "Unexpected auth flow. This may be a phishing attempt.",
                      void 0,
                      T.h.OAUTH_UNEXPECTED
                    ))
                  );
                let u = await (async function ({
                  appId: e,
                  stateCode: t,
                  codeVerifier: n,
                  authorizationCode: r,
                  action: a,
                  client: i,
                }) {
                  if (!r || !t)
                    throw new T.P(
                      "[Cross-App AuthFlow] Authorization and state codes code must be set prior to calling authenicate."
                    );
                  if ("undefined" === r)
                    throw new T.P(
                      "User denied confirmation during cross-app auth flow"
                    );
                  try {
                    let o = new no({
                      authorizationCode: r,
                      stateCode: t,
                      codeVerifier: n,
                      provider: `privy:${e}`,
                    });
                    i.startAuthFlow(o);
                    let s =
                        "link" === a ? await i.link() : await i.authenticate(),
                      l = s.oAuthTokens?.accessToken;
                    return console.debug(), l;
                  } catch (t) {
                    let e = (0, T.f)(t);
                    if (e.privyErrorCode === T.h.ACCOUNT_TRANSFER_REQUIRED)
                      throw e;
                    if (e.privyErrorCode)
                      throw new T.P(
                        e.message || "Invalid code during cross-app auth flow.",
                        void 0,
                        e.privyErrorCode
                      );
                    if (
                      "User denied confirmation during cross-app auth flow" ===
                      e.message
                    )
                      throw new T.P(
                        "Invalid code during cross-app auth flow.",
                        void 0,
                        T.h.OAUTH_USER_DENIED
                      );
                    throw new T.P(
                      "Invalid code during cross-app auth flow.",
                      void 0,
                      T.h.UNKNOWN_AUTH_ERROR
                    );
                  }
                })({
                  appId: e,
                  codeVerifier: s,
                  stateCode: c,
                  authorizationCode: d,
                  action: r,
                  client: t,
                });
                u && t.storeProviderAccessToken(e, u);
                let h = await eX.refreshSessionAndUser();
                if (!h) throw new T.P("Unable to update user");
                return (
                  t.createAnalyticsEvent({
                    eventName: "cross_app_auth_completed",
                    payload: { providerAppId: e },
                  }),
                  h
                );
              } catch (e) {
                throw (
                  (t.createAnalyticsEvent({
                    eventName: "cross_app_auth_error",
                    payload: { error: e.toString(), provider: a },
                  }),
                  e)
                );
              }
            },
            async initLoginWithOAuth(e, n, r) {
              if (
                ((eE.current = e),
                !(0, _.N)() ||
                  ("google" === e && (0, _.bD)(window.navigator.userAgent)))
              )
                return void eN(n$);
              "twitter" === e &&
                window.opener &&
                window.opener.postMessage({ type: ni }, "*"),
                _.s.del(_.H),
                _.s.del(_.O);
              let a = new eT({
                provider: e,
                disableSignup: !!r,
                withPrivyUi: !0,
                customOAuthRedirectUrl: ei.customOAuthRedirectUrl,
              });
              n && a.addCaptchaToken(n), t.startAuthFlow(a);
              let i = await t.authFlow.getAuthorizationUrl();
              if (i && i.url) {
                if (
                  ("twitter" === e &&
                    y.Dt &&
                    (i.url = i.url.replace("x.com", "twitter.com")),
                  "chrome-extension:" === window.location.protocol && eA())
                )
                  try {
                    let { privyOAuthCode: e, privyOAuthState: t } = await ex(
                      i.url
                    );
                    eN(rc),
                      (a.meta.stateCode = t),
                      (a.meta.authorizationCode = e);
                  } catch (e) {
                    throw (
                      (console.error(
                        "OAuth in chrome extension flow failed:",
                        e
                      ),
                      e)
                    );
                  }
                else window.location.assign(i.url);
              }
            },
            async initLoginWithTelegram(e, n) {
              if (!b) throw new T.ac();
              eE.current = "telegram";
              let r = new _.bu(e, n);
              t.startAuthFlow(r),
                en({ status: "loading" }),
                (r.meta.telegramWebAppData = void 0),
                (r.meta.telegramAuthResult = await new Promise((e, t) =>
                  ei.loginConfig.telegramAuthConfiguration
                    ? window.Telegram
                      ? void window.Telegram.Login.auth(
                          {
                            bot_id:
                              ei.loginConfig.telegramAuthConfiguration.botId,
                            request_access: !0,
                          },
                          (n) =>
                            n
                              ? e(n)
                              : ("link" === eI.current
                                  ? (0, _.br)(
                                      eb,
                                      "linkAccount",
                                      "onError",
                                      T.h.FAILED_TO_LINK_ACCOUNT,
                                      { linkMethod: "telegram" }
                                    )
                                  : "login" === eI.current
                                  ? (0, _.br)(
                                      eb,
                                      "login",
                                      "onError",
                                      T.h.INVALID_CREDENTIALS
                                    )
                                  : "update" === eI.current &&
                                    (0, _.br)(
                                      eb,
                                      "login",
                                      "onError",
                                      T.h.FAILED_TO_UPDATE_ACCOUNT
                                    ),
                                t(
                                  new T.P(
                                    "Telegram auth failed or was canceled by the client"
                                  )
                                ))
                        )
                      : t(new T.P("Telegram was not initialized"))
                    : t(new T.P("Telegram Auth configuration is not loaded"))
                ));
            },
            async loginWithTelegram(e) {
              let n, r;
              if (!(t.authFlow instanceof _.bu))
                throw new T.P(
                  "Must initialize Telegram flow before calling loginWithTelegram"
                );
              t.authFlow.meta.captchaToken ||= e?.captchaToken;
              let a = await rC(),
                i = e?.intent || eI.current;
              if ("login" === i)
                try {
                  let e = await t.authenticate();
                  (n = e.user), (r = e.isNewUser), (eE.current = "telegram");
                } catch (e) {
                  throw (
                    ((0, _.br)(
                      eb,
                      "login",
                      "onError",
                      e.privyErrorCode || T.h.UNKNOWN_AUTH_ERROR
                    ),
                    e)
                  );
                }
              else {
                if ("link" !== i) throw new T.P("Unknown auth intent");
                try {
                  (n = (await t.link()).user), (eE.current = "telegram");
                } catch (e) {
                  throw (
                    ((0, _.br)(
                      eb,
                      "linkAccount",
                      "onError",
                      e.privyErrorCode || T.h.FAILED_TO_LINK_ACCOUNT,
                      { linkMethod: "telegram" }
                    ),
                    e)
                  );
                }
              }
              S(n), R(r || !1), E(!0), en({ status: "done" });
              let o =
                n?.linkedAccounts.find(({ type: e }) => "telegram" === e) ||
                null;
              return {
                user: n,
                isNewUser: r || !1,
                wasAlreadyAuthenticated: !!a,
                loginAccount: o,
              };
            },
            async loginWithOAuth(e) {
              let n, r, a;
              if (!(t.authFlow instanceof eT))
                throw new T.P(
                  "Must initialize OAuth flow before calling loginWithOAuth"
                );
              let i = _.s.get(_.S),
                o = t.authFlow.meta.stateCode;
              if (i !== o)
                throw (
                  (t.createAnalyticsEvent({
                    eventName: "possible_phishing_attempt",
                    payload: {
                      provider: e,
                      storedStateCode: i ?? "",
                      returnedStateCode: o ?? "",
                    },
                  }),
                  new T.P(
                    "Unexpected auth flow. This may be a phishing attempt.",
                    void 0,
                    T.h.OAUTH_UNEXPECTED
                  ))
                );
              if (null !== (await t.getAccessToken()))
                try {
                  let r = await t.link();
                  (n = r.user), (a = r.oAuthTokens), (eE.current = e);
                } catch (t) {
                  throw (
                    ((0, _.br)(
                      eb,
                      "linkAccount",
                      "onError",
                      t.privyErrorCode || T.h.FAILED_TO_LINK_ACCOUNT,
                      { linkMethod: e }
                    ),
                    t)
                  );
                }
              else
                try {
                  let i = await t.authenticate();
                  (n = i.user),
                    (r = i.isNewUser),
                    (a = i.oAuthTokens),
                    (eE.current = e);
                } catch (t) {
                  throw (
                    ("login" === eI.current
                      ? (0, _.br)(
                          eb,
                          "login",
                          "onError",
                          t.privyErrorCode || T.h.UNKNOWN_AUTH_ERROR
                        )
                      : "link" === eI.current &&
                        (0, _.br)(
                          eb,
                          "linkAccount",
                          "onError",
                          t.privyErrorCode || T.h.FAILED_TO_LINK_ACCOUNT,
                          { linkMethod: e }
                        ),
                    t)
                  );
                }
              return (
                S(n),
                R(r || !1),
                E(!0),
                a &&
                  n &&
                  (0, _.br)(eb, "oAuthAuthorization", "onOAuthTokenGrant", {
                    oAuthTokens: a,
                    user: n,
                  }),
                a
              );
            },
            passkeyAuthState: V,
            setPasskeyAuthState: H,
            async initSignupWithPasskey({ captchaToken: e, withPrivyUi: n }) {
              let r = new eP({ captchaToken: e, setPasskeyAuthState: H });
              t.startAuthFlow(r), (eI.current = "login");
              try {
                (eE.current = "passkey"),
                  H({ status: "generating-challenge" }),
                  await r.initRegisterFlow(n),
                  H({ status: "awaiting-passkey" });
              } catch (e) {
                throw (
                  (H({ status: "error", error: e }),
                  (0, _.br)(
                    eb,
                    "login",
                    "onError",
                    e.privyErrorCode || T.h.UNKNOWN_AUTH_ERROR
                  ),
                  e)
                );
              }
            },
            async signupWithPasskey() {
              let e, n;
              if (!b) throw new T.ac();
              if (!(t.authFlow instanceof eP))
                throw new T.P("Must initialize Passkey flow first.");
              if ("passkey" !== eE.current) {
                let e = new T.P("Must init login with Passkey flow first.");
                throw (H({ status: "error", error: e }), e);
              }
              let r = await rC();
              try {
                (eE.current = "passkey"),
                  H({ status: "awaiting-passkey" }),
                  ({ user: e, isNewUser: n } = await t.authenticate());
              } catch (e) {
                throw (
                  (H({ status: "error", error: e }),
                  (0, _.br)(
                    eb,
                    "login",
                    "onError",
                    e.privyErrorCode || T.h.UNKNOWN_AUTH_ERROR
                  ),
                  e)
                );
              }
              S(e), R(n || !1), E(!0), H({ status: "done" });
              let a =
                e?.linkedAccounts.find(({ type: e }) => "passkey" === e) ||
                null;
              return {
                user: e,
                isNewUser: n || !1,
                wasAlreadyAuthenticated: !!r,
                loginAccount: a,
              };
            },
            async initLoginWithPasskey({ captchaToken: e, withPrivyUi: n }) {
              let r = new eP({ captchaToken: e, setPasskeyAuthState: H });
              t.startAuthFlow(r), (eI.current = "login");
              try {
                (eE.current = "passkey"),
                  H({ status: "generating-challenge" }),
                  await r.initAuthenticationFlow(n),
                  H({ status: "awaiting-passkey" });
              } catch (e) {
                throw (
                  (H({ status: "error", error: e }),
                  (0, _.br)(
                    eb,
                    "login",
                    "onError",
                    e.privyErrorCode || T.h.UNKNOWN_AUTH_ERROR
                  ),
                  e)
                );
              }
            },
            async loginWithPasskey(e) {
              let n, r;
              if (!b) throw new T.ac();
              if (!(t.authFlow instanceof eP))
                throw new T.P("Must initialize Passkey flow first.");
              if (
                (e?.credentialIds &&
                  (t.authFlow.meta.allowedCredentialsIds = e.credentialIds),
                "passkey" !== eE.current)
              ) {
                let e = new T.P("Must init login with Passkey flow first.");
                throw (H({ status: "error", error: e }), e);
              }
              let a = await rC();
              try {
                (eE.current = "passkey"),
                  H({ status: "awaiting-passkey" }),
                  ({ user: n, isNewUser: r } = await t.authenticate());
              } catch (e) {
                throw (
                  (H({ status: "error", error: e }),
                  (0, _.br)(
                    eb,
                    "login",
                    "onError",
                    e.privyErrorCode || T.h.UNKNOWN_AUTH_ERROR
                  ),
                  e)
                );
              }
              S(n), R(r || !1), E(!0), H({ status: "done" });
              let i =
                n?.linkedAccounts.find(({ type: e }) => "passkey" === e) ||
                null;
              return {
                user: n,
                isNewUser: r || !1,
                wasAlreadyAuthenticated: !!a,
                loginAccount: i,
              };
            },
            async initLinkWithPasskey(e) {
              let n = new eP({ captchaToken: e });
              t.startAuthFlow(n),
                (eI.current = "link"),
                (eE.current = "passkey"),
                H({ status: "generating-challenge" });
              try {
                await n.initLinkFlow(), H({ status: "awaiting-passkey" });
              } catch (e) {
                throw (
                  ((0, _.br)(
                    eb,
                    "linkAccount",
                    "onError",
                    e.privyErrorCode || T.h.UNKNOWN_AUTH_ERROR,
                    { linkMethod: "passkey" }
                  ),
                  H({ status: "error", error: e }),
                  e)
                );
              }
            },
            async linkWithPasskey() {
              let e;
              if (!b) throw new T.ac();
              if (!(t.authFlow instanceof eP))
                throw new T.P("Must initialize Passkey flow first.");
              if ("passkey" !== eE.current)
                throw new T.P("Must init login with Passkey flow first.");
              try {
                (eE.current = "passkey"), ({ user: e } = await t.link());
              } catch (e) {
                throw (
                  ((0, _.br)(
                    eb,
                    "linkAccount",
                    "onError",
                    e.privyErrorCode || T.h.FAILED_TO_LINK_ACCOUNT,
                    { linkMethod: "passkey" }
                  ),
                  e)
                );
              }
              return S(e || I || null), H({ status: "done" }), e;
            },
            async initLoginWithHeadlessOAuth(e, n, r) {
              if (
                !(0, _.N)() ||
                ("google" === e && (0, _.bD)(window.navigator.userAgent))
              )
                throw Error(
                  "It looks like you're using an in-app browser.  To log in, please try again using an external browser."
                );
              let a = new eT({
                provider: e,
                withPrivyUi: !1,
                disableSignup: r ?? !1,
                customOAuthRedirectUrl: ei.customOAuthRedirectUrl,
              });
              n && a.addCaptchaToken(n), ee({ status: "loading" });
              let i = await t.startAuthFlow(a).getAuthorizationUrl();
              if (i?.url) {
                if ("chrome-extension:" === window.location.protocol && eA())
                  try {
                    let { privyOAuthCode: e, privyOAuthState: t } = await ex(
                      i.url
                    );
                    (a.meta.stateCode = t),
                      (a.meta.authorizationCode = e),
                      await this.loginWithHeadlessOAuth(a.meta);
                  } catch (e) {
                    throw (ee({ status: "error", error: e }), e);
                  }
                else window.location.assign(i.url);
              }
            },
            async loginWithHeadlessOAuth(e) {
              let n, r, a;
              z(!0),
                ee({ status: "loading" }),
                t.startAuthFlow(
                  new eT({
                    ...e,
                    customOAuthRedirectUrl: ei.customOAuthRedirectUrl,
                  })
                );
              let i = _.s.get(_.S),
                o = e.stateCode;
              if (i !== o)
                throw (
                  (t.createAnalyticsEvent({
                    eventName: "possible_phishing_attempt",
                    payload: {
                      provider: e.provider,
                      storedStateCode: i ?? "",
                      returnedStateCode: o ?? "",
                    },
                  }),
                  z(!1),
                  new T.P(
                    "Unexpected auth flow. This may be a phishing attempt.",
                    void 0,
                    T.h.OAUTH_UNEXPECTED
                  ))
                );
              if (null !== (await t.getAccessToken()))
                try {
                  ({ user: n, oAuthTokens: a } = await t.link()),
                    (eE.current = e.provider);
                  let r = eK(n);
                  n &&
                    r &&
                    (0, _.br)(eb, "linkAccount", "onSuccess", {
                      user: n,
                      linkMethod: eE.current,
                      linkedAccount: r,
                    });
                } catch (t) {
                  throw (
                    (z(!1),
                    (0, _.br)(
                      eb,
                      "linkAccount",
                      "onError",
                      t.privyErrorCode || T.h.FAILED_TO_LINK_ACCOUNT,
                      { linkMethod: e.provider }
                    ),
                    t)
                  );
                }
              else
                try {
                  ({
                    user: n,
                    isNewUser: r,
                    oAuthTokens: a,
                  } = await t.authenticate()),
                    (eE.current = e.provider);
                  let i = eK(n);
                  n &&
                    i &&
                    void 0 !== r &&
                    (0, _.br)(eb, "login", "onComplete", {
                      user: n,
                      isNewUser: r,
                      wasAlreadyAuthenticated: !1,
                      loginMethod: eE.current,
                      loginAccount: i,
                    });
                } catch (e) {
                  throw (
                    (z(!1),
                    ee({ status: "error", error: e }),
                    (0, _.br)(
                      eb,
                      "login",
                      "onError",
                      e.privyErrorCode || T.h.UNKNOWN_AUTH_ERROR
                    ),
                    e)
                  );
                }
              return (
                S(n),
                R(r || !1),
                E(!0),
                z(!1),
                ee({ status: "done" }),
                a &&
                  n &&
                  (0, _.br)(eb, "oAuthAuthorization", "onOAuthTokenGrant", {
                    oAuthTokens: a,
                    user: n,
                  }),
                n ?? void 0
              );
            },
            initLoginWithEmail: async ({
              email: e,
              captchaToken: n,
              disableSignup: r,
              withPrivyUi: a,
            }) => {
              let i = new ef({ email: e, captchaToken: n, disableSignup: r });
              t.startAuthFlow(i);
              try {
                (eE.current = "email"),
                  Z({ status: "sending-code" }),
                  await i.sendCodeEmail({ withPrivyUi: a }),
                  Z({ status: "awaiting-code-input" });
              } catch (e) {
                throw (
                  (Z({ status: "error", error: e }),
                  "login" === eI.current
                    ? (0, _.br)(
                        eb,
                        "login",
                        "onError",
                        e.privyErrorCode || T.h.UNKNOWN_AUTH_ERROR
                      )
                    : "link" === eI.current &&
                      (0, _.br)(
                        eb,
                        "linkAccount",
                        "onError",
                        e.privyErrorCode || T.h.FAILED_TO_LINK_ACCOUNT,
                        { linkMethod: "email" }
                      ),
                  e)
                );
              }
            },
            initUpdateEmail: async ({
              oldAddress: e,
              newAddress: n,
              captchaToken: r,
            }) => {
              let a = new ev(e, n, r);
              t.startAuthFlow(a);
              try {
                await a.sendCodeEmail({ withPrivyUi: !0 });
              } catch (e) {
                (0, _.br)(
                  eb,
                  "update",
                  "onError",
                  e.privyErrorCode || T.h.UNKNOWN_AUTH_ERROR,
                  { linkMethod: eE.current }
                );
              }
            },
            initUpdatePhone: async (e, n, r) => {
              let a = new eU(e, n, r);
              t.startAuthFlow(a);
              try {
                await a.sendSmsCode({ withPrivyUi: !0 });
              } catch (e) {
                (0, _.br)(
                  eb,
                  "update",
                  "onError",
                  e.privyErrorCode || T.h.UNKNOWN_AUTH_ERROR,
                  { linkMethod: eE.current }
                );
              }
            },
            initLoginWithSms: async ({
              phoneNumber: e,
              captchaToken: n,
              disableSignup: r,
              withPrivyUi: a,
            }) => {
              Y({ status: "sending-code" });
              let i = new ej({
                phoneNumber: e,
                captchaToken: n,
                disableSignup: r,
              });
              t.startAuthFlow(i);
              try {
                (eE.current = "sms"),
                  await i.sendSmsCode({ withPrivyUi: a }),
                  Y({ status: "awaiting-code-input" });
              } catch (e) {
                throw (
                  (Y({ status: "error", error: e }),
                  "login" === eI.current
                    ? (0, _.br)(
                        eb,
                        "login",
                        "onError",
                        e.privyErrorCode || T.h.UNKNOWN_AUTH_ERROR
                      )
                    : "link" === eI.current &&
                      (0, _.br)(
                        eb,
                        "linkAccount",
                        "onError",
                        e.privyErrorCode || T.h.FAILED_TO_LINK_ACCOUNT,
                        { linkMethod: "sms" }
                      ),
                  e)
                );
              }
            },
            resendEmailCode: async () => {
              await t.authFlow?.sendCodeEmail({ withPrivyUi: !0 });
            },
            resendSmsCode: async () => {
              await t.authFlow?.sendSmsCode({ withPrivyUi: !0 });
            },
            loginWithCode: async (e) => {
              let n, r;
              function a(e) {
                t.authFlow instanceof ef
                  ? Z(e)
                  : t.authFlow instanceof ej && Y(e);
              }
              if ((a({ status: "submitting-code" }), !b)) {
                let e = new T.ac();
                throw (a({ status: "error", error: e }), e);
              }
              if (t.authFlow instanceof ef)
                t.authFlow.meta.emailCode = e.trim();
              else {
                if (!(t.authFlow instanceof ej)) {
                  let e = new T.P(
                    "Must initialize a passwordless code flow first"
                  );
                  throw (a({ status: "error", error: e }), e);
                }
                t.authFlow.meta.smsCode = e.trim();
              }
              let i = await rC();
              if ("link" === eI.current)
                try {
                  ({ user: n } = await t.link());
                } catch (e) {
                  throw (
                    (a({ status: "error", error: e }),
                    (0, _.br)(
                      eb,
                      "linkAccount",
                      "onError",
                      e.privyErrorCode || T.h.FAILED_TO_LINK_ACCOUNT,
                      { linkMethod: eE.current }
                    ),
                    e)
                  );
                }
              else if ("update" === eI.current)
                try {
                  ({ user: n } = await t.link());
                } catch (e) {
                  throw (
                    (a({ status: "error", error: e }),
                    (0, _.br)(
                      eb,
                      "update",
                      "onError",
                      e.privyErrorCode || T.h.FAILED_TO_UPDATE_ACCOUNT,
                      { linkMethod: eE.current }
                    ),
                    e)
                  );
                }
              else
                try {
                  ({ user: n, isNewUser: r } = await t.authenticate());
                } catch (e) {
                  throw (
                    (a({ status: "error", error: e }),
                    (0, _.br)(
                      eb,
                      "login",
                      "onError",
                      e.privyErrorCode || T.h.UNKNOWN_AUTH_ERROR
                    ),
                    e)
                  );
                }
              let o = n || I;
              S(o || null), R(r || !1), E(!0), a({ status: "done" });
              let s = null;
              return (
                t.authFlow instanceof ef
                  ? (s =
                      o?.linkedAccounts.find(({ type: e }) => "email" === e) ||
                      null)
                  : t.authFlow instanceof ej &&
                    (s =
                      o?.linkedAccounts.find(({ type: e }) => "phone" === e) ||
                      null),
                {
                  user: o,
                  isNewUser: r || !1,
                  wasAlreadyAuthenticated: !!i,
                  linkedAccount: s,
                }
              );
            },
            generateSiweMessage: async ({
              address: e,
              chainId: n,
              captchaToken: r,
            }) => {
              (eI.current = x ? "link" : "login"),
                (eE.current = "siwe"),
                Q({ status: "generating-message" });
              let a = await t.generateSiweNonce({
                address: e,
                captchaToken: r,
              });
              return (
                Q({ status: "awaiting-signature" }),
                (0, _.bE)({
                  address: e,
                  chainId: n.replace("eip155:", ""),
                  nonce: a,
                })
              );
            },
            generateSiweMessageForSmartWallet: async ({
              address: e,
              chainId: n,
            }) => {
              let r = await t.generateSiweNonce({ address: e });
              return (0, _.bE)({
                address: e,
                chainId: n.replace("eip155:", ""),
                nonce: r,
              });
            },
            linkSmartWallet: async ({
              message: e,
              signature: n,
              smartWalletType: r,
              smartWalletVersion: a,
            }) => {
              let i;
              (i = await t.linkSmartWallet({
                message: e,
                signature: n,
                smartWalletType: r,
                smartWalletVersion: a,
              })),
                S((i = (await eX.refreshSessionAndUser()) ?? i) || I || null);
            },
            loginWithSiwe: async ({
              message: e,
              signature: n,
              captchaToken: r,
              disableSignup: a,
            }) => {
              let i,
                o = null;
              try {
                if (I) throw Error("User already authenticated");
                let s = new _.X(t, void 0, r, a, { message: e, signature: n });
                t.startAuthFlow(s),
                  (eE.current = "siwe"),
                  (eI.current = "login"),
                  Q({ status: "submitting-signature" });
                let l = await t.authenticate();
                if ((({ user: o, isNewUser: i } = l), !o))
                  throw Error("Authentication failed - no user returned");
              } catch (e) {
                throw (
                  ((0, _.br)(
                    eb,
                    "login",
                    "onError",
                    e.privyErrorCode || T.h.UNKNOWN_AUTH_ERROR
                  ),
                  Q({ status: "error", error: e }),
                  e)
                );
              }
              return (
                S(o),
                R(i || !1),
                E(!0),
                Q({ status: "done" }),
                (eI.current = null),
                (eE.current = null),
                { user: o, isNewUser: i || !1 }
              );
            },
            linkWithSiwe: async ({
              message: e,
              signature: n,
              chainId: r,
              walletClientType: a,
              connectorType: i,
            }) => {
              let o;
              eB("siwe");
              let s = null;
              try {
                Q({ status: "submitting-signature" }),
                  (o = await t.linkWithSiwe({
                    message: e,
                    signature: n,
                    chainId: r,
                    walletClientType: a,
                    connectorType: i,
                  })),
                  (o = (await eX.refreshSessionAndUser()) ?? o),
                  Q({ status: "done" }),
                  (s = eK(o) || null) &&
                    (0, _.br)(eb, "linkAccount", "onSuccess", {
                      user: o,
                      linkMethod: "siwe",
                      linkedAccount: s,
                    });
              } catch (e) {
                throw (
                  ((0, _.br)(
                    eb,
                    "linkAccount",
                    "onError",
                    e.privyErrorCode || T.h.FAILED_TO_LINK_ACCOUNT,
                    { linkMethod: "siwe" }
                  ),
                  (eI.current = null),
                  (eE.current = null),
                  Q({ status: "error", error: e }),
                  e)
                );
              }
              let l = o || I;
              return (
                S(l || null),
                (eI.current = null),
                (eE.current = null),
                { user: l, linkedAccount: s }
              );
            },
            refreshSessionAndUser: async () => {
              let e = await t.getAuthenticatedUser();
              return E(!!e), S(e), e;
            },
            walletProxy: er,
            createAnalyticsEvent: ({
              eventName: e,
              payload: n,
              timestamp: r,
            }) =>
              t.createAnalyticsEvent({
                eventName: e,
                payload: n,
                timestamp: r,
              }),
            acceptTerms: async () => {
              let e = await t.acceptTerms();
              return S(e), e;
            },
            getUsdTokenPrice: (e) => t.getUsdTokenPrice(e),
            getUsdPriceForSol: () => t.getUsdPriceForSol(),
            getSplTokenMetadata: (e) => t.getSplTokenMetadata(e),
            recoverEmbeddedWallet: async (e) =>
              new Promise(async (n, r) => {
                if (!I) return void n(!0);
                let a = e?.address
                  ? (0, P.f)(I, e.address)
                  : (0, P.a)(I) || (0, P.e)(I).at(0) || (0, P.j)(I).at(0);
                if (!a || (0, P.g)(a)) return void n(!0);
                let i = await rC();
                if (!i || !er || !a)
                  return void r(
                    Error(
                      "Must have valid access token and Privy wallet to recover wallet"
                    )
                  );
                let { entropyId: o, entropyIdVerifier: s } = (0, _.F)(I, a);
                try {
                  await er.connect({
                    accessToken: i,
                    entropyId: o,
                    entropyIdVerifier: s,
                  }),
                    n(!0);
                } catch (e) {
                  if ((0, _.aO)(e) && "privy" === a.recoveryMethod) {
                    let e;
                    t.createAnalyticsEvent({
                      eventName: "embedded_wallet_pinless_recovery_started",
                      payload: { walletAddress: a.address },
                    });
                    try {
                      e = await er.recover({
                        entropyId: o,
                        entropyIdVerifier: s,
                        accessToken: i,
                      });
                    } catch (e) {
                      return void r(e);
                    }
                    e.entropyId || r(Error("Unable to recover wallet")),
                      t.createAnalyticsEvent({
                        eventName: "embedded_wallet_recovery_completed",
                        payload: { walletAddress: a.address },
                      }),
                      n(!0);
                  } else
                    (0, _.aO)(e) &&
                    "privy" !== a.recoveryMethod &&
                    "privy-v2" !== a.recoveryMethod
                      ? (el({
                          recoverWallet: {
                            entropyId: o,
                            entropyIdVerifier: s,
                            onFailure: r,
                            onSuccess: () => n(!0),
                          },
                          recoveryOAuthStatus: {
                            provider: a.recoveryMethod,
                            action: "recover",
                            shouldCreateEth: !1,
                            shouldCreateSol: !1,
                          },
                        }),
                        eN((0, _.bF)(a.recoveryMethod)))
                      : r(e);
                }
              }),
            setReadyToTrue: (e) => {
              A(!0), ec?.(e);
            },
            updateWallets: () => eH(),
            fundWallet: async (e, t) => {
              el({
                funding: (0, G.p)({
                  address: e,
                  appConfig: ei,
                  fundWalletConfig: t,
                  methodScreen: _.aH,
                }),
              }),
                eN(_.aH);
            },
            openModal: eN,
            requestFarcasterSignerStatus: async (e) => {
              let n = await rC(),
                r = I?.linkedAccounts.find(
                  (e) => "wallet" === e.type && "privy" === e.walletClientType
                );
              if (!n)
                throw Error(
                  "Must have valid access token to connect with Farcaster"
                );
              if (!er || !r)
                throw Error(
                  "Must have an embedded wallet to use Farcaster signers"
                );
              if (!I?.farcaster?.fid)
                throw Error(
                  "Must have Farcaster account to use Farcaster signers"
                );
              let a = await t.requestFarcasterSignerStatus(e);
              return (
                "approved" === a.status &&
                  S((await t.getAuthenticatedUser()) || I || null),
                a
              );
            },
            connectCoinbaseSmartWallet: async () => {
              ei.externalWallets.coinbaseWallet.config.preference = {
                ...ei.externalWallets.coinbaseWallet.config.preference,
                options: "smartWalletOnly",
              };
              let e =
                t.connectors?.findWalletConnector(
                  "coinbase_wallet",
                  "coinbase_smart_wallet"
                ) ||
                t.connectors?.findWalletConnector(
                  "coinbase_wallet",
                  "coinbase_wallet"
                );
              if (e)
                return e.updateConnectionPreference("smartWalletOnly"), eL(e);
              await eF("coinbase_wallet", "coinbase_smart_wallet");
            },
            connectBaseAccount: async () => {
              let e = t.connectors?.findWalletConnector(
                "base_account",
                "base_account"
              );
              if (e) return eL(e);
              await eF("base_account", "base_account");
            },
            initiateAccountTransfer: async ({
              nonce: e,
              account: n,
              accountType: r,
              externalWalletMetadata: a,
              telegramAuthResult: i,
              telegramWebAppData: o,
              farcasterEmbeddedAddress: s,
              oAuthUserInfo: l,
            }) => {
              let c = await t.sendAccountTransferRequest({
                nonce: e,
                account: n,
                accountType: r,
                externalWalletMetadata: a,
                telegramAuthResult: i,
                telegramWebAppData: o,
                farcasterEmbeddedAddress: s,
                oAuthUserInfo: l,
              });
              return S(c), c;
            },
            inProgressAuthFlowRef: eI,
            inProgressLoginOrLinkMethodRef: eE,
          };
          (u = eX.recoverEmbeddedWallet), eX.recoverEmbeddedWallet;
          let e0 = (0, w.useMemo)(
              () => ({ wallets: j, ready: eh && ek }),
              [j, eh, ek]
            ),
            e1 = t.authFlow instanceof _.bu,
            e2 = !ei.headless && ei.captchaEnabled && !x && (b || e1);
          return (0, p.jsx)(rv.Provider, {
            value: !0,
            children: (0, p.jsx)(P.P.Provider, {
              value: eQ,
              children: (0, p.jsx)(_.bG.Provider, {
                value: eb,
                children: (0, p.jsx)(_.bH.Provider, {
                  value: e0,
                  children: (0, p.jsx)(_.bI, {
                    ...ei,
                    children: (0, p.jsxs)(L.I.Provider, {
                      value: eX,
                      children: [
                        (0, p.jsx)(_.bJ, {
                          children: (0, p.jsxs)(_.bK, {
                            data: es,
                            setModalData: el,
                            setInitialScreen: F,
                            initialScreen: M,
                            authenticated: x,
                            open: i,
                            children: [
                              e.children,
                              (0, p.jsx)(rf, { customAuth: ei.customAuth }),
                              e2 && (0, p.jsx)(tn, { delayedExecution: !1 }),
                              (0, p.jsx)(t1, {}),
                              (0, p.jsx)(nI, {
                                disabled:
                                  ei.embeddedWallets.disableAutomaticMigration,
                              }),
                              (0, p.jsx)(tD, {
                                palette: ei.appearance.palette || {},
                              }),
                              !ei.render.standalone &&
                                (0, p.jsx)(tJ, { open: i }),
                            ],
                          }),
                        }),
                        (0, p.jsx)(t8, {
                          appId: e.appId,
                          appClientId: e.clientId,
                          clientAnalyticsId: t.clientAnalyticsId,
                          origin: t.apiUrl,
                          mfaMethods: I?.mfaMethods,
                          mfaPromise: ey,
                          mfaSubmitPromise: eg,
                          onLoad: ea,
                          onLoadFailed: () => null,
                        }),
                        ei.loginConfig.telegramAuthConfiguration &&
                          (0, p.jsx)(_.aw, {
                            $if: !0,
                            children: (0, p.jsx)(t0, {
                              scriptHost: e.apiUrl || _.a6,
                              botUsername:
                                ei.loginConfig.telegramAuthConfiguration
                                  .botName,
                            }),
                          }),
                      ],
                    }),
                  }),
                }),
              }),
            }),
          });
        };
    },
  },
]);
